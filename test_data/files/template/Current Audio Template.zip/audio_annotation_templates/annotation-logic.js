/**
 * Audio Annotation Template Logic
 * Reuses Video Template Architecture with Audio Waveform Media Track
 */
console.log("Audio Annotation Logic loaded successfully!");

const CUSTOM_RESIZE_CURSOR = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none'%3E%3Cline x1='10.5' y1='5.5' x2='10.5' y2='18.5' stroke='%23000000' stroke-width='1'/%3E%3Cline x1='13.5' y1='5.5' x2='13.5' y2='18.5' stroke='%23000000' stroke-width='1'/%3E%3Cline x1='3' y1='12' x2='8.5' y2='12' stroke='%23000000' stroke-width='1'/%3E%3Cpolyline points='6,9.5 3,12 6,14.5' stroke='%23000000' stroke-width='1' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cline x1='15.5' y1='12' x2='21' y2='12' stroke='%23000000' stroke-width='1'/%3E%3Cpolyline points='18,9.5 21,12 18,14.5' stroke='%23000000' stroke-width='1' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") 12 12, col-resize`;

const CONFIG = {
    FPS: 30,
    INITIAL_PPS: 24,
    CLASSES: [
        {
            id: 'speaker_1',
            name: 'Speaker 1',
            color: 'rgb(254, 217, 255)',
            handleColor: 'rgb(253, 161, 255)',
            handleOpacity: '0.6',
            textColor: 'rgb(253, 161, 255)',
            type: 'object',
            classShortcut: '1',
            subInputs: [
                { id: 'transcript', name: 'Transcript', label: 'Transcript', type: 'text', shortcut: 'Q', required: true }
            ]
        },
        {
            id: 'speaker_2',
            name: 'Speaker 2',
            color: 'rgb(237, 173, 161)',
            handleColor: 'rgb(211, 49, 21)',
            handleOpacity: '0.6',
            textColor: 'rgb(211, 49, 21)',
            type: 'object',
            classShortcut: '2',
            subInputs: [
                { id: 'transcript', name: 'Transcript', label: 'Transcript', type: 'text', shortcut: 'Q', required: true }
            ]
        },
        {
            id: 'audio_quality',
            name: 'Audio quality',
            color: 'rgb(195, 165, 250)',
            selectedColor: 'rgb(150, 97, 246)',
            handleColor: 'rgb(105, 29, 242)',
            handleOpacity: '0.6',
            textColor: 'rgb(105, 29, 242)',
            selectedTextColor: '#ffffff',
            type: 'radio',
            classShortcut: '3',
            required: true,
            options: ['Excellent', 'Good', 'Fair', 'Poor'],
            optionShortcuts: ['Q', 'W', 'E', 'R']
        }
    ],
    MIN_PPS: 8,
    MAX_PPS: 120,
    ZOOM_STEP: 0.1,
    PLAYBACK_SPEEDS: [0.125, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 4, 8, 16],
    DEFAULT_TIMESTAMP_FORMAT: 'MM:SS',
    TIMESTAMP_FORMATS: ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'],
    FRAME_SKIP_VALUES: [1, 3, 4, 5, 6, 7, 12, 18],
    DEFAULT_FRAME_SKIP: 6
};

function isSameClass(name1, name2) {
    if (!name1 || !name2) return false;
    if (name1 === name2) return true;
    const n1 = String(name1).toLowerCase().replace(/[^a-z0-9]/g, '');
    const n2 = String(name2).toLowerCase().replace(/[^a-z0-9]/g, '');
    return n1 === n2;
}

function mergeRangeSegments(rawSegments) {
    if (!rawSegments) return '0 - 0';
    if (!Array.isArray(rawSegments)) {
        rawSegments = String(rawSegments).split(' | ');
    }
    const parsed = [];
    rawSegments.forEach(segStr => {
        if (!segStr) return;
        const parts = String(segStr).split(' - ').map(Number);
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
            parsed.push({ s: Math.min(parts[0], parts[1]), e: Math.max(parts[0], parts[1]) });
        }
    });
    if (parsed.length === 0) return '0 - 0';
    parsed.sort((a, b) => a.s - b.s);

    const merged = [];
    for (const seg of parsed) {
        if (merged.length === 0) {
            merged.push({ s: seg.s, e: seg.e });
        } else {
            const prev = merged[merged.length - 1];
            if (seg.s <= prev.e) {
                prev.e = Math.max(prev.e, seg.e);
            } else {
                merged.push({ s: seg.s, e: seg.e });
            }
        }
    }
    return merged.map(m => `${m.s} - ${m.e}`).join(' | ');
}

const PLAY_ICON_SVG = `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" height="15" width="15" xmlns="http://www.w3.org/2000/svg"><polygon points="6 3 20 12 6 21 6 3"></polygon></svg>`;
const PAUSE_ICON_SVG = `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" height="15" width="15" xmlns="http://www.w3.org/2000/svg"><rect x="14" y="4" width="4" height="16" rx="1"></rect><rect x="6" y="4" width="4" height="16" rx="1"></rect></svg>`;
const VOLUME_UP_SVG = `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"></path><path d="M16 9a5 5 0 0 1 0 6"></path><path d="M19.364 18.364a9 9 0 0 0 0-12.728"></path></svg>`;
const VOLUME_OFF_SVG = `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"></path><line x1="22" y1="9" x2="16" y2="15"></line><line x1="16" y1="9" x2="22" y2="15"></line></svg>`;
const PARTITION_ICON_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M640.6 429.8h257.1c7.9 0 14.3-6.4 14.3-14.3V158.3c0-7.9-6.4-14.3-14.3-14.3H640.6c-7.9 0-14.3 6.4-14.3 14.3v92.9H490.6c-3.9 0-7.1 3.2-7.1 7.1v221.5h-85.7v-96.5c0-7.9-6.4-14.3-14.3-14.3H126.3c-7.9 0-14.3 6.4-14.3 14.3v257.2c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3V544h85.7v221.5c0 3.9 3.2 7.1 7.1 7.1h135.7v92.9c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3v-257c0-7.9-6.4-14.3-14.3-14.3h-257c-7.9 0-14.3 6.4-14.3 14.3v100h-78.6v-393h78.6v100c0 7.9 6.4 14.3 14.3 14.3zm53.5-217.9h150V362h-150V211.9zM329.9 587h-150V437h150v150zm364.2 75.1h150v150.1h-150V662.1z"></path></svg>`;

// Speaker icon SVG — matches reference inspect code (react-icons speaker with outer wave paths)
function getSpeakerIconSVG(color) {
    return `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg" style="color: ${color};"><path d="M16 21c3.527-1.547 5.999-4.909 5.999-9S19.527 4.547 16 3v2c2.387 1.386 3.999 4.047 3.999 7S18.387 17.614 16 19v2z"></path><path d="M16 7v10c1.225-1.1 2-3.229 2-5s-.775-3.9-2-5zM4 17h2.697l5.748 3.832a1.004 1.004 0 0 0 1.027.05A1 1 0 0 0 14 20V4a1 1 0 0 0-1.554-.832L6.697 7H4c-1.103 0-2 .897-2 2v6c0 1.103.897 2 2 2zm0-8h3c.033 0 .061-.016.093-.019a1.027 1.027 0 0 0 .38-.116c.026-.015.057-.017.082-.033L12 5.868v12.264l-4.445-2.964c-.025-.017-.056-.02-.082-.033a.986.986 0 0 0-.382-.116C7.059 15.016 7.032 15 7 15H4V9z"></path></svg>`;
}

function formatTimeBadge(seconds) {
    const s = Math.max(0, Number(seconds) || 0);
    if (window.app && window.app.timestampFormat === 'SS') {
        return s.toFixed(2);
    }
    const mins = Math.floor(s / 60);
    const remSecs = s % 60;
    if (mins > 0) {
        const wholeSecs = Math.floor(remSecs);
        const millis = Math.floor((remSecs - wholeSecs) * 100);
        return `${mins}:${wholeSecs.toString().padStart(2, '0')}.${millis.toString().padStart(2, '0')}`;
    }
    return remSecs.toFixed(2);
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

class VideoController {
    constructor(mediaElement) {
        this.video = mediaElement;
        this.frameSkip = 6;
        this.playbackRate = 1.0;
        this.rangePlaybackMode = 'PLAY_ONCE'; // 'PLAY_ONCE', 'LOOP_ON_PLAY', 'LOOP_CONTINUOUSLY'
        if (this.video) {
            this.video.playbackRate = this.playbackRate;
            this.video.addEventListener('play', () => {
                if (window.app) window.app.updatePlayButtonState(true);
            });
            this.video.addEventListener('pause', () => {
                if (window.app) window.app.updatePlayButtonState(false);
            });
            this.video.addEventListener('ended', () => {
                if (window.app) window.app.handlePlaybackEnded();
            });
            this.video.addEventListener('seeked', () => {
                if (window.app) {
                    window.app.isSeekingForRangePlayback = false;
                }
            });
        }
    }

    play() {
        if (this.video) this.video.play();
    }

    pause() {
        if (this.video) this.video.pause();
    }

    togglePlayPause() {
        if (!this.video) return;
        this.video.paused ? this.play() : this.pause();
    }

    get currentTime() { return this.video ? (this.video.currentTime || 0) : 0; }
    set currentTime(value) {
        if (!this.video) return;
        this.video.currentTime = Math.max(0, Math.min(value, this.duration || 180));
    }

    get duration() { return this.video ? (this.video.duration || 180) : 180; }
    get playbackRate() { return this.video ? this.video.playbackRate : 1.0; }
    set playbackRate(value) {
        if (this.video) this.video.playbackRate = value;
    }
    get muted() { return this.video ? this.video.muted : false; }
    set muted(value) {
        if (this.video) this.video.muted = value;
    }

    getCurrentFrame() { return Math.round(this.currentTime * CONFIG.FPS); }
    getTotalFrames() { return Math.floor(this.duration * CONFIG.FPS); }

    seekToFrame(frame) {
        this.currentTime = frame / CONFIG.FPS;
    }

    advanceFrame() {
        const skip = Math.max(1, this.frameSkip || 1);
        const step = skip * 0.001;
        this.currentTime = Math.min(this.duration, Math.round((this.currentTime + step) * 1000) / 1000);
        if (window.app) window.app.onVideoTimeUpdate(true);
    }

    rewindFrame() {
        const skip = Math.max(1, this.frameSkip || 1);
        const step = skip * 0.001;
        this.currentTime = Math.max(0, Math.round((this.currentTime - step) * 1000) / 1000);
        if (window.app) window.app.onVideoTimeUpdate(true);
    }

    addTimeUpdateListener(callback) {
        if (this.video) this.video.addEventListener('timeupdate', callback);
    }

    addMetadataLoadedListener(callback) {
        if (this.video) {
            this.video.addEventListener('loadedmetadata', callback);
            if (this.video.readyState >= 1) {
                setTimeout(callback, 0);
            }
        }
    }
}

/**
 * AudioWaveformRenderer: Renders audio amplitude waveform / spectrogram on a tiled canvas in Row 0
 * Supports arbitrarily long audio (from 3 mins to 10+ hours) without exceeding browser canvas limits.
 */
class AudioWaveformRenderer {
    constructor(canvasElement) {
        this.canvas = canvasElement;
        this.ctx = canvasElement ? canvasElement.getContext('2d') : null;
        this.audioBuffer = null;
        this.peaks = null;
        this.spectrogramImage = null;
        this.currentHeight = 128;
        this.tileCanvases = [];
        this.loadedUrl = null;
    }

    async loadAudio(url) {
        if (!url || url.includes('{{')) return;
        this.loadedUrl = url;
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const arrayBuffer = await response.arrayBuffer();
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            this.audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
            this.extractPeaks();
            this.generateSpectrogram();
            const dur = (window.app && window.app.timelineView && window.app.timelineView.videoDuration) ? window.app.timelineView.videoDuration : (this.audioBuffer.duration || 180);
            const pps = (window.app && window.app.timelineView) ? window.app.timelineView.currentPPS : CONFIG.INITIAL_PPS;
            this.render(dur, pps);
        } catch (e) {
            console.warn("Direct audio decode fallback (CORS or network error):", e);
            const dur = (window.app && window.app.videoController && window.app.videoController.duration) ? window.app.videoController.duration : 180;
            this.generateSyntheticPeaks(dur);
            this.generateSpectrogram();
            const pps = (window.app && window.app.timelineView) ? window.app.timelineView.currentPPS : CONFIG.INITIAL_PPS;
            this.render(dur, pps);
        }
    }

    extractPeaks() {
        if (!this.audioBuffer) return;
        const channelData = this.audioBuffer.getChannelData(0);
        const duration = this.audioBuffer.duration || 180;
        const samples = Math.max(3000, Math.min(30000, Math.round(duration * 20)));
        const blockSize = Math.max(1, Math.floor(channelData.length / samples));
        this.peaks = [];
        for (let i = 0; i < samples; i++) {
            let sum = 0;
            let peak = 0;
            const start = i * blockSize;
            for (let j = 0; j < blockSize; j++) {
                const val = Math.abs(channelData[start + j] || 0);
                if (val > peak) peak = val;
                sum += val;
            }
            const rms = Math.sqrt(sum / blockSize);
            const amp = Math.min(1.0, (peak * 0.65 + rms * 1.1));
            this.peaks.push(amp);
        }
    }

    generateSyntheticPeaks(duration = 180) {
        this.peaks = [];
        const samples = Math.max(3000, Math.min(30000, Math.round(duration * 20)));
        for (let i = 0; i < samples; i++) {
            // Realistic speech waveform envelope with natural cadence and pauses
            const speechBurst = Math.sin(i * 0.03) * Math.sin(i * 0.008);
            const modulation = Math.max(0, Math.sin(i * 0.015));
            const detail = 0.15 * Math.sin(i * 0.2);
            let val = Math.abs(speechBurst * modulation) * 0.85 + detail;
            if (modulation < 0.15) val *= 0.2; // quiet gap between speech segments
            this.peaks.push(Math.min(1, Math.max(0.04, val)));
        }
    }

    generateSpectrogram() {
        const offCanvas = document.createElement('canvas');
        const w = 4800; // Ultra high-resolution width
        const h = 248;  // Height matching 248px
        offCanvas.width = w;
        offCanvas.height = h;
        const oCtx = offCanvas.getContext('2d');
        if (!oCtx) return;

        // 1. Deep black background
        oCtx.fillStyle = '#000002';
        oCtx.fillRect(0, 0, w, h);

        const imgData = oCtx.createImageData(w, h);
        const data = imgData.data;

        const setPixel = (px, py, r, g, b, a) => {
            if (px < 0 || px >= w || py < 0 || py >= h) return;
            const idx = (py * w + px) * 4;
            data[idx] = r;
            data[idx + 1] = g;
            data[idx + 2] = b;
            data[idx + 3] = a;
        };

        // Exact 3-Color Palette from Reference Template: Black -> Violet -> Rose/Pink (Zero orange / yellow)
        const mapSpectrogramColor = (normVal) => {
            const v = Math.max(0, Math.min(1, normVal));
            let r = 0, g = 0, b = 0;
            if (v < 0.08) {
                const t = v / 0.08;
                r = Math.round(t * 10);
                g = Math.round(t * 2);
                b = Math.round(t * 25);
            } else if (v < 0.40) {
                const t = (v - 0.08) / 0.32;
                r = Math.round(10 + t * 95);   // 10 -> 105
                g = Math.round(2 + t * 20);    // 2 -> 22
                b = Math.round(25 + t * 145);  // 25 -> 170
            } else if (v < 0.75) {
                const t = (v - 0.40) / 0.35;
                r = Math.round(105 + t * 115); // 105 -> 220
                g = Math.round(22 + t * 50);   // 22 -> 72
                b = Math.round(170 + t * 35);  // 170 -> 205
            } else {
                const t = (v - 0.75) / 0.25;
                r = Math.round(220 + t * 35);  // 220 -> 255
                g = Math.round(72 + t * 110);  // 72 -> 182
                b = Math.round(205 + t * 45);  // 205 -> 250
            }
            return [r, g, b];
        };

        if (this.audioBuffer) {
            const channelData = this.audioBuffer.getChannelData(0);
            const totalSamples = channelData.length;
            const fftSize = 1024;
            const halfFft = fftSize / 2;
            
            const windowFunc = new Float32Array(fftSize);
            for (let i = 0; i < fftSize; i++) {
                windowFunc[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (fftSize - 1)));
            }

            const step = Math.max(1, Math.floor(totalSamples / w));
            const real = new Float32Array(fftSize);
            const imag = new Float32Array(fftSize);

            for (let x = 0; x < w; x++) {
                const startIdx = Math.min(totalSamples - fftSize, x * step);
                
                for (let i = 0; i < fftSize; i++) {
                    real[i] = (channelData[startIdx + i] || 0) * windowFunc[i];
                    imag[i] = 0;
                }

                let j = 0;
                for (let i = 0; i < fftSize - 1; i++) {
                    if (i < j) {
                        const tr = real[i]; real[i] = real[j]; real[j] = tr;
                        const ti = imag[i]; imag[i] = imag[j]; imag[j] = ti;
                    }
                    let k = fftSize >> 1;
                    while (k <= j) {
                        j -= k;
                        k >>= 1;
                    }
                    j += k;
                }

                for (let len = 2; len <= fftSize; len <<= 1) {
                    const halfLen = len >> 1;
                    const angle = -2 * Math.PI / len;
                    const wstepR = Math.cos(angle);
                    const wstepI = Math.sin(angle);
                    for (let i = 0; i < fftSize; i += len) {
                        let curR = 1.0;
                        let curI = 0.0;
                        for (let k = 0; k < halfLen; k++) {
                            const uR = real[i + k];
                            const uI = imag[i + k];
                            const vR = real[i + k + halfLen] * curR - imag[i + k + halfLen] * curI;
                            const vI = real[i + k + halfLen] * curI + imag[i + k + halfLen] * curR;
                            real[i + k] = uR + vR;
                            imag[i + k] = uI + vI;
                            real[i + k + halfLen] = uR - vR;
                            imag[i + k + halfLen] = uI - vI;
                            const nextCurR = curR * wstepR - curI * wstepI;
                            curI = curR * wstepI + curI * wstepR;
                            curR = nextCurR;
                        }
                    }
                }

                for (let y = 0; y < h; y++) {
                    const normY = 1 - (y / h); // 0 at bottom, 1 at top
                    const binIdx = Math.min(halfFft - 1, Math.max(0, Math.floor(Math.pow(normY, 1.35) * (halfFft * 0.45))));
                    const mag = Math.sqrt(real[binIdx] * real[binIdx] + imag[binIdx] * imag[binIdx]);
                    const db = 20 * Math.log10(mag + 1e-6);
                    const normVal = Math.max(0, Math.min(1, (db + 58) / 58));
                    
                    const [r, g, b] = mapSpectrogramColor(normVal);
                    setPixel(x, y, r, g, b, 255);
                }
            }
        } else {
            // High-detail speech synthesis matching Reference Image 1
            if (!this.peaks) this.generateSyntheticPeaks(180);
            const peaks = this.peaks || [];
            for (let x = 0; x < w; x++) {
                const progress = x / w;
                const peakIdx = Math.min(peaks.length - 1, Math.floor(progress * peaks.length));
                const baseAmp = peaks.length > 0 ? (peaks[peakIdx] || 0.02) : 0.05;

                const pitchPeriod = 7;
                const glottalPulse = 0.8 + 0.3 * Math.cos((x % pitchPeriod) * ((2 * Math.PI) / pitchPeriod));

                for (let y = 0; y < h; y++) {
                    const freqNorm = 1 - (y / h);
                    let n = (Math.random() * 0.035);

                    if (baseAmp > 0.07) {
                        const f1Center = 0.14 + 0.04 * Math.sin(x * 0.015);
                        const f1 = Math.exp(-Math.pow(freqNorm - f1Center, 2) * 180) * baseAmp * 1.35;

                        const f2Center = 0.38 + 0.07 * Math.cos(x * 0.012);
                        const f2 = Math.exp(-Math.pow(freqNorm - f2Center, 2) * 120) * baseAmp * 1.25;

                        const f3Center = 0.66 + 0.05 * Math.sin(x * 0.02);
                        const f3 = Math.exp(-Math.pow(freqNorm - f3Center, 2) * 140) * baseAmp * 1.05;

                        const f4Center = 0.86 + 0.03 * Math.cos(x * 0.025);
                        const f4 = Math.exp(-Math.pow(freqNorm - f4Center, 2) * 160) * baseAmp * 0.75;

                        const harmonicTracks = Math.pow(Math.max(0, Math.sin(freqNorm * 42 + Math.sin(x * 0.01) * 3)), 4) * 0.45 * baseAmp;
                        const fricative = (freqNorm > 0.5) ? (Math.random() * baseAmp * 0.35 * Math.sin(x * 0.04)) : 0;

                        const totalEnergy = n + (f1 + f2 + f3 + f4 + harmonicTracks + Math.max(0, fricative)) * glottalPulse * (0.8 + 0.4 * Math.sin(x * 0.005));
                        const val = Math.min(1, Math.max(0, totalEnergy));
                        const [r, g, b] = mapSpectrogramColor(val);
                        setPixel(x, y, r, g, b, 255);
                    } else {
                        const bgVal = n * 0.6;
                        setPixel(x, y, Math.round(bgVal * 10), Math.round(bgVal * 2), Math.round(bgVal * 25), 255);
                    }
                }
            }
        }

        oCtx.putImageData(imgData, 0, 0);
        this.spectrogramImage = offCanvas;
    }

    render(duration, pps, height = null, previewRange = null) {
        if (!this.canvas) return;
        if (height) this.currentHeight = height;
        const dur = Math.max(1, Number(duration) || 180);
        const currentPps = Math.max(1, Number(pps) || CONFIG.INITIAL_PPS);
        const width = Math.max(100, Math.round(dur * currentPps));
        const h = Math.max(20, Math.round(this.currentHeight || 128));
        const dpr = window.devicePixelRatio || 1;

        const container = this.canvas.parentElement;
        if (!container) return;

        // Tiled canvas system: caps individual canvas widths at 3000px so browsers never crash
        const TILE_WIDTH = 3000;
        const numTiles = Math.ceil(width / TILE_WIDTH);

        if (!this.tileCanvases) this.tileCanvases = [];

        // Hide original canvas element in favor of tiled canvases
        this.canvas.style.display = 'none';

        // Synchronize tile canvases with DOM
        while (this.tileCanvases.length < numTiles) {
            const tile = document.createElement('canvas');
            tile.className = 'block absolute top-0 pointer-events-none waveform-tile';
            container.insertBefore(tile, this.canvas);
            this.tileCanvases.push(tile);
        }
        while (this.tileCanvases.length > numTiles) {
            const tile = this.tileCanvases.pop();
            if (tile && tile.parentElement) tile.parentElement.removeChild(tile);
        }

        const isSpectrogram = window.app && window.app.currentViz === 'Spectrogram';
        if (isSpectrogram && !this.spectrogramImage) {
            this.generateSpectrogram();
        }
        if (!isSpectrogram && !this.peaks) {
            this.generateSyntheticPeaks(dur);
        }

        const centerY = h / 2;
        const halfHeight = (h / 2) * 0.78;
        const peaks = this.peaks || [];
        const count = peaks.length;

        // Get annotation instructions for region projections
        let instructions = [];
        if (window.app && window.app.annotationModel) {
            instructions = window.app.annotationModel.getInstructions();
        }
        const selectedIdx = (window.app && window.app.editingAnnotationIndex !== undefined) ? window.app.editingAnnotationIndex : -1;
        const selectionMode = (window.app && window.app.selectionMode) ? window.app.selectionMode : 'none';
        const activeClassObj = (window.app && window.app.activeClassId) ? CONFIG.CLASSES.find(c => c.id === window.app.activeClassId) : null;

        // Draw each canvas tile
        for (let t = 0; t < numTiles; t++) {
            const tile = this.tileCanvases[t];
            const tileStartX = t * TILE_WIDTH;
            const tileW = Math.min(TILE_WIDTH, width - tileStartX);

            tile.style.left = `${26.8098 + tileStartX}px`;
            tile.style.width = `${tileW}px`;
            tile.style.height = `${h}px`;
            tile.style.display = 'block';

            if (tile.width !== tileW * dpr || tile.height !== h * dpr) {
                tile.width = tileW * dpr;
                tile.height = h * dpr;
            }

            const ctx = tile.getContext('2d');
            if (!ctx) continue;

            ctx.save();
            ctx.scale(dpr, dpr);
            ctx.clearRect(0, 0, tileW, h);

            // Shift coordinate system so all rendering uses global timeline X [0, width]
            ctx.translate(-tileStartX, 0);

            if (isSpectrogram) {
                if (this.spectrogramImage) {
                    ctx.imageSmoothingEnabled = true;
                    ctx.imageSmoothingQuality = 'high';
                    ctx.drawImage(this.spectrogramImage, 0, 0, width, h);
                }

                // Frequency axis labels on tile 0
                if (t === 0) {
                    ctx.save();
                    ctx.fillStyle = 'rgba(245, 245, 252, 0.95)';
                    ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
                    ctx.shadowBlur = 3;
                    ctx.shadowOffsetX = 1;
                    ctx.shadowOffsetY = 1;

                    if (h >= 100) {
                        ctx.font = '500 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                        ctx.fillText('2.7 kHz', 8, Math.round(h * 0.14));
                        ctx.fillText('1.6 kHz', 8, Math.round(h * 0.36));
                        ctx.fillText('837 Hz', 8, Math.round(h * 0.58));
                        ctx.fillText('337 Hz', 8, Math.round(h * 0.79));
                        ctx.fillText('0 Hz', 8, Math.round(h * 0.95));
                    } else if (h >= 45) {
                        ctx.font = '500 10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                        ctx.fillText('2.7 kHz', 8, 12);
                        ctx.fillText('837 Hz', 8, Math.round(h * 0.52));
                        ctx.fillText('0 Hz', 8, h - 4);
                    } else {
                        ctx.font = '500 9px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                        ctx.fillText('2.7 kHz', 8, 10);
                        ctx.fillText('0 Hz', 8, h - 3);
                    }
                    ctx.restore();
                }
            } else {
                // Waveform Baseline
                ctx.strokeStyle = '#e0e0e0';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(tileStartX, centerY);
                ctx.lineTo(tileStartX + tileW, centerY);
                ctx.stroke();

                // Waveform Peaks Fill
                ctx.fillStyle = 'rgba(175, 178, 182, 0.72)';
                ctx.beginPath();
                ctx.moveTo(tileStartX, centerY);

                const startX = tileStartX;
                const endX = tileStartX + tileW;

                for (let x = startX; x <= endX; x += 1) {
                    const peakIdx = Math.floor((x / width) * count);
                    const amp = peaks[peakIdx] !== undefined ? peaks[peakIdx] : 0.05;
                    const y = centerY - (amp * halfHeight);
                    ctx.lineTo(x, y);
                }

                for (let x = endX; x >= startX; x -= 1) {
                    const peakIdx = Math.floor((x / width) * count);
                    const amp = peaks[peakIdx] !== undefined ? peaks[peakIdx] : 0.05;
                    const y = centerY + (amp * halfHeight);
                    ctx.lineTo(x, y);
                }

                ctx.closePath();
                ctx.fill();
            }

            // Region Projections on Tile
            const projectRange = (sFrame, eFrame, className, isSelected = false) => {
                if (eFrame <= sFrame) return;
                const rStartX = (sFrame / CONFIG.FPS) * currentPps;
                const projWidth = Math.max(1, ((eFrame - sFrame) / CONFIG.FPS) * currentPps);

                if (rStartX + projWidth < tileStartX || rStartX > tileStartX + tileW) return;

                let projColor = isSelected ? 'rgba(150, 97, 246, 0.75)' : 'rgba(150, 97, 246, 0.45)';
                let handleCol = isSelected ? 'rgb(105, 29, 242)' : 'rgba(105, 29, 242, 0.7)';
                if (isSameClass(className, 'Speaker 1')) {
                    projColor = isSelected ? 'rgba(253, 161, 255, 0.75)' : 'rgba(253, 161, 255, 0.45)';
                    handleCol = isSelected ? 'rgb(230, 90, 235)' : 'rgb(253, 161, 255)';
                } else if (isSameClass(className, 'Speaker 2')) {
                    projColor = isSelected ? 'rgba(237, 173, 161, 0.85)' : 'rgba(237, 173, 161, 0.55)';
                    handleCol = isSelected ? 'rgb(211, 49, 21)' : 'rgb(237, 173, 161)';
                } else if (isSameClass(className, 'Audio quality')) {
                    projColor = isSelected ? 'rgba(195, 165, 250, 0.75)' : 'rgba(195, 165, 250, 0.45)';
                    handleCol = isSelected ? 'rgb(105, 29, 242)' : 'rgb(150, 97, 246)';
                }

                ctx.fillStyle = projColor;
                ctx.fillRect(rStartX, 0, projWidth, h);

                const handleWidth = Math.min(4, Math.max(2, projWidth / 2));
                ctx.fillStyle = handleCol;
                ctx.fillRect(rStartX, 0, handleWidth, h);
                ctx.fillRect(rStartX + projWidth - handleWidth, 0, handleWidth, h);

                if (isSelected) {
                    ctx.strokeStyle = '#f59e0b';
                    ctx.lineWidth = 1.5;
                    ctx.strokeRect(rStartX + 0.5, 0.5, Math.max(1, projWidth - 1), h - 1);
                    ctx.lineWidth = 1;
                }
            };

            instructions.forEach((ins, idx) => {
                if (ins && ins.frames) {
                    const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, ins.className)) || { id: 'speaker_1', name: ins.className };
                    if (window.app && window.app.isRowHidden && window.app.isRowHidden(cls.id, idx)) return;

                    const rawRanges = (ins.frames || '').split(' | ').filter(Boolean);
                    rawRanges.forEach((rStr, rIdx) => {
                        const parts = rStr.split(' - ').map(Number);
                        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                            let isSelected = false;
                            if (selectionMode === 'individual' && idx === selectedIdx) {
                                if (window.app && (window.app.editingSegmentIndex === null || window.app.editingSegmentIndex === undefined || window.app.editingSegmentIndex === rIdx)) {
                                    isSelected = true;
                                }
                            } else if (selectionMode === 'row' && activeClassObj && isSameClass(ins.className, activeClassObj.name)) {
                                isSelected = true;
                            }
                            projectRange(parts[0], parts[1], ins.className, isSelected);
                        }
                    });
                }
            });

            if (previewRange && previewRange.sFrame !== undefined && previewRange.eFrame !== undefined) {
                projectRange(previewRange.sFrame, previewRange.eFrame, previewRange.className, true);
            }

            ctx.restore();
        }

        // DOM Handle Overlay for top waveform track (Interactive handles and selection bars)
        const overlayContainer = document.getElementById('waveformRangesOverlay');
        if (overlayContainer) {
            overlayContainer.innerHTML = '';
            overlayContainer.style.width = `${width}px`;
            overlayContainer.style.height = `${h}px`;

            instructions.forEach((ins, idx) => {
                if (!ins || !ins.frames) return;
                const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, ins.className)) || { id: 'speaker_1', name: ins.className };
                if (window.app && window.app.isRowHidden && window.app.isRowHidden(cls.id, idx)) return;
                const isRowLocked = window.app && window.app.isRowLocked ? window.app.isRowLocked(cls.id, idx) : false;

                const rawRanges = (ins.frames || '').split(' | ').filter(Boolean);
                rawRanges.forEach((rStr, rIdx) => {
                    const parts = rStr.split(' - ').map(Number);
                    if (parts.length !== 2 || parts[1] <= parts[0]) return;

                    const startX = (parts[0] / CONFIG.FPS) * currentPps;
                    const projWidth = Math.max(8, ((parts[1] - parts[0]) / CONFIG.FPS) * currentPps);

                    const bar = document.createElement('div');
                    bar.setAttribute('data-testid', 'waveform-range');
                    bar.className = 'absolute top-0 bottom-0 pointer-events-auto select-none';
                    bar.style.left = `${startX}px`;
                    bar.style.width = `${projWidth}px`;
                    bar.style.height = `${h}px`;
                    bar.style.cursor = isRowLocked ? 'default' : 'pointer';

                    if (!isRowLocked) {
                        const leftWrap = document.createElement('div');
                        leftWrap.className = 'pointer-events-auto absolute top-0 bottom-0 z-20 w-3 range-left-handle range-handle-wrap custom-range-handle';
                        leftWrap.style.left = '0px';
                        leftWrap.style.cursor = CUSTOM_RESIZE_CURSOR;

                        const leftHandle = document.createElement('div');
                        leftHandle.className = 'absolute bottom-0 top-0 w-1 range-left-handle custom-range-handle';
                        leftHandle.setAttribute('data-testid', 'left-handle');
                        leftHandle.style.left = '0px';
                        leftHandle.style.cursor = CUSTOM_RESIZE_CURSOR;
                        leftWrap.appendChild(leftHandle);

                        leftWrap.onmousedown = (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            if (window.app && window.app.selectIndividualRange) {
                                window.app.selectIndividualRange(idx, rIdx);
                            }
                            if (window.app && window.app.startRangeEdgeDrag) {
                                window.app.startRangeEdgeDrag(e, idx, rIdx, 'left', cls, null);
                            }
                        };
                        bar.appendChild(leftWrap);

                        const rightWrap = document.createElement('div');
                        rightWrap.className = 'pointer-events-auto absolute top-0 bottom-0 z-20 w-3 range-right-handle range-handle-wrap custom-range-handle';
                        rightWrap.style.right = '0px';
                        rightWrap.style.cursor = CUSTOM_RESIZE_CURSOR;

                        const rightHandle = document.createElement('div');
                        rightHandle.className = 'absolute bottom-0 top-0 w-1 range-right-handle custom-range-handle';
                        rightHandle.setAttribute('data-testid', 'right-handle');
                        rightHandle.style.right = '0px';
                        rightHandle.style.cursor = CUSTOM_RESIZE_CURSOR;
                        rightWrap.appendChild(rightHandle);

                        rightWrap.onmousedown = (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            if (window.app && window.app.selectIndividualRange) {
                                window.app.selectIndividualRange(idx, rIdx);
                            }
                            if (window.app && window.app.startRangeEdgeDrag) {
                                window.app.startRangeEdgeDrag(e, idx, rIdx, 'right', cls, null);
                            }
                        };
                        bar.appendChild(rightWrap);
                    }

                    bar.onmousedown = (e) => {
                        if (e.target.closest && e.target.closest('.range-handle-wrap')) return;
                        e.stopPropagation();
                        if (isRowLocked) return;
                        if (window.app && window.app.selectIndividualRange) {
                            window.app.selectIndividualRange(idx, rIdx);
                        }
                    };

                    overlayContainer.appendChild(bar);
                });
            });
        }
    }
}

class AnnotationModel {
    constructor() {
        this.instructions = [];
    }
    getInstructions() { return [...this.instructions]; }
    setInstructions(list) { this.instructions = Array.isArray(list) ? [...list] : []; }
    deleteInstruction(idx) {
        if (idx >= 0 && idx < this.instructions.length) {
            this.instructions.splice(idx, 1);
        }
    }
}

class DragState {
    constructor() {
        this.isDragging = false;
        this.dragType = null;
    }

    startDrag(type) {
        this.isDragging = true;
        this.dragType = type;
        document.body.style.userSelect = 'none';
    }

    endDrag() {
        this.isDragging = false;
        this.dragType = null;
        document.body.style.userSelect = '';
    }

    isActive() { return this.isDragging; }
    getType() { return this.dragType; }
}

class ProgressBarView {
    constructor(fillElement, knobElement, trackElement, hoverPillElement) {
        this.fill = fillElement;
        this.knob = knobElement;
        this.track = trackElement;
        this.hoverPill = hoverPillElement;
    }

    update(percent) {
        if (this.fill) this.fill.style.width = (percent * 100) + '%';
        if (this.knob) this.knob.style.left = (percent * 100) + '%';
    }

    showHoverPill(percent, seconds) {
        if (!this.hoverPill) return;
        this.hoverPill.innerText = (window.app && window.app.formatTimeDisplay)
            ? window.app.formatTimeDisplay(seconds)
            : (typeof seconds === 'number' ? seconds.toFixed(3) : seconds);
        this.hoverPill.style.left = (percent * 100) + '%';
        this.hoverPill.classList.remove('hidden');
    }

    hideHoverPill() {
        if (this.hoverPill) this.hoverPill.classList.add('hidden');
    }
}

class TimelineView {
    constructor(rulerElement, tracksContainer, playheadElement, elements) {
        this.rulerContainer = rulerElement;
        this.ruler = document.getElementById('timeRulerMarks') || rulerElement;
        this.tracks = tracksContainer;
        this.playhead = playheadElement;
        this.elements = elements;
        this.currentPPS = CONFIG.INITIAL_PPS;
        this.leftOffset = 26.8098;
        this.rightOffset = 26.8098;
        this.videoDuration = 180;
        this.selectedTrackIndex = -1;
        this.selectedRangeKey = null;
        this.playingRange = null;
        this.playingRangeIndex = null;
        this.playingRangeSegIdx = null;
        this.playingRangeKey = null;
        this.collapsedRows = {};

        if (this.playhead) {
            this.playhead.style.left = this.leftOffset + 'px';
        }
    }

    computeFitPPS(duration) {
        if (!duration || duration <= 0) return CONFIG.INITIAL_PPS;
        const contentColumn = document.getElementById('timelineContentColumn');
        let colWidth = contentColumn ? contentColumn.clientWidth : 0;
        const leftGutter = this.leftOffset || 26.8098;
        const rightGutter = this.rightOffset || 26.8098;

        const availableWidth = Math.max(100, colWidth - leftGutter - rightGutter);
        return Math.max(CONFIG.INITIAL_PPS, availableWidth / duration);
    }

    updateRightGutter(contentWidth = null) {
        const rightGutterEl = document.getElementById('timelineRightGutterCover');
        if (!rightGutterEl) return;
        const rightGutter = this.rightOffset || 26.8098;
        rightGutterEl.style.width = rightGutter + 'px';
        rightGutterEl.style.right = '0px';
        rightGutterEl.style.left = '';
    }

    initialize(duration, pps = null) {
        if (!pps) pps = this.computeFitPPS(duration);
        this.currentPPS = pps;
        this.videoDuration = duration || 180;

        const leftGutter = this.leftOffset || 26.8098;
        const rightGutter = this.rightOffset || 26.8098;
        const contentWidth = this.videoDuration * this.currentPPS;
        const totalContentWidth = leftGutter + contentWidth + rightGutter;

        const rulerMarks = document.getElementById('timeRulerMarks') || this.ruler;
        if (rulerMarks) rulerMarks.style.width = totalContentWidth + 'px';
        if (this.tracks) this.tracks.style.width = totalContentWidth + 'px';

        const timelineHeader = document.getElementById('timelineHeader');
        if (timelineHeader) timelineHeader.style.width = totalContentWidth + 'px';

        const videoContainer = document.getElementById('videoTrackContainer');
        if (videoContainer) videoContainer.style.width = totalContentWidth + 'px';

        this.updateRightGutter(contentWidth);

        this.renderRuler(this.videoDuration, totalContentWidth);
        this.applyTrackGridLines();
        this.setupTracksHoverGuide();
        this.setupLabelsHoverGuide();
        this.updatePlayhead(0, totalContentWidth);

        if (window.app && window.app.waveformRenderer) {
            window.app.waveformRenderer.render(this.videoDuration, this.currentPPS);
        }
    }

    getGridSteps() {
        const pxPerFrame = this.currentPPS / CONFIG.FPS;
        // Steps in frames for 30 FPS audio/video timeline:
        // Each step has major frames & minor frames, guaranteed integer division
        const steps = [
            { major: 6, minor: 3 },       // 0.2s major, 0.1s minor (2 subs)
            { major: 12, minor: 6 },     // 0.4s major, 0.2s minor (2 subs)
            { major: 24, minor: 12 },    // 0.8s major, 0.4s minor (2 subs)
            { major: 30, minor: 15 },    // 1.0s major, 0.5s minor (2 subs)
            { major: 60, minor: 30 },    // 2.0s major, 1.0s minor (2 subs)
            { major: 120, minor: 60 },   // 4.0s major, 2.0s minor (2 subs)
            { major: 240, minor: 120 },  // 8.0s major, 4.0s minor (2 subs)
            { major: 300, minor: 150 },  // 10s major,  5s minor   (2 subs)
            { major: 600, minor: 300 },  // 20s major, 10s minor   (2 subs)
            { major: 1500, minor: 300 }, // 50s major, 10s minor   (5 subs)
            { major: 3000, minor: 600 }  // 100s major, 20s minor  (5 subs)
        ];

        let selected = steps[steps.length - 1];
        for (let s of steps) {
            if (s.major * pxPerFrame >= 80) {
                selected = s;
                break;
            }
        }
        return { majorStep: selected.major, minorStep: selected.minor };
    }

    applyTrackGridLines() {
        const gridTargets = [this.tracks, document.getElementById('videoTrackContainer')].filter(Boolean);
        if (gridTargets.length === 0) return;

        const { majorStep, minorStep } = this.getGridSteps();
        const pxPerFrame = this.currentPPS / CONFIG.FPS;
        const majorSpacing = majorStep * pxPerFrame;
        const leftGutter = 26.8098;

        const subdivisions = Math.round(majorStep / minorStep);
        const subWidth = majorSpacing / subdivisions;

        // Build a single linear-gradient with NO overlapping repeating layers
        // This completely eliminates subpixel double lines / multilines when zooming
        const gradientStops = [];
        gradientStops.push('#e5e7eb 0px', '#e5e7eb 1px', 'transparent 1px');

        for (let k = 1; k < subdivisions; k++) {
            const pos = Math.round(k * subWidth * 100) / 100;
            gradientStops.push(
                `transparent ${pos}px`,
                `rgba(229,231,235,0.5) ${pos}px`,
                `rgba(229,231,235,0.5) ${pos + 1}px`,
                `transparent ${pos + 1}px`
            );
        }
        gradientStops.push(`transparent ${Math.round(majorSpacing * 100) / 100}px`);

        const gridBackground = `linear-gradient(to right, ${gradientStops.join(', ')})`;

        gridTargets.forEach(target => {
            target.style.setProperty('background-image', gridBackground, 'important');
            target.style.setProperty('background-size', `${majorSpacing}px 100%`, 'important');
            target.style.setProperty('background-position', `${leftGutter}px 0`, 'important');
            target.style.setProperty('background-repeat', 'repeat', 'important');
        });
    }

    setupTracksHoverGuide() {
        if (!this.tracks || this._tracksHoverBound) return;
        this._tracksHoverBound = true;

        this.ensureTracksHoverGuide();

        this.tracks.addEventListener('mousemove', (e) => {
            if (window.app && (window.app._directRangeDrag || (window.app.dragState && window.app.dragState.isActive()))) {
                if (this.tracksGuideLine) this.tracksGuideLine.style.display = 'none';
                if (this.waveformGuideLine) this.waveformGuideLine.style.display = 'none';
                if (this.tracksAddBtn) this.tracksAddBtn.style.display = 'none';
                return;
            }

            const guideLine = this.ensureTracksHoverGuide();
            if (!guideLine) return;

            const rect = this.tracks.getBoundingClientRect();
            const leftGutter = this.leftOffset || 26.8098;
            const offsetX = e.clientX - rect.left;
            const maxDurationWidth = leftGutter + ((this.videoDuration || 180) * this.currentPPS);

            if (offsetX < leftGutter || (maxDurationWidth > 0 && offsetX > maxDurationWidth)) {
                guideLine.style.display = 'none';
                if (this.waveformGuideLine) this.waveformGuideLine.style.display = 'none';
                if (this.tracksAddBtn) this.tracksAddBtn.style.display = 'none';
                this.setHoveredRow(null);
                return;
            }

            guideLine.style.left = offsetX + 'px';
            guideLine.style.height = Math.max(this.tracks.scrollHeight, this.tracks.clientHeight) + 'px';
            guideLine.style.display = 'block';

            if (this.waveformGuideLine) {
                this.waveformGuideLine.style.left = offsetX + 'px';
                this.waveformGuideLine.style.height = '100%';
                this.waveformGuideLine.style.display = 'block';
            }

            // Find hovered data-row
            const elements = document.elementsFromPoint(e.clientX, e.clientY);
            const dataRow = elements.find(el => el.classList && el.classList.contains('data-row') && el.parentNode === this.tracks);

            // Check if pointer is hovering over an existing range bar
            const isOverRange = elements.some(el => {
                if (!el || !el.getAttribute) return false;
                return el.getAttribute('data-testid') === 'range' || (el.closest && el.closest('[data-testid="range"]'));
            });

            if (isOverRange) {
                guideLine.style.display = 'none';
                if (this.waveformGuideLine) this.waveformGuideLine.style.display = 'none';
                if (this.tracksAddBtn) this.tracksAddBtn.style.display = 'none';
                if (dataRow) {
                    this.setHoveredRow(dataRow);
                }
                return;
            }

            if (dataRow) {
                this.setHoveredRow(dataRow);

                const rowTop = dataRow.offsetTop;
                const rowHeight = dataRow.offsetHeight;
                const centerY = rowTop + (rowHeight / 2);

                const classId = dataRow.getAttribute('data-class-id');
                const instrIdxStr = dataRow.getAttribute('data-instr-idx');
                const rowInstrIdx = (instrIdxStr !== null && instrIdxStr !== undefined && instrIdxStr !== '') ? parseInt(instrIdxStr, 10) : null;
                const cls = CONFIG.CLASSES.find(c => c.id === classId);
                const isRowLocked = (window.app && window.app.isRowLocked) ? window.app.isRowLocked(classId, rowInstrIdx) : false;

                this._hoveredCls = cls;
                this._hoveredDataRow = dataRow;

                if (this.tracksAddBtn) {
                    if (isRowLocked) {
                        this.tracksAddBtn.style.display = 'none';
                    } else {
                        this.tracksAddBtn.style.left = offsetX + 'px';
                        this.tracksAddBtn.style.top = centerY + 'px';
                        this.tracksAddBtn.style.display = 'flex';
                    }
                }
            } else {
                this.setHoveredRow(null);
                this._hoveredCls = null;
                this._hoveredDataRow = null;
                if (this.tracksAddBtn) {
                    this.tracksAddBtn.style.display = 'none';
                }
            }
        });

        this.tracks.addEventListener('mouseleave', () => {
            if (this.tracksGuideLine) this.tracksGuideLine.style.display = 'none';
            if (this.waveformGuideLine) this.waveformGuideLine.style.display = 'none';
            if (this.tracksAddBtn) this.tracksAddBtn.style.display = 'none';
            this.setHoveredRow(null);
            this._hoveredCls = null;
            this._hoveredDataRow = null;
        });

        this.tracks.addEventListener('click', (e) => {
            if (window.app && window.app.handleTimelineClick) {
                window.app.handleTimelineClick(e);
            }
        });
    }

    setHoveredRow(dataRow) {
        if (this._currentHoveredRow === dataRow) return;

        if (this._currentHoveredRow) {
            this._currentHoveredRow.classList.remove('hovered-track-highlight', 'is-hovered');
            const oldId = this._currentHoveredRow.getAttribute('data-class-id');
            if (oldId) {
                const lbl = document.querySelector(`.label-row[data-class-id="${oldId}"]`);
                if (lbl) lbl.classList.remove('hovered-track-highlight', 'is-hovered');
            }
        }

        this._currentHoveredRow = dataRow;

        if (dataRow) {
            dataRow.classList.add('hovered-track-highlight', 'is-hovered');
            const newId = dataRow.getAttribute('data-class-id');
            if (newId) {
                const lbl = document.querySelector(`.label-row[data-class-id="${newId}"]`);
                if (lbl) lbl.classList.add('hovered-track-highlight', 'is-hovered');
            }
        }
    }

    setupLabelsHoverGuide() {
        const labelsBody = document.getElementById('labelsBody');
        if (!labelsBody || this._labelsHoverBound) return;
        this._labelsHoverBound = true;

        labelsBody.addEventListener('mousemove', (e) => {
            const labelRow = e.target.closest('.label-row');
            if (labelRow) {
                const classId = labelRow.getAttribute('data-class-id');
                if (classId) {
                    const dataRow = document.querySelector(`.data-row[data-class-id="${classId}"]`);
                    this.setHoveredRow(dataRow);
                }
            } else {
                this.setHoveredRow(null);
            }
        });

        labelsBody.addEventListener('mouseleave', () => {
            this.setHoveredRow(null);
        });
    }

    ensureTracksHoverGuide() {
        if (!this.tracks) return null;
        if (!this.tracksGuideLine || !this.tracksGuideLine.parentNode) {
            this.tracksGuideLine = document.createElement('div');
            this.tracksGuideLine.id = 'tracksHoverGuideLine';
            this.tracksGuideLine.style.cssText = 'position:absolute; top:0; bottom:0; width:1.5px; background-image:repeating-linear-gradient(to bottom, #9ca3af 0px, #9ca3af 4px, transparent 4px, transparent 8px); pointer-events:none; z-index:35; display:none; transform:translateX(-50%);';
            this.tracks.appendChild(this.tracksGuideLine);
        }
        const videoTrackContainer = document.getElementById('videoTrackContainer');
        if (videoTrackContainer && (!this.waveformGuideLine || !this.waveformGuideLine.parentNode)) {
            this.waveformGuideLine = document.createElement('div');
            this.waveformGuideLine.id = 'waveformHoverGuideLine';
            this.waveformGuideLine.style.cssText = 'position:absolute; top:0; bottom:0; width:1.5px; background-image:repeating-linear-gradient(to bottom, #9ca3af 0px, #9ca3af 4px, transparent 4px, transparent 8px); pointer-events:none; z-index:35; display:none; transform:translateX(-50%);';
            videoTrackContainer.appendChild(this.waveformGuideLine);
        }
        if (!this.tracksAddBtn || !this.tracksAddBtn.parentNode) {
            this.tracksAddBtn = document.createElement('div');
            this.tracksAddBtn.id = 'tracksHoverAddBtn';
            this.tracksAddBtn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#374151" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" style="pointer-events:none;"><line x1="12" y1="4" x2="12" y2="20"></line><line x1="4" y1="12" x2="20" y2="12"></line></svg>`;
            this.tracksAddBtn.style.cssText = 'position:absolute; width:20px; height:20px; border-radius:5px; background:#ffffff; border:1px solid rgba(0,0,0,0.08); display:none; align-items:center; justify-content:center; transform:translate(-50%, -50%); cursor:pointer; z-index:40; box-shadow:0 2px 5px rgba(0,0,0,0.12), 0 0 1px rgba(0,0,0,0.08); user-select:none; transition:transform 0.1s ease, background-color 0.1s ease;';
            this.tracksAddBtn.onmouseenter = () => {
                this.tracksAddBtn.style.backgroundColor = '#f9fafb';
                this.tracksAddBtn.style.transform = 'translate(-50%, -50%) scale(1.05)';
            };
            this.tracksAddBtn.onmouseleave = () => {
                this.tracksAddBtn.style.backgroundColor = '#ffffff';
                this.tracksAddBtn.style.transform = 'translate(-50%, -50%) scale(1)';
            };
            this.tracksAddBtn.onmousedown = (e) => {
                e.stopPropagation();
                e.preventDefault();
                const dataRow = this._hoveredDataRow;
                const cls = this._hoveredCls;
                const classId = dataRow ? dataRow.getAttribute('data-class-id') : (cls ? cls.id : null);
                const instrIdxStr = dataRow ? dataRow.getAttribute('data-instr-idx') : null;
                const rowInstrIdx = (instrIdxStr !== null && instrIdxStr !== undefined && instrIdxStr !== '') ? parseInt(instrIdxStr, 10) : null;
                const isRowLocked = (window.app && window.app.isRowLocked) ? window.app.isRowLocked(classId, rowInstrIdx) : false;
                if (isRowLocked) return;

                if (this.tracksGuideLine) this.tracksGuideLine.style.display = 'none';
                if (this.waveformGuideLine) this.waveformGuideLine.style.display = 'none';
                this.tracksAddBtn.style.display = 'none';
                if (dataRow && cls && window.app) {
                    if (window.app.setActiveClass) {
                        window.app.setActiveClass(cls.id);
                    }
                    if (window.app.startDirectRangeDrag) {
                        window.app.startDirectRangeDrag(e, dataRow, cls, true, (dataRow && dataRow._rowDef) ? dataRow._rowDef : null);
                    }
                }
            };
            this.tracks.appendChild(this.tracksAddBtn);
        }
        return this.tracksGuideLine;
    }

    formatRulerLabel(frame, majorStep) {
        const totalSeconds = frame / CONFIG.FPS;

        if (majorStep < CONFIG.FPS) {
            return totalSeconds.toFixed(2);
        } else if (totalSeconds < 60) {
            if (majorStep % CONFIG.FPS === 0) {
                return Math.round(totalSeconds).toString();
            } else {
                return totalSeconds.toFixed(2);
            }
        } else {
            const mins = Math.floor(totalSeconds / 60);
            const secs = totalSeconds % 60;
            if (majorStep % CONFIG.FPS === 0) {
                return `${mins}:${Math.round(secs).toString().padStart(2, '0')}`;
            } else {
                return `${mins}:${secs.toFixed(2).padStart(5, '0')}`;
            }
        }
    }

    renderRuler(duration, timelineWidth) {
        if (!this.ruler) return;
        this.ruler.innerHTML = '';
        const fragment = document.createDocumentFragment();

        const { majorStep } = this.getGridSteps();
        const totalFrames = Math.round(duration * CONFIG.FPS);
        const pxPerFrame = this.currentPPS / CONFIG.FPS;
        const leftGutter = 26.8098;

        for (let f = 0; f <= totalFrames; f += majorStep) {
            const xPos = leftGutter + (f * pxPerFrame);

            const label = document.createElement('span');
            label.style.left = `${xPos}px`;
            label.style.position = 'absolute';
            label.className = 'top-1/2 -translate-y-1/2 -translate-x-1/2 text-[10px] text-gray-500 font-medium pointer-events-none select-none';

            label.innerText = this.formatRulerLabel(f, majorStep);
            fragment.appendChild(label);
        }
        this.ruler.appendChild(fragment);
    }

    updatePlayhead(percent, timelineWidth) {
        if (!this.playhead) return;
        const baseWidth = (this.videoDuration || 180) * this.currentPPS;
        this.playhead.style.left = (26.8098 + (percent * baseWidth)) + 'px';

        const playheadNum = document.getElementById('playheadFrameNum');
        if (playheadNum && window.app && window.app.videoController) {
            playheadNum.innerText = window.app.formatTimeDisplay(window.app.videoController.currentTime);
        }
    }

    toggleClassCollapse(classId) {
        if (!this.collapsedRows) this.collapsedRows = {};
        this.collapsedRows[classId] = !this.collapsedRows[classId];
        this.renderTracks(window.app ? window.app.annotationModel.getInstructions() : []);
    }

    getPersistentRows(instructions = []) {
        const rows = [];
        const isCollapsedMap = this.collapsedRows || {};

        CONFIG.CLASSES.forEach((cls) => {
            const classInstructions = instructions
                .map((ins, idx) => ({ ins, idx }))
                .filter(item => isSameClass(item.ins.className, cls.name));

            const isClassCollapsed = !!isCollapsedMap[cls.id];
            const hasChildren = classInstructions.length > 0;

            // 1. Top-Level Parent Class Header Row
            rows.push({
                id: cls.id,
                classId: cls.id,
                className: cls.name,
                name: cls.name,
                cls: cls,
                isParentHeader: true,
                isChildRangeRow: false,
                isFlatRow: false,
                isCollapsed: isClassCollapsed,
                hasChildren: hasChildren,
                rangeCount: classInstructions.length,
                rangeItems: isClassCollapsed ? classInstructions : []
            });

            // 2. If Expanded and has instances/children:
            if (!isClassCollapsed && hasChildren) {
                classInstructions.forEach(({ ins: instr, idx: instrIdx }, itemIndex) => {
                    const isAudioQuality = (cls.id === 'audio_quality' || isSameClass(cls.name, 'Audio quality'));
                    let instanceTitle = isAudioQuality
                        ? (classInstructions.length > 1 ? `Audio quality (${itemIndex})` : `Audio quality`)
                        : `${cls.name} (${itemIndex})`;

                    rows.push({
                        id: `instance_${cls.id}_${instr.id || instrIdx}`,
                        classId: cls.id,
                        className: cls.name,
                        name: instanceTitle,
                        cls: cls,
                        isParentHeader: false,
                        isChildRangeRow: true,
                        isFlatRow: false,
                        isCollapsed: false,
                        hasChildren: false,
                        rangeCount: 1,
                        rangeItems: [{ ins: instr, idx: instrIdx }],
                        instrIdx: instrIdx,
                        itemIndex: itemIndex
                    });
                });
            }
        });

        return rows;
    }

    getFlatRows(instructions = []) {
        const rows = [];

        CONFIG.CLASSES.forEach((cls) => {
            const classInstructions = instructions
                .map((ins, idx) => ({ ins, idx }))
                .filter(item => isSameClass(item.ins.className, cls.name));

            if (classInstructions.length === 0) {
                rows.push({
                    id: cls.id,
                    classId: cls.id,
                    className: cls.name,
                    name: cls.name,
                    cls: cls,
                    isParentHeader: false,
                    isChildRangeRow: false,
                    isFlatRow: true,
                    isCollapsed: false,
                    hasChildren: false,
                    rangeCount: 0,
                    rangeItems: []
                });
            } else {
                classInstructions.forEach(({ ins: instr, idx: instrIdx }, itemIndex) => {
                    const isAudioQuality = (cls.id === 'audio_quality' || isSameClass(cls.name, 'Audio quality'));
                    let instanceTitle = isAudioQuality
                        ? (classInstructions.length > 1 ? `Audio quality (${itemIndex})` : `Audio quality`)
                        : `${cls.name} (${itemIndex})`;

                    rows.push({
                        id: `flat_${cls.id}_${instr.id || instrIdx}`,
                        classId: cls.id,
                        className: cls.name,
                        name: instanceTitle,
                        cls: cls,
                        isParentHeader: false,
                        isChildRangeRow: false,
                        isFlatRow: true,
                        isCollapsed: false,
                        hasChildren: false,
                        rangeCount: 1,
                        rangeItems: [{ ins: instr, idx: instrIdx }],
                        instrIdx: instrIdx,
                        itemIndex: itemIndex
                    });
                });
            }
        });

        return rows;
    }

    getActiveRows(instructions = []) {
        const isGrouped = window.app ? (window.app.groupByClass !== false) : true;
        let rows = isGrouped ? this.getPersistentRows(instructions) : this.getFlatRows(instructions);

        if (window.app && window.app.showSelectedOnly) {
            const hasIndividual = (window.app.selectionMode === 'individual' && window.app.editingAnnotationIndex !== undefined && window.app.editingAnnotationIndex !== -1 && window.app.editingAnnotationIndex !== null);
            const hasGroup = ((window.app.selectionLevel === 'group' || window.app.selectionMode === 'group') && window.app.selectedGroupInstrIndices && window.app.selectedGroupInstrIndices.length > 0);
            const hasRow = (window.app.selectionMode === 'row' && window.app.activeClassId);

            if (hasIndividual || hasGroup || hasRow) {
                const targetIndices = new Set();
                if (hasIndividual) {
                    targetIndices.add(window.app.editingAnnotationIndex);
                }
                if (hasGroup) {
                    window.app.selectedGroupInstrIndices.forEach(idx => targetIndices.add(idx));
                }

                const selectedClassNames = new Set();
                targetIndices.forEach(iIdx => {
                    const ins = instructions[iIdx];
                    if (ins && ins.className) selectedClassNames.add(ins.className);
                });

                rows = rows.filter(rowDef => {
                    if (rowDef.instrIdx !== undefined && targetIndices.has(rowDef.instrIdx)) {
                        return true;
                    }
                    if (rowDef.rangeItems && rowDef.rangeItems.some(item => targetIndices.has(item.idx))) {
                        return true;
                    }
                    if (hasRow && rowDef.classId === window.app.activeClassId) {
                        return true;
                    }
                    if (isGrouped && rowDef.isParentHeader) {
                        if (selectedClassNames.has(rowDef.className || rowDef.name) || (hasRow && rowDef.classId === window.app.activeClassId)) {
                            return true;
                        }
                    }
                    return false;
                });
            }
        }

        return rows;
    }

    renderTracks(instructions = [], pps = this.currentPPS) {
        this.currentPPS = pps;
        const { labelsBody, tracksContainer } = this.elements;
        if (!labelsBody || !tracksContainer) return;

        labelsBody.innerHTML = '';
        tracksContainer.innerHTML = '';

        const leftGutter = this.leftOffset || 26.8098;
        const rightGutter = this.rightOffset || 26.8098;
        const contentWidth = (this.videoDuration || 180) * pps;
        const totalWidth = leftGutter + contentWidth + rightGutter;
        tracksContainer.style.width = totalWidth + 'px';

        this.updateRightGutter(contentWidth);

        const activeRows = this.getActiveRows(instructions);
        activeRows.forEach((rowDef) => {
            const cls = rowDef.cls || CONFIG.CLASSES.find(c => c.id === rowDef.classId || c.name === rowDef.className) || { id: rowDef.classId, name: rowDef.className };
            const isRowChild = (rowDef.isChildRangeRow || rowDef.isFlatRow) && rowDef.instrIdx !== undefined;
            const rowInstrIdx = isRowChild ? rowDef.instrIdx : null;
            const isRowLocked = window.app && window.app.isRowLocked ? window.app.isRowLocked(cls.id, rowInstrIdx) : false;
            const isRowHidden = window.app && window.app.isRowHidden ? window.app.isRowHidden(cls.id, rowInstrIdx) : false;

            let rowIconHtml;
            if (cls.id === 'audio_quality') {
                rowIconHtml = `<span class="anticon anticon-partition shrink-0" style="display:inline-flex;align-items:center;">${PARTITION_ICON_SVG}</span>`;
            } else if (cls.id === 'speaker_1') {
                rowIconHtml = `<span class="justify-center align-middle leading-none shrink-0">${getSpeakerIconSVG('rgb(253, 161, 255)')}</span>`;
            } else if (cls.id === 'speaker_2') {
                rowIconHtml = `<span class="justify-center align-middle leading-none shrink-0">${getSpeakerIconSVG('rgb(211, 49, 21)')}</span>`;
            } else {
                rowIconHtml = `<span class="anticon shrink-0">${PARTITION_ICON_SVG}</span>`;
            }
            let isRowActive = false;
            if (window.app && !rowDef.isParentHeader) {
                if (window.app.selectionMode === 'row' || window.app.selectionLevel === 'group' || window.app.selectionMode === 'group') {
                    if (window.app.selectedGroupInstrIndices && window.app.selectedGroupInstrIndices.length > 0) {
                        isRowActive = (rowDef.rangeItems || []).some(item => window.app.selectedGroupInstrIndices.includes(item.idx));
                        if (!isRowActive && rowDef.instrIdx !== undefined) {
                            isRowActive = window.app.selectedGroupInstrIndices.includes(rowDef.instrIdx);
                        }
                    } else {
                        isRowActive = (window.app.activeClassId === rowDef.classId);
                    }
                } else if (window.app.selectionMode === 'individual') {
                    if (rowDef.instrIdx !== undefined) {
                        isRowActive = (window.app.editingAnnotationIndex === rowDef.instrIdx);
                    }
                }
            }

            const label = document.createElement('div');
            const indentStyle = rowDef.isChildRangeRow ? 'padding-left: 20px;' : 'padding-left: 8px;';
            label.className = `label-row group/labelrow flex items-center justify-between px-2 text-[13px] text-gray-800 h-[32px] shrink-0 border-l-[3.5px] cursor-pointer ${isRowActive ? 'is-active-row is-selected clicked-track-highlight border-l-[#52c41a]' : 'border-l-transparent'} ${isRowLocked ? 'opacity-70' : ''}`;
            label.setAttribute('data-class-id', rowDef.classId);
            label.setAttribute('data-row-id', rowDef.id);
            if (rowDef.instrIdx !== undefined) {
                label.setAttribute('data-instr-idx', rowDef.instrIdx);
            }
            label.style.cssText = indentStyle;

            let chevronHtml = '';
            if (rowDef.isParentHeader && rowDef.hasChildren) {
                chevronHtml = `
                    <div class="row-collapse-toggle flex w-4 shrink-0 items-center justify-center text-gray-400 hover:text-black cursor-pointer ml-0.5"
                         onclick="event.stopPropagation(); window.app && window.app.timelineView && window.app.timelineView.toggleClassCollapse('${rowDef.classId}')">
                        <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="w-3.5 h-3.5 transition-transform ${rowDef.isCollapsed ? '' : 'rotate-90'}"><path d="m9 18 6-6-6-6"></path></svg>
                    </div>
                `;
            }

            const rowActionsHtml = `
                <div class="flex items-center gap-1 opacity-0 group-hover/labelrow:opacity-100 ${isRowLocked || isRowHidden ? '!opacity-100' : ''} transition-opacity ml-auto">
                    <button aria-label="lock" type="button" class="w-4 h-4 flex items-center justify-center text-gray-400 hover:text-black rounded cursor-pointer ${isRowLocked ? 'text-gray-800' : ''}" onclick="event.stopPropagation(); window.app && window.app.toggleRowLock('${cls.id}', ${rowInstrIdx !== null ? rowInstrIdx : 'null'})" data-tooltip="${isRowLocked ? 'Unlock row' : 'Lock row'}">
                        ${isRowLocked ? 
                            `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="11" width="11"><path d="M336 208v-96a80 80 0 0 0-160 0v96H96a48 48 0 0 0-48 48v176a48 48 0 0 0 48 48h320a48 48 0 0 0 48-48V256a48 48 0 0 0-48-48zM256 368a32 32 0 1 1 32-32 32 32 0 0 1-32 32zm48-160h-96v-96a48 48 0 0 1 96 0z"></path></svg>` : 
                            `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="11" width="11"><path fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M336 112a80 80 0 0 0-160 0v96"></path><rect width="320" height="272" x="96" y="208" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" rx="48" ry="48"></rect></svg>`
                        }
                    </button>
                    <button type="button" class="w-4 h-4 flex items-center justify-center text-gray-400 hover:text-black rounded cursor-pointer ${isRowHidden ? 'text-gray-800' : ''}" onclick="event.stopPropagation(); window.app && window.app.toggleRowVisibility('${cls.id}', ${rowInstrIdx !== null ? rowInstrIdx : 'null'})" data-tooltip="${isRowHidden ? 'Show row' : 'Hide row'}">
                        ${isRowHidden ? 
                            `<svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-48.4 0-95.2 6.4-138.8 18.2l76.7 76.7C474.3 277 493 276 512 276c161.3 0 279.4 81.8 362.7 254-26.6 55-61.7 102.7-103.8 141.6l64.5 64.5C895.8 683.7 925.3 630.9 942.2 486.2zM281.8 335.7l64.5 64.5C342.3 403.4 340 407.5 340 412c0 95 77 172 172 172 4.5 0 8.6-2.3 11.8-6.3l64.5 64.5C564.1 647.7 538.7 652 512 652c-192.2 0-335.4-100.5-430.2-300.3-7.7-16.2-7.7-35 0-51.5 35.8-75.6 86.8-139.7 149.3-188.7l50.7 50.7zM512 766c-48.4 0-94.8-6.2-138.1-17.7l60.2 60.2C460.6 813.1 486 816 512 816c192.2 0 335.4-100.5 430.2-300.3a60.3 60.3 0 0 0 0-51.5c-9.2-19.4-19.8-37.8-31.5-55.2l-62.8 62.8C838.2 678.8 720.1 766 512 766zm-389.7-658l769.4 769.4c6.2 6.2 6.2 16.4 0 22.6l-22.6 22.6c-6.2 6.2-16.4 6.2-22.6 0L99.7 153.2c-6.2-6.2-6.2-16.4 0-22.6l22.6-22.6c6.2-6.2 16.4-6.2 22.6 0z"></path></svg>` : 
                            `<svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 000 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z"></path></svg>`
                        }
                    </button>
                    ${chevronHtml}
                </div>
            `;

            label.innerHTML = `
                <div class="flex items-center gap-1.5 min-w-0 pr-1">
                    ${rowIconHtml}
                    <span class="select-none truncate font-[450] text-gray-800 text-[12.5px]" title="${rowDef.name}">${rowDef.name}</span>
                </div>
                ${rowActionsHtml}
            `;

            label.onclick = (e) => {
                e.stopPropagation();
                if (e.target.closest('.row-collapse-toggle')) return;
                if (window.app) {
                    if (rowDef.isParentHeader) {
                        this.toggleClassCollapse(rowDef.classId);
                        return;
                    }

                    if (rowDef.isChildRangeRow || rowDef.isFlatRow) {
                        if (rowDef.instrIdx !== undefined) {
                            const ins = instructions[rowDef.instrIdx];
                            const segs = ins && ins.frames ? ins.frames.split(' | ').filter(Boolean) : [];
                            if (segs.length > 1) {
                                window.app.selectGroup(rowDef.instrIdx, [rowDef.instrIdx]);
                            } else {
                                window.app.selectIndividualRange(rowDef.instrIdx, 0);
                            }
                        } else {
                            window.app.selectClassRow(rowDef.classId);
                        }
                    } else {
                        window.app.selectClassRow(rowDef.classId);
                    }
                }
            };

            label.oncontextmenu = (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (window.app && window.app.showGroupContextMenu) {
                    window.app.showGroupContextMenu(e.clientX, e.clientY, rowDef);
                }
            };
            labelsBody.appendChild(label);

            const data = document.createElement('div');
            data._rowDef = rowDef;
            data.className = `data-row relative w-full h-[32px] border-none ${isRowActive ? 'is-active-row is-selected clicked-track-highlight' : ''} ${isRowLocked ? 'opacity-60' : ''}`;
            data.setAttribute('data-class-id', rowDef.classId);
            data.setAttribute('data-row-id', rowDef.id);
            if (rowDef.instrIdx !== undefined) {
                data.setAttribute('data-instr-idx', rowDef.instrIdx);
            }

            data.onclick = (e) => {
                if (e.target.closest && (e.target.closest('[data-testid="range"]') || e.target.closest('#tracksHoverAddBtn'))) return;
                if (window.app) {
                    if (rowDef.isParentHeader) {
                        this.toggleClassCollapse(rowDef.classId);
                        return;
                    }
                    if (rowDef.isChildRangeRow || rowDef.isFlatRow) {
                        if (rowDef.instrIdx !== undefined) {
                            const ins = instructions[rowDef.instrIdx];
                            const segs = ins && ins.frames ? ins.frames.split(' | ').filter(Boolean) : [];
                            if (segs.length > 1) {
                                window.app.selectGroup(rowDef.instrIdx, [rowDef.instrIdx]);
                            } else {
                                window.app.selectIndividualRange(rowDef.instrIdx, 0);
                            }
                        } else {
                            window.app.selectClassRow(rowDef.classId);
                        }
                    } else {
                        window.app.selectClassRow(rowDef.classId);
                    }
                }
            };

            data.oncontextmenu = (e) => {
                if (e.target.closest && e.target.closest('[data-testid="range"]')) return;
                e.preventDefault();
                e.stopPropagation();
                if (window.app && window.app.showGroupContextMenu) {
                    window.app.showGroupContextMenu(e.clientX, e.clientY, rowDef);
                }
            };

            data.onmousedown = (e) => {
                if (e.target !== data) return;
                if (isRowLocked) return;
                if (window.app) {
                    if (rowDef.isChildRangeRow || rowDef.isFlatRow) {
                        if (rowDef.instrIdx !== undefined) {
                            window.app.selectIndividualRange(rowDef.instrIdx);
                        } else {
                            window.app.selectClassRow(rowDef.classId);
                        }
                    } else if (!rowDef.isParentHeader) {
                        window.app.selectClassRow(rowDef.classId);
                    }
                    if (window.app.startDirectRangeDrag) {
                        window.app.startDirectRangeDrag(e, data, cls, false, rowDef);
                    }
                }
            };

            if (!isRowHidden) {
                rowDef.rangeItems.forEach(({ ins: instr, idx: instrIdx }) => {
                if (window.app && window.app.isRowHidden && window.app.isRowHidden(cls.id, instrIdx)) return;
                const isItemLocked = isRowLocked || (window.app && window.app.isRowLocked ? window.app.isRowLocked(cls.id, instrIdx) : false);

                const rawSegments = (instr.frames || '').split(' | ').filter(Boolean);
                rawSegments.forEach((segStr, segIdx) => {
                    const parts = segStr.split(' - ').map(Number);
                    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                        const startX = leftGutter + ((parts[0] / CONFIG.FPS) * pps);
                        const widthX = ((parts[1] - parts[0]) / CONFIG.FPS) * pps;

                        const bar = document.createElement('div');
                        bar.setAttribute('data-testid', 'range');
                        bar.setAttribute('data-instr-idx', instrIdx);
                        bar.setAttribute('data-seg-idx', segIdx);
                        bar.setAttribute('data-start-frame', parts[0]);
                        bar.setAttribute('data-end-frame', parts[1]);

                        const isIndividuallySelected = window.app && window.app.editingAnnotationIndex === instrIdx && (window.app.selectionMode === 'individual' || window.app.selectionLevel === 'range') && (window.app.editingSegmentIndex === null || window.app.editingSegmentIndex === undefined || window.app.editingSegmentIndex === segIdx);
                        const isRowSelected = (window.app && window.app.activeClassId === rowDef.classId && window.app.selectionMode === 'row');
                        const isGroupSelected = window.app && (window.app.selectionLevel === 'group' || window.app.selectionMode === 'group') && window.app.selectedGroupInstrIndices && window.app.selectedGroupInstrIndices.includes(instrIdx) && (!window.app.deselectedSegmentIndices || (!window.app.deselectedSegmentIndices.has(`${instrIdx}_${segIdx}`) && !window.app.deselectedSegmentIndices.has(segIdx)));
                        const isSelected = isIndividuallySelected || isRowSelected || isGroupSelected;

                        const isPlaying = (this.playingRange && this.playingRange.instrIdx === instrIdx && (this.playingRange.segIdx === null || this.playingRange.segIdx === undefined || this.playingRange.segIdx === segIdx)) ||
                                          (this.playingRangeIndex === instrIdx && (this.playingRangeSegIdx === null || this.playingRangeSegIdx === undefined || this.playingRangeSegIdx === segIdx));

                        let isAudioQuality = (cls.id === 'audio_quality' || isSameClass(cls.name, 'Audio quality'));
                        let bgCol = cls.color || 'rgb(195, 165, 250)';
                        let handleCol = cls.handleColor || 'rgb(105, 29, 242)';
                        let handleOpacity = isSelected ? '1' : (cls.handleOpacity || '0.6');
                        let textCol = cls.textColor || 'rgb(105, 29, 242)';

                        if (cls.id === 'speaker_1' || isSameClass(cls.name, 'Speaker 1')) {
                            if (isSelected) {
                                bgCol = 'rgb(253, 161, 255)';
                                handleCol = 'rgb(230, 90, 235)';
                                handleOpacity = '1';
                                textCol = '#ffffff';
                            } else {
                                bgCol = 'rgb(254, 217, 255)';
                                handleCol = 'rgb(233, 137, 235)';
                                handleOpacity = '0.6';
                                textCol = 'rgb(253, 161, 255)';
                            }
                        } else if (cls.id === 'speaker_2' || isSameClass(cls.name, 'Speaker 2')) {
                            bgCol = 'rgb(237, 173, 161)';
                            handleCol = 'rgb(211, 49, 21)';
                            handleOpacity = isSelected ? '1' : '0.6';
                            textCol = 'rgb(211, 49, 21)';
                        } else if (isAudioQuality) {
                            if (isSelected) {
                                bgCol = cls.selectedColor || 'rgb(150, 97, 246)';
                                handleCol = 'rgb(105, 29, 242)';
                                handleOpacity = '1';
                                textCol = cls.selectedTextColor || '#ffffff';
                            } else {
                                bgCol = 'rgb(195, 165, 250)';
                                handleCol = 'rgb(105, 29, 242)';
                                handleOpacity = '0.6';
                                textCol = 'rgb(105, 29, 242)';
                            }
                        }

                        if (isSelected) {
                            bar.setAttribute('data-active', 'true');
                        }
                        if (isPlaying) {
                            bar.setAttribute('data-playing', 'true');
                        }
                        bar.className = `absolute top-1 flex h-6 min-w-[8px] ${isItemLocked ? 'cursor-default' : 'cursor-pointer'} items-center ${isPlaying ? '' : 'overflow-hidden'} rounded-[4px] z-10 select-none ${isAudioQuality && isSelected ? '!text-white' : ''} ${isSelected ? 'range-active-highlight' : ''} ${isPlaying ? 'range-reclick-highlight' : ''}`;
                        bar.style.width = Math.max(8, widthX) + 'px';
                        bar.style.height = '24px';
                        bar.style.left = startX + 'px';
                        bar.style.top = '50%';
                        bar.style.transform = 'translateY(-50%)';
                        bar.style.background = bgCol;
                        bar.style.opacity = isItemLocked ? '0.6' : '1';
                        bar.style.color = textCol;

                        if (isPlaying) {
                            bar.classList.add('range-reclick-highlight');
                            bar.style.setProperty('outline', '2px solid #faad14', 'important');
                            bar.style.setProperty('outline-offset', '0px', 'important');
                            bar.style.setProperty('box-shadow', '0 0 0 2px #faad14, 0 0 8px rgba(250, 173, 20, 0.6)', 'important');
                            bar.style.setProperty('border-color', '#faad14', 'important');
                            bar.style.setProperty('z-index', '40', 'important');
                        } else {
                            bar.classList.remove('range-reclick-highlight');
                        }

                        if (isAudioQuality) {
                            const barLabel = document.createElement('span');
                            barLabel.className = 'relative z-10 select-none truncate pl-2 pr-1 text-[11px] font-medium leading-5 pointer-events-none';
                            barLabel.textContent = instr.text || '';
                            bar.appendChild(barLabel);
                        }

                        const leftWrap = document.createElement('div');
                        leftWrap.className = 'pointer-events-auto absolute z-20 w-2 h-6 range-left-handle range-handle-wrap custom-range-handle';
                        leftWrap.style.left = '0px';
                        leftWrap.style.cursor = isItemLocked ? 'default' : CUSTOM_RESIZE_CURSOR;
                        leftWrap.setAttribute('draggable', isItemLocked ? 'false' : 'true');

                        const leftHandle = document.createElement('div');
                        leftHandle.className = 'absolute bottom-0 top-0 w-1 range-left-handle custom-range-handle';
                        leftHandle.setAttribute('data-testid', 'left-handle');
                        leftHandle.style.left = '0px';
                        leftHandle.style.opacity = handleOpacity;
                        leftHandle.style.background = handleCol;
                        leftHandle.style.cursor = isItemLocked ? 'default' : CUSTOM_RESIZE_CURSOR;
                        leftWrap.appendChild(leftHandle);

                        leftWrap.onmousedown = (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            if (isItemLocked) return;
                            if (window.app && window.app.selectIndividualRange) {
                                window.app.selectIndividualRange(instrIdx, segIdx);
                            } else if (window.app && window.app.openFullEditSidebar) {
                                window.app.openFullEditSidebar(instrIdx, segIdx);
                            }
                            if (window.app && window.app.startRangeEdgeDrag) {
                                window.app.startRangeEdgeDrag(e, instrIdx, segIdx, 'left', cls, bar);
                            }
                        };
                        bar.appendChild(leftWrap);

                        const rightWrap = document.createElement('div');
                        rightWrap.className = 'pointer-events-auto absolute z-20 w-2 h-6 range-right-handle range-handle-wrap custom-range-handle';
                        rightWrap.style.right = '0px';
                        rightWrap.style.cursor = isItemLocked ? 'default' : CUSTOM_RESIZE_CURSOR;
                        rightWrap.setAttribute('draggable', isItemLocked ? 'false' : 'true');

                        const rightHandle = document.createElement('div');
                        rightHandle.className = 'absolute bottom-0 top-0 w-1 range-right-handle custom-range-handle';
                        rightHandle.setAttribute('data-testid', 'right-handle');
                        rightHandle.style.right = '0px';
                        rightHandle.style.opacity = handleOpacity;
                        rightHandle.style.background = handleCol;
                        rightHandle.style.cursor = isItemLocked ? 'default' : CUSTOM_RESIZE_CURSOR;
                        rightWrap.appendChild(rightHandle);

                        rightWrap.onmousedown = (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            if (isItemLocked) return;
                            if (window.app && window.app.selectIndividualRange) {
                                window.app.selectIndividualRange(instrIdx, segIdx);
                            } else if (window.app && window.app.openFullEditSidebar) {
                                window.app.openFullEditSidebar(instrIdx, segIdx);
                            }
                            if (window.app && window.app.startRangeEdgeDrag) {
                                window.app.startRangeEdgeDrag(e, instrIdx, segIdx, 'right', cls, bar);
                            }
                        };
                        bar.appendChild(rightWrap);

                        bar.onmousedown = (e) => {
                            if (e.target === leftHandle || e.target === rightHandle || e.target === leftWrap || e.target === rightWrap || (e.target.closest && e.target.closest('.range-handle-wrap'))) return;
                            e.stopPropagation();
                            if (isItemLocked) return;

                            const now = Date.now();
                            const lastClick = window.__lastRangeClick;
                            const isDoubleClick = lastClick &&
                                lastClick.instrIdx === instrIdx &&
                                lastClick.segIdx === segIdx &&
                                (now - lastClick.time) < 450 &&
                                Math.abs(e.clientX - lastClick.x) < 12 &&
                                Math.abs(e.clientY - lastClick.y) < 12;

                            if (isDoubleClick) {
                                window.__lastRangeClick = null;
                                e.preventDefault();
                                if (window.app && window.app.playRangeOnly) {
                                    window.app.stopRangePlayback(false);
                                    window.app.playRangeOnly(parts[0], parts[1], instrIdx, segIdx);
                                }
                                return;
                            }

                            window.__lastRangeClick = {
                                instrIdx,
                                segIdx,
                                time: now,
                                x: e.clientX,
                                y: e.clientY
                            };

                            // Only re-select if not already selected (avoids DOM rebuild that kills dblclick)
                            const alreadySelected = window.app && window.app.editingAnnotationIndex === instrIdx && window.app.selectionMode === 'individual' && (window.app.editingSegmentIndex === segIdx || (window.app.editingSegmentIndex === null && segIdx === 0));
                            if (!alreadySelected && window.app && window.app.selectIndividualRange) {
                                window.app.selectIndividualRange(instrIdx, segIdx);
                            }
                        };

                        bar.onclick = (e) => {
                            e.stopPropagation();
                            if (isItemLocked) return;
                            if (window.app && window.app.selectIndividualRange) {
                                window.app.selectIndividualRange(instrIdx, segIdx);
                            }
                        };

                        bar.ondblclick = (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            if (isItemLocked) return;
                            if (window.app && window.app.playRangeOnly) {
                                window.app.stopRangePlayback(false);
                                window.app.playRangeOnly(parts[0], parts[1], instrIdx, segIdx);
                            }
                        };

                        bar.oncontextmenu = (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (window.app && window.app.showRangeContextMenu) {
                                window.app.showRangeContextMenu(e.clientX, e.clientY, instrIdx, cls, parts, segIdx);
                            }
                        };

                        data.appendChild(bar);
                    }
                });
            });
            }

            tracksContainer.appendChild(data);
        });

        this.applyTrackGridLines();
        if (window.app && window.app.instructionRenderer) {
            window.app.instructionRenderer.render(instructions || (window.app.annotationModel ? window.app.annotationModel.getInstructions() : []));
        }
        if (window.app && window.app.waveformRenderer && this.videoDuration && this.currentPPS) {
            window.app.waveformRenderer.render(this.videoDuration, this.currentPPS);
        }
    }
}

class ScrollSynchronizer {
    constructor(scrollContainer, playheadElement) {
        this.scrollContainer = scrollContainer;
        this.playhead = playheadElement;
    }

    sync(currentTime, duration, currentPPS, forceCenter = false) {
        if (!duration || !currentPPS || !this.scrollContainer) return;

        const leftGutter = 26.8098;
        const timelineWidth = duration * currentPPS;
        const percent = currentTime / duration;
        const playheadX = leftGutter + (percent * timelineWidth);

        const visibleWidth = this.scrollContainer.clientWidth;

        if (forceCenter) {
            this.scrollContainer.scrollTo({
                left: playheadX - (visibleWidth / 2),
                behavior: 'smooth'
            });
        } else if (window.app && window.app.autoScroll && window.app.videoController && !window.app.videoController.video.paused) {
            if (playheadX > this.scrollContainer.scrollLeft + visibleWidth - 40) {
                this.scrollContainer.scrollLeft = playheadX - 60;
            } else if (playheadX < this.scrollContainer.scrollLeft) {
                this.scrollContainer.scrollLeft = Math.max(0, playheadX - 60);
            }
        }
    }
}

class InstructionListRenderer {
    constructor(containerElement) {
        this.container = containerElement;
        this.expandedGroups = new Set(['Speaker 1', 'Speaker 2', 'Audio quality']);
        this.collapsedGroups = new Set();
    }

    toggleGroup(className) {
        if (!this.expandedGroups) this.expandedGroups = new Set(['Speaker 1', 'Speaker 2', 'Audio quality']);
        if (!this.collapsedGroups) this.collapsedGroups = new Set();

        if (this.expandedGroups.has(className)) {
            this.expandedGroups.delete(className);
            this.collapsedGroups.add(className);
        } else {
            this.expandedGroups.add(className);
            this.collapsedGroups.delete(className);
        }
        if (window.app) window.app.renderInstructions();
    }

    render(instructions = []) {
        if (!this.container) {
            this.container = document.getElementById('instructionContainer');
        }
        if (!this.container) return;

        let effectiveInstructions = instructions;
        if ((!effectiveInstructions || effectiveInstructions.length === 0) && window.app && window.app.annotationModel) {
            effectiveInstructions = window.app.annotationModel.getInstructions();
        }

        if (!effectiveInstructions || effectiveInstructions.length === 0) {
            this.container.className = "flex-1 overflow-y-auto p-0 bg-white hide-scrollbar flex flex-col justify-center items-center w-full";
            this.container.innerHTML = `
                <div class="flex flex-col items-center justify-center p-6 text-center select-none">
                    <svg width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg">
                        <title>Simple Empty</title>
                        <g transform="translate(0 1)" fill="none" fill-rule="evenodd">
                            <ellipse fill="#f5f5f5" cx="32" cy="33" rx="32" ry="7"></ellipse>
                            <g fill-rule="nonzero" stroke="#d9d9d9">
                                <path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path>
                                <path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" fill="#fafafa"></path>
                            </g>
                        </g>
                    </svg>
                    <div class="mt-4 text-[#8c8c8c] text-[13px] font-normal">No classifications or objects</div>
                </div>
            `;
            return;
        }

        this.container.className = "flex-1 overflow-y-auto p-1.5 bg-white hide-scrollbar block w-full";

        if (!this.expandedGroups) this.expandedGroups = new Set(['Speaker 1', 'Speaker 2', 'Audio quality']);
        if (!this.collapsedGroups) this.collapsedGroups = new Set();

        // Group instructions by className
        const groups = {};
        effectiveInstructions.forEach((instr, idx) => {
            const cls = instr.className || 'Audio quality';
            if (!groups[cls]) groups[cls] = [];
            groups[cls].push({ instr, idx });
        });

        let html = `<div class="space-y-2 w-full flex flex-col">`;

        Object.keys(groups).forEach(className => {
            const groupItems = groups[className];
            if (!this.expandedGroups.has(className) && !this.collapsedGroups.has(className)) {
                this.expandedGroups.add(className);
            }
            const isExpanded = this.expandedGroups.has(className);
            const count = groupItems.length;

            const groupClsObj = CONFIG.CLASSES.find(c => isSameClass(c.name, className)) || { id: className, name: className };
            const isGroupLocked = window.app && window.app.isRowLocked ? window.app.isRowLocked(groupClsObj.id) : false;
            const isGroupHidden = window.app && window.app.hiddenRows ? !!window.app.hiddenRows[groupClsObj.id] : false;

            let iconSvg = PARTITION_ICON_SVG;
            if (className === 'Speaker 1') {
                iconSvg = getSpeakerIconSVG('rgb(253, 161, 255)');
            } else if (className === 'Speaker 2') {
                iconSvg = getSpeakerIconSVG('rgb(211, 49, 21)');
            }

            html += `
                <div class="w-full flex flex-col">
                    <!-- Parent Class Header -->
                    <div class="flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer select-none bg-[#f5f5f5] hover:bg-[#ebebeb] transition-colors group/grouprow"
                         onclick="window.app && window.app.instructionRenderer.toggleGroup('${className}')">
                        <div class="flex items-center gap-2 min-w-0">
                            <span class="text-xs text-gray-500 transition-transform ${isExpanded ? 'rotate-90' : ''} inline-flex items-center justify-center w-3 h-3">
                                <svg viewBox="0 0 1024 1024" width="10" height="10" fill="currentColor"><path d="M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z"></path></svg>
                            </span>
                            <span class="inline-flex items-center justify-center shrink-0 leading-none text-base">${iconSvg}</span>
                            <span class="font-medium text-[13px] text-gray-900 truncate">${className}</span>
                            <span class="rounded-full px-2 py-0.5 text-[11px] bg-white border border-gray-200 text-gray-700 font-normal leading-tight ml-1 shadow-2xs">${count}</span>
                        </div>
                        <div class="flex items-center gap-1 opacity-0 group-hover/grouprow:opacity-100 transition-opacity">
                            <button aria-label="lock" type="button" class="w-5 h-5 flex items-center justify-center text-gray-400 hover:text-black rounded cursor-pointer ${isGroupLocked ? 'text-gray-800' : ''}" onclick="event.stopPropagation(); window.app && window.app.toggleGroupLock('${className}')" data-tooltip="${isGroupLocked ? 'Unlock row' : 'Lock row'}">
                                ${isGroupLocked ? 
                                    `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="11" width="11"><path d="M336 208v-96a80 80 0 0 0-160 0v96H96a48 48 0 0 0-48 48v176a48 48 0 0 0 48 48h320a48 48 0 0 0 48-48V256a48 48 0 0 0-48-48zM256 368a32 32 0 1 1 32-32 32 32 0 0 1-32 32zm48-160h-96v-96a48 48 0 0 1 96 0z"></path></svg>` : 
                                    `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="11" width="11"><path fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M336 112a80 80 0 0 0-160 0v96"></path><rect width="320" height="272" x="96" y="208" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" rx="48" ry="48"></rect></svg>`
                                }
                            </button>
                            <button type="button" class="w-5 h-5 flex items-center justify-center text-gray-400 hover:text-black rounded cursor-pointer ${isGroupHidden ? 'text-gray-800' : ''}" onclick="event.stopPropagation(); window.app && window.app.toggleGroupVisibility('${className}')" data-tooltip="${isGroupHidden ? 'Show row' : 'Hide row'}">
                                ${isGroupHidden ? 
                                    `<svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-48.4 0-95.2 6.4-138.8 18.2l76.7 76.7C474.3 277 493 276 512 276c161.3 0 279.4 81.8 362.7 254-26.6 55-61.7 102.7-103.8 141.6l64.5 64.5C895.8 683.7 925.3 630.9 942.2 486.2zM281.8 335.7l64.5 64.5C342.3 403.4 340 407.5 340 412c0 95 77 172 172 172 4.5 0 8.6-2.3 11.8-6.3l64.5 64.5C564.1 647.7 538.7 652 512 652c-192.2 0-335.4-100.5-430.2-300.3-7.7-16.2-7.7-35 0-51.5 35.8-75.6 86.8-139.7 149.3-188.7l50.7 50.7zM512 766c-48.4 0-94.8-6.2-138.1-17.7l60.2 60.2C460.6 813.1 486 816 512 816c192.2 0 335.4-100.5 430.2-300.3a60.3 60.3 0 0 0 0-51.5c-9.2-19.4-19.8-37.8-31.5-55.2l-62.8 62.8C838.2 678.8 720.1 766 512 766zm-389.7-658l769.4 769.4c6.2 6.2 6.2 16.4 0 22.6l-22.6 22.6c-6.2 6.2-16.4 6.2-22.6 0L99.7 153.2c-6.2-6.2-6.2-16.4 0-22.6l22.6-22.6c6.2-6.2 16.4-6.2 22.6 0z"></path></svg>` : 
                                    `<svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 000 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z"></path></svg>`
                                }
                            </button>
                        </div>
                    </div>
            `;

            if (isExpanded) {
                html += `
                    <div class="flex flex-col gap-2 pl-3 pt-1.5 pb-0.5">
                        ${groupItems.map(({ instr, idx: instrIdx }, itemIndex) => {
                    const rawSegs = (instr.frames || '').split(' | ').filter(Boolean);
                    const validSegs = rawSegs.map(seg => {
                        const parts = seg.split(' - ').map(Number);
                        const sSec = isNaN(parts[0]) ? 0 : parts[0] / CONFIG.FPS;
                        const eSec = isNaN(parts[1]) ? 0 : parts[1] / CONFIG.FPS;
                        return { sSec, eSec, valid: !isNaN(parts[0]) && !isNaN(parts[1]) };
                    }).filter(s => s.valid);

                    let instanceTitle = `${className} (${itemIndex})`;
                    if (className === 'Audio quality' || isSameClass(className, 'Audio quality')) {
                        instanceTitle = groupItems.length > 1 ? `Audio quality (${itemIndex})` : `Audio quality`;
                    }

                    const isSelected = (window.app && window.app.editingAnnotationIndex === instrIdx);
                    const isInstLocked = window.app && window.app.isRowLocked ? window.app.isRowLocked(groupClsObj.id, instrIdx) : false;
                    const isInstHidden = window.app && window.app.isRowHidden ? window.app.isRowHidden(groupClsObj.id, instrIdx) : false;

                    return `
                                <div class="rounded-xl p-2.5 transition-all select-none cursor-pointer group/instrow flex flex-col gap-1.5 ${isSelected ? 'bg-[#f0f0f0] border border-gray-200 shadow-2xs' : 'bg-transparent hover:bg-gray-50 border border-transparent'}"
                                     data-testid="select-label-button"
                                     onclick="window.app && window.app.selectIndividualRange(${instrIdx}, null)"
                                     onmouseenter="window.app && window.app.highlightRangeBar(${instrIdx})"
                                     onmouseleave="window.app && window.app.unhighlightRangeBar(${instrIdx})">
                                    
                                    <!-- Row 1: Instance Name + Action Buttons -->
                                    <div class="flex items-center justify-between min-h-[22px]">
                                        <div class="flex items-center gap-1.5 truncate text-[13px] font-medium text-gray-800">
                                            <span class="justify-center align-middle leading-none flex items-center shrink-0">${iconSvg}</span>
                                            <span class="truncate">${instanceTitle}</span>
                                        </div>
                                        <div class="flex items-center gap-1.5 ${isSelected ? 'opacity-100' : 'opacity-0 group-hover/instrow:opacity-100'} transition-opacity">
                                            <!-- Options button (...) -->
                                            <button type="button" class="w-4 h-4 flex items-center justify-center text-gray-500 hover:text-black rounded cursor-pointer" onclick="event.stopPropagation(); window.app && window.app.toggleInstanceContextMenu(event, ${instrIdx})" data-tooltip="Options">
                                                <svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M456 231a56 56 0 10112 0 56 56 0 10-112 0zm0 281a56 56 0 10112 0 56 56 0 10-112 0zm0 281a56 56 0 10112 0 56 56 0 10-112 0z"></path></svg>
                                            </button>
                                            <!-- Edit button (pencil) -->
                                            <button type="button" class="w-4 h-4 flex items-center justify-center text-gray-500 hover:text-black rounded cursor-pointer" onclick="event.stopPropagation(); window.app && window.app.selectIndividualRange(${instrIdx}, null)" data-tooltip="Edit attributes">
                                                <svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M257.7 752c2 0 4-.2 6-.5L431.9 722c2-.4 3.9-1.3 5.3-2.8l423.9-423.9a9.96 9.96 0 000-14.1L694.9 114.9c-1.9-1.9-4.4-2.9-7.1-2.9s-5.2 1-7.1 2.9L256.8 538.8c-1.5 1.5-2.4 3.3-2.8 5.3l-29.5 168.2a33.5 33.5 0 009.4 29.8c6.6 6.4 14.9 9.9 23.8 9.9zm67.4-174.4L687.8 215l73.3 73.3-362.7 362.6-88.9 15.7 15.6-89zM880 836H144c-17.7 0-32 14.3-32 32v36c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-36c0-17.7-14.3-32-32-32z"></path></svg>
                                            </button>
                                            <!-- Lock button -->
                                            <button type="button" class="w-4 h-4 flex items-center justify-center text-gray-500 hover:text-black rounded cursor-pointer ${isInstLocked ? 'text-gray-800' : ''}" onclick="event.stopPropagation(); window.app && window.app.toggleInstanceLock(${instrIdx})" data-tooltip="${isInstLocked ? 'Unlock object instance' : 'Lock object instance'}">
                                                ${isInstLocked ? 
                                                    `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="11" width="11"><path d="M336 208v-96a80 80 0 0 0-160 0v96H96a48 48 0 0 0-48 48v176a48 48 0 0 0 48 48h320a48 48 0 0 0 48-48V256a48 48 0 0 0-48-48zM256 368a32 32 0 1 1 32-32 32 32 0 0 1-32 32zm48-160h-96v-96a48 48 0 0 1 96 0z"></path></svg>` : 
                                                    `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="11" width="11"><path fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M336 112a80 80 0 0 0-160 0v96"></path><rect width="320" height="272" x="96" y="208" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" rx="48" ry="48"></rect></svg>`
                                                }
                                            </button>
                                            <!-- Eye button -->
                                            <button type="button" class="w-4 h-4 flex items-center justify-center text-gray-500 hover:text-black rounded cursor-pointer ${isInstHidden ? 'text-gray-800' : ''}" onclick="event.stopPropagation(); window.app && window.app.toggleInstanceVisibility(${instrIdx})" data-tooltip="${isInstHidden ? 'Show object instance' : 'Hide object instance'}">
                                                ${isInstHidden ? 
                                                    `<svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-48.4 0-95.2 6.4-138.8 18.2l76.7 76.7C474.3 277 493 276 512 276c161.3 0 279.4 81.8 362.7 254-26.6 55-61.7 102.7-103.8 141.6l64.5 64.5C895.8 683.7 925.3 630.9 942.2 486.2zM281.8 335.7l64.5 64.5C342.3 403.4 340 407.5 340 412c0 95 77 172 172 172 4.5 0 8.6-2.3 11.8-6.3l64.5 64.5C564.1 647.7 538.7 652 512 652c-192.2 0-335.4-100.5-430.2-300.3-7.7-16.2-7.7-35 0-51.5 35.8-75.6 86.8-139.7 149.3-188.7l50.7 50.7zM512 766c-48.4 0-94.8-6.2-138.1-17.7l60.2 60.2C460.6 813.1 486 816 512 816c192.2 0 335.4-100.5 430.2-300.3a60.3 60.3 0 0 0 0-51.5c-9.2-19.4-19.8-37.8-31.5-55.2l-62.8 62.8C838.2 678.8 720.1 766 512 766zm-389.7-658l769.4 769.4c6.2 6.2 6.2 16.4 0 22.6l-22.6 22.6c-6.2 6.2-16.4 6.2-22.6 0L99.7 153.2c-6.2-6.2-6.2-16.4 0-22.6l22.6-22.6c6.2-6.2 16.4-6.2 22.6 0z"></path></svg>` : 
                                                    `<svg viewBox="64 64 896 896" width="11" height="11" fill="currentColor"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 000 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z"></path></svg>`
                                                }
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Row 2: Time Ranges -->
                                    ${validSegs.length > 0 ? `
                                    <div class="flex items-center flex-wrap gap-1.5">
                                        <span class="text-[12px] text-gray-400 font-normal select-none mr-0.5">Time</span>
                                        <div class="flex flex-wrap items-center gap-1.5">
                                            ${validSegs.map(s => `
                                                <span data-testid="frame-range" class="inline-flex items-center rounded bg-[#eaf7cf] text-[#2b8a3e] px-1.5 py-0.5 text-xs font-normal hover:bg-[#ddf2b4] transition-colors cursor-pointer" onclick="event.stopPropagation(); window.app && window.app.seekToTime(${s.sSec})">
                                                    ${formatTimeBadge(s.sSec)} - ${formatTimeBadge(s.eSec)}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                    ` : ''}

                                    <!-- Row 3: Transcript Badge (if present) -->
                                    ${(instr.text && String(instr.text).trim().length > 0) ? `
                                    <div class="flex items-center mt-0.5">
                                        <span class="inline-flex items-center rounded border border-[#adc6ff] bg-[#f0f5ff] px-2 py-0.5 text-xs text-[#1d39c4]">
                                            <strong class="font-bold mr-1.5">${isSameClass(instr.className, 'Audio quality') ? 'Quality' : 'Transcript'}</strong> ${escapeHtml(instr.text)}
                                        </span>
                                    </div>
                                    ` : ''}
                                </div>
                            `;
                }).join('')}
                    </div>
                `;
            }

            html += `</div>`;
        });

        html += `</div>`;
        this.container.innerHTML = html;
    }
}

class AudioAnnotationApp {
    constructor() {
        this.videoController = null;
        this.annotationModel = null;
        this.dragState = null;
        this.progressBarView = null;
        this.timelineView = null;
        this.waveformRenderer = null;
        this.scrollSync = null;
        this.displayTimestamps = true;
        this.timestampFormat = 'MM:SS';

        this.frameInput = null;
        this.totalFramesText = null;
        this.audioName = "VID_20260328_134136_401_3min.mp3";

        this.showSkipSelector = true;
        this.groupByClass = true;
        this.showSelectedOnly = false;
        this.classificationMode = 'single';
        this.limitSingleFrame = false;
        this.propagateAcrossGaps = false;
        this.currentViz = 'Waveform';

        this.activeClassId = 'speaker_1';
        this.editingAnnotationIndex = -1;
        this.editingSegmentIndex = null;
        this.selectionMode = 'none'; // 'none', 'individual', 'row', 'group'
        this.selectionLevel = null; // 'range' or 'group'
        this.selectedGroupInstrIndices = [];
        this.deselectedSegmentIndices = new Set();
        this.rangePlaybackLimitSec = null;
        this.rangePlaybackStartFrame = null;
        this.isSeekingForRangePlayback = false;
        this.isPlayingRangeSequence = false;
        this.onRangePlaybackEnd = null;
        this.lockedRows = {};
        this.hiddenRows = {};
        this.lockedInstances = {};
        this.hiddenInstances = {};
        this.instructionRenderer = null;
    }

    resolveAudioUrl() {
        const audio = document.getElementById('mainAudio');
        if (!audio) return "VID_20260328_134136_401_3min.mp3";

        // 1. Check currentSrc
        if (audio.currentSrc && !audio.currentSrc.includes('{{')) {
            return audio.currentSrc;
        }
        // 2. Check src attribute
        if (audio.src && !audio.src.includes('{{')) {
            return audio.src;
        }
        // 3. Check <source> children
        const sources = Array.from(audio.querySelectorAll('source'));
        for (const srcEl of sources) {
            const rawSrc = srcEl.getAttribute('src') || srcEl.src;
            if (rawSrc && !rawSrc.includes('{{')) {
                return rawSrc;
            }
        }
        return "VID_20260328_134136_401_3min.mp3";
    }

    updateAudioNameDisplay(url) {
        if (!url) return;
        try {
            const cleanUrl = url.split('?')[0].split('#')[0];
            const fileName = cleanUrl.substring(cleanUrl.lastIndexOf('/') + 1) || url;
            if (fileName && !fileName.includes('{{')) {
                this.audioName = fileName;
                const el = document.getElementById('audioNameDisplay');
                if (el) {
                    el.innerText = fileName;
                    el.title = fileName;
                }
            }
        } catch (e) {
            console.error("Error updating audio name display:", e);
        }
    }

    initialize() {
        const audio = document.getElementById('mainAudio');
        this.videoController = new VideoController(audio);
        this.annotationModel = new AnnotationModel();
        this.dragState = new DragState();

        const canvas = document.getElementById('waveformCanvas');
        this.waveformRenderer = new AudioWaveformRenderer(canvas);

        this.progressBarView = new ProgressBarView(
            document.getElementById('progressFill'),
            document.getElementById('progressKnob'),
            document.getElementById('progressTrack'),
            document.getElementById('hoverPill')
        );

        this.timelineView = new TimelineView(
            document.getElementById('timeRuler'),
            document.getElementById('tracksContainer'),
            document.getElementById('vPlayhead'),
            {
                labelsBody: document.getElementById('labelsBody'),
                tracksContainer: document.getElementById('tracksContainer')
            }
        );

        this.scrollSync = new ScrollSynchronizer(
            document.getElementById('timelineContentColumn'),
            document.getElementById('vPlayhead')
        );

        this.instructionRenderer = new InstructionListRenderer(
            document.getElementById('instructionContainer')
        );

        this.frameInput = document.getElementById('currentFrameInput');
        this.totalFramesText = document.getElementById('totalFramesText');

        this.renderClassList();
        this.renderInstructions();
        this.setupEventListeners();
        this.setupResizers();
        this.setupFormSubmission();

        this.videoController.addTimeUpdateListener(() => this.onVideoTimeUpdate());
        this.videoController.addMetadataLoadedListener(() => this.onVideoMetadataLoaded());

        // Load waveform dynamically
        const audioUrl = this.resolveAudioUrl();
        this.updateAudioNameDisplay(audioUrl);
        this.waveformRenderer.loadAudio(audioUrl);

        // Sync initial Content Navigation toolbar values
        const valEl = document.getElementById('skipIntervalVal');
        if (valEl) valEl.innerText = this.videoController.frameSkip || 6;
        const speedDisplay = document.getElementById('speedDisplayVal');
        if (speedDisplay) speedDisplay.innerText = (this.videoController.playbackRate || 1) + 'x';

        // Initial metadata trigger
        this.onVideoMetadataLoaded();

        // Initialize Global Tooltips
        initGlobalTooltipManager();
    }

    setupResizers() {
        // 1. Sidebar Width Resizer (#sidebarVResizer)
        const sidebar = document.getElementById('sidebar');
        const vResizer = document.getElementById('sidebarVResizer');
        const app = this;
        if (sidebar && vResizer) {
            vResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const startX = e.clientX;
                const startWidth = sidebar.offsetWidth;
                vResizer.classList.add('is-resizing');
                document.body.style.cursor = 'ew-resize';
                document.body.classList.add('select-none');

                const onMouseMove = (moveEvent) => {
                    moveEvent.preventDefault();
                    const deltaX = moveEvent.clientX - startX;
                    const newWidth = Math.max(320, Math.min(700, startWidth + deltaX));
                    sidebar.style.setProperty('width', `${newWidth}px`, 'important');
                    sidebar.style.setProperty('min-width', `${newWidth}px`, 'important');
                    sidebar.style.setProperty('max-width', `${newWidth}px`, 'important');
                    sidebar.style.flex = 'none';
                    sidebar.style.flexShrink = '0';
                    window.dispatchEvent(new Event('resize'));
                    if (app.waveformRenderer && app.timelineView) {
                        app.waveformRenderer.render(
                            app.videoController ? app.videoController.duration : 180,
                            app.timelineView.currentPPS
                        );
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    vResizer.classList.remove('is-resizing');
                    const finalWidth = Math.max(320, sidebar.offsetWidth);
                    sidebar.style.setProperty('width', `${finalWidth}px`, 'important');
                    sidebar.style.setProperty('min-width', '320px');
                    sidebar.style.setProperty('max-width', '700px');
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                    window.dispatchEvent(new Event('resize'));
                    if (app.waveformRenderer && app.timelineView) {
                        app.waveformRenderer.render(
                            app.videoController ? app.videoController.duration : 180,
                            app.timelineView.currentPPS
                        );
                    }
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        // 2. Classes vs Labels Split Resizer (#sidebarHResizer)
        const hResizer = document.getElementById('sidebarHResizer');
        const classesSection = document.getElementById('classesSection');
        const labelsSection = document.getElementById('labelsSection');
        if (hResizer && classesSection && labelsSection) {
            hResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startY = e.clientY;
                const startHeight = classesSection.offsetHeight;
                hResizer.classList.add('is-resizing');
                document.body.style.cursor = 'ns-resize';
                document.body.classList.add('select-none');

                const onMouseMove = (moveEvent) => {
                    const deltaY = moveEvent.clientY - startY;
                    const sidebarHeight = sidebar ? sidebar.offsetHeight : 600;
                    const newHeight = Math.max(60, Math.min(sidebarHeight - 140, startHeight + deltaY));
                    classesSection.style.height = `${newHeight}px`;
                    classesSection.style.flex = 'none';
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    hResizer.classList.remove('is-resizing');
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        // 3. Labels vs Available Actions Resizer (#actionsHResizer)
        const actionsResizer = document.getElementById('actionsHResizer');
        const availableActionsBody = document.getElementById('availableActionsBody');
        const availableActionsSection = document.getElementById('availableActionsSection');
        if (actionsResizer && availableActionsBody && availableActionsSection) {
            actionsResizer.addEventListener('mousedown', (e) => {
                // If collapsed at the bottom, ignore resizing
                if (availableActionsBody.classList.contains('hidden')) return;
                e.preventDefault();
                const startY = e.clientY;
                const startHeight = availableActionsSection.offsetHeight;
                actionsResizer.classList.add('is-resizing');
                availableActionsSection.style.transition = 'none';
                document.body.style.cursor = 'ns-resize';
                document.body.classList.add('select-none');

                const sidebar = document.getElementById('sidebar');
                const classesSection = document.getElementById('classesSection');

                const onMouseMove = (moveEvent) => {
                    const deltaY = startY - moveEvent.clientY; // dragging UP expands available actions
                    const naturalHeight = 138;
                    const sidebarRect = sidebar ? sidebar.getBoundingClientRect() : { bottom: window.innerHeight };
                    const classesBottom = classesSection ? classesSection.getBoundingClientRect().bottom : 0;
                    // Labels panel needs at least 200px to maintain its header and empty state intact without clipping
                    const maxAllowedHeight = Math.max(naturalHeight, (sidebarRect.bottom - classesBottom) - 210);
                    const newHeight = Math.max(naturalHeight, Math.min(maxAllowedHeight, startHeight + deltaY));

                    availableActionsSection.style.height = `${newHeight}px`;
                    this.savedActionsHeight = newHeight;
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    actionsResizer.classList.remove('is-resizing');
                    availableActionsSection.style.transition = '';
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        // 4. Timeline Labels Column Resizer (#timelineLabelsResizer)
        const timelineLabelsResizer = document.getElementById('timelineLabelsResizer');
        const timelineLabelsColumn = document.getElementById('timelineLabelsColumn');
        if (timelineLabelsResizer && timelineLabelsColumn) {
            timelineLabelsResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startX = e.clientX;
                const startWidth = timelineLabelsColumn.offsetWidth;
                timelineLabelsResizer.classList.add('is-resizing');
                document.body.style.cursor = 'ew-resize';
                document.body.classList.add('select-none');

                const onMouseMove = (moveEvent) => {
                    const deltaX = moveEvent.clientX - startX;
                    const newWidth = Math.max(90, Math.min(480, startWidth + deltaX));
                    timelineLabelsColumn.style.setProperty('width', `${newWidth}px`, 'important');
                    timelineLabelsColumn.style.setProperty('min-width', `${newWidth}px`, 'important');
                    timelineLabelsColumn.style.setProperty('max-width', `${newWidth}px`, 'important');
                    window.dispatchEvent(new Event('resize'));
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    timelineLabelsResizer.classList.remove('is-resizing');
                    const finalWidth = timelineLabelsColumn.offsetWidth;
                    timelineLabelsColumn.style.setProperty('width', `${finalWidth}px`, 'important');
                    timelineLabelsColumn.style.setProperty('min-width', '90px');
                    timelineLabelsColumn.style.setProperty('max-width', '480px');
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                    window.dispatchEvent(new Event('resize'));
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        // 5. Waveform Track Height Resizer (#waveformHResizer)
        const waveformResizer = document.getElementById('waveformHResizer');
        const videoTrackContainer = document.getElementById('videoTrackContainer');
        const audioLabelContainer = document.getElementById('audioLabelContainer');
        const labelsHeader = document.getElementById('labelsHeader');

        if (waveformResizer && videoTrackContainer) {
            waveformResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startY = e.clientY;
                const startHeight = videoTrackContainer.offsetHeight;
                waveformResizer.classList.add('is-resizing');
                document.body.style.cursor = 'ns-resize';
                document.body.classList.add('select-none');

                const onMouseMove = (moveEvent) => {
                    const deltaY = moveEvent.clientY - startY;
                    const maxLimit = Math.max(800, (document.getElementById('timelineSection')?.clientHeight || 600) - 60);
                    const newHeight = Math.max(24, Math.min(maxLimit, startHeight + deltaY));
                    videoTrackContainer.style.height = `${newHeight}px`;
                    videoTrackContainer.style.minHeight = `${newHeight}px`;
                    if (audioLabelContainer) {
                        audioLabelContainer.style.height = `${newHeight}px`;
                        audioLabelContainer.style.minHeight = `${newHeight}px`;
                    }
                    if (labelsHeader) {
                        labelsHeader.style.height = `${32 + newHeight}px`;
                        labelsHeader.style.minHeight = `${32 + newHeight}px`;
                    }

                    if (this.waveformRenderer && this.timelineView) {
                        this.waveformRenderer.render(
                            this.timelineView.videoDuration,
                            this.timelineView.currentPPS,
                            newHeight
                        );
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    waveformResizer.classList.remove('is-resizing');
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }
    }

    setActiveClass(classId, rerenderTracks = false) {
        if (!classId) return;
        this.activeClassId = classId;
        this.renderClassList();

        // Update the active track visual state in-place without destroying DOM
        const isRowMode = (this.selectionMode === 'row');
        const isGrouped = (this.groupByClass !== false);
        const labelRows = document.querySelectorAll('.label-row');
        labelRows.forEach(row => {
            const rowClassId = row.getAttribute('data-class-id');
            const isParentHeader = isGrouped && !row.hasAttribute('data-instr-idx');
            const isActive = isRowMode && (rowClassId === classId) && !isParentHeader;
            row.classList.toggle('is-active-row', isActive);
            row.classList.toggle('is-selected', isActive);
            row.classList.toggle('clicked-track-highlight', isActive);
            if (isActive) {
                row.classList.remove('border-l-transparent');
                row.classList.add('border-l-[#52c41a]');
            } else {
                row.classList.remove('border-l-[#52c41a]');
                row.classList.add('border-l-transparent');
            }
        });

        const dataRows = document.querySelectorAll('.data-row');
        dataRows.forEach(row => {
            const rowClassId = row.getAttribute('data-class-id');
            const isParentHeader = isGrouped && !row.hasAttribute('data-instr-idx');
            const isActive = isRowMode && (rowClassId === classId) && !isParentHeader;
            row.classList.toggle('is-active-row', isActive);
            row.classList.toggle('is-selected', isActive);
            row.classList.toggle('clicked-track-highlight', isActive);
        });

        // Update range bar highlights
        this.updateRangeHighlights();

        if ((rerenderTracks || this.showSelectedOnly) && this.timelineView) {
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
    }

    /**
     * Select an individual range (click on a specific range bar).
     * Only that single range gets the golden outline.
     */
    selectIndividualRange(instrIdx, segIdx = null) {
        this.selectionLevel = 'range';
        this.selectionMode = 'individual';
        this.editingAnnotationIndex = instrIdx;
        this.editingSegmentIndex = (typeof segIdx === 'number') ? segIdx : null;
        this.selectedGroupInstrIndices = [instrIdx];
        this.deselectedSegmentIndices = new Set();
        // Set activeClassId based on the instruction's class
        const instr = this.annotationModel.instructions[instrIdx];
        if (instr) {
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
            if (cls) this.activeClassId = cls.id;
            if (typeof segIdx === 'number') {
                const segs = (instr.frames || '').split(' | ').filter(Boolean);
                if (segs[segIdx]) {
                    const parts = segs[segIdx].split(' - ').map(Number);
                    if (!isNaN(parts[0])) {
                        this.seekToTime(parts[0] / CONFIG.FPS);
                    }
                }
            }
        }
        this.openFullEditSidebar(instrIdx, segIdx);
    }

    selectParentClassGroup(className) {
        if (!className || !this.annotationModel) return;
        const matchingItems = this.annotationModel.instructions
            .map((ins, idx) => ({ ins, idx }))
            .filter(item => isSameClass(item.ins.className, className));
        if (matchingItems.length === 0) return;

        const matchingIndices = matchingItems.map(item => item.idx);
        this.selectedGroupInstrIndices = matchingIndices;
        this.editingAnnotationIndex = matchingIndices[0];
        this.editingSegmentIndex = null;
        this.selectionLevel = 'group';
        this.selectionMode = 'group';
        this.deselectedSegmentIndices = new Set();

        const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, className));
        if (cls) this.activeClassId = cls.id;

        const sidebar = document.getElementById('fullEditSidebar');
        const classesSection = document.getElementById('classesSection');
        const labelsSection = document.getElementById('labelsSection');
        if (classesSection) classesSection.classList.add('hidden');
        if (labelsSection) labelsSection.classList.add('hidden');
        if (sidebar) {
            sidebar.classList.remove('hidden');
            sidebar.style.display = 'flex';
        }

        this.renderFullEditSidebarContent();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    selectGroup(instrIdx, instrIndices = null) {
        if (instrIdx === undefined || instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const targetInstr = this.annotationModel.instructions[instrIdx];
        const allMatchingIndices = targetInstr ? this.annotationModel.instructions
            .map((ins, idx) => ({ ins, idx }))
            .filter(item => isSameClass(item.ins.className, targetInstr.className))
            .map(item => item.idx) : [instrIdx];

        this.selectedGroupInstrIndices = (instrIndices && instrIndices.length > 0) ? instrIndices : allMatchingIndices;
        this.editingAnnotationIndex = instrIdx;
        this.editingSegmentIndex = null;
        this.selectionLevel = 'group';
        this.selectionMode = 'group';
        this.deselectedSegmentIndices = new Set();

        const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, targetInstr.className));
        if (cls) this.activeClassId = cls.id;

        const sidebar = document.getElementById('fullEditSidebar');
        const classesSection = document.getElementById('classesSection');
        const labelsSection = document.getElementById('labelsSection');
        if (classesSection) classesSection.classList.add('hidden');
        if (labelsSection) labelsSection.classList.add('hidden');
        if (sidebar) {
            sidebar.classList.remove('hidden');
            sidebar.style.display = 'flex';
        }

        this.renderFullEditSidebarContent();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    dismissGroupHighlight() {
        this.selectionLevel = null;
        this.selectionMode = 'none';
        this.selectedGroupInstrIndices = [];
        this.editingAnnotationIndex = -1;
        this.editingSegmentIndex = null;
        this.deselectedSegmentIndices = new Set();
        this.closeFullEditSidebar();
    }

    deselectRangeSegment(instrIdx, sIdx) {
        if (!this.deselectedSegmentIndices) {
            this.deselectedSegmentIndices = new Set();
        }
        const key = `${instrIdx}_${sIdx}`;
        this.deselectedSegmentIndices.add(key);
        this.deselectedSegmentIndices.add(Number(sIdx));

        const targetIndices = (this.selectedGroupInstrIndices && this.selectedGroupInstrIndices.length > 0)
            ? this.selectedGroupInstrIndices.filter(i => i >= 0 && i < this.annotationModel.instructions.length)
            : (this.editingAnnotationIndex !== -1 ? [this.editingAnnotationIndex] : []);

        const remainingActive = [];
        targetIndices.forEach(iIdx => {
            const ins = this.annotationModel.instructions[iIdx];
            if (!ins) return;
            const segs = (ins.frames || '').split(' | ').filter(Boolean);
            segs.forEach((segStr, segIdx) => {
                const segKey = `${iIdx}_${segIdx}`;
                if (!this.deselectedSegmentIndices.has(segKey) && !this.deselectedSegmentIndices.has(segIdx)) {
                    const parts = segStr.split(' - ').map(Number);
                    remainingActive.push({
                        instrIdx: iIdx,
                        sIdx: segIdx,
                        start: isNaN(parts[0]) ? 0 : parts[0],
                        end: isNaN(parts[1]) ? 0 : parts[1]
                    });
                }
            });
        });

        if (remainingActive.length === 0) {
            this.dismissGroupHighlight();
            return;
        }

        if (remainingActive.length === 1) {
            const only = remainingActive[0];
            this.selectIndividualRange(only.instrIdx, only.sIdx);
            return;
        }

        this.renderFullEditSidebarContent();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    /**
     * Select an entire class row (click on label-row or data-row empty space).
     * All ranges belonging to that class get highlighted.
     */
    selectClassRow(classId) {
        // If already in row mode for the same class, toggle off (deselect)
        if (this.selectionMode === 'row' && this.activeClassId === classId) {
            this.deselectAll();
            return;
        }
        this.selectionMode = 'row';
        this.editingAnnotationIndex = -1;
        this.editingSegmentIndex = null;
        this.activeClassId = classId;

        // Close full edit sidebar if open
        const sidebar = document.getElementById('fullEditSidebar');
        if (sidebar && !sidebar.classList.contains('hidden')) {
            sidebar.classList.add('hidden');
            sidebar.style.display = 'none';
            const classesSection = document.getElementById('classesSection');
            const labelsSection = document.getElementById('labelsSection');
            if (classesSection) classesSection.classList.remove('hidden');
            if (labelsSection) labelsSection.classList.remove('hidden');
        }

        this.renderClassList();
        this.setActiveClass(classId);
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    /**
     * Deselect all - clicking outside any range or label.
     * Clears all selection state and removes all highlights.
     */
    deselectAll() {
        this.selectionMode = 'none';
        this.editingAnnotationIndex = -1;
        this.editingSegmentIndex = null;
        this.activeClassId = null;

        // Close full edit sidebar if open
        const sidebar = document.getElementById('fullEditSidebar');
        if (sidebar && !sidebar.classList.contains('hidden')) {
            sidebar.classList.add('hidden');
            sidebar.style.display = 'none';
            const classesSection = document.getElementById('classesSection');
            const labelsSection = document.getElementById('labelsSection');
            if (classesSection) classesSection.classList.remove('hidden');
            if (labelsSection) labelsSection.classList.remove('hidden');
        }

        // Remove all row highlights
        document.querySelectorAll('.label-row').forEach(row => {
            row.classList.remove('is-active-row', 'is-selected', 'clicked-track-highlight');
            row.classList.remove('border-l-[#52c41a]');
            row.classList.add('border-l-transparent');
        });
        document.querySelectorAll('.data-row').forEach(row => {
            row.classList.remove('is-active-row', 'is-selected', 'clicked-track-highlight');
        });

        // Remove range highlights
        this.updateRangeHighlights();

        this.renderClassList();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    /**
     * Update range bar highlights based on current selectionMode.
     */
    updateRangeHighlights() {
        const allRanges = document.querySelectorAll('[data-testid="range"]');
        allRanges.forEach(range => {
            const instrIdx = parseInt(range.getAttribute('data-instr-idx'), 10);
            const segIdx = parseInt(range.getAttribute('data-seg-idx'), 10);
            let shouldHighlight = false;

            if (this.selectionMode === 'individual' && instrIdx === this.editingAnnotationIndex) {
                if (this.editingSegmentIndex === null || this.editingSegmentIndex === undefined || isNaN(segIdx) || segIdx === this.editingSegmentIndex) {
                    shouldHighlight = true;
                }
            } else if (this.selectionMode === 'row' && this.activeClassId) {
                const instr = this.annotationModel.instructions[instrIdx];
                if (instr) {
                    const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
                    if (cls && cls.id === this.activeClassId) {
                        shouldHighlight = true;
                    }
                }
            }

            if (shouldHighlight) {
                range.classList.add('range-active-highlight');
                range.setAttribute('data-active', 'true');
            } else {
                range.classList.remove('range-active-highlight');
                range.removeAttribute('data-active');
            }
        });
    }

    renderClassList() {
        const container = document.getElementById('classListContainer');
        if (!container) return;

        container.innerHTML = CONFIG.CLASSES.map((cls, idx) => {
            let iconSvg = PARTITION_ICON_SVG;
            let extraBadge = '';
            if (cls.id === 'speaker_1') {
                iconSvg = getSpeakerIconSVG('rgb(253, 161, 255)');
            } else if (cls.id === 'speaker_2') {
                iconSvg = getSpeakerIconSVG('rgb(211, 49, 21)');
            } else if (cls.id === 'audio_quality') {
                extraBadge = `<span class="text-[#ff4d4f] font-bold ml-1.5 text-[14px] leading-none select-none">✱</span>`;
            }

            const isActive = (this.activeClassId === cls.id);

            return `
                <div class="class-item group flex items-center justify-between px-2.5 py-2 cursor-pointer ${isActive ? 'bg-gray-200/70 font-medium' : 'hover:bg-gray-100/70'} rounded-md transition-colors"
                     onclick="event.stopPropagation(); window.app && window.app.handleClassClick('${cls.id}')">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="anticon shrink-0 flex items-center justify-center">${iconSvg}</span>
                        <div class="flex items-center min-w-0">
                            <span class="text-[13.5px] font-[450] text-[#262626] truncate select-none">${cls.name}</span>
                            ${extraBadge}
                        </div>
                    </div>
                    <span class="flex items-center justify-center w-5 h-5 border border-gray-200 rounded text-[11px] font-medium text-gray-500 bg-[#fafafa] select-none shrink-0">${idx + 1}</span>
                </div>
            `;
        }).join('');
    }

    toggleAvailableActions() {
        const body = document.getElementById('availableActionsBody');
        const chevron = document.getElementById('availableActionsChevron');
        const section = document.getElementById('availableActionsSection');
        const actionsResizer = document.getElementById('actionsHResizer');
        if (!body || !chevron) return;
        if (body.classList.contains('hidden')) {
            body.classList.remove('hidden');
            chevron.style.transform = 'rotate(0deg)';
            if (section) {
                section.style.height = this.savedActionsHeight ? `${this.savedActionsHeight}px` : 'auto';
            }
            if (actionsResizer) actionsResizer.style.display = 'block';
        } else {
            if (section && section.style.height && section.style.height !== 'auto') {
                this.savedActionsHeight = section.offsetHeight;
                section.style.height = 'auto';
            }
            body.classList.add('hidden');
            chevron.style.transform = 'rotate(180deg)';
            if (actionsResizer) actionsResizer.style.display = 'none';
        }
    }

    toggleFullEditActions() {
        const body = document.getElementById('fullEditActionsBody');
        const chevron = document.getElementById('fullEditActionsChevron');
        if (!body || !chevron) return;
        if (body.classList.contains('hidden')) {
            body.classList.remove('hidden');
            chevron.style.transform = 'rotate(0deg)';
        } else {
            body.classList.add('hidden');
            chevron.style.transform = 'rotate(180deg)';
        }
    }

    getInstanceIndex(instruction) {
        if (!instruction || !this.annotationModel) return 0;
        const matching = this.annotationModel.instructions.filter(ins => isSameClass(ins.className, instruction.className));
        const idx = matching.indexOf(instruction);
        return idx !== -1 ? idx : 0;
    }

    calculatePointClickRange(className, currentFrame) {
        if (!this.annotationModel) return { start: 0, end: 0, isExisting: false };
        const cf = Math.max(0, Math.round(Number(currentFrame) || 0));

        // Gather all existing segments for this class
        const validSegments = [];
        this.annotationModel.instructions.forEach((ins, instrIdx) => {
            if (!isSameClass(ins.className, className)) return;
            const segs = (ins.frames || '').split(' | ').filter(Boolean);
            segs.forEach((seg, rangeIdx) => {
                const parts = seg.split(' - ').map(s => Number(s.trim()));
                if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                    const s = parts[0];
                    const e = parts[1];
                    validSegments.push({
                        start: s,
                        end: e,
                        instrIdx,
                        rangeIdx
                    });
                }
            });
        });

        // 1. Sort ascending by start frame
        validSegments.sort((a, b) => a.start - b.start || a.end - b.end);

        // 2. Check if currentFrame falls inside an existing range
        const inside = validSegments.find(seg => cf >= seg.start && cf <= seg.end);
        if (inside) {
            return {
                start: inside.start,
                end: inside.end,
                isExisting: true,
                instrIdx: inside.instrIdx,
                rangeIdx: inside.rangeIdx
            };
        }

        // 3. Single frame mode (either 'single' mode or default)
        const isSingle = (this.classificationMode !== 'back_propagate');
        if (isSingle) {
            return { start: cf, end: cf, isExisting: false };
        }

        // 4. Back propagate mode
        // Find preceding ranges whose endFrame <= cf
        const preceding = validSegments.filter(seg => seg.end <= cf);
        if (preceding.length === 0) {
            return { start: 0, end: cf, isExisting: false };
        }

        // Find max end frame among preceding ranges
        const maxEnd = Math.max(...preceding.map(seg => seg.end));
        let startF = maxEnd;
        if (startF > cf) {
            startF = cf;
        }

        return { start: startF, end: cf, isExisting: false };
    }

    handleClassClick(classId) {
        const cls = CONFIG.CLASSES.find(c => c.id === classId || c.name === classId);
        if (!cls) return;

        const isAudioQuality = isSameClass(cls.name, 'Audio quality');
        const defaultText = '';
        const currentF = this.videoController ? this.videoController.getCurrentFrame() : 0;

        const target = this.calculatePointClickRange(cls.name, currentF);

        if (target.isExisting) {
            const targetIdx = target.instrIdx;
            this.activeClassId = cls.id;
            this.selectIndividualRange(targetIdx, target.rangeIdx);
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
            this.renderInstructions();
            if (this.waveformRenderer && this.timelineView) {
                this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
            }
            return;
        }

        const startF = target.start;
        const endF = target.end;

        // Clicking in left classes panel creates a NEW instance/class row!
        const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;

        this.annotationModel.instructions.push({
            id: newId,
            segmentId: newId,
            className: cls.name,
            frames: `${startF} - ${endF}`,
            text: defaultText,
            timestamp: Date.now()
        });

        if (isAudioQuality && endF > startF) {
            this.resolveNonOverlappingRanges('Audio quality', startF, endF, newId);
        }
        const targetIdx = this.annotationModel.instructions.findIndex(i => i.id === newId || i.segmentId === newId);

        if (this.groupByClass) {
            if (!this.collapsedRows) this.collapsedRows = {};
            this.collapsedRows[cls.id] = false; // Auto expand parent
        }

        this.activeClassId = cls.id;
        this.selectIndividualRange(targetIdx !== -1 ? targetIdx : this.annotationModel.instructions.length - 1, 0);
        if (!isAudioQuality && this.checkShowInstanceHint) {
            this.checkShowInstanceHint(cls);
        }

        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    checkShowInstanceHint(cls) {
        if (!cls || (cls.id !== 'speaker_1' && cls.id !== 'speaker_2')) return;
        try {
            if (localStorage.getItem('hideInstanceLabelHint') === 'true') return;
        } catch (e) { }

        const toast = document.getElementById('instanceLabelToast');
        if (toast) {
            toast.classList.remove('hidden');
            toast.style.display = 'flex';
        }
    }

    dismissInstanceHint(forcePermanent = false) {
        const toast = document.getElementById('instanceLabelToast');
        if (toast) {
            toast.classList.add('hidden');
            toast.style.display = 'none';
        }
        const chk = document.getElementById('dontShowAgainCheckbox');
        if (forcePermanent || (chk && chk.checked)) {
            try {
                localStorage.setItem('hideInstanceLabelHint', 'true');
            } catch (e) { }
        }
    }

    /**
     * Toggle or set the Right Transcript Panel state.
     */
    toggleTranscriptPanel(forceState) {
        const panel = document.getElementById('transcriptPanel');
        const btn = document.getElementById('showTranscriptBtn');
        if (!panel) return;

        const isHidden = panel.classList.contains('hidden');
        const show = (forceState !== undefined) ? forceState : isHidden;

        if (show) {
            panel.classList.remove('hidden');
            if (btn) {
                btn.setAttribute('aria-pressed', 'true');
                btn.classList.add('bg-gray-200', 'text-black');
            }
            this.renderTranscriptPanel();
        } else {
            panel.classList.add('hidden');
            if (btn) {
                btn.setAttribute('aria-pressed', 'false');
                btn.classList.remove('bg-gray-200', 'text-black');
            }
        }
    }

    /**
     * Render contents of the Right Transcript Panel.
     * Shows empty state if no transcript segments exist, or lists transcript segments.
     */
    renderTranscriptPanel() {
        const emptyState = document.getElementById('transcriptEmptyState');
        const segmentsList = document.getElementById('transcriptSegmentsList');
        if (!emptyState || !segmentsList) return;

        const instructions = this.annotationModel ? this.annotationModel.getInstructions() : [];
        const transcriptSegments = instructions.filter(ins => ins.text && ins.text.trim() !== '');

        if (transcriptSegments.length === 0) {
            emptyState.classList.remove('hidden');
            segmentsList.classList.add('hidden');
            segmentsList.innerHTML = '';
        } else {
            emptyState.classList.add('hidden');
            segmentsList.classList.remove('hidden');
            segmentsList.innerHTML = transcriptSegments.map(ins => {
                const realIdx = instructions.indexOf(ins);
                return `
                    <div class="p-3 rounded-lg border border-gray-100 bg-gray-50/80 hover:bg-gray-100/90 transition-colors text-[13px] cursor-pointer" onclick="window.app && window.app.selectIndividualRange(${realIdx})">
                        <div class="flex items-center justify-between text-gray-500 text-[11px] mb-1 font-medium">
                            <span class="text-gray-700">${ins.className || 'Segment'}</span>
                            <span>${ins.start !== undefined ? Number(ins.start).toFixed(3) : '0.000'}s - ${ins.end !== undefined ? Number(ins.end).toFixed(3) : '0.000'}s</span>
                        </div>
                        <div class="text-gray-800 font-normal leading-relaxed">${ins.text}</div>
                    </div>
                `;
            }).join('');
        }
    }

    openFullEditSidebar(index, segIdx = null) {
        if (index === undefined || index < 0 || index >= this.annotationModel.instructions.length) return;
        this.editingAnnotationIndex = index;
        if (typeof segIdx === 'number') {
            this.editingSegmentIndex = segIdx;
        } else {
            this.editingSegmentIndex = null;
        }
        if (this.selectionLevel !== 'group') {
            this.selectionLevel = 'range';
            this.selectionMode = 'individual';
        }

        const instr = this.annotationModel.instructions[index];
        if (instr) {
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
            if (cls) {
                this.activeClassId = cls.id;
                this.renderClassList();
            }
        }

        const sidebar = document.getElementById('fullEditSidebar');
        const classesSection = document.getElementById('classesSection');
        const labelsSection = document.getElementById('labelsSection');

        if (classesSection) classesSection.classList.add('hidden');
        if (labelsSection) labelsSection.classList.add('hidden');
        if (sidebar) {
            sidebar.classList.remove('hidden');
            sidebar.style.display = 'flex';
        }

        this.renderFullEditSidebarContent();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    closeFullEditSidebar() {
        this.editingAnnotationIndex = -1;
        this.editingSegmentIndex = null;
        this.selectionMode = 'none';
        this.selectionLevel = null;
        this.selectedGroupInstrIndices = [];
        this.deselectedSegmentIndices = new Set();
        const sidebar = document.getElementById('fullEditSidebar');
        const classesSection = document.getElementById('classesSection');
        const labelsSection = document.getElementById('labelsSection');

        if (sidebar) {
            sidebar.classList.add('hidden');
            sidebar.style.display = 'none';
        }
        if (classesSection) classesSection.classList.remove('hidden');
        if (labelsSection) labelsSection.classList.remove('hidden');

        const headerRow = document.getElementById('fullEditHeaderRow');
        const classInputArea = document.getElementById('fullEditClassInputArea');
        const doneWrap = document.getElementById('fullEditDoneBtnWrap');
        if (headerRow) headerRow.classList.remove('hidden');
        if (classInputArea) classInputArea.classList.remove('hidden');
        if (doneWrap) doneWrap.classList.remove('hidden');

        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    saveFullEditSidebar() {
        if (this.editingAnnotationIndex !== -1 && this.annotationModel.instructions[this.editingAnnotationIndex]) {
            const instr = this.annotationModel.instructions[this.editingAnnotationIndex];
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
        }

        const output = document.getElementById('annotations_output');
        if (output && this.annotationModel) {
            output.value = JSON.stringify(this.annotationModel.getInstructions());
        }

        this.closeFullEditSidebar();
    }

    deleteCurrentAnnotation() {
        if (this.selectionLevel === 'group') {
            const targetIndices = (this.selectedGroupInstrIndices && this.selectedGroupInstrIndices.length > 0)
                ? [...this.selectedGroupInstrIndices].sort((a, b) => b - a)
                : (this.editingAnnotationIndex !== -1 ? [this.editingAnnotationIndex] : []);

            if (this.deselectedSegmentIndices && this.deselectedSegmentIndices.size > 0) {
                targetIndices.forEach(iIdx => {
                    const instr = this.annotationModel.instructions[iIdx];
                    if (!instr) return;
                    const clsObj = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
                    if (clsObj && this.isRowLocked(clsObj.id, iIdx)) return;
                    const segs = (instr.frames || '').split(' | ').filter(Boolean);
                    const remaining = segs.filter((s, sIdx) => {
                        const segKey = `${iIdx}_${sIdx}`;
                        return !this.deselectedSegmentIndices.has(segKey) && !this.deselectedSegmentIndices.has(sIdx);
                    });
                    if (remaining.length > 0) {
                        instr.frames = remaining.join(' | ');
                    } else {
                        this.annotationModel.instructions.splice(iIdx, 1);
                    }
                });
            } else {
                targetIndices.forEach(iIdx => {
                    if (iIdx >= 0 && iIdx < this.annotationModel.instructions.length) {
                        const instr = this.annotationModel.instructions[iIdx];
                        if (instr) {
                            const clsObj = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
                            if (clsObj && this.isRowLocked(clsObj.id, iIdx)) return;
                        }
                        this.annotationModel.instructions.splice(iIdx, 1);
                    }
                });
            }

            const output = document.getElementById('annotations_output');
            if (output && this.annotationModel) {
                output.value = JSON.stringify(this.annotationModel.getInstructions());
            }

            this.dismissGroupHighlight();
            return;
        }

        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) return;
        const instr = this.annotationModel.instructions[this.editingAnnotationIndex];
        const clsObj = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
        if (clsObj && this.isRowLocked(clsObj.id, this.editingAnnotationIndex)) return;

        const segs = (instr.frames || '').split(' | ').filter(Boolean);
        const segIdx = (typeof this.editingSegmentIndex === 'number') ? this.editingSegmentIndex : null;

        if (segs.length > 1 && segIdx !== null && segIdx >= 0 && segIdx < segs.length) {
            segs.splice(segIdx, 1);
            instr.frames = segs.join(' | ');
            const output = document.getElementById('annotations_output');
            if (output) {
                output.value = JSON.stringify(this.annotationModel.getInstructions());
            }
            this.closeFullEditSidebar();
        } else {
            this.deleteAnnotation(this.editingAnnotationIndex);
        }
    }

    deleteAnnotation(index) {
        if (index < 0 || !this.annotationModel || index >= this.annotationModel.instructions.length) return;
        const ins = this.annotationModel.instructions[index];
        if (!ins) return;
        const clsObj = CONFIG.CLASSES.find(c => isSameClass(c.name, ins.className));
        if (clsObj && this.isRowLocked(clsObj.id, index)) return;

        this.annotationModel.instructions.splice(index, 1);
        if (this.editingAnnotationIndex === index) {
            this.closeFullEditSidebar();
        } else if (this.editingAnnotationIndex > index) {
            this.editingAnnotationIndex--;
        }
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderTranscriptPanel();
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }

        const output = document.getElementById('annotations_output');
        if (output) {
            output.value = JSON.stringify(this.annotationModel.getInstructions());
        }
    }

    selectSegmentPill(sIdx) {
        this.editingSegmentIndex = sIdx;
        this.renderFullEditSidebarContent();
        if (this.timelineView) {
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    renderFullEditSidebarContent() {
        const headerRow = document.getElementById('fullEditHeaderRow');
        const classInputArea = document.getElementById('fullEditClassInputArea');
        const doneWrap = document.getElementById('fullEditDoneBtnWrap');
        let classContentEl = document.getElementById('fullEditClassContent');
        let actionsContainer = document.getElementById('fullEditActionsContainer');

        if (this.selectionLevel === 'group') {
            if (headerRow) headerRow.classList.add('hidden');
            if (classInputArea) classInputArea.classList.add('hidden');
            if (doneWrap) doneWrap.classList.add('hidden');

            const targetIndices = (this.selectedGroupInstrIndices && this.selectedGroupInstrIndices.length > 0)
                ? this.selectedGroupInstrIndices.filter(i => i >= 0 && i < this.annotationModel.instructions.length)
                : (this.editingAnnotationIndex !== -1 ? [this.editingAnnotationIndex] : []);

            const groupCardsData = targetIndices.map(iIdx => {
                const instr = this.annotationModel.instructions[iIdx];
                if (!instr) return null;
                const rawSegs = (instr.frames || '').split(' | ').filter(Boolean);
                const segs = [];
                rawSegs.forEach((rStr, sIdx) => {
                    const segKey = `${iIdx}_${sIdx}`;
                    const isDeselected = this.deselectedSegmentIndices && (this.deselectedSegmentIndices.has(segKey) || this.deselectedSegmentIndices.has(sIdx));
                    if (isDeselected) return;

                    const parts = rStr.split(' - ').map(Number);
                    segs.push({
                        sIdx,
                        rStr,
                        start: isNaN(parts[0]) ? 0 : parts[0],
                        end: isNaN(parts[1]) ? 0 : parts[1]
                    });
                });

                let iconSvg = PARTITION_ICON_SVG;
                if (instr.className === 'Speaker 1') {
                    iconSvg = getSpeakerIconSVG('rgb(253, 161, 255)');
                } else if (instr.className === 'Speaker 2') {
                    iconSvg = getSpeakerIconSVG('rgb(211, 49, 21)');
                }

                return {
                    instrIdx: iIdx,
                    instr,
                    iconSvg,
                    segments: segs
                };
            }).filter(card => card && card.segments.length > 0);

            const totalRegions = groupCardsData.reduce((sum, card) => sum + card.segments.length, 0);

            if (totalRegions === 0) {
                this.dismissGroupHighlight();
                return;
            }

            if (classContentEl) {
                classContentEl.innerHTML = `
                    <div class="flex flex-col px-0.5 mt-0.5 mb-2">
                        <div class="flex items-center justify-between px-0.5 mb-2">
                            <div class="text-[13px] font-semibold text-[#1f2937] select-none flex items-center gap-1.5">
                                <span class="inline-flex items-center justify-center border border-gray-300 rounded px-1.5 py-0 text-xs font-semibold bg-white">${totalRegions}</span>
                                <span>Region${totalRegions === 1 ? '' : 's'} selected</span>
                            </div>
                        </div>
                        ${groupCardsData.map(card => `
                            <div class="border border-gray-200 hover:border-gray-300 rounded-lg p-2.5 bg-white shadow-xs mb-2.5">
                                <div class="flex items-center justify-between pb-2 border-b border-gray-100">
                                    <div class="flex items-center gap-1.5 min-w-0">
                                        <span class="text-black shrink-0 flex items-center justify-center">${card.iconSvg}</span>
                                        <span class="text-[13px] font-[550] text-[#262626] truncate select-none">${card.instr.className}</span>
                                    </div>
                                    <button type="button" class="cursor-pointer text-gray-400 hover:text-gray-700 text-[13px] font-bold p-0.5 select-none transition-colors leading-none" onclick="event.stopPropagation(); window.app && window.app.dismissGroupHighlight()" title="Clear selection">✕</button>
                                </div>
                                <div class="flex flex-wrap items-center gap-1.5 pt-2">
                                    ${card.segments.map((seg) => `
                                        <span class="group-range-pill inline-flex items-center gap-1 px-2 py-0.5 border rounded text-[11.5px] font-medium bg-[#f5f5f5] hover:bg-[#e8e8e8] border-[#d9d9d9] text-gray-700 select-none cursor-pointer transition-all" onclick="event.stopPropagation(); window.app && window.app.selectIndividualRange(${card.instrIdx}, ${seg.sIdx})">
                                            <span>${this.formatDisplay(seg.start)} - ${this.formatDisplay(seg.end)}</span>
                                            <span class="pill-delete-x text-gray-400 hover:text-gray-800 text-[11px] font-bold ml-0.5 leading-none cursor-pointer" onclick="event.stopPropagation(); window.app && window.app.deselectRangeSegment(${card.instrIdx}, ${seg.sIdx})" title="Deselect range">✕</span>
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `;
            }

            if (actionsContainer) {
                actionsContainer.innerHTML = `
                    <div class="flex items-center justify-between font-[648] text-[13.5px] text-gray-900 mb-1 select-none cursor-pointer py-1" onclick="window.app && window.app.toggleFullEditActions()">
                        <span>Available actions</span>
                        <div class="flex items-center justify-center w-5 h-5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-800 transition-colors cursor-pointer text-[13px]">
                            <svg id="fullEditActionsChevron" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" height="14" width="14" class="transition-transform duration-200" style="transform: rotate(180deg);"><path d="m6 9 6 6 6-6"></path></svg>
                        </div>
                    </div>
                    <div id="fullEditActionsBody" class="hidden space-y-1.5 text-[11.5px] text-gray-700 select-none pt-1 pb-1">
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app && window.app.deleteCurrentAnnotation()">
                            <span>Delete selected</span>
                            <div class="flex items-center gap-1">
                                <span class="action-kbd">DEL</span>
                                <span class="text-gray-400">/</span>
                                <span class="action-kbd">⌫</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app && window.app.changeCurrentClass()">
                            <span>Change class</span>
                            <span class="action-kbd">C</span>
                        </div>
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app && window.app.dismissGroupHighlight()">
                            <span>Clear selection</span>
                            <span class="action-kbd">ESC</span>
                        </div>
                    </div>
                `;
            }
            return;
        }

        if (headerRow) headerRow.classList.remove('hidden');
        if (classInputArea) classInputArea.classList.remove('hidden');
        if (doneWrap) doneWrap.classList.remove('hidden');

        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) {
            this.closeFullEditSidebar();
            return;
        }

        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instruction.className)) || CONFIG.CLASSES[0];

        // 1. Update Header Title & Icon
        const titleEl = document.getElementById('sidebarHeaderTitle');
        const iconEl = document.getElementById('fullEditClassIcon');
        const speakerIconsEl = document.getElementById('fullEditSpeakerIcons');

        let isSpeaker = (cls.id === 'speaker_1' || cls.id === 'speaker_2');

        if (titleEl) {
            if (isSpeaker) {
                titleEl.textContent = `${cls.name} (${this.getInstanceIndex(instruction)})`;
            } else if (isSameClass(cls.name, 'Audio quality')) {
                const aqCount = this.annotationModel.instructions.filter(i => isSameClass(i.className, 'Audio quality')).length;
                titleEl.textContent = aqCount > 1 ? `Audio quality (${this.getInstanceIndex(instruction)})` : `Audio quality`;
            } else {
                titleEl.textContent = cls.name;
            }
        }

        if (iconEl) {
            if (cls.id === 'speaker_1') {
                iconEl.innerHTML = getSpeakerIconSVG('rgb(253, 161, 255)');
            } else if (cls.id === 'speaker_2') {
                iconEl.innerHTML = getSpeakerIconSVG('rgb(211, 49, 21)');
            } else {
                iconEl.innerHTML = PARTITION_ICON_SVG;
            }
        }

        if (speakerIconsEl) {
            if (isSpeaker) {
                speakerIconsEl.classList.remove('hidden');
                speakerIconsEl.classList.add('flex');
            } else {
                speakerIconsEl.classList.add('hidden');
                speakerIconsEl.classList.remove('flex');
            }
        }

        // 2. Update Frames / Time Pill Row
        const segments = (instruction.frames || '0 - 0').split(' | ').filter(Boolean);
        classContentEl = document.getElementById('fullEditClassContent');
        if (classContentEl) {
            classContentEl.innerHTML = `
                <div class="flex items-start gap-1.5 text-[12px] text-gray-500">
                    <span id="sidebarLabelWord" class="shrink-0 mt-0.5">${isSpeaker ? 'Time' : 'Frames'}</span>
                    <div class="flex flex-wrap items-center gap-1.5 flex-1">
                        ${segments.map((seg, sIdx) => {
                const parts = seg.split(' - ').map(Number);
                const sFrame = isNaN(parts[0]) ? 0 : parts[0];
                const eFrame = isNaN(parts[1]) ? 0 : parts[1];
                const startVal = this.formatDisplay(sFrame);
                const endVal = this.formatDisplay(eFrame);
                const isPillActive = (this.editingSegmentIndex === sIdx);
                return `
                                <div class="frame-input-pill inline-flex items-center gap-1 ${isPillActive ? 'bg-[#d9f7be] border-[#389e0d] ring-1 ring-[#389e0d]/40 shadow-xs' : 'bg-[#effadb] border-[#d7f0b2]/60'} px-1.5 py-0.5 rounded border transition-all cursor-pointer"
                                     onclick="window.app && window.app.selectSegmentPill(${sIdx})">
                                    <input type="text" data-sidx="${sIdx}" data-field="start"
                                        class="frame-num-input h-5 text-center bg-white border border-gray-200 rounded text-[12px] font-medium text-gray-800 outline-none focus:border-gray-400 transition-all !px-1 [appearance:textfield]"
                                        style="width: calc(${String(startVal).length}ch + 0.75rem);"
                                        value="${startVal}"
                                        onclick="event.stopPropagation()"
                                        onchange="window.app && window.app.handleFrameInputChange('start', this.value, ${sIdx})" />
                                    <span class="text-[#389e0d] font-medium text-[11px] select-none">-</span>
                                    <input type="text" data-sidx="${sIdx}" data-field="end"
                                        class="frame-num-input h-5 text-center bg-white border border-gray-200 rounded text-[12px] font-medium text-gray-800 outline-none focus:border-gray-400 transition-all !px-1 [appearance:textfield]"
                                        style="width: calc(${String(endVal).length}ch + 0.75rem);"
                                        value="${endVal}"
                                        onclick="event.stopPropagation()"
                                        onchange="window.app && window.app.handleFrameInputChange('end', this.value, ${sIdx})" />
                                </div>
                            `;
            }).join('')}
                    </div>
                </div>
            `;
        }

        // 3. Render Class Input Area
        const container = document.getElementById('fullEditSidebarInputContainer');
        actionsContainer = document.getElementById('fullEditActionsContainer');

        if (cls.id === 'audio_quality') {
            // Audio Quality Radio List (Image 2)
            const options = cls.options || ['Excellent', 'Good', 'Fair', 'Poor'];
            const shortcuts = cls.optionShortcuts || ['Q', 'W', 'E', 'R'];
            const currentVal = instruction.text || '';

            if (container) {
                container.innerHTML = `
                    <div class="tree-radio-system mt-1">
                        <div class="tree-v-line" style="height: calc(100% - 24px);"></div>
                        ${options.map((opt, oIdx) => {
                    const isChecked = (currentVal === opt);
                    const shortcut = shortcuts[oIdx] || '';
                    return `
                                <div class="tree-radio-row" onclick="window.app.selectAudioQualityOption('${opt}')">
                                    <div class="tree-h-line"></div>
                                    <label class="flex items-center gap-2.5 w-full cursor-pointer">
                                        <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}"></div>
                                        <span class="text-[13.5px] font-[450] ${isChecked ? 'text-gray-900 font-medium' : 'text-gray-700'}">${opt}</span>
                                        ${shortcut ? `<span class="kbd-key scale-90 ml-auto">${shortcut}</span>` : ''}
                                    </label>
                                </div>
                            `;
                }).join('')}
                    </div>
                `;
            }

            if (actionsContainer) {
                actionsContainer.innerHTML = `
                    <div class="flex items-center justify-between font-[648] text-[13.5px] text-gray-900 mb-1 select-none cursor-pointer py-1" onclick="window.app && window.app.toggleFullEditActions()">
                        <span>Available actions</span>
                        <div class="flex items-center justify-center w-5 h-5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-800 transition-colors cursor-pointer text-[13px]">
                            <svg id="fullEditActionsChevron" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" height="14" width="14" class="transition-transform duration-200" style="transform: rotate(180deg);"><path d="m6 9 6 6 6-6"></path></svg>
                        </div>
                    </div>
                    <div id="fullEditActionsBody" class="hidden space-y-1.5 text-[11.5px] text-gray-700 select-none pt-1 pb-1">
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app && window.app.deleteCurrentAnnotation()">
                            <span>Delete selected</span>
                            <div class="flex items-center gap-1">
                                <span class="action-kbd">DEL</span>
                                <span class="text-gray-400">/</span>
                                <span class="action-kbd">⌫</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app.adjustCurrentRangeEdge('right', 1)">
                            <span>Adjust right side</span>
                            <div class="flex items-center gap-1">
                                <span class="action-kbd">Alt</span>
                                <span class="action-kbd">←</span>
                                <span class="text-gray-400">/</span>
                                <span class="action-kbd">→</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app.adjustCurrentRangeEdge('left', -1)">
                            <span>Adjust left side</span>
                            <div class="flex items-center gap-1">
                                <span class="action-kbd">Alt</span>
                                <span class="action-kbd">⇧</span>
                                <span class="action-kbd">←</span>
                                <span class="text-gray-400">/</span>
                                <span class="action-kbd">→</span>
                            </div>
                        </div>
                    </div>
                `;
            }
        } else {
            // Speaker 1 / Speaker 2 Transcript Input (Image 3 & 4)
            if (container) {
                container.innerHTML = `
                    <div class="search-attributes-box mb-3">
                        <svg class="text-gray-400 shrink-0" width="13" height="13" fill="currentColor" viewBox="64 64 896 896"><path d="M909.6 854.5L649.9 594.8C690.2 542.7 712 479 712 412c0-80.2-31.3-155.4-87.9-212.1-56.6-56.7-132-87.9-212.1-87.9s-155.5 31.3-212.1 87.9C143.2 256.5 112 331.8 112 412c0 80.1 31.3 155.5 87.9 212.1C256.5 680.8 331.8 712 412 712c67 0 130.6-21.8 182.7-62l259.7 259.6a8.2 8.2 0 0011.6 0l43.6-43.5a8.2 8.2 0 000-11.6zM570.4 570.4C528 612.7 471.8 636 412 636s-116-23.3-158.4-65.6C211.3 528 188 471.8 188 412s23.3-116.1 65.6-158.4C296 211.3 352.2 188 412 188s116.1 23.2 158.4 65.6S636 352.2 636 412s-23.3 116.1-65.6 158.4z"></path></svg>
                        <input type="text" name="search_attributes" placeholder="Search attributes (Ctrl+F)" class="text-[12.5px] w-full outline-none bg-transparent placeholder-gray-400 font-normal" />
                    </div>
                    <div class="relative pl-5 mt-2">
                        <div class="attr-elbow-line"></div>
                        <div class="flex items-center gap-1.5 mb-1.5">
                            <span class="text-[13px] text-gray-500 font-normal">Transcript</span>
                            <span class="text-[#f84d63] font-bold text-[14px] leading-none">*</span>
                            <span class="text-gray-300 hover:text-gray-500 cursor-pointer ml-0.5 text-xs select-none" onclick="window.app.clearTranscriptInput()" title="Clear">✕</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <div class="flex-1 flex items-center bg-white border border-gray-300 rounded-md px-2.5 py-1 focus-within:border-[#5f45ff] transition-all">
                                <input type="text" id="transcriptInputField" name="transcript_input" value="${instruction.text || ''}" placeholder="" class="w-full text-[13px] text-gray-800 outline-none bg-transparent" oninput="window.app.handleTranscriptInput(this.value)" />
                            </div>
                            <span class="kbd-key scale-90">Q</span>
                        </div>
                    </div>
                `;
            }

            if (actionsContainer) {
                actionsContainer.innerHTML = `
                    <div class="flex items-center justify-between font-[648] text-[13.5px] text-gray-900 mb-1 select-none cursor-pointer py-1" onclick="window.app && window.app.toggleFullEditActions()">
                        <span>Available actions</span>
                        <div class="flex items-center justify-center w-5 h-5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-800 transition-colors cursor-pointer text-[13px]">
                            <svg id="fullEditActionsChevron" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" height="14" width="14" class="transition-transform duration-200" style="transform: rotate(180deg);"><path d="m6 9 6 6 6-6"></path></svg>
                        </div>
                    </div>
                    <div id="fullEditActionsBody" class="hidden space-y-1.5 text-[11.5px] text-gray-700 select-none pt-1 pb-1">
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app.deleteCurrentAnnotation()">
                            <span>Delete selected</span>
                            <div class="flex items-center gap-1">
                                <span class="action-kbd">DEL</span>
                                <span class="text-gray-400">/</span>
                                <span class="action-kbd">⌫</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app.changeCurrentClass()">
                            <span>Change class</span>
                            <span class="action-kbd">C</span>
                        </div>
                        <div class="flex items-center justify-between py-1 px-1 hover:bg-gray-50 rounded cursor-pointer transition-colors" onclick="window.app.adjustCurrentRangeEdge('right', 1)">
                            <span>Adjust right side</span>
                            <div class="flex items-center gap-1">
                                <span class="action-kbd">Alt</span>
                                <span class="action-kbd">←</span>
                                <span class="text-gray-400">/</span>
                                <span class="action-kbd">→</span>
                            </div>
                        </div>
                    </div>
                `;
            }

            setTimeout(() => {
                const transcriptInput = document.getElementById('transcriptInputField');
                if (transcriptInput && document.activeElement !== transcriptInput) {
                    transcriptInput.focus();
                }
            }, 50);
        }
    }

    selectAudioQualityOption(opt) {
        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        instruction.text = opt;

        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderFullEditSidebarContent();
    }

    handleTranscriptInput(val) {
        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        instruction.text = val;

        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderTranscriptPanel();
    }

    clearTranscriptInput() {
        this.handleTranscriptInput('');
        this.renderFullEditSidebarContent();
    }

    handleFrameInputChange(field, val, sIdx = 0) {
        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        const segments = (instruction.frames || '0 - 0').split(' | ').filter(Boolean);
        const targetSegIdx = (typeof sIdx === 'number' && sIdx >= 0 && sIdx < segments.length) ? sIdx : 0;
        const parts = (segments[targetSegIdx] || '0 - 0').split(' - ').map(Number);
        let s = isNaN(parts[0]) ? 0 : parts[0];
        let e = isNaN(parts[1]) ? 0 : parts[1];

        const numVal = Math.round(this.parseInputTime(val) * CONFIG.FPS);

        if (field === 'start') {
            s = Math.max(0, Math.min(numVal, e - 1));
        } else {
            e = Math.min(this.videoController ? this.videoController.getTotalFrames() : 999999, Math.max(numVal, s + 1));
        }

        segments[targetSegIdx] = `${s} - ${e}`;
        instruction.frames = mergeRangeSegments(segments);
        if (isSameClass(instruction.className, 'Audio quality')) {
            this.resolveNonOverlappingRanges(instruction.className, s, e, instruction.id);
        }
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderFullEditSidebarContent();
    }

    adjustCurrentRangeEdge(edge, delta) {
        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        const parts = (instruction.frames || '0 - 0').split(' - ').map(Number);
        let s = isNaN(parts[0]) ? 0 : parts[0];
        let e = isNaN(parts[1]) ? 0 : parts[1];

        const totalFrames = this.videoController ? this.videoController.getTotalFrames() : 99999;
        const step = delta * (this.videoController ? this.videoController.frameSkip : 6);

        if (edge === 'left') {
            s = Math.max(0, Math.min(s + step, e - 1));
        } else {
            e = Math.min(totalFrames, Math.max(e + step, s + 1));
        }

        instruction.frames = `${s} - ${e}`;
        this.resolveNonOverlappingRanges(instruction.className, s, e, instruction.id);
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderFullEditSidebarContent();
    }

    changeCurrentClass() {
        if (!this.annotationModel) return;
        if (this.selectionLevel === 'group' && this.selectedGroupInstrIndices && this.selectedGroupInstrIndices.length > 0) {
            this.selectedGroupInstrIndices.forEach(idx => {
                const instruction = this.annotationModel.instructions[idx];
                if (instruction) {
                    if (instruction.className === 'Speaker 1') {
                        instruction.className = 'Speaker 2';
                    } else if (instruction.className === 'Speaker 2') {
                        instruction.className = 'Speaker 1';
                    }
                }
            });
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
            this.renderFullEditSidebarContent();
            this.renderInstructions();
            return;
        }

        if (this.editingAnnotationIndex === -1 || !this.annotationModel.instructions[this.editingAnnotationIndex]) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        // Cycle between Speaker 1 and Speaker 2
        if (instruction.className === 'Speaker 1') {
            instruction.className = 'Speaker 2';
        } else if (instruction.className === 'Speaker 2') {
            instruction.className = 'Speaker 1';
        }
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderFullEditSidebarContent();
        this.renderInstructions();
    }

    playRangeOnly(startFrame, endFrame, instrIdx = null, segIdx = null) {
        if (!this.videoController) return;
        if (startFrame >= endFrame) {
            this.seekToTime(startFrame / CONFIG.FPS);
            return;
        }

        if (this.timelineView) {
            this.timelineView.playingRange = { instrIdx, segIdx };
            this.timelineView.playingRangeIndex = instrIdx;
            this.timelineView.playingRangeSegIdx = segIdx;
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }

        const startSec = startFrame / CONFIG.FPS;
        const endSec = endFrame / CONFIG.FPS;

        this.rangePlaybackLimitSec = endSec;
        this.rangePlaybackStartFrame = startFrame;
        this.isSeekingForRangePlayback = true;

        this.videoController.currentTime = startSec;
        const playPromise = this.videoController.video.play();
        if (playPromise !== undefined) {
            playPromise.then(() => {
                this.updatePlayButtonState(true);
            }).catch(err => {
                console.log("Range playback interrupted:", err);
            });
        }
    }

    stopRangePlayback(isNaturalFinish = false) {
        this.isPlayingRangeSequence = false;
        this.onRangePlaybackEnd = null;
        this.rangePlaybackLimitSec = null;
        this.rangePlaybackStartFrame = null;
        this.isSeekingForRangePlayback = false;

        if (this.videoController && isNaturalFinish) {
            this.videoController.pause();
        }

        if (this.timelineView) {
            this.timelineView.playingRange = null;
            this.timelineView.playingRangeIndex = null;
            this.timelineView.playingRangeSegIdx = null;
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
    }

    playRangeSequence(ranges) {
        if (!ranges || ranges.length === 0) return;

        // Sort ranges strictly in ascending order by startFrame
        const sorted = [...ranges].sort((a, b) => a.startFrame - b.startFrame);
        let currentIndex = 0;
        this.isPlayingRangeSequence = true;

        const playCurrentRange = () => {
            if (!this.isPlayingRangeSequence) return;

            if (currentIndex >= sorted.length) {
                // Sequence finished: stop playback and clear golden border
                this.stopRangePlayback(true);
                return;
            }

            const r = sorted[currentIndex];
            currentIndex++;

            // Set up next step callback when current range finishes
            this.onRangePlaybackEnd = () => {
                if (this.isPlayingRangeSequence) {
                    playCurrentRange();
                }
            };

            this.playRangeOnly(r.startFrame, r.endFrame, r.instrIdx, r.segIdx);
        };

        playCurrentRange();
    }

    getRangesForRowDef(rowDef) {
        if (!rowDef || !this.annotationModel) return [];
        const instructions = this.annotationModel.getInstructions();
        const ranges = [];

        if (rowDef.isParentHeader) {
            instructions.forEach((ins, idx) => {
                if (isSameClass(ins.className, rowDef.className || rowDef.name)) {
                    const segs = (ins.frames || '').split(' | ').filter(Boolean);
                    segs.forEach((segStr, sIdx) => {
                        const parts = segStr.split(' - ').map(Number);
                        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                            ranges.push({
                                startFrame: Math.min(parts[0], parts[1]),
                                endFrame: Math.max(parts[0], parts[1]),
                                instrIdx: idx,
                                segIdx: sIdx
                            });
                        }
                    });
                }
            });
        } else if (rowDef.isChildRangeRow || rowDef.isFlatRow) {
            const indices = [];
            if (rowDef.rangeItems && rowDef.rangeItems.length > 0) {
                rowDef.rangeItems.forEach(item => {
                    if (item && item.idx !== undefined) indices.push(item.idx);
                });
            } else if (rowDef.instrIdx !== undefined) {
                indices.push(rowDef.instrIdx);
            }

            indices.forEach(idx => {
                const ins = instructions[idx];
                if (ins) {
                    const segs = (ins.frames || '').split(' | ').filter(Boolean);
                    segs.forEach((segStr, sIdx) => {
                        const parts = segStr.split(' - ').map(Number);
                        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                            ranges.push({
                                startFrame: Math.min(parts[0], parts[1]),
                                endFrame: Math.max(parts[0], parts[1]),
                                instrIdx: idx,
                                segIdx: sIdx
                            });
                        }
                    });
                }
            });
        }

        // Sort ascending by startFrame
        ranges.sort((a, b) => a.startFrame - b.startFrame);
        return ranges;
    }

    showGroupContextMenu(x, y, rowDef) {
        const menu = document.getElementById('rangeContextMenu');
        if (!menu) return;

        const isLocked = rowDef ? (this.isRowLocked(rowDef.classId || rowDef.id)) : false;
        menu.style.left = `${Math.min(window.innerWidth - 220, x)}px`;
        menu.style.top = `${Math.min(window.innerHeight - 150, y)}px`;

        const ranges = this.getRangesForRowDef(rowDef);
        const count = ranges.length;
        const playLabel = count === 1 ? 'Play 1 selected range' : (count > 1 ? `Play ${count} selected ranges` : 'Play');

        menu.innerHTML = `
            ${count > 0 ? `
            <div class="range-ctx-item" id="ctx-play-group">
                <span class="ctx-icon">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="14" width="14"><polygon points="6 3 20 12 6 21 6 3"></polygon></svg>
                </span>
                <span>${playLabel}</span>
            </div>
            <div class="range-ctx-separator"></div>
            ` : ''}
            <div class="range-ctx-item" id="ctx-lock-group">
                <span class="ctx-icon">
                    <svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M680 384v-96c0-97.2-78.8-176-176-176S328 190.8 328 288v96h-40c-17.7 0-32 14.3-32 32v464c0 17.7 14.3 32 32 32h464c17.7 0 32-14.3 32-32V416c0-17.7-14.3-32-32-32h-40zm-280-96c0-57.4 46.6-104 104-104s104 46.6 104 104v96H400v-96zm312 552H312V448h400v392z"></path></svg>
                </span>
                <span>${isLocked ? 'Unlock row' : 'Lock row'}</span>
            </div>
        `;
        menu.classList.add('visible');

        const playBtn = menu.querySelector('#ctx-play-group');
        if (playBtn) {
            playBtn.onclick = (e) => {
                e.stopPropagation();
                this.hideRangeContextMenu();
                this.stopRangePlayback(false);
                this.playRangeSequence(ranges);
            };
        }

        const lockBtn = menu.querySelector('#ctx-lock-group');
        if (lockBtn) {
            lockBtn.onclick = (e) => {
                e.stopPropagation();
                this.hideRangeContextMenu();
                if (rowDef) this.toggleRowLock(rowDef.classId || rowDef.id);
            };
        }
    }

    showRangeContextMenu(x, y, instrIdx, cls, parts, segIdx = 0) {
        const menu = document.getElementById('rangeContextMenu');
        if (!menu) return;

        const isLocked = this.isRowLocked(cls.id);
        menu.style.left = `${Math.min(window.innerWidth - 180, x)}px`;
        menu.style.top = `${Math.min(window.innerHeight - 150, y)}px`;

        menu.innerHTML = `
            <div class="range-ctx-item" onclick="window.app.copyRangeAnnotation(${instrIdx}); window.app.hideRangeContextMenu();">
                <span class="ctx-icon">
                    <svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M832 64H296c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h496v688c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V96c0-17.7-14.3-32-32-32zM704 192H192c-17.7 0-32 14.3-32 32v530.7c0 8.5 3.4 16.6 9.4 22.6l173.3 173.3c2.2 2.2 4.7 4 7.4 5.5v1.9h4.2c3.5 1.3 7.2 2 11 2H704c17.7 0 32-14.3 32-32V224c0-17.7-14.3-32-32-32zM350 856.2L263.9 770H350v86.2zM664 888H414V746c0-22.1-17.9-40-40-40H232V264h432v624z"></path></svg>
                </span>
                <span>Copy range</span>
            </div>
            <div class="range-ctx-item danger" onclick="window.app.deleteRangeSegment(${instrIdx}, ${segIdx}); window.app.hideRangeContextMenu();">
                <span class="ctx-icon">
                    <svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72zm504 72H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z"></path></svg>
                </span>
                <span>Delete range</span>
            </div>
            <div class="range-ctx-item" onclick="window.app.stopRangePlayback(false); window.app.playRangeOnly(${parts[0]}, ${parts[1]}, ${instrIdx}, ${segIdx}); window.app.hideRangeContextMenu();">
                <span class="ctx-icon">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="14" width="14"><polygon points="6 3 20 12 6 21 6 3"></polygon></svg>
                </span>
                <span>Play range</span>
            </div>
            <div class="range-ctx-separator"></div>
            <div class="range-ctx-item" onclick="window.app.toggleRowLock('${cls.id}'); window.app.hideRangeContextMenu();">
                <span class="ctx-icon">
                    <svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M680 384v-96c0-97.2-78.8-176-176-176S328 190.8 328 288v96h-40c-17.7 0-32 14.3-32 32v464c0 17.7 14.3 32 32 32h464c17.7 0 32-14.3 32-32V416c0-17.7-14.3-32-32-32h-40zm-280-96c0-57.4 46.6-104 104-104s104 46.6 104 104v96H400v-96zm312 552H312V448h400v392z"></path></svg>
                </span>
                <span>${isLocked ? 'Unlock row' : 'Lock row'}</span>
            </div>
        `;
        menu.classList.add('visible');
    }

    hideRangeContextMenu() {
        const menu = document.getElementById('rangeContextMenu');
        if (menu) menu.classList.remove('visible');
    }

    copyRangeAnnotation(instrIdx) {
        if (instrIdx < 0 || instrIdx >= this.annotationModel.instructions.length) return;
        const orig = this.annotationModel.instructions[instrIdx];
        const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        this.annotationModel.instructions.push({
            ...orig,
            id: newId,
            segmentId: newId,
            timestamp: Date.now()
        });
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
    }

    deleteRangeSegment(instrIdx, segIdx = null) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const instr = this.annotationModel.instructions[instrIdx];
        const segs = (instr.frames || '').split(' | ').filter(Boolean);
        if (segs.length > 1 && segIdx !== null && segIdx >= 0 && segIdx < segs.length) {
            segs.splice(segIdx, 1);
            instr.frames = segs.join(' | ');
            const output = document.getElementById('annotations_output');
            if (output) {
                output.value = JSON.stringify(this.annotationModel.getInstructions());
            }
            if (this.editingAnnotationIndex === instrIdx) {
                this.closeFullEditSidebar();
            } else {
                this.timelineView.renderTracks(this.annotationModel.getInstructions());
                this.renderInstructions();
                if (this.waveformRenderer && this.timelineView) {
                    this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
                }
            }
        } else {
            this.deleteAnnotation(instrIdx);
        }
    }

    copyAnnotationUrl() {
        navigator.clipboard.writeText(window.location.href);
        this.closeSidebarDropdown();
    }

    copyAnnotationIdentifier() {
        if (this.editingAnnotationIndex !== -1 && this.annotationModel.instructions[this.editingAnnotationIndex]) {
            navigator.clipboard.writeText(this.annotationModel.instructions[this.editingAnnotationIndex].id || '');
        }
        this.closeSidebarDropdown();
    }

    goToClassification() {
        if (this.editingAnnotationIndex !== -1 && this.annotationModel.instructions[this.editingAnnotationIndex]) {
            const parts = (this.annotationModel.instructions[this.editingAnnotationIndex].frames || '').split(' - ').map(Number);
            if (!isNaN(parts[0])) {
                this.seekToTime(parts[0] / CONFIG.FPS);
            }
        }
        this.closeSidebarDropdown();
    }

    closeSidebarDropdown() {
        const menu = document.getElementById('sidebarDropdownMenu');
        if (menu) menu.classList.add('hidden');
    }

    getInstanceKey(instr, instrIdx) {
        if (!instr && typeof instrIdx === 'number' && this.annotationModel && this.annotationModel.instructions[instrIdx]) {
            instr = this.annotationModel.instructions[instrIdx];
        }
        if (instr) {
            return instr.segmentId || instr.id || `inst_${instrIdx}`;
        }
        return `inst_${instrIdx}`;
    }

    isRowLocked(classId, instrIdx = null) {
        if (instrIdx !== null && instrIdx !== undefined && this.annotationModel && this.annotationModel.instructions[instrIdx]) {
            const instr = this.annotationModel.instructions[instrIdx];
            const instKey = this.getInstanceKey(instr, instrIdx);
            if (this.lockedInstances && this.lockedInstances[instKey]) return true;
        }
        if (!classId) return false;
        if (this.lockedRows && this.lockedRows[classId]) return true;
        const cls = CONFIG.CLASSES.find(c => c.id === classId || isSameClass(c.name, classId));
        if (cls && this.lockedRows && this.lockedRows[cls.id]) return true;
        return false;
    }

    isRowHidden(classId, instrIdx = null) {
        if (instrIdx !== null && instrIdx !== undefined && this.annotationModel && this.annotationModel.instructions[instrIdx]) {
            const instr = this.annotationModel.instructions[instrIdx];
            const instKey = this.getInstanceKey(instr, instrIdx);
            if (this.hiddenInstances && this.hiddenInstances[instKey]) return true;
        }
        if (!classId) return false;
        if (this.hiddenRows && this.hiddenRows[classId]) return true;
        const cls = CONFIG.CLASSES.find(c => c.id === classId || isSameClass(c.name, classId));
        if (cls && this.hiddenRows && this.hiddenRows[cls.id]) return true;
        return false;
    }

    toggleRowLock(classId, instrIdx = null) {
        if (instrIdx !== null && instrIdx !== undefined) {
            this.toggleInstanceLock(instrIdx);
            return;
        }
        const cls = CONFIG.CLASSES.find(c => c.id === classId || isSameClass(c.name, classId));
        const key = cls ? cls.id : classId;
        this.lockedRows[key] = !this.lockedRows[key];
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleCurrentRowLock() {
        if (this.editingAnnotationIndex !== -1 && this.annotationModel.instructions[this.editingAnnotationIndex]) {
            const instr = this.annotationModel.instructions[this.editingAnnotationIndex];
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
            if (cls) this.toggleRowLock(cls.id, this.editingAnnotationIndex);
        }
    }

    toggleCurrentRowVisibility() {
        if (this.editingAnnotationIndex !== -1 && this.annotationModel.instructions[this.editingAnnotationIndex]) {
            const instr = this.annotationModel.instructions[this.editingAnnotationIndex];
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
            if (cls) this.toggleRowVisibility(cls.id, this.editingAnnotationIndex);
        }
    }

    toggleRowVisibility(classId, instrIdx = null) {
        if (instrIdx !== null && instrIdx !== undefined) {
            this.toggleInstanceVisibility(instrIdx);
            return;
        }
        const cls = CONFIG.CLASSES.find(c => c.id === classId || isSameClass(c.name, classId));
        const key = cls ? cls.id : classId;
        this.hiddenRows[key] = !this.hiddenRows[key];
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleAllLocks() {
        const allLocked = CONFIG.CLASSES.every(c => this.isRowLocked(c.id));
        CONFIG.CLASSES.forEach(c => {
            this.lockedRows[c.id] = !allLocked;
        });
        this.lockedInstances = {};
        const btn = document.querySelector('[data-tooltip*="labels"][onclick*="toggleAllLocks"]');
        if (btn) btn.setAttribute('data-tooltip', !allLocked ? 'Unlock all labels' : 'Lock all labels');
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleAllVisibility() {
        const allHidden = CONFIG.CLASSES.every(c => !!this.hiddenRows[c.id]);
        CONFIG.CLASSES.forEach(c => {
            this.hiddenRows[c.id] = !allHidden;
        });
        this.hiddenInstances = {};
        const btn = document.querySelector('[data-tooltip*="labels"][onclick*="toggleAllVisibility"]');
        if (btn) btn.setAttribute('data-tooltip', !allHidden ? 'Show all labels' : 'Hide all labels');
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleGroupLock(className) {
        const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, className));
        if (cls) this.toggleRowLock(cls.id);
    }

    toggleGroupVisibility(className) {
        const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, className));
        if (cls) this.toggleRowVisibility(cls.id);
    }

    toggleInstanceLock(instrIdx) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const instr = this.annotationModel.instructions[instrIdx];
        if (!instr) return;
        const instKey = this.getInstanceKey(instr, instrIdx);
        if (!this.lockedInstances) this.lockedInstances = {};
        this.lockedInstances[instKey] = !this.lockedInstances[instKey];
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleInstanceVisibility(instrIdx) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const instr = this.annotationModel.instructions[instrIdx];
        if (!instr) return;
        const instKey = this.getInstanceKey(instr, instrIdx);
        if (!this.hiddenInstances) this.hiddenInstances = {};
        this.hiddenInstances[instKey] = !this.hiddenInstances[instKey];
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleInstanceContextMenu(event, instrIdx) {
        event.stopPropagation();
        event.preventDefault();

        const menu = document.getElementById('instanceContextMenu');
        if (!menu) return;

        if (this.activeInstanceContextMenuIdx === instrIdx && !menu.classList.contains('hidden')) {
            this.closeInstanceContextMenu();
            return;
        }

        this.activeInstanceContextMenuIdx = instrIdx;

        menu.innerHTML = `
            <div class="px-3 py-1.5 hover:bg-gray-100/80 cursor-pointer flex items-center gap-2.5 text-gray-700" onclick="window.app.copyInstanceIdentifier(${instrIdx}); window.app.closeInstanceContextMenu();">
                <svg class="w-3.5 h-3.5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                <span>Copy identifier</span>
            </div>
            <div class="px-3 py-1.5 hover:bg-gray-100/80 cursor-pointer flex items-center gap-2.5 text-gray-700" onclick="window.app.copyInstanceUrl(${instrIdx}); window.app.closeInstanceContextMenu();">
                <svg class="w-3.5 h-3.5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                <span>Copy URL</span>
            </div>
            <div class="h-px bg-gray-100 my-1"></div>
            <div class="px-3 py-1.5 hover:bg-gray-100/80 cursor-pointer flex items-center gap-2.5 text-gray-700" onclick="window.app.goToObject(${instrIdx}); window.app.closeInstanceContextMenu();">
                <svg class="w-3.5 h-3.5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/></svg>
                <span>Go to object</span>
            </div>
            <div class="px-3 py-1.5 hover:bg-gray-100/80 cursor-pointer flex items-center justify-between text-gray-700" onclick="window.app.openFullEditSidebar(${instrIdx}); window.app.closeInstanceContextMenu();">
                <div class="flex items-center gap-2.5">
                    <svg class="w-3.5 h-3.5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>
                    <span>Change class</span>
                </div>
                <kbd class="px-1.5 py-0.5 text-[11px] text-gray-400 bg-gray-100 rounded border border-gray-200">C</kbd>
            </div>
            <div class="px-3 py-1.5 hover:bg-gray-100/80 cursor-pointer flex items-center justify-between text-gray-700" onclick="window.app.promptChangeInstance(${instrIdx}); window.app.closeInstanceContextMenu();">
                <div class="flex items-center gap-2.5">
                    <svg class="w-3.5 h-3.5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                    <span>Change instance</span>
                </div>
                <div class="flex items-center gap-1">
                    <kbd class="px-1 py-0.5 text-[10px] text-gray-400 bg-gray-100 rounded border border-gray-200">⇧</kbd>
                    <kbd class="px-1.5 py-0.5 text-[11px] text-gray-400 bg-gray-100 rounded border border-gray-200">O</kbd>
                </div>
            </div>
            <div class="h-px bg-gray-100 my-1"></div>
            <div class="px-3 py-1.5 hover:bg-gray-100/80 cursor-pointer flex items-center justify-between text-red-600" onclick="window.app.deleteAnnotation(${instrIdx}); window.app.closeInstanceContextMenu();">
                <div class="flex items-center gap-2.5">
                    <svg class="w-3.5 h-3.5 text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                    <span>Delete</span>
                </div>
                <div class="flex items-center gap-1">
                    <kbd class="px-1 py-0.5 text-[10px] text-gray-400 bg-gray-100 rounded border border-gray-200">DEL</kbd>
                    <span class="text-gray-300 text-xs">/</span>
                    <kbd class="px-1 py-0.5 text-[10px] text-gray-400 bg-gray-100 rounded border border-gray-200">⌫</kbd>
                </div>
            </div>
        `;

        const targetBtn = event.currentTarget;
        const rect = targetBtn.getBoundingClientRect();
        const posX = Math.min(window.innerWidth - 240, rect.left);
        const posY = Math.min(window.innerHeight - 250, rect.bottom + 4);

        menu.style.left = `${posX}px`;
        menu.style.top = `${posY}px`;
        menu.classList.remove('hidden');
    }

    closeInstanceContextMenu() {
        const menu = document.getElementById('instanceContextMenu');
        if (menu) menu.classList.add('hidden');
        this.activeInstanceContextMenuIdx = null;
    }

    copyInstanceIdentifier(instrIdx) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const instr = this.annotationModel.instructions[instrIdx];
        const idText = instr.segmentId || instr.id || `${instr.className || 'Object'} (0)`;
        navigator.clipboard.writeText(idText).catch(() => { });
    }

    copyInstanceUrl(instrIdx) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const instr = this.annotationModel.instructions[instrIdx];
        const parts = (instr.frames || '').split(' - ').map(Number);
        const startSec = isNaN(parts[0]) ? 0 : parts[0] / CONFIG.FPS;
        const url = `${window.location.origin}${window.location.pathname}?t=${startSec.toFixed(2)}`;
        navigator.clipboard.writeText(url).catch(() => { });
    }

    goToObject(instrIdx) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        const instr = this.annotationModel.instructions[instrIdx];
        const parts = (instr.frames || '').split(' - ').map(Number);
        const startSec = isNaN(parts[0]) ? 0 : parts[0] / CONFIG.FPS;
        this.seekToTime(startSec);
    }

    promptChangeInstance(instrIdx) {
        if (instrIdx < 0 || !this.annotationModel || instrIdx >= this.annotationModel.instructions.length) return;
        this.openFullEditSidebar(instrIdx);
    }

    highlightRangeBar(instrIdx) {
        const bars = document.querySelectorAll(`[data-testid="range"][data-instr-idx="${instrIdx}"]`);
        bars.forEach(bar => bar.classList.add('range-active-highlight'));
    }

    unhighlightRangeBar(instrIdx) {
        const bars = document.querySelectorAll(`[data-testid="range"][data-instr-idx="${instrIdx}"]`);
        bars.forEach(bar => {
            const segIdx = parseInt(bar.getAttribute('data-seg-idx'), 10);
            const isSelected = this.selectionMode === 'individual' && this.editingAnnotationIndex === instrIdx && (this.editingSegmentIndex === null || this.editingSegmentIndex === undefined || isNaN(segIdx) || segIdx === this.editingSegmentIndex);
            if (!isSelected) {
                bar.classList.remove('range-active-highlight');
            }
        });
    }

    showInstanceMenu(event, instrIdx) {
        event.stopPropagation();
        this.openFullEditSidebar(instrIdx);
        window.toggleSidebarDropdown(event);
    }

    resolveNonOverlappingRanges(targetClassName, nS, nE, excludeId = null) {
        if (!this.annotationModel || nE <= nS) return;
        // 1st: Only Audio quality enforces strict non-overlapping range replacement across the track
        if (!isSameClass(targetClassName, 'Audio quality')) return;

        const currentList = this.annotationModel.getInstructions();
        const updatedList = [];

        for (const instr of currentList) {
            if (!instr || !instr.frames) continue;
            if (excludeId && (instr.id === excludeId || instr.segmentId === excludeId)) {
                updatedList.push(instr);
                continue;
            }
            if (!isSameClass(instr.className, targetClassName)) {
                updatedList.push(instr);
                continue;
            }

            const rawSegs = instr.frames.split(' | ').filter(Boolean);
            const remainingSegs = [];

            for (const segStr of rawSegs) {
                const parts = segStr.split(' - ').map(Number);
                if (parts.length < 2) continue;
                const eS = parts[0];
                const eE = parts[1];

                if (eE <= nS || eS >= nE) {
                    remainingSegs.push(`${eS} - ${eE}`);
                } else if (nS <= eS && nE >= eE) {
                    // Fully covered -> delete
                    continue;
                } else if (eS < nS && eE > nE) {
                    remainingSegs.push(`${eS} - ${nS}`);
                    remainingSegs.push(`${nE} - ${eE}`);
                } else if (eS < nS && eE <= nE) {
                    remainingSegs.push(`${eS} - ${nS}`);
                } else if (eS >= nS && eE > nE) {
                    remainingSegs.push(`${nE} - ${eE}`);
                }
            }

            if (remainingSegs.length > 0) {
                instr.frames = remainingSegs.join(' | ');
                updatedList.push(instr);
            }
        }

        this.annotationModel.setInstructions(updatedList);
    }

    renderInstructions() {
        if (this.timelineView && this.annotationModel) {
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
        if (this.instructionRenderer && this.annotationModel) {
            this.instructionRenderer.render(this.annotationModel.getInstructions());
        }
    }

    startRangeMoveDrag(e, instrIdx, segIdxOrCls, clsOrBar, barEl) {
        if (e && e.preventDefault) e.preventDefault();
        if (e && e.stopPropagation) e.stopPropagation();
        const segIdx = (typeof segIdxOrCls === 'number') ? segIdxOrCls : 0;
        if (this.selectIndividualRange) {
            this.selectIndividualRange(instrIdx, segIdx);
        }
        return;
    }

    startRangeEdgeDrag(e, instrIdx, segIdxOrEdge, edgeOrCls, clsOrBar, barEl) {
        e.preventDefault();
        e.stopPropagation();
        const rawSegments = (this.annotationModel && this.annotationModel.instructions[instrIdx] && this.annotationModel.instructions[instrIdx].frames || '').split(' | ').filter(Boolean);
        const segIdx = (typeof segIdxOrEdge === 'number') ? segIdxOrEdge : 0;
        const edge = (typeof segIdxOrEdge === 'string') ? segIdxOrEdge : (typeof edgeOrCls === 'string' ? edgeOrCls : 'right');

        if (this.openFullEditSidebar) {
            this.openFullEditSidebar(instrIdx, segIdx);
        }
        const startX = e.clientX;
        const instr = this.annotationModel.instructions[instrIdx];
        if (!instr) return;
        const clsObj = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));
        if (clsObj && this.isRowLocked(clsObj.id, instrIdx)) return;

        document.body.style.cursor = CUSTOM_RESIZE_CURSOR;
        document.body.classList.add('range-active-edge-drag');

        const parts = (rawSegments[segIdx] || '').split(' - ').map(Number);
        let s = parts[0] || 0;
        let en = parts[1] || 0;

        const pps = this.timelineView.currentPPS;
        const totalFrames = this.videoController.getTotalFrames();

        const onMouseMove = (moveEvent) => {
            const dx = moveEvent.clientX - startX;
            const df = Math.round((dx / pps) * CONFIG.FPS);

            if (edge === 'left') {
                s = Math.max(0, Math.min(en - 1, parts[0] + df));
            } else {
                en = Math.min(totalFrames, Math.max(s + 1, parts[1] + df));
            }

            rawSegments[segIdx] = `${s} - ${en}`;
            instr.frames = rawSegments.join(' | ');
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
            if (this.waveformRenderer && this.timelineView) {
                this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
            }
            if (this.editingAnnotationIndex === instrIdx) {
                this.renderFullEditSidebarContent();
            }
        };

        const onMouseUp = () => {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            document.body.style.cursor = '';
            document.body.classList.remove('range-active-edge-drag');

            if (instr && instr.frames) {
                const segs = instr.frames.split(' | ').filter(Boolean);
                instr.frames = mergeRangeSegments(segs);
                if (isSameClass(instr.className, 'Audio quality')) {
                    const currentParts = (instr.frames || '').split(' - ').map(Number);
                    if (currentParts.length === 2 && currentParts[1] > currentParts[0]) {
                        this.resolveNonOverlappingRanges(instr.className, currentParts[0], currentParts[1], instr.id);
                    }
                }
            }
            this.renderInstructions();
            if (this.waveformRenderer && this.timelineView) {
                this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
            }
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    formatTimeDisplay(seconds) {
        if (this.displayTimestamps) {
            const t = Math.max(0, Number(seconds) || 0) + 0.001;
            const mins = Math.floor(t / 60);
            const secs = t % 60;
            if (mins > 0) {
                const wholeSecs = Math.floor(secs);
                const millis = Math.floor((secs - wholeSecs) * 1000);
                return `${mins}:${wholeSecs.toString().padStart(2, '0')}.${millis.toString().padStart(3, '0')}`;
            } else {
                return t.toFixed(3);
            }
        }
        return Math.round((Number(seconds) || 0) * CONFIG.FPS).toString();
    }

    formatDisplay(frameVal) {
        const seconds = (Number(frameVal) || 0) / CONFIG.FPS;
        return this.formatTimeDisplay(seconds);
    }

    formatTimeBadgeDisplay(val) {
        return formatTimeBadge(val);
    }

    parseInputTime(str) {
        if (!str) return 0;
        str = String(str).trim();
        let totalSecs = 0;
        if (str.includes(':')) {
            const parts = str.split(':');
            const mins = parseFloat(parts[0]) || 0;
            const secs = parseFloat(parts[1]) || 0;
            totalSecs = mins * 60 + secs;
        } else {
            totalSecs = parseFloat(str) || 0;
        }
        return Math.max(0, totalSecs - 0.001);
    }

    onVideoMetadataLoaded() {
        const duration = this.videoController.duration || 180;
        if (this.totalFramesText) this.totalFramesText.innerHTML = `<span>${this.formatTimeDisplay(duration)}</span>`;

        const audioUrl = this.resolveAudioUrl();
        this.updateAudioNameDisplay(audioUrl);
        if (this.waveformRenderer && (!this.waveformRenderer.loadedUrl || this.waveformRenderer.loadedUrl !== audioUrl)) {
            this.waveformRenderer.loadAudio(audioUrl);
        }

        this.timelineView.initialize(duration);
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.onVideoTimeUpdate();
    }

    onVideoTimeUpdate(forceCenter = false) {
        if (!this.videoController) return;
        const currentTime = this.videoController.currentTime;

        // Check if range-only playback has reached its end limit
        if (this.rangePlaybackLimitSec !== null && this.rangePlaybackLimitSec !== undefined && !this.isSeekingForRangePlayback) {
            const startSec = (this.rangePlaybackStartFrame !== undefined && this.rangePlaybackStartFrame !== null)
                ? (this.rangePlaybackStartFrame / CONFIG.FPS)
                : 0;
            if (currentTime >= this.rangePlaybackLimitSec && currentTime >= startSec) {
                this.rangePlaybackLimitSec = null;
                this.rangePlaybackStartFrame = null;
                if (this.onRangePlaybackEnd) {
                    const cb = this.onRangePlaybackEnd;
                    this.onRangePlaybackEnd = null;
                    cb();
                } else {
                    this.stopRangePlayback(true);
                }
                return;
            }
        }

        const duration = this.videoController.duration || 180;
        const percent = duration > 0 ? (currentTime / duration) : 0;
        const pps = this.timelineView ? this.timelineView.currentPPS : CONFIG.INITIAL_PPS;
        const timelineWidth = duration * pps;

        if (this.progressBarView) this.progressBarView.update(percent);
        if (this.timelineView) this.timelineView.updatePlayhead(percent, timelineWidth);
        if (this.frameInput && document.activeElement !== this.frameInput) {
            this.frameInput.value = this.formatTimeDisplay(currentTime);
        }
        if (this.scrollSync) this.scrollSync.sync(currentTime, duration, pps, forceCenter);

        // Dynamically update outer yellow highlight on ranges currently playing
        const currentFrame = Math.round(currentTime * CONFIG.FPS);
        const isVideoPlaying = this.videoController && !this.videoController.video.paused;
        const allBars = document.querySelectorAll('[data-testid="range"]');
        allBars.forEach(b => {
            const sF = Number(b.getAttribute('data-start-frame'));
            const eF = Number(b.getAttribute('data-end-frame'));
            const iIdx = Number(b.getAttribute('data-instr-idx'));
            const sIdx = Number(b.getAttribute('data-seg-idx'));

            const isSpecificPlaying = (this.timelineView && this.timelineView.playingRange && this.timelineView.playingRange.instrIdx === iIdx && (this.timelineView.playingRange.segIdx === null || this.timelineView.playingRange.segIdx === undefined || this.timelineView.playingRange.segIdx === sIdx)) ||
                                      (this.timelineView && this.timelineView.playingRangeIndex === iIdx && (this.timelineView.playingRangeSegIdx === null || this.timelineView.playingRangeSegIdx === undefined || this.timelineView.playingRangeSegIdx === sIdx));

            const isPlaying = isSpecificPlaying && isVideoPlaying;

            if (isPlaying) {
                if (b.getAttribute('data-playing') !== 'true') {
                    b.setAttribute('data-playing', 'true');
                    b.classList.add('range-reclick-highlight');
                    b.style.setProperty('outline', '2px solid #faad14', 'important');
                    b.style.setProperty('outline-offset', '0px', 'important');
                    b.style.setProperty('box-shadow', '0 0 0 2px #faad14, 0 0 8px rgba(250, 173, 20, 0.6)', 'important');
                    b.style.setProperty('border-color', '#faad14', 'important');
                    b.style.setProperty('z-index', '40', 'important');
                }
            } else {
                if (b.getAttribute('data-playing') === 'true') {
                    b.removeAttribute('data-playing');
                    b.classList.remove('range-reclick-highlight');
                    if (b.getAttribute('data-active') === 'true') {
                        b.style.setProperty('outline', '2px solid #f59e0b', 'important');
                        b.style.setProperty('outline-offset', '-1px', 'important');
                        b.style.setProperty('box-shadow', '0 0 0 1px #f59e0b', 'important');
                        b.style.removeProperty('border-color');
                        b.style.setProperty('z-index', '25', 'important');
                    } else {
                        b.style.removeProperty('outline');
                        b.style.removeProperty('outline-offset');
                        b.style.removeProperty('box-shadow');
                        b.style.removeProperty('border-color');
                        b.style.removeProperty('z-index');
                    }
                }
            }
        });
    }

    updatePlayButtonState(isPlaying) {
        const playBtn = document.getElementById('btnPlayPause');
        if (!playBtn) return;
        if (isPlaying) {
            playBtn.innerHTML = `
                <span class="ant-btn-icon">
                    <span class="justify-center align-middle leading-none">
                        ${PAUSE_ICON_SVG}
                    </span>
                </span>
            `;
            playBtn.setAttribute('data-tooltip', 'Pause (SPACE)');
            this.startPlaybackLoop();
        } else {
            if (!this.isPlayingRangeSequence && this.timelineView && this.timelineView.playingRangeIndex !== null) {
                this.stopRangePlayback(false);
            }
            playBtn.innerHTML = `
                <span class="ant-btn-icon">
                    <span class="justify-center align-middle leading-none">
                        ${PLAY_ICON_SVG}
                    </span>
                </span>
            `;
            playBtn.setAttribute('data-tooltip', 'Play (SPACE)');
            this.stopPlaybackLoop();
        }
    }

    startPlaybackLoop() {
        if (this._rafId) cancelAnimationFrame(this._rafId);
        const loop = () => {
            if (this.videoController && this.videoController.video && !this.videoController.video.paused) {
                this.onVideoTimeUpdate();
                this._rafId = requestAnimationFrame(loop);
            } else {
                this._rafId = null;
            }
        };
        this._rafId = requestAnimationFrame(loop);
    }

    stopPlaybackLoop() {
        if (this._rafId) {
            cancelAnimationFrame(this._rafId);
            this._rafId = null;
        }
    }

    handlePlaybackEnded() {
        this.stopPlaybackLoop();
        this.updatePlayButtonState(false);
        if (this.videoController && this.videoController.rangePlaybackMode === 'LOOP_ALL') {
            this.videoController.currentTime = 0;
            this.videoController.play();
        }
        this.onVideoTimeUpdate();
    }

    closeAllNavigationMenus() {
        const menus = ['moreNavMenu', 'frameSkipMenu', 'speedMenu', 'loopModeMenu', 'visualizationMenu', 'settingsMenu', 'instanceContextMenu'];
        menus.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.add('hidden');
        });
        const sub = document.getElementById('settingsSkipSubmenu');
        if (sub) sub.classList.add('hidden');
        this.closeInstanceContextMenu();

        // Remove active background from trigger buttons
        ['currentSpeedBtn', 'loopToggleBtn', 'visualizationBtn', 'settingsBtn', 'moreNavBtn'].forEach(btnId => {
            const btn = document.getElementById(btnId);
            if (btn) btn.classList.remove('bg-gray-100');
        });
    }

    toggleMoreNavMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('moreNavMenu');
        const trigger = document.getElementById('moreNavBtn');
        if (!menu) return;
        const wasHidden = menu.classList.contains('hidden');
        this.closeAllNavigationMenus();
        if (wasHidden) {
            if (trigger) trigger.classList.add('bg-gray-100');
            menu.innerHTML = `
                <div class="ref-dropdown-item justify-between" onclick="window.app.seekToTime(0); window.app.closeAllNavigationMenus();">
                    <span>Jump to Start</span>
                    <span class="text-[11px] text-gray-400">Home</span>
                </div>
                <div class="ref-dropdown-item justify-between" onclick="window.app.seekToTime(window.app.videoController.duration); window.app.closeAllNavigationMenus();">
                    <span>Jump to End</span>
                    <span class="text-[11px] text-gray-400">End</span>
                </div>
                <div class="ref-dropdown-divider"></div>
                <div class="ref-dropdown-item justify-between" onclick="window.app.jumpToPrevAnnotation(); window.app.closeAllNavigationMenus();">
                    <span>Previous Range</span>
                    <span class="text-[11px] text-gray-400">Alt+←</span>
                </div>
                <div class="ref-dropdown-item justify-between" onclick="window.app.jumpToNextAnnotation(); window.app.closeAllNavigationMenus();">
                    <span>Next Range</span>
                    <span class="text-[11px] text-gray-400">Alt+→</span>
                </div>
            `;
            menu.classList.remove('hidden');
        }
    }

    toggleFrameSkipMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('frameSkipMenu');
        if (!menu) return;
        const wasHidden = menu.classList.contains('hidden');
        this.closeAllNavigationMenus();
        if (wasHidden) {
            const intervals = [1, 3, 4, 5, 6, 7, 12, 18];
            const currentSkip = this.videoController ? (this.videoController.frameSkip || 6) : 6;
            menu.innerHTML = `
                <div class="max-h-[175px] overflow-y-auto custom-nav-scrollbar flex flex-col pr-0.5">
                    ${intervals.map(val => `
                        <div class="ref-dropdown-item ${val === currentSkip ? 'active' : ''}" onclick="window.app.setFrameSkip(${val})">
                            <span>${val}</span>
                        </div>
                    `).join('')}
                </div>
                <div class="ref-dropdown-divider"></div>
                <div class="flex items-center gap-1.5 px-1 pt-0.5" onclick="event.stopPropagation()">
                    <input type="number" name="customFrameSkipInput" id="customFrameSkipInput" placeholder="N..." class="w-[58px] h-[28px] border border-gray-200 rounded-lg px-2 text-xs font-normal text-gray-700 outline-none focus:border-[#a6e40e] bg-white placeholder:text-gray-400" onkeydown="if(event.key==='Enter'){window.app.addCustomFrameSkip(event);}" />
                    <button type="button" onclick="window.app.addCustomFrameSkip(event)" class="w-[28px] h-[28px] flex items-center justify-center text-[#7da617] hover:bg-[#f4fbe8] rounded-lg text-lg font-bold transition-colors select-none">+</button>
                </div>
            `;
            menu.classList.remove('hidden');
        }
    }

    addCustomFrameSkip(e) {
        if (e) e.stopPropagation();
        const input = document.getElementById('customFrameSkipInput');
        if (!input) return;
        const val = parseInt(input.value);
        if (val && val > 0) {
            this.setFrameSkip(val);
        }
    }

    setFrameSkip(val) {
        if (this.videoController) {
            this.videoController.frameSkip = val;
        }
        const valEl = document.getElementById('skipIntervalVal');
        if (valEl) valEl.innerText = val;
        const btnNext = document.getElementById('btnNext');
        if (btnNext) btnNext.setAttribute('data-tooltip', `Jump forward ${val} frames`);
        const btnStart = document.getElementById('btnStart');
        if (btnStart) btnStart.setAttribute('data-tooltip', `Jump backward ${val} frames`);
        this.closeAllNavigationMenus();
    }

    jumpToFirstFrame() {
        this.seekToTime(0);
        this.closeAllNavigationMenus();
    }

    jumpToLastFrame() {
        const duration = this.videoController ? (this.videoController.duration || 180) : 180;
        this.seekToTime(duration);
        this.closeAllNavigationMenus();
    }

    toggleSpeedMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('speedMenu');
        const trigger = document.getElementById('currentSpeedBtn');
        if (!menu) return;
        const wasHidden = menu.classList.contains('hidden');
        this.closeAllNavigationMenus();
        if (wasHidden) {
            if (trigger) trigger.classList.add('bg-gray-100');
            const speeds = ['0.125x', '0.25x', '0.5x', '0.75x', '1x', '1.25x', '1.5x', '1.75x', '2x', '4x', '8x', '16x'];
            const currentRate = this.videoController ? (this.videoController.playbackRate || 1) : 1;
            menu.innerHTML = `
                <div class="max-h-[320px] overflow-y-auto custom-nav-scrollbar flex flex-col pr-0.5">
                    ${speeds.map(spd => {
                const num = parseFloat(spd);
                const isActive = Math.abs(num - currentRate) < 0.01;
                return `
                            <div class="ref-dropdown-item ${isActive ? 'active' : ''}" onclick="window.app.setPlaybackSpeed('${spd}')">
                                <span>${spd}</span>
                            </div>
                        `;
            }).join('')}
                </div>
            `;
            menu.classList.remove('hidden');
        }
    }

    setPlaybackSpeed(speedStr) {
        const rate = parseFloat(speedStr);
        if (this.videoController) {
            this.videoController.playbackRate = rate;
        }
        const speedDisplay = document.getElementById('speedDisplayVal');
        if (speedDisplay) speedDisplay.innerText = speedStr;
        this.closeAllNavigationMenus();
    }

    toggleVolume(e) {
        if (e) e.stopPropagation();
        if (!this.videoController) return;
        this.videoController.muted = !this.videoController.muted;
        this.updateVolumeIcon();
    }

    updateVolumeIcon() {
        const wrapper = document.getElementById('volumeIconWrapper');
        if (!wrapper || !this.videoController) return;
        wrapper.innerHTML = this.videoController.muted ? VOLUME_OFF_SVG : VOLUME_UP_SVG;
        const btnVolume = document.getElementById('btnVolume');
        if (btnVolume) {
            btnVolume.setAttribute('data-tooltip', this.videoController.muted ? 'Unmute' : 'Mute');
        }
    }

    toggleLoopModeMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('loopModeMenu');
        const trigger = document.getElementById('loopToggleBtn');
        if (!menu) return;
        const wasHidden = menu.classList.contains('hidden');
        this.closeAllNavigationMenus();
        if (wasHidden) {
            if (trigger) trigger.classList.add('bg-gray-100');
            const currentMode = this.videoController ? (this.videoController.rangePlaybackMode || 'PLAY_ONCE') : 'PLAY_ONCE';
            const modes = [
                {
                    id: 'LOOP_CONTINUOUSLY',
                    name: 'Loop continuously',
                    icon: `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="15" width="15" class="shrink-0"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path><path d="M16 16h5v5"></path></svg>`
                },
                {
                    id: 'LOOP_ON_PLAY',
                    name: 'Loop on play',
                    icon: `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="15" width="15" class="shrink-0"><polyline points="9 10 4 15 9 20"></polyline><path d="M20 4v7a4 4 0 0 1-4 4H4"></path></svg>`
                },
                {
                    id: 'PLAY_ONCE',
                    name: 'Play once',
                    icon: `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="15" width="15" class="shrink-0"><path d="M4 12v-3c0 -1.336 .873 -2.468 2.08 -2.856m3.92 -.144h10m-3 -3l3 3l-3 3"></path><path d="M20 12v3a3 3 0 0 1 -.133 .886m-1.99 1.984a3 3 0 0 1 -.877 .13h-13m3 3l-3 -3l3 -3"></path><path d="M3 3l18 18"></path></svg>`
                }
            ];
            menu.innerHTML = modes.map(m => `
                <div class="ref-dropdown-item gap-2.5 ${m.id === currentMode ? 'active' : ''}" onclick="window.app.setRangePlaybackMode('${m.id}')">
                    ${m.icon}
                    <span>${m.name}</span>
                </div>
            `).join('');
            menu.classList.remove('hidden');
        }
    }

    setRangePlaybackMode(mode) {
        if (this.videoController) {
            this.videoController.rangePlaybackMode = mode;
        }
        const loopBtn = document.getElementById('loopToggleBtn');
        if (loopBtn) {
            loopBtn.setAttribute('data-range-playback-mode', mode);
            if (mode === 'PLAY_ONCE') {
                loopBtn.innerHTML = `<span class="ant-btn-icon"><span class="justify-center align-middle leading-none"><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M4 12v-3c0 -1.336 .873 -2.468 2.08 -2.856m3.92 -.144h10m-3 -3l3 3l-3 3"></path><path d="M20 12v3a3 3 0 0 1 -.133 .886m-1.99 1.984a3 3 0 0 1 -.877 .13h-13m3 3l-3 -3l3 -3"></path><path d="M3 3l18 18"></path></svg></span></span>`;
            } else if (mode === 'LOOP_ON_PLAY') {
                loopBtn.innerHTML = `<span class="ant-btn-icon"><span class="justify-center align-middle leading-none text-[#a6e40e]"><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><polyline points="9 10 4 15 9 20"></polyline><path d="M20 4v7a4 4 0 0 1-4 4H4"></path></svg></span></span>`;
            } else {
                loopBtn.innerHTML = `<span class="ant-btn-icon"><span class="justify-center align-middle leading-none text-[#a6e40e]"><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path><path d="M16 16h5v5"></path></svg></span></span>`;
            }
        }
        this.closeAllNavigationMenus();
    }

    toggleVisualizationMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('visualizationMenu');
        const trigger = document.getElementById('visualizationBtn');
        if (!menu) return;
        const wasHidden = menu.classList.contains('hidden');
        this.closeAllNavigationMenus();
        if (wasHidden) {
            if (trigger) trigger.classList.add('bg-gray-100');
            const vizOptions = [
                { id: 'Waveform', name: 'Waveform' },
                { id: 'Spectrogram', name: 'Spectrogram' }
            ];
            const activeViz = this.currentViz || 'Waveform';
            menu.innerHTML = `
                <div class="ref-dropdown-header">Type</div>
                ${vizOptions.map(v => `
                    <div class="ref-dropdown-item ${v.id === activeViz ? 'active' : ''}" onclick="window.app.setVisualization('${v.id}')">
                        <span>${v.name}</span>
                    </div>
                `).join('')}
            `;
            menu.classList.remove('hidden');
        }
    }

    setVisualization(type) {
        this.currentViz = type;
        const videoTrack = document.getElementById('videoTrackContainer');
        if (this.waveformRenderer && this.timelineView) {
            const h = videoTrack ? (videoTrack.offsetHeight || this.waveformRenderer.currentHeight || 128) : (this.waveformRenderer.currentHeight || 128);
            this.waveformRenderer.render(
                this.timelineView.videoDuration,
                this.timelineView.currentPPS,
                h
            );
        }
        this.closeAllNavigationMenus();
    }

    toggleSettingsMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('settingsMenu');
        const trigger = document.getElementById('settingsBtn');
        if (!menu) return;
        const wasHidden = menu.classList.contains('hidden');
        this.closeAllNavigationMenus();
        if (wasHidden) {
            if (trigger) trigger.classList.add('bg-gray-100');
            const showSkip = this.showSkipSelector !== false;
            const groupBy = this.groupByClass !== false;
            const showSelected = this.showSelectedOnly === true;
            const classMode = this.classificationMode || 'single';
            const limitSingle = this.limitSingleFrame === true;
            const propagateGaps = this.propagateAcrossGaps === true;

            menu.innerHTML = `
                <!-- Section 1: Content Navigation -->
                <div class="ref-dropdown-header">Content Navigation</div>
                <div class="relative group/submenu ref-dropdown-item justify-between" onmouseenter="window.app.showSettingsSubmenu(event)" onmouseleave="window.app.hideSettingsSubmenu(event)" onclick="window.app.toggleSettingsSubmenu(event)">
                    <div class="flex items-center gap-2 pl-4">
                        <span>Frame skip interval</span>
                    </div>
                    <span class="text-gray-400 text-sm">›</span>
                    <div id="settingsSkipSubmenu" class="hidden absolute right-full top-0 mr-1.5 w-[90px] ref-floating-dropdown flex flex-col pointer-events-auto">
                        <div class="max-h-[175px] overflow-y-auto custom-nav-scrollbar flex flex-col pr-0.5">
                            ${[1, 3, 4, 5, 6, 7, 12, 18].map(val => `
                                <div class="ref-dropdown-item ${(this.videoController && this.videoController.frameSkip === val) ? 'active' : ''}" onclick="window.app.setFrameSkip(${val});">
                                    <span>${val}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                <div class="ref-dropdown-item gap-2" onclick="window.app.toggleFrameSkipVisibility(event)">
                    <span class="w-3.5 text-xs text-[#262626] font-semibold">${showSkip ? '✓' : ''}</span>
                    <span>Show frame skip selector</span>
                </div>

                <div class="ref-dropdown-divider"></div>

                <!-- Section 2: Timeline -->
                <div class="ref-dropdown-header">Timeline</div>
                <div class="ref-dropdown-item gap-2" onclick="window.app.toggleGroupByClass(event)">
                    <span class="w-3.5 text-xs text-[#262626] font-semibold">${groupBy ? '✓' : ''}</span>
                    <span>Group by class</span>
                </div>
                <div class="ref-dropdown-item gap-2" onclick="window.app.toggleShowSelectedOnly(event)">
                    <span class="w-3.5 text-xs text-[#262626] font-semibold">${showSelected ? '✓' : ''}</span>
                    <span>Show selected only</span>
                </div>

                <div class="ref-dropdown-divider"></div>

                <!-- Section 3: Classification mode -->
                <div class="ref-dropdown-header">Classification mode</div>
                <div class="ref-dropdown-item gap-2" onclick="window.app.setClassificationMode('single', event)">
                    <span class="w-3.5 text-xs text-[#262626] font-semibold">${classMode === 'single' ? '✓' : ''}</span>
                    <span>Single frame</span>
                </div>
                <div class="ref-dropdown-item gap-2" onclick="window.app.setClassificationMode('back_propagate', event)">
                    <span class="w-3.5 text-xs text-[#262626] font-semibold">${classMode === 'back_propagate' ? '✓' : ''}</span>
                    <span>Back propagate</span>
                </div>
            `;
            menu.classList.remove('hidden');
        }
    }

    showSettingsSubmenu(e) {
        if (e) e.stopPropagation();
        const sub = document.getElementById('settingsSkipSubmenu');
        if (sub) sub.classList.remove('hidden');
    }

    hideSettingsSubmenu(e) {
        if (e) e.stopPropagation();
        const sub = document.getElementById('settingsSkipSubmenu');
        if (sub) sub.classList.add('hidden');
    }

    toggleSettingsSubmenu(e) {
        if (e) e.stopPropagation();
        const sub = document.getElementById('settingsSkipSubmenu');
        if (sub) sub.classList.toggle('hidden');
    }

    toggleFrameSkipVisibility(e) {
        if (e) e.stopPropagation();
        this.showSkipSelector = !this.showSkipSelector;
        const trigger = document.getElementById('frameSkipIntervalTrigger');
        if (trigger) {
            trigger.parentElement.style.display = this.showSkipSelector ? 'block' : 'none';
        }
        this.toggleSettingsMenu();
    }

    toggleGroupByClass(e) {
        if (e) e.stopPropagation();
        this.groupByClass = !this.groupByClass;
        this.toggleSettingsMenu();
        if (this.timelineView) {
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    toggleShowSelectedOnly(e) {
        if (e) e.stopPropagation();
        this.showSelectedOnly = !this.showSelectedOnly;
        this.toggleSettingsMenu();
        if (this.timelineView) {
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
        if (this.waveformRenderer && this.timelineView) {
            this.waveformRenderer.render(this.videoController ? this.videoController.duration : 180, this.timelineView.currentPPS);
        }
    }

    setClassificationMode(mode, e) {
        if (e) e.stopPropagation();
        this.classificationMode = mode;
        this.toggleSettingsMenu();
    }

    toggleLimitSingleFrame(e) {
        if (e) e.stopPropagation();
        this.limitSingleFrame = !this.limitSingleFrame;
        this.toggleSettingsMenu();
    }

    togglePropagateAcrossGaps(e) {
        if (e) e.stopPropagation();
        this.propagateAcrossGaps = !this.propagateAcrossGaps;
        this.toggleSettingsMenu();
    }

    toggleTimestampDisplay() {
        this.displayTimestamps = !this.displayTimestamps;
        this.onVideoTimeUpdate();
        if (this.totalFramesText && this.videoController) {
            this.totalFramesText.innerHTML = `<span>${this.formatDisplay(this.videoController.getTotalFrames())}</span>`;
        }
        if (this.timelineView) {
            this.timelineView.renderTracks(this.annotationModel.getInstructions());
        }
    }

    toggleAutoScroll() {
        this.autoScroll = this.autoScroll === false ? true : false;
    }

    toggleSnapToGrid() {
        this.snapToGrid = !this.snapToGrid;
    }

    seekToTime(seconds) {
        if (!this.videoController) return;
        this.videoController.currentTime = seconds;
        this.onVideoTimeUpdate();
    }

    jumpToNextAnnotation() {
        if (!this.annotationModel || !this.videoController) return;
        const currentSec = this.videoController.currentTime;
        const items = this.annotationModel.getInstructions();
        let closest = null;
        items.forEach(it => {
            const startFrame = parseInt(it.frames.split('-')[0].trim()) || 0;
            const startSec = startFrame / CONFIG.FPS;
            if (startSec > currentSec + 0.05) {
                if (closest === null || startSec < closest) closest = startSec;
            }
        });
        if (closest !== null) this.seekToTime(closest);
    }

    jumpToPrevAnnotation() {
        if (!this.annotationModel || !this.videoController) return;
        const currentSec = this.videoController.currentTime;
        const items = this.annotationModel.getInstructions();
        let closest = null;
        items.forEach(it => {
            const startFrame = parseInt(it.frames.split('-')[0].trim()) || 0;
            const startSec = startFrame / CONFIG.FPS;
            if (startSec < currentSec - 0.05) {
                if (closest === null || startSec > closest) closest = startSec;
            }
        });
        if (closest !== null) this.seekToTime(closest);
    }

    handleTimelineClick(e) {
        if (e.target.closest('[data-testid="range"]') ||
            e.target.closest('[data-testid="left-handle"]') ||
            e.target.closest('[data-testid="right-handle"]') ||
            e.target.closest('.robust-resizer') ||
            e.target.closest('#playheadHandle') ||
            e.target.closest('#playheadLineDragZone')) {
            return;
        }

        const contentCol = document.getElementById('timelineContentColumn');
        if (!contentCol || !this.videoController) return;
        const rect = contentCol.getBoundingClientRect();
        const scrollLeft = contentCol.scrollLeft;
        const leftGutter = this.timelineView ? (this.timelineView.leftOffset || 26.8098) : 26.8098;
        const pps = this.timelineView ? this.timelineView.currentPPS : CONFIG.INITIAL_PPS;
        const offsetX = e.clientX - rect.left + scrollLeft - leftGutter;
        const duration = this.videoController.duration || 180;
        const seconds = Math.max(0, Math.min(duration, offsetX / pps));
        this.videoController.currentTime = seconds;
        this.onVideoTimeUpdate();
    }

    handleWaveformClick(e) {
        const contentCol = document.getElementById('timelineContentColumn');
        if (!contentCol || !this.videoController || !this.timelineView) {
            this.handleTimelineClick(e);
            return;
        }
        const rect = contentCol.getBoundingClientRect();
        const scrollLeft = contentCol.scrollLeft;
        const leftGutter = this.timelineView.leftOffset || 26.8098;
        const pps = this.timelineView.currentPPS || CONFIG.INITIAL_PPS;
        const offsetX = e.clientX - rect.left + scrollLeft - leftGutter;
        const clickedFrame = Math.round((offsetX / pps) * CONFIG.FPS);

        // Bidirectional Waveform Range Selection
        if (this.annotationModel) {
            const instructions = this.annotationModel.getInstructions();
            for (let i = instructions.length - 1; i >= 0; i--) {
                const ins = instructions[i];
                if (ins && ins.frames) {
                    const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, ins.className)) || { id: 'speaker_1', name: ins.className };
                    if (this.isRowHidden(cls.id, i)) continue;
                    const rawSegs = ins.frames.split(' | ').filter(Boolean);
                    for (let rIdx = rawSegs.length - 1; rIdx >= 0; rIdx--) {
                        const parts = rawSegs[rIdx].split(' - ').map(Number);
                        if (parts.length === 2 && clickedFrame >= parts[0] && clickedFrame <= parts[1]) {
                            this.selectIndividualRange(i, rIdx);
                            return;
                        }
                    }
                }
            }
        }

        // If no range clicked, seek playhead
        this.handleTimelineClick(e);
    }

    handleWaveformMouseMove(e) {
        const contentCol = document.getElementById('timelineContentColumn');
        const container = document.getElementById('videoTrackContainer');
        const canvas = document.getElementById('waveformCanvas');
        if (!contentCol || !container || !this.timelineView || !this.annotationModel) return;

        const rect = contentCol.getBoundingClientRect();
        const scrollLeft = contentCol.scrollLeft;
        const leftGutter = this.timelineView.leftOffset || 26.8098;
        const pps = this.timelineView.currentPPS || CONFIG.INITIAL_PPS;
        const mouseTrackX = e.clientX - rect.left + scrollLeft - leftGutter;

        const instructions = this.annotationModel.getInstructions();
        let isNearEdge = false;
        let isInsideRange = false;
        const edgeThresholdPx = 10; // 10px generous hit zone

        for (let i = 0; i < instructions.length; i++) {
            const ins = instructions[i];
            if (!ins || !ins.frames) continue;
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, ins.className)) || { id: 'speaker_1', name: ins.className };
            if (this.isRowHidden(cls.id, i)) continue;
            const isRowLocked = this.isRowLocked(cls.id, i);
            const rawSegs = ins.frames.split(' | ').filter(Boolean);
            for (const seg of rawSegs) {
                const parts = seg.split(' - ').map(Number);
                if (parts.length === 2) {
                    const sPx = (parts[0] / CONFIG.FPS) * pps;
                    const ePx = (parts[1] / CONFIG.FPS) * pps;
                    if (!isRowLocked && (Math.abs(mouseTrackX - sPx) <= edgeThresholdPx || Math.abs(mouseTrackX - ePx) <= edgeThresholdPx)) {
                        isNearEdge = true;
                        break;
                    } else if (mouseTrackX >= sPx && mouseTrackX <= ePx) {
                        isInsideRange = true;
                    }
                }
            }
            if (isNearEdge) break;
        }

        if (isNearEdge) {
            container.style.setProperty('cursor', CUSTOM_RESIZE_CURSOR, 'important');
            if (canvas) canvas.style.setProperty('cursor', CUSTOM_RESIZE_CURSOR, 'important');
        } else if (isInsideRange) {
            container.style.setProperty('cursor', 'pointer', 'important');
            if (canvas) canvas.style.setProperty('cursor', 'pointer', 'important');
        } else {
            container.style.cursor = 'default';
            if (canvas) canvas.style.cursor = 'default';
        }

        // Synchronize hover guide line across waveform and tracks
        if (this.timelineView && this.timelineView.tracks) {
            const tracksRect = this.timelineView.tracks.getBoundingClientRect();
            const offsetX = e.clientX - tracksRect.left;
            const maxDurationWidth = leftGutter + ((this.timelineView.videoDuration || 180) * pps);
            if (offsetX >= leftGutter && (maxDurationWidth <= 0 || offsetX <= maxDurationWidth)) {
                const guideLine = this.timelineView.ensureTracksHoverGuide();
                if (guideLine) {
                    guideLine.style.left = offsetX + 'px';
                    guideLine.style.height = Math.max(this.timelineView.tracks.scrollHeight, this.timelineView.tracks.clientHeight) + 'px';
                    guideLine.style.display = 'block';
                }
                if (this.timelineView.waveformGuideLine) {
                    this.timelineView.waveformGuideLine.style.left = offsetX + 'px';
                    this.timelineView.waveformGuideLine.style.height = '100%';
                    this.timelineView.waveformGuideLine.style.display = 'block';
                }
            } else {
                if (this.timelineView.tracksGuideLine) this.timelineView.tracksGuideLine.style.display = 'none';
                if (this.timelineView.waveformGuideLine) this.timelineView.waveformGuideLine.style.display = 'none';
            }
        }
    }

    handleWaveformMouseLeave() {
        const container = document.getElementById('videoTrackContainer');
        const canvas = document.getElementById('waveformCanvas');
        if (container) {
            container.style.cursor = 'default';
            container.style.removeProperty('cursor');
        }
        if (canvas) {
            canvas.style.cursor = 'default';
            canvas.style.removeProperty('cursor');
        }
        if (this.timelineView) {
            if (this.timelineView.tracksGuideLine) this.timelineView.tracksGuideLine.style.display = 'none';
            if (this.timelineView.waveformGuideLine) this.timelineView.waveformGuideLine.style.display = 'none';
        }
    }

    handleWaveformMouseDown(e) {
        const contentCol = document.getElementById('timelineContentColumn');
        if (!contentCol || !this.timelineView || !this.annotationModel) return;

        const rect = contentCol.getBoundingClientRect();
        const scrollLeft = contentCol.scrollLeft;
        const leftGutter = this.timelineView.leftOffset || 26.8098;
        const pps = this.timelineView.currentPPS || CONFIG.INITIAL_PPS;
        const mouseTrackX = e.clientX - rect.left + scrollLeft - leftGutter;

        const instructions = this.annotationModel.getInstructions();
        const edgeThresholdPx = 10; // 10px generous hit zone

        for (let i = instructions.length - 1; i >= 0; i--) {
            const ins = instructions[i];
            if (!ins || !ins.frames) continue;
            const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, ins.className)) || { id: 'speaker_1', name: ins.className };
            if (this.isRowHidden(cls.id, i)) continue;
            const isRowLocked = this.isRowLocked(cls.id, i);
            const rawSegs = ins.frames.split(' | ').filter(Boolean);
            for (let rIdx = rawSegs.length - 1; rIdx >= 0; rIdx--) {
                const parts = rawSegs[rIdx].split(' - ').map(Number);
                if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                    const sPx = (parts[0] / CONFIG.FPS) * pps;
                    const ePx = (parts[1] / CONFIG.FPS) * pps;
                    if (Math.abs(mouseTrackX - sPx) <= edgeThresholdPx) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (isRowLocked) return;
                        this.startRangeEdgeDrag(e, i, rIdx, 'left', cls, null);
                        return;
                    } else if (Math.abs(mouseTrackX - ePx) <= edgeThresholdPx) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (isRowLocked) return;
                        this.startRangeEdgeDrag(e, i, rIdx, 'right', cls, null);
                        return;
                    } else if (mouseTrackX >= sPx && mouseTrackX <= ePx) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (isRowLocked) return;
                        this.selectIndividualRange(i, rIdx);
                        return;
                    }
                }
            }
        }
    }

    handleTimelineZoomIn() {
        const duration = this.videoController.duration || 180;
        const minPPS = this.timelineView ? this.timelineView.computeFitPPS(duration) : CONFIG.MIN_PPS;
        const maxPPS = CONFIG.MAX_PPS;
        const newPPS = Math.min(maxPPS, Math.max(minPPS, this.timelineView.currentPPS * 1.25));
        this.timelineView.initialize(duration, newPPS);
        this.timelineView.renderTracks(this.annotationModel.getInstructions(), newPPS);
        this.onVideoTimeUpdate();
    }

    handleTimelineZoomOut() {
        const duration = this.videoController.duration || 180;
        const minPPS = this.timelineView ? this.timelineView.computeFitPPS(duration) : CONFIG.MIN_PPS;
        const maxPPS = CONFIG.MAX_PPS;
        const newPPS = Math.min(maxPPS, Math.max(minPPS, this.timelineView.currentPPS / 1.25));
        this.timelineView.initialize(duration, newPPS);
        this.timelineView.renderTracks(this.annotationModel.getInstructions(), newPPS);
        this.onVideoTimeUpdate();
    }

    setupEventListeners() {
        const playBtn = document.getElementById('btnPlayPause');
        if (playBtn) playBtn.onclick = () => this.videoController.togglePlayPause();

        const btnStart = document.getElementById('btnStart');
        if (btnStart) btnStart.onclick = () => this.videoController.rewindFrame();

        const btnNext = document.getElementById('btnNext');
        if (btnNext) btnNext.onclick = () => this.videoController.advanceFrame();

        // Frame input change / blur / enter
        const frameInput = document.getElementById('currentFrameInput');
        if (frameInput) {
            frameInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const seconds = this.parseInputTime(frameInput.value);
                    this.seekToTime(seconds);
                    frameInput.blur();
                }
            });
            frameInput.addEventListener('blur', () => {
                const seconds = this.parseInputTime(frameInput.value);
                this.seekToTime(seconds);
            });
        }

        // Progress bar click & drag
        const progressTrack = document.getElementById('progressTrack');
        if (progressTrack) {
            let isDraggingSlider = false;
            const seekFromSliderEvent = (e) => {
                const rect = progressTrack.getBoundingClientRect();
                const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                const duration = this.videoController ? (this.videoController.duration || 180) : 180;
                this.videoController.currentTime = pct * duration;
                this.onVideoTimeUpdate();
            };

            progressTrack.addEventListener('mousedown', (e) => {
                e.preventDefault();
                isDraggingSlider = true;
                seekFromSliderEvent(e);
            });

            progressTrack.addEventListener('mousemove', (e) => {
                if (isDraggingSlider) {
                    seekFromSliderEvent(e);
                } else {
                    const rect = progressTrack.getBoundingClientRect();
                    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                    const hoverSeconds = pct * (this.videoController ? this.videoController.duration : 180);
                    if (this.progressBarView) {
                        this.progressBarView.showHoverPill(pct, hoverSeconds);
                    }
                }
            });

            progressTrack.addEventListener('mouseleave', () => {
                if (!isDraggingSlider && this.progressBarView) {
                    this.progressBarView.hideHoverPill();
                }
            });

            document.addEventListener('mousemove', (e) => {
                if (isDraggingSlider) {
                    seekFromSliderEvent(e);
                }
            });

            document.addEventListener('mouseup', () => {
                if (isDraggingSlider) {
                    isDraggingSlider = false;
                }
            });
        }

        // Click outside listener for dropdowns
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.ant-dropdown-trigger') && !e.target.closest('.ant-select') && !e.target.closest('#moreNavMenu') && !e.target.closest('#frameSkipMenu') && !e.target.closest('#speedMenu') && !e.target.closest('#loopModeMenu') && !e.target.closest('#visualizationMenu') && !e.target.closest('#settingsMenu') && !e.target.closest('#settingsSkipSubmenu')) {
                this.closeAllNavigationMenus();
            }
        });

        // Click outside listener for range context menu
        document.addEventListener('mousedown', (e) => {
            if (!e.target.closest('#rangeContextMenu')) {
                this.hideRangeContextMenu();
            }
        }, true);

        // Global click-outside deselection: clicking outside ranges, labels, class list deselects all
        document.addEventListener('click', (e) => {
            // Don't deselect if clicking on interactive selection targets
            if (e.target.closest('[data-testid="range"]') ||
                e.target.closest('.label-row') ||
                e.target.closest('.data-row') ||
                e.target.closest('#classListContainer') ||
                e.target.closest('.class-item') ||
                e.target.closest('#fullEditSidebar') ||
                e.target.closest('#waveformRangesOverlay') ||
                e.target.closest('#videoTrackContainer') ||
                e.target.closest('.range-handle-wrap') ||
                e.target.closest('#tracksHoverAddBtn') ||
                e.target.closest('.ant-dropdown-trigger') ||
                e.target.closest('.ant-select') ||
                e.target.closest('[id$="Menu"]') ||
                e.target.closest('.range-ctx-menu') ||
                e.target.closest('#playheadHandle') ||
                e.target.closest('#playheadLineDragZone') ||
                e.target.closest('#timeRuler') ||
                e.target.closest('#instructionContainer') ||
                e.target.closest('#transcriptPanel') ||
                e.target.closest('#showTranscriptBtn') ||
                e.target.closest('.select-label-button')) {
                return;
            }
            // Deselect all when clicking outside
            if (this.selectionMode !== 'none') {
                this.deselectAll();
            }
        });

        // Timeline Dragging (Playhead handle, Playhead line, and Ruler)
        const playheadHandle = document.getElementById('playheadHandle');
        const playheadDragZone = document.getElementById('playheadLineDragZone');
        const timeRuler = document.getElementById('timeRuler');

        const seekTimelineFromEvent = (e) => {
            const contentCol = document.getElementById('timelineContentColumn');
            if (!contentCol || !this.videoController) return;
            const rect = contentCol.getBoundingClientRect();
            const leftGutter = this.timelineView ? (this.timelineView.leftOffset || 26.8098) : 26.8098;
            const pps = this.timelineView ? this.timelineView.currentPPS : CONFIG.INITIAL_PPS;
            const duration = this.videoController.duration || 180;
            const offsetX = e.clientX - rect.left + contentCol.scrollLeft - leftGutter;
            const seconds = Math.max(0, Math.min(duration, offsetX / pps));
            this.videoController.currentTime = seconds;
            this.onVideoTimeUpdate();
        };

        if (playheadHandle) {
            playheadHandle.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.dragState.startDrag('timeline_seek');
                seekTimelineFromEvent(e);
            });
        }

        if (playheadDragZone) {
            playheadDragZone.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.dragState.startDrag('timeline_seek');
                seekTimelineFromEvent(e);
            });
        }

        if (timeRuler) {
            timeRuler.addEventListener('mousedown', (e) => {
                e.preventDefault();
                this.dragState.startDrag('timeline_seek');
                seekTimelineFromEvent(e);
            });
        }

        document.addEventListener('mousemove', (e) => {
            if (this.dragState.isActive() && (this.dragState.getType() === 'timeline_seek' || this.dragState.getType() === 'playhead')) {
                seekTimelineFromEvent(e);
            }
        });

        document.addEventListener('mouseup', () => {
            if (this.dragState.isActive() && (this.dragState.getType() === 'timeline_seek' || this.dragState.getType() === 'playhead')) {
                this.dragState.endDrag();
            }
        });

        // Keyboard controls
        window.addEventListener('keydown', (e) => {
            const isTyping = document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA');

            // ESC: Dismiss group selection first, then save/close full edit sidebar
            if (e.key === 'Escape') {
                if (this.selectionLevel === 'group') {
                    e.preventDefault();
                    this.dismissGroupHighlight();
                    return;
                }
                if (this.editingAnnotationIndex !== -1) {
                    e.preventDefault();
                    this.saveFullEditSidebar();
                    return;
                }
                if (isTyping) {
                    document.activeElement.blur();
                    e.preventDefault();
                    return;
                }
            }

            // Dedicated DEL key: Delete group-selected or currently selected annotation
            if (e.key === 'Delete') {
                if (this.selectionLevel === 'group') {
                    e.preventDefault();
                    this.deleteCurrentAnnotation();
                    return;
                }
                if (this.editingAnnotationIndex !== -1) {
                    e.preventDefault();
                    this.deleteCurrentAnnotation();
                    return;
                }
            }

            // Ignore normal shortcuts if typing in text input (unless input is empty)
            if (isTyping) {
                const activeEl = document.activeElement;
                if (e.key === 'Backspace' && activeEl && activeEl.id === 'transcriptInputField' && activeEl.value === '') {
                    if (this.editingAnnotationIndex !== -1) {
                        e.preventDefault();
                        this.deleteCurrentAnnotation();
                        return;
                    }
                }
                return;
            }

            const key = e.key.toUpperCase();

            // DEL or Backspace: Delete selected annotation when not typing
            if (e.key === 'Delete' || e.key === 'Backspace') {
                if (this.editingAnnotationIndex !== -1) {
                    e.preventDefault();
                    this.deleteCurrentAnnotation();
                    return;
                }
            }

            // Shortcuts while in Full Edit mode
            if (this.editingAnnotationIndex !== -1 && this.annotationModel.instructions[this.editingAnnotationIndex]) {
                const instr = this.annotationModel.instructions[this.editingAnnotationIndex];
                const cls = CONFIG.CLASSES.find(c => isSameClass(c.name, instr.className));

                if (cls && cls.id === 'audio_quality') {
                    if (key === 'Q') { e.preventDefault(); this.selectAudioQualityOption('Excellent'); return; }
                    if (key === 'W') { e.preventDefault(); this.selectAudioQualityOption('Good'); return; }
                    if (key === 'E') { e.preventDefault(); this.selectAudioQualityOption('Fair'); return; }
                    if (key === 'R') { e.preventDefault(); this.selectAudioQualityOption('Poor'); return; }
                } else if (cls && (cls.id === 'speaker_1' || cls.id === 'speaker_2')) {
                    if (key === 'Q') {
                        e.preventDefault();
                        const transcriptInput = document.getElementById('transcriptInputField');
                        if (transcriptInput) transcriptInput.focus();
                        return;
                    }
                    if (key === 'C') {
                        e.preventDefault();
                        this.changeCurrentClass();
                        return;
                    }
                }

                // Alt + Arrow Left/Right to adjust edge
                if (e.altKey && e.key === 'ArrowRight') {
                    e.preventDefault();
                    this.adjustCurrentRangeEdge('right', 1);
                    return;
                }
                if (e.altKey && e.key === 'ArrowLeft') {
                    e.preventDefault();
                    this.adjustCurrentRangeEdge(e.shiftKey ? 'left' : 'right', -1);
                    return;
                }
            }

            // Class selection shortcuts (1: Speaker 1, 2: Speaker 2, 3: Audio quality)
            if (key === '1') { e.preventDefault(); this.handleClassClick('speaker_1'); return; }
            if (key === '2') { e.preventDefault(); this.handleClassClick('speaker_2'); return; }
            if (key === '3') { e.preventDefault(); this.handleClassClick('audio_quality'); return; }

            // Playback controls
            if (e.key === ' ') { e.preventDefault(); this.videoController.togglePlayPause(); }
            if (e.key === 'ArrowRight') { e.preventDefault(); this.videoController.advanceFrame(); }
            if (e.key === 'ArrowLeft') { e.preventDefault(); this.videoController.rewindFrame(); }
        });

        // Ctrl + Mouse Wheel Timeline Zoom
        const timelineSec = document.getElementById('timelineSection');
        if (timelineSec) {
            timelineSec.addEventListener('wheel', (e) => {
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    const contentCol = document.getElementById('timelineContentColumn');
                    const rect = contentCol ? contentCol.getBoundingClientRect() : timelineSec.getBoundingClientRect();
                    const cursorX = e.clientX - rect.left;
                    const scrollLeft = contentCol ? contentCol.scrollLeft : 0;
                    const leftGutter = 26.8098;

                    const duration = this.videoController.duration || 180;
                    const minPPS = this.timelineView ? this.timelineView.computeFitPPS(duration) : CONFIG.MIN_PPS;
                    const maxPPS = CONFIG.MAX_PPS;

                    const oldPPS = this.timelineView.currentPPS;
                    const zoomFactor = e.deltaY < 0 ? 1.25 : 1 / 1.25;
                    const newPPS = Math.min(maxPPS, Math.max(minPPS, oldPPS * zoomFactor));

                    if (Math.abs(newPPS - oldPPS) > 0.01) {
                        const timeAtCursor = Math.max(0, (scrollLeft + cursorX - leftGutter) / oldPPS);
                        this.timelineView.initialize(duration, newPPS);
                        this.timelineView.renderTracks(this.annotationModel.getInstructions(), newPPS);
                        this.onVideoTimeUpdate();

                        if (contentCol) {
                            contentCol.scrollLeft = Math.max(0, (timeAtCursor * newPPS) + leftGutter - cursorX);
                        }
                    }
                }
            }, { passive: false });
        }
    }

    startDirectRangeDrag(e, dataEl, cls, isFromAddBtn = false, rowDef = null) {
        e.preventDefault();

        const contentCol = document.getElementById('timelineContentColumn');
        if (!contentCol) return;

        const leftGutter = this.timelineView ? (this.timelineView.leftOffset || 26.8098) : 26.8098;
        const pps = this.timelineView ? this.timelineView.currentPPS : CONFIG.INITIAL_PPS;
        const duration = this.videoController ? (this.videoController.duration || 180) : 180;
        const totalTimelineWidth = duration * pps;
        const totalFrames = this.videoController ? this.videoController.getTotalFrames() : Math.round(duration * CONFIG.FPS);

        const getTimelineCoord = (clientX) => {
            const colRect = contentCol.getBoundingClientRect();
            const rawTrackX = clientX - colRect.left + contentCol.scrollLeft;
            const framePx = Math.max(0, Math.min(totalTimelineWidth, rawTrackX - leftGutter));
            const frame = Math.max(0, Math.min(totalFrames, Math.round((framePx / pps) * CONFIG.FPS)));
            return { rawTrackX, framePx, frame };
        };

        const startCoord = getTimelineCoord(e.clientX);
        const startFrame = startCoord.frame;
        const startX = leftGutter + (startFrame / CONFIG.FPS) * pps;
        const startClientX = e.clientX;
        const startClientY = e.clientY;

        let bgCol = cls.color || 'rgb(150, 97, 246)';
        let handleCol = cls.handleColor || 'rgb(105, 29, 242)';
        let textCol = cls.textColor || '#ffffff';
        let isAudioQuality = (cls.id === 'audio_quality' || isSameClass(cls.name, 'Audio quality'));

        if (cls.id === 'speaker_1' || isSameClass(cls.name, 'Speaker 1')) {
            bgCol = 'rgb(254, 217, 255)';
            handleCol = 'rgb(253, 161, 255)';
            textCol = 'rgb(253, 161, 255)';
        } else if (cls.id === 'speaker_2' || isSameClass(cls.name, 'Speaker 2')) {
            bgCol = 'rgb(237, 173, 161)';
            handleCol = 'rgb(211, 49, 21)';
            textCol = 'rgb(211, 49, 21)';
        } else if (isAudioQuality) {
            bgCol = 'rgb(150, 97, 246)';
            handleCol = 'rgb(105, 29, 242)';
            textCol = '#ffffff';
        }

        const targetRow = (dataEl && dataEl.isConnected)
            ? dataEl
            : (document.querySelector(`.data-row[data-class-id="${cls.id}"]`) || dataEl);

        const previewEl = document.createElement('div');
        previewEl.className = `absolute h-[24px] top-1/2 -translate-y-1/2 rounded-[4px] pointer-events-none flex items-center px-1.5 z-30 shadow-xs ${isAudioQuality ? '!text-white' : ''}`;
        previewEl.style.left = startX + 'px';
        previewEl.style.width = '0px';
        previewEl.style.background = bgCol;
        previewEl.style.opacity = '1';
        previewEl.style.color = textCol;
        previewEl.style.display = 'none';

        const previewText = document.createElement('span');
        previewText.className = 'text-[11px] font-semibold truncate select-none whitespace-nowrap';
        if (isAudioQuality) {
            previewText.textContent = `${this.formatDisplay(startFrame)} - ${this.formatDisplay(startFrame)}`;
            previewEl.appendChild(previewText);
        }

        if (targetRow) {
            targetRow.appendChild(previewEl);
        }

        this._directRangeDrag = true;
        if (this.timelineView && this.timelineView.tracksAddBtn) {
            this.timelineView.tracksAddBtn.style.display = 'none';
        }

        const guideLine = this.timelineView ? this.timelineView.ensureTracksHoverGuide() : null;

        let hasMoved = false;

        const onMouseMove = (moveEvent) => {
            const dx = Math.abs(moveEvent.clientX - startClientX);
            const dy = Math.abs(moveEvent.clientY - startClientY);
            if (!hasMoved && (dx >= 3 || dy >= 3)) {
                hasMoved = true;
                previewEl.style.display = 'flex';
            }

            if (!hasMoved) return;

            const curCoord = getTimelineCoord(moveEvent.clientX);
            const currentFrame = curCoord.frame;
            const sFrame = Math.min(startFrame, currentFrame);
            const eFrame = Math.max(startFrame, currentFrame);

            const left = leftGutter + (sFrame / CONFIG.FPS) * pps;
            const width = Math.max(2, ((eFrame - sFrame) / CONFIG.FPS) * pps);

            previewEl.style.left = left + 'px';
            previewEl.style.width = width + 'px';
            if (isAudioQuality) {
                previewText.textContent = `${this.formatDisplay(sFrame)} - ${this.formatDisplay(eFrame)}`;
            }

            if (this.waveformRenderer && this.timelineView) {
                this.waveformRenderer.render(
                    this.timelineView.videoDuration || 180,
                    this.timelineView.currentPPS,
                    null,
                    { sFrame, eFrame, className: cls.name }
                );
            }

            if (guideLine && this.timelineView && this.timelineView.tracks) {
                const guidePos = leftGutter + (currentFrame / CONFIG.FPS) * pps;
                guideLine.style.left = guidePos + 'px';
                guideLine.style.height = Math.max(this.timelineView.tracks.scrollHeight, this.timelineView.tracks.clientHeight) + 'px';
                guideLine.style.display = 'block';
            }
        };

        const onMouseUp = (upEvent) => {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);

            this._directRangeDrag = false;

            if (previewEl && previewEl.parentNode) {
                previewEl.parentNode.removeChild(previewEl);
            }
            if (guideLine) {
                guideLine.style.display = 'none';
            }

            const endCoord = getTimelineCoord(upEvent.clientX);
            const currentFrame = endCoord.frame;
            const sFrame = Math.min(startFrame, currentFrame);
            const eFrame = Math.max(startFrame, currentFrame);

            const effectiveRowDef = rowDef || (targetRow ? targetRow._rowDef : null);
            let rowInstrIdx = (effectiveRowDef && effectiveRowDef.instrIdx !== undefined) ? effectiveRowDef.instrIdx : undefined;
            let isParentHeader = effectiveRowDef ? !!effectiveRowDef.isParentHeader : false;
            let isChildRangeRow = effectiveRowDef ? !!effectiveRowDef.isChildRangeRow : false;
            let isFlatRow = effectiveRowDef ? !!effectiveRowDef.isFlatRow : false;

            if (targetRow) {
                const idxAttr = targetRow.getAttribute('data-instr-idx');
                const rowIdAttr = targetRow.getAttribute('data-row-id');
                if (idxAttr !== null && idxAttr !== undefined && idxAttr !== '') {
                    const parsed = parseInt(idxAttr, 10);
                    if (!isNaN(parsed)) {
                        rowInstrIdx = parsed;
                        isChildRangeRow = true;
                        isParentHeader = false;
                    }
                } else if (rowIdAttr && rowIdAttr.startsWith('instance_')) {
                    isChildRangeRow = true;
                    isParentHeader = false;
                } else if (rowIdAttr === cls.id && rowInstrIdx === undefined) {
                    isParentHeader = true;
                    isChildRangeRow = false;
                }
            }

            if (hasMoved && eFrame > sFrame) {
                const isAudioQuality = isSameClass(cls.name, 'Audio quality');
                const defaultText = '';

                if (this.groupByClass) {
                    if ((isChildRangeRow || rowInstrIdx !== undefined) && rowInstrIdx !== undefined && this.annotationModel.instructions[rowInstrIdx]) {
                        // Dragged on an existing child row: ALWAYS add multi-range segment to that existing child instance (never create new class!)
                        const targetInstr = this.annotationModel.instructions[rowInstrIdx];
                        const segs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        segs.push(`${sFrame} - ${eFrame}`);
                        targetInstr.frames = mergeRangeSegments(segs);
                        const mergedSegs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        const newSegIdx = mergedSegs.findIndex(s => {
                            const parts = s.split(' - ').map(Number);
                            return parts.length === 2 && sFrame >= parts[0] && eFrame <= parts[1];
                        });
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(rowInstrIdx, newSegIdx !== -1 ? newSegIdx : mergedSegs.length - 1);
                    } else if (isParentHeader) {
                        // Dragged on parent class header: creates a NEW child instance underneath
                        const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
                        this.annotationModel.instructions.push({
                            id: newId,
                            segmentId: newId,
                            className: cls.name,
                            frames: `${sFrame} - ${eFrame}`,
                            text: defaultText,
                            timestamp: Date.now()
                        });
                        const targetIdx = this.annotationModel.instructions.length - 1;
                        if (!this.collapsedRows) this.collapsedRows = {};
                        this.collapsedRows[cls.id] = false; // Auto expand parent to show new child instance
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(targetIdx, 0);
                        if (!isAudioQuality) {
                            this.checkShowInstanceHint(cls);
                        }
                    } else {
                        // Fallback: check if an existing instance for this class exists to add to
                        const existingIdx = this.annotationModel.instructions.findIndex(ins => isSameClass(ins.className, cls.name));
                        if (existingIdx !== -1) {
                            const targetInstr = this.annotationModel.instructions[existingIdx];
                            const segs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                            segs.push(`${sFrame} - ${eFrame}`);
                            targetInstr.frames = mergeRangeSegments(segs);
                            const mergedSegs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                            const newSegIdx = mergedSegs.findIndex(s => {
                                const parts = s.split(' - ').map(Number);
                                return parts.length === 2 && sFrame >= parts[0] && eFrame <= parts[1];
                            });
                            this.timelineView.renderTracks(this.annotationModel.getInstructions());
                            this.renderInstructions();
                            this.openFullEditSidebar(existingIdx, newSegIdx !== -1 ? newSegIdx : mergedSegs.length - 1);
                        } else {
                            const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
                            this.annotationModel.instructions.push({
                                id: newId,
                                segmentId: newId,
                                className: cls.name,
                                frames: `${sFrame} - ${eFrame}`,
                                text: defaultText,
                                timestamp: Date.now()
                            });
                            const targetIdx = this.annotationModel.instructions.length - 1;
                            this.timelineView.renderTracks(this.annotationModel.getInstructions());
                            this.renderInstructions();
                            this.openFullEditSidebar(targetIdx, 0);
                        }
                    }
                } else {
                    // Group by class OFF (Flat list view):
                    if (rowInstrIdx !== undefined && this.annotationModel.instructions[rowInstrIdx]) {
                        // Dragged on an existing flat row: add multi-range segment to that existing track (does NOT create a new row)
                        const targetInstr = this.annotationModel.instructions[rowInstrIdx];
                        const segs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        segs.push(`${sFrame} - ${eFrame}`);
                        targetInstr.frames = mergeRangeSegments(segs);
                        const mergedSegs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        const newSegIdx = mergedSegs.findIndex(s => {
                            const parts = s.split(' - ').map(Number);
                            return parts.length === 2 && sFrame >= parts[0] && eFrame <= parts[1];
                        });
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(rowInstrIdx, newSegIdx !== -1 ? newSegIdx : mergedSegs.length - 1);
                    } else {
                        // First range on empty class track
                        const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
                        this.annotationModel.instructions.push({
                            id: newId,
                            segmentId: newId,
                            className: cls.name,
                            frames: `${sFrame} - ${eFrame}`,
                            text: defaultText,
                            timestamp: Date.now()
                        });
                        const targetIdx = this.annotationModel.instructions.length - 1;
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(targetIdx, 0);
                    }
                }
            } else if (isFromAddBtn && !hasMoved) {
                const finalEndFrame = Math.min(totalFrames, sFrame + Math.round(CONFIG.FPS));
                const isAudioQuality = isSameClass(cls.name, 'Audio quality');
                const defaultText = '';

                if (this.groupByClass) {
                    if ((isChildRangeRow || rowInstrIdx !== undefined) && rowInstrIdx !== undefined && this.annotationModel.instructions[rowInstrIdx]) {
                        const targetInstr = this.annotationModel.instructions[rowInstrIdx];
                        const segs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        segs.push(`${sFrame} - ${finalEndFrame}`);
                        targetInstr.frames = mergeRangeSegments(segs);
                        const mergedSegs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        const newSegIdx = mergedSegs.findIndex(s => {
                            const parts = s.split(' - ').map(Number);
                            return parts.length === 2 && sFrame >= parts[0] && finalEndFrame <= parts[1];
                        });
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(rowInstrIdx, newSegIdx !== -1 ? newSegIdx : mergedSegs.length - 1);
                    } else if (isParentHeader) {
                        const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
                        this.annotationModel.instructions.push({
                            id: newId,
                            segmentId: newId,
                            className: cls.name,
                            frames: `${sFrame} - ${finalEndFrame}`,
                            text: defaultText,
                            timestamp: Date.now()
                        });
                        const targetIdx = this.annotationModel.instructions.length - 1;
                        if (!this.collapsedRows) this.collapsedRows = {};
                        this.collapsedRows[cls.id] = false;
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(targetIdx, 0);
                        if (!isAudioQuality) {
                            this.checkShowInstanceHint(cls);
                        }
                    } else {
                        const existingIdx = this.annotationModel.instructions.findIndex(ins => isSameClass(ins.className, cls.name));
                        if (existingIdx !== -1) {
                            const targetInstr = this.annotationModel.instructions[existingIdx];
                            const segs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                            segs.push(`${sFrame} - ${finalEndFrame}`);
                            targetInstr.frames = mergeRangeSegments(segs);
                            const mergedSegs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                            const newSegIdx = mergedSegs.findIndex(s => {
                                const parts = s.split(' - ').map(Number);
                                return parts.length === 2 && sFrame >= parts[0] && finalEndFrame <= parts[1];
                            });
                            this.timelineView.renderTracks(this.annotationModel.getInstructions());
                            this.renderInstructions();
                            this.openFullEditSidebar(existingIdx, newSegIdx !== -1 ? newSegIdx : mergedSegs.length - 1);
                        } else {
                            const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
                            this.annotationModel.instructions.push({
                                id: newId,
                                segmentId: newId,
                                className: cls.name,
                                frames: `${sFrame} - ${finalEndFrame}`,
                                text: defaultText,
                                timestamp: Date.now()
                            });
                            const targetIdx = this.annotationModel.instructions.length - 1;
                            this.timelineView.renderTracks(this.annotationModel.getInstructions());
                            this.renderInstructions();
                            this.openFullEditSidebar(targetIdx, 0);
                        }
                    }
                } else {
                    if (rowInstrIdx !== undefined && this.annotationModel.instructions[rowInstrIdx]) {
                        const targetInstr = this.annotationModel.instructions[rowInstrIdx];
                        const segs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        segs.push(`${sFrame} - ${finalEndFrame}`);
                        targetInstr.frames = mergeRangeSegments(segs);
                        const mergedSegs = (targetInstr.frames || '').split(' | ').filter(Boolean);
                        const newSegIdx = mergedSegs.findIndex(s => {
                            const parts = s.split(' - ').map(Number);
                            return parts.length === 2 && sFrame >= parts[0] && finalEndFrame <= parts[1];
                        });
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(rowInstrIdx, newSegIdx !== -1 ? newSegIdx : mergedSegs.length - 1);
                    } else {
                        const newId = `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
                        this.annotationModel.instructions.push({
                            id: newId,
                            segmentId: newId,
                            className: cls.name,
                            frames: `${sFrame} - ${finalEndFrame}`,
                            text: defaultText,
                            timestamp: Date.now()
                        });
                        const targetIdx = this.annotationModel.instructions.length - 1;
                        this.timelineView.renderTracks(this.annotationModel.getInstructions());
                        this.renderInstructions();
                        this.openFullEditSidebar(targetIdx, 0);
                    }
                }
            }
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    setupFormSubmission() {
        const form = document.querySelector('crowd-form');
        if (!form) return;

        form.onsubmit = (e) => {
            const instructions = this.annotationModel ? this.annotationModel.getInstructions() : [];

            // 1. Validate Audio quality (Required '*')
            const hasAudioQuality = instructions.some(ins => isSameClass(ins.className, 'Audio quality'));
            if (!hasAudioQuality) {
                e.preventDefault();
                this.showValidationError('Audio quality is required. Please add at least one Audio quality segment.');
                return false;
            }

            const unselectedAudioQuality = instructions.find(ins => isSameClass(ins.className, 'Audio quality') && (!ins.text || !ins.text.trim()));
            if (unselectedAudioQuality) {
                e.preventDefault();
                this.showValidationError('Please select an Audio quality rating (Excellent, Good, Fair, or Poor).');
                return false;
            }

            // 2. Validate Speaker Transcripts (Required '*')
            const missingTranscript = instructions.find(ins => {
                const isSpeaker = isSameClass(ins.className, 'Speaker 1') || isSameClass(ins.className, 'Speaker 2');
                return isSpeaker && (!ins.text || !ins.text.trim());
            });

            if (missingTranscript) {
                e.preventDefault();
                this.showValidationError(`Please enter a Transcript for all ${missingTranscript.className} segments.`);
                return false;
            }

            // 3. Serialize structured annotations into #annotations_output
            const formattedPayload = instructions.map((ins, idx) => {
                const parts = (ins.frames || '0 - 0').split(' - ').map(Number);
                const sFrame = isNaN(parts[0]) ? 0 : parts[0];
                const eFrame = isNaN(parts[1]) ? 0 : parts[1];
                const startTime = +(sFrame / CONFIG.FPS).toFixed(3);
                const endTime = +(eFrame / CONFIG.FPS).toFixed(3);

                const item = {
                    segment_id: ins.segmentId || ins.id || `seg_${idx}`,
                    class_name: ins.className,
                    start_frame: sFrame,
                    end_frame: eFrame,
                    start_time: startTime,
                    end_time: endTime
                };

                if (isSameClass(ins.className, 'Audio quality')) {
                    item.audio_quality = ins.text || '';
                } else {
                    item.transcript = ins.text || '';
                    item.instance_id = this.getInstanceIndex(ins);
                }

                return item;
            });

            const output = document.getElementById('annotations_output');
            if (output) {
                output.value = JSON.stringify(formattedPayload);
            }

            const progress = document.getElementById('progress_status');
            if (progress) {
                progress.value = 'completed';
            }

            return true;
        };
    }

    showValidationError(msg) {
        const toast = document.getElementById('validationToast');
        const msgEl = document.getElementById('validationToastMessage');
        if (toast && msgEl) {
            msgEl.textContent = msg;
            toast.classList.remove('hidden');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 4500);
        } else {
            alert(msg);
        }
    }
}

function initGlobalTooltipManager() {
    if (window._globalTooltipManagerInitialized) return;
    window._globalTooltipManagerInitialized = true;

    let tooltipEl = document.getElementById('globalAppTooltip');
    if (!tooltipEl) {
        tooltipEl = document.createElement('div');
        tooltipEl.id = 'globalAppTooltip';
        document.body.appendChild(tooltipEl);
    }

    let activeTarget = null;

    function getTooltipTarget(target) {
        if (!target || target === document || target === document.body) return null;
        return target.closest('[data-tooltip], [data-title], [title]');
    }

    function showTooltip(el) {
        if (!el) return;
        activeTarget = el;

        let text = el.getAttribute('data-tooltip') || el.getAttribute('data-title');
        if (!text && el.getAttribute('title')) {
            text = el.getAttribute('title');
            el.setAttribute('data-tooltip', text);
            el.removeAttribute('title');
        }
        if (!text || !text.trim()) {
            hideTooltip();
            return;
        }

        const shortcut = el.getAttribute('data-shortcut');
        if (shortcut && !text.includes(shortcut) && !text.includes('(')) {
            tooltipEl.innerHTML = `<span>${escapeHtml(text)}</span><span style="opacity:0.75;font-size:11px;margin-left:6px;font-weight:400;">(${escapeHtml(shortcut)})</span>`;
        } else {
            tooltipEl.textContent = text;
        }

        tooltipEl.style.display = 'block';
        tooltipEl.className = '';

        const rect = el.getBoundingClientRect();
        const tipRect = tooltipEl.getBoundingClientRect();

        const pos = el.getAttribute('data-tooltip-pos') || (rect.top > tipRect.height + 12 ? 'top' : 'bottom');
        tooltipEl.setAttribute('data-pos', pos);

        let top = 0;
        let left = rect.left + (rect.width / 2) - (tipRect.width / 2);

        if (pos === 'top') {
            top = rect.top - tipRect.height - 7;
        } else if (pos === 'bottom') {
            top = rect.bottom + 7;
        } else if (pos === 'left') {
            left = rect.left - tipRect.width - 7;
            top = rect.top + (rect.height / 2) - (tipRect.height / 2);
        } else if (pos === 'right') {
            left = rect.right + 7;
            top = rect.top + (rect.height / 2) - (tipRect.height / 2);
        }

        const padding = 8;
        if (left < padding) left = padding;
        if (left + tipRect.width > window.innerWidth - padding) {
            left = window.innerWidth - tipRect.width - padding;
        }
        if (top < padding) top = padding;

        tooltipEl.style.left = `${Math.round(left)}px`;
        tooltipEl.style.top = `${Math.round(top)}px`;
        tooltipEl.classList.add('visible');
    }

    function hideTooltip() {
        activeTarget = null;
        if (tooltipEl) {
            tooltipEl.classList.remove('visible');
            tooltipEl.style.display = 'none';
        }
    }

    document.addEventListener('mouseover', (e) => {
        const target = getTooltipTarget(e.target);
        if (target) {
            if (target.hasAttribute('title')) {
                const t = target.getAttribute('title');
                target.setAttribute('data-tooltip', target.getAttribute('data-tooltip') || t);
                target.removeAttribute('title');
            }
            showTooltip(target);
        } else if (activeTarget && !activeTarget.contains(e.target)) {
            hideTooltip();
        }
    }, true);

    document.addEventListener('mouseout', (e) => {
        if (activeTarget && (e.relatedTarget === null || !activeTarget.contains(e.relatedTarget))) {
            hideTooltip();
        }
    }, true);

    document.addEventListener('mousedown', () => {
        hideTooltip();
    }, true);

    document.addEventListener('scroll', () => {
        if (activeTarget) {
            showTooltip(activeTarget);
        }
    }, true);
}

// Global Alias for Compatibility
const Step1TimelineApp = AudioAnnotationApp;

document.addEventListener('DOMContentLoaded', () => {
    window.app = new AudioAnnotationApp();
    window.app.initialize();
});