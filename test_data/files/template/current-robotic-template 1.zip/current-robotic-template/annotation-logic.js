/**
* SOLID Principles: SRP, OCP, LSP, ISP, DIP
*/
console.log("Script loaded successfully!");
// ============================================================================
// CONFIGURATION & CONSTANTS
// ============================================================================
const CONFIG = {
    FPS: 30,
    INITIAL_PPS: 160,
    CLASSES: [
            {
        id: 'segment',
        name: 'Segment',
        classShortcut: '1',
        color: '#34d399',
        subInputs: [
            { 
                id: 'task_name', 
                name: 'Task', 
                label: 'Task', 
                type: 'text', 
                shortcut: 'Q', 
                optionShortcuts: ['E'], 
                required: false 
            },
            { 
                id: 'action_label', 
                name: 'Action_label', 
                label: 'Action_label', 
                type: 'text', 
                shortcut: 'W', 
                optionShortcuts: ['R'], 
                required: false 
            },
            { 
                id: 'environment', 
                name: 'Environment', 
                label: 'Environment', 
                type: 'dropdown', 
                options: [
                    'Kitchen',
                    'Bedroom',
                    'Bathroom',
                    'Living Room',
                    'Home Office',
                    'Garage',
                    'Outdoor',
                    'Rejected'
                ], 
                shortcut: 'E', 
                required: false 
            }
        ]
    }

    ],
    MIN_PPS: 50,
    MAX_PPS: 1000,
    PIXELS_PER_SECOND: 160,
    SIDEBAR_WIDTH: 160,
    ZOOM_STEP: 0.1,
    MIN_ZOOM: 0.2,
    MAX_ZOOM: 10,
    SCROLL_PADDING: 100,
    PLAYBACK_SPEEDS: [0.125, 0.25, 0.5, 1, 1.25, 1.5, 1.75, 2, 4, 8],
    FILTER_SLIDERS: ['brightRange', 'contrastRange', 'gammaRange'],
    ZOOM_TOOLS_SELECTOR: '.zoom-tool',
    ROTATE_OPTIONS_SELECTOR: '.rotate-opt',
    FILTER_OPTIONS_SELECTOR: '.filter-opt',
    DEFAULT_TIMESTAMP_FORMAT: 'MM:SS', // Default to Frames (FPS)
    TIMESTAMP_FORMATS: ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'],
    FRAME_SKIP_VALUES: [1, 6, 12, 18, 24, 30, 36, 42, 48, 54, 60, 120, 240],
    DEFAULT_FRAME_SKIP: 1,
    SIDEBAR_MIN_WIDTH: 260,
    SIDEBAR_MAX_WIDTH: 600,
    TIMELINE_MIN_HEIGHT: 40,
    INITIAL_TIMELINE_HEIGHT: 350,
    overwrite_validate: true,
    ISSUE_TAGS: [
        { id: 'high', name: 'High', color: '#ff4d4f', bgColor: '#fff1f0', borderColor: '#ffa39e', fontWeight: '480' },
        { id: 'medium', name: 'Medium', color: '#ffa940', bgColor: '#fff7e6', borderColor: '#ffd591', fontWeight: '480' },
        { id: 'low', name: 'Low', color: '#ffec3d', bgColor: '#feffe6', borderColor: '#fffb8f', fontWeight: '480' }
    ]
};
// Global Icon Constants
const PARTITION_ICON_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M640.6 429.8h257.1c7.9 0 14.3-6.4 14.3-14.3V158.3c0-7.9-6.4-14.3-14.3-14.3H640.6c-7.9 0-14.3 6.4-14.3 14.3v92.9H490.6c-3.9 0-7.1 3.2-7.1 7.1v221.5h-85.7v-96.5c0-7.9-6.4-14.3-14.3-14.3H126.3c-7.9 0-14.3 6.4-14.3 14.3v257.2c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3V544h85.7v221.5c0 3.9 3.2 7.1 7.1 7.1h135.7v92.9c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3v-257c0-7.9-6.4-14.3-14.3-14.3h-257c-7.9 0-14.3 6.4-14.3 14.3v100h-78.6v-393h78.6v100c0 7.9 6.4 14.3 14.3 14.3zm53.5-217.9h150V362h-150V211.9zM329.9 587h-150V437h150v150zm364.2 75.1h150v150.1h-150V662.1z"></path></svg>`;
const VIDEO_ICON_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M912 302.3L784 376V224c0-35.3-28.7-64-64-64H128c-35.3 0-64 28.7-64 64v576c0 35.3 28.7 64 64 64h592c35.3 0 64-28.7 64-64V648l128 73.7c21.3 12.3 48-3.1 48-27.6V330c0-24.6-26.7-40-48-27.7zM712 792H136V232h576v560zm176-167l-104-59.8V458.9L888 399v226zM208 360h112c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H208c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path></svg>`;
const VOLUME_UP_SVG = `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"></path><path d="M16 9a5 5 0 0 1 0 6"></path><path d="M19.364 18.364a9 9 0 0 0 0-12.728"></path></svg>`;
const VOLUME_OFF_SVG = `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M16 9a5 5 0 0 1 .95 2.293"></path><path d="M19.364 5.636a9 9 0 0 1 1.889 9.96"></path><path d="m2 2 20 20"></path><path d="m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11"></path><path d="M9.828 4.172A.686.686 0 0 1 11 4.657v.686"></path></svg>`;
const PLAY_ICON_SVG = `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" height="15" width="15" xmlns="http://www.w3.org/2000/svg"><polygon points="6 3 20 12 6 21 6 3"></polygon></svg>`;
const PAUSE_ICON_SVG = `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" height="15" width="15" xmlns="http://www.w3.org/2000/svg"><rect x="14" y="4" width="4" height="16" rx="1"></rect><rect x="6" y="4" width="4" height="16" rx="1"></rect></svg>`;
const COPY_ICON_SVG = `<svg viewBox="64 64 896 896" width="16" height="16" fill="currentColor"><path d="M832 64H296c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h496v688c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V96c0-17.7-14.3-32-32-32zM704 192H192c-17.7 0-32 14.3-32 32v530.7c0 8.5 3.4 16.6 9.4 22.6l173.3 173.3c2.2 2.2 4.7 4 7.4 5.5v1.9h4.2c3.5 1.3 7.2 2 11 2H704c17.7 0 32-14.3 32-32V224c0-17.7-14.3-32-32-32zM350 856.2L263.9 770H350v86.2zM664 888H414V746c0-22.1-17.9-40-40-40H232V264h432v624z"></path></svg>`;
const LINK_ICON_SVG = `<svg viewBox="64 64 896 896" width="16" height="16" fill="currentColor"><path d="M574 665.4a8.03 8.03 0 00-11.3 0L446.5 781.6c-53.8 53.8-144.6 59.5-204 0-59.5-59.5-53.8-150.2 0-204l116.2-116.2c3.1-3.1 3.1-8.2 0-11.3l-39.8-39.8a8.03 8.03 0 00-11.3 0L191.4 526.5c-84.6 84.6-84.6 221.5 0 306s221.5 84.6 306 0l116.2-116.2c3.1-3.1 3.1-8.2 0-11.3L574 665.4zm258.6-474c-84.6-84.6-221.5-84.6-306 0L410.3 307.6a8.03 8.03 0 000 11.3l39.7 39.7c3.1 3.1 8.2 3.1 11.3 0l116.2-116.2c53.8-53.8 144.6-59.5 204 0 59.5 59.5 53.8 150.2 0 204L665.3 562.6a8.03 8.03 0 000 11.3l39.8 39.8c3.1 3.1 8.2 3.1 11.3 0l116.2-116.2c84.5-84.6 84.5-221.5 0-306.1zM610.1 372.3a8.03 8.03 0 00-11.3 0L372.3 598.7a8.03 8.03 0 000 11.3l39.6 39.6c3.1 3.1 8.2 3.1 11.3 0l226.4-226.4c3.1-3.1 3.1-8.2 0-11.3l-39.5-39.6z"></path></svg>`;
const GO_TO_ICON_SVG = `<svg viewBox="64 64 896 896" width="16" height="16" fill="currentColor"><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h360c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H184V184h656v320c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V144c0-17.7-14.3-32-32-32zM653.3 599.4l52.2-52.2a8.01 8.01 0 00-4.7-13.6l-179.4-21c-5.1-.6-9.5 3.7-8.9 8.9l21 179.4c.8 6.6 8.9 9.4 13.6 4.7l52.4-52.4 256.2 256.2c3.1 3.1 8.2 3.1 11.3 0l42.4-42.4c3.1-3.1 3.1-8.2 0-11.3L653.3 599.4z"></path></svg>`;
const EDIT_ICON_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="setting" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M924.8 625.7l-65.5-56c3.1-19 4.7-38.4 4.7-57.8s-1.6-38.8-4.7-57.8l65.5-56a32.03 32.03 0 009.3-35.2l-.9-2.6a443.74 443.74 0 00-79.7-137.9l-1.8-2.1a32.12 32.12 0 00-35.1-9.5l-81.3 28.9c-30-24.6-63.5-44-99.7-57.6l-15.7-85a32.05 32.05 0 00-25.8-25.7l-2.7-.5c-52.1-9.4-106.9-9.4-159 0l-2.7.5a32.05 32.05 0 00-25.8 25.7l-15.8 85.4a351.86 351.86 0 00-99 57.4l-81.9-29.1a32 32 0 00-35.1 9.5l-1.8 2.1a446.02 446.02 0 00-79.7 137.9l-.9 2.6c-4.5 12.5-.8 26.5 9.3 35.2l66.3 56.6c-3.1 18.8-4.6 38-4.6 57.1 0 19.2 1.5 38.4 4.6 57.1L99 625.5a32.03 32.03 0 00-9.3 35.2l.9 2.6c18.1 50.4 44.9 96.9 79.7 137.9l1.8 2.1a32.12 32.12 0 0035.1 9.5l81.9-29.1c29.8 24.5 63.1 43.9 99 57.4l15.8 85.4a32.05 32.05 0 0025.8 25.7l2.7.5a449.4 449.4 0 00159 0l2.7-.5a32.05 32.05 0 0025.8-25.7l15.7-85a350 350 0 0099.7-57.6l81.3 28.9a32 32 0 0035.1-9.5l1.8-2.1c34.8-41.1 61.6-87.5 79.7-137.9l.9-2.6c4.5-12.3.8-26.3-9.3-35zM788.3 465.9c2.5 15.1 3.8 30.6 3.8 46.1s-1.3 31-3.8 46.1l-6.6 40.1 74.7 63.9a370.03 370.03 0 01-42.6 73.6L721 702.8l-31.4 25.8c-23.9 19.6-50.5 35-79.3 45.8l-38.1 14.3-17.9 97a377.5 377.5 0 01-85 0l-17.9-97.2-37.8-14.5c-28.5-10.8-55-26.2-78.7-45.7l-31.4-25.9-93.4 33.2c-17-22.9-31.2-47.6-42.6-73.6l75.5-64.5-6.5-40c-2.4-14.9-3.7-30.3-3.7-45.5 0-15.3 1.2-30.6 3.7-45.5l6.5-40-75.5-64.5c11.3-26.1 25.6-50.7 42.6-73.6l93.4 33.2 31.4-25.9c23.7-19.5 50.2-34.9 78.7-45.7l37.9-14.3 17.9-97.2c28.1-3.2 56.8-3.2 85 0l17.9 97 38.1 14.3c28.7 10.8 55.4 26.2 79.3 45.8l31.4 25.8 92.8-32.9c17 22.9 31.2 47.6 42.6 73.6L781.8 426l6.5 39.9zM512 326c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm79.2 255.2A111.6 111.6 0 01512 614c-29.9 0-58-11.7-79.2-32.8A111.6 111.6 0 01400 502c0-29.9 11.7-58 32.8-79.2C454 401.6 482.1 390 512 390c29.9 0 58 11.6 79.2 32.8A111.6 111.6 0 01624 502c0 29.9-11.7 58-32.8 79.2z"></path></svg>`;
const PENCIL_EDIT_ICON_SVG = `<svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M257.7 752c2 0 4-.2 6-.5L431.9 722c2-.4 3.9-1.3 5.3-2.8l423.9-423.9a9.96 9.96 0 000-14.1L694.9 114.9c-1.9-1.9-4.4-2.9-7.1-2.9s-5.2 1-7.1 2.9L256.8 538.8c-1.5 1.5-2.4 3.3-2.8 5.3l-29.5 168.2a33.5 33.5 0 009.4 29.8c6.6 6.4 14.9 9.9 23.8 9.9zm67.4-174.4L687.8 215l73.3 73.3-362.7 362.6-88.9 15.7 15.6-89zM880 836H144c-17.7 0-32 14.3-32 32v36c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-36c0-17.7-14.3-32-32-32z"></path></svg>`;
const DELETE_ICON_SVG = `<svg viewBox="64 64 896 896" width="16" height="16" fill="currentColor"><path d="M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72zm504 72H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z"></path></svg>`;
const CLOSE_CIRCLE_FILLED_SVG = `<svg fill-rule="evenodd" viewBox="64 64 896 896" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm127.98 274.82h-.04l-.08.06L512 466.75 384.14 338.88c-.04-.05-.06-.06-.08-.06a.12.12 0 00-.07 0c-.03 0-.05.01-.09.05l-45.02 45.02a.2.2 0 00-.05.09.12.12 0 000 .07v.02a.27.27 0 00.06.06L466.75 512 338.88 639.86c-.05.04-.06.06-.06.08a.12.12 0 000 .07c0 .03.01.05.05.09l45.02 45.02a.2.2 0 00.09.05.12.12 0 00.07 0c.02 0 .04-.01.08-.05L512 557.25l127.86 127.87c.04.04.06.05.08.05a.12.12 0 00.07 0c.03 0 .05-.01.09-.05l45.02-45.02a.2.2 0 00.05-.09.12.12 0 000-.07v-.02a.27.27 0 00-.05-.06L557.25 512l127.87-127.86c.04-.04.05-.06.05-.08a.12.12 0 000-.07c0-.03-.01-.05-.05-.09l-45.02-45.02a.2.2 0 00-.09-.05.12.12 0 00-.07 0z"></path></svg>`;
const CLOSE_CIRCLE_OUTLINE_SVG = `<svg fill-rule="evenodd" viewBox="64 64 896 896" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm0 76c-205.4 0-372 166.6-372 372s166.6 372 372 372 372-166.6 372-372-166.6-372-372-372zm128.01 198.83c.03 0 .05.01.09.06l45.02 45.01a.2.2 0 01.05.09.12.12 0 010 .07c0 .02-.01.04-.05.08L557.25 512l127.87 127.86a.27.27 0 01.05.06v.02a.12.12 0 010 .07c0 .03-.01.05-.05.09l-45.02 45.02a.2.2 0 01-.09.05.12.12 0 01-.07 0c-.02 0-.04-.01-.08-.05L512 557.25 384.14 685.12c-.04.04-.06.05-.08.05a.12.12 0 01-.07 0c-.03 0-.05-.01-.09-.05l-45.02-45.02a.2.2 0 01-.05-.09.12.12 0 010-.07c0-.02.01-.04.06-.08L466.75 512 338.88 384.14a.27.27 0 01-.05-.06l-.01-.02a.12.12 0 010-.07c0-.03.01-.05.05-.09l45.02-45.02a.2.2 0 01.09-.05.12.12 0 01.07 0c.02 0 .04.01.08.06L512 466.75l127.86-127.86c.04-.05.06-.06.08-.06a.12.12 0 01.07 0z"></path></svg>`;
const ARROW_DOWN_ICON_SVG = `<span class="material-icons-outlined text-gray-600 !text-[20px]">arrow_drop_down</span>`;
const ARROW_RIGHT_ICON_SVG = `<span class="material-icons-outlined text-gray-600 !text-[20px]">arrow_right</span>`;
const CARET_RIGHT_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor"><path d="M715.8 493.5L335.1 123.6c-13.8-13.4-36.1-4-36.1 15.3v740.2c0 19.3 22.3 28.7 36.1 15.3l380.7-369.9c10.4-10.1 10.4-26.9 0-37z"></path></svg>`;
const CARET_DOWN_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;
const CHEVRON_RIGHT_SVG = CARET_RIGHT_SVG;
const CHEVRON_DOWN_SVG = CARET_DOWN_SVG;
// const MORE_VERT_ICON_SVG = `<svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M456 231a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0z"></path></svg>`;
const ISSUE_UNRESOLVED_SVG = `<svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.3838 0.226562H2.38379C1.28079 0.226562 0.383789 1.12356 0.383789 2.22656V20.2266L5.71679 16.2266H18.3838C19.4868 16.2266 20.3838 15.3296 20.3838 14.2266V2.22656C20.3838 1.12356 19.4868 0.226562 18.3838 0.226562Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.23189 14.7719H18.3838C18.6834 14.7719 18.9292 14.5262 18.9292 14.2266V2.22656C18.9292 1.92693 18.6834 1.68118 18.3838 1.68118H2.38379C2.08415 1.68118 1.83841 1.92693 1.83841 2.22656V17.3172L5.23189 14.7719ZM0.383789 20.2266V2.22656C0.383789 1.12356 1.28079 0.226562 2.38379 0.226562H18.3838C19.4868 0.226562 20.3838 1.12356 20.3838 2.22656V14.2266C20.3838 15.3296 19.4868 16.2266 18.3838 16.2266H5.71679L0.383789 20.2266Z" fill="#d93026"></path><path d="M9.38284 4.22298H11.3828V9.22298H9.38284V4.22298ZM9.38284 10.223H11.3828V12.223H9.38284V10.223Z" fill="#d93026"></path></svg>`;
const ISSUE_RESOLVED_SVG = `<svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="hover:scale-[1.2]"><g clip-path="url(#clip0_2050_371)"><path d="M18.3838 0.226562H2.38379C1.28079 0.226562 0.383789 1.12356 0.383789 2.22656V20.2266L5.71679 16.2266H18.3838C19.4868 16.2266 20.3838 15.3296 20.3838 14.2266V2.22656C20.3838 1.12356 19.4868 0.226562 18.3838 0.226562Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.23189 14.7719H18.3838C18.6834 14.7719 18.9292 14.5262 18.9292 14.2266V2.22656C18.9292 1.92693 18.6834 1.68118 18.3838 1.68118H2.38379C2.08415 1.68118 1.83841 1.92693 1.83841 2.22656V17.3172L5.23189 14.7719ZM0.383789 20.2266V2.22656C0.383789 1.12356 1.28079 0.226562 2.38379 0.226562H18.3838C19.4868 0.226562 20.3838 1.12356 20.3838 2.22656V14.2266C20.3838 15.3296 19.4868 16.2266 18.3838 16.2266H5.71679L0.383789 20.2266Z" fill="#66C526"></path><path d="M15.7834 5.78364L14.4998 4.5L8.86504 10.1349L6.49946 7.76975L5.21582 9.05338L8.86504 12.7022L15.7834 5.78364Z" fill="#66C526"></path></g><defs><clipPath id="clip0_2050_371"><rect width="21" height="21" fill="white"></rect></clipPath></defs></svg>`;
const INSIDE_PIN_TAG_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="tag" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M938 458.8l-29.6-312.6c-1.5-16.2-14.4-29-30.6-30.6L565.2 86h-.4c-3.2 0-5.7 1-7.6 2.9L88.9 557.2a9.96 9.96 0 000 14.1l363.8 363.8c1.9 1.9 4.4 2.9 7.1 2.9s5.2-1 7.1-2.9l468.3-468.3c2-2.1 3-5 2.8-8zM699 387c-35.3 0-64-28.7-64-64s28.7-64 64-64 64 28.7 64 64-28.7 64-64 64z"></path></svg>`;
const OUTSIDE_OF_PIN_ICON = `<svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.3838 0.226562H2.38379C1.28079 0.226562 0.383789 1.12356 0.383789 2.22656V20.2266L5.71679 16.2266H18.3838C19.4868 16.2266 20.3838 15.3296 20.3838 14.2266V2.22656C20.3838 1.12356 19.4868 0.226562 18.3838 0.226562Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.23189 14.7719H18.3838C18.6834 14.7719 18.9292 14.5262 18.9292 14.2266V2.22656C18.9292 1.92693 18.6834 1.68118 18.3838 1.68118H2.38379C2.08415 1.68118 1.83841 1.92693 1.83841 2.22656V17.3172L5.23189 14.7719ZM0.383789 20.2266V2.22656C0.383789 1.12356 1.28079 0.226562 2.38379 0.226562H18.3838C19.4868 0.226562 20.3838 1.12356 20.3838 2.22656V14.2266C20.3838 15.3296 19.4868 16.2266 18.3838 16.2266H5.71679L0.383789 20.2266Z" fill="black"></path><path d="M9.38284 4.22298H11.3828V9.22298H9.38284V4.22298ZM9.38284 10.223H11.3828V12.223H9.38284V10.223Z" fill="black"></path></svg>`;
const CHECK_SVG = `<svg viewBox="64 64 896 896" width="14" height="14" fill="currentColor"><path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path></svg>`;
// Updated SVG Constants
const MORE_VERT_ICON_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M456 231a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0z"></path></svg>`;
const CLOSE_X_SVG = `<svg fill-rule="evenodd" viewBox="64 64 896 896" focusable="false" data-icon="close" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M799.86 166.31c.02 0 .04.02.08.06l57.69 57.7c.04.03.05.05.06.08a.12.12 0 010 .06c0 .03-.02.05-.06.09L569.93 512l287.7 287.7c.04.04.05.06.06.09a.12.12 0 010 .07c0 .02-.02.04-.06.08l-57.7 57.69c-.03.04-.05.05-.07.06a.12.12 0 01-.07 0c-.03 0-.05-.02-.09-.06L512 569.93l-287.7 287.7c-.04.04-.06.05-.09.06a.12.12 0 01-.07 0c-.02 0-.04-.02-.08-.06l-57.69-57.7c-.04-.03-.05-.05-.06-.07a.12.12 0 010-.07c0-.03.02-.05.06-.09L454.07 512l-287.7-287.7c-.04-.04-.05-.06-.06-.09a.12.12 0 010-.07c0-.02.02-.04.06-.08l57.7-57.69c.03-.04.05-.05.07-.06a.12.12 0 01.07 0c.03 0 .05.02.09.06L512 454.07l287.7-287.7c.04-.04.06-.05.09-.06a.12.12 0 01.07 0z"></path></svg>`;
const ARROW_UP_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="arrow-up" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M868 545.5L536.1 163a31.96 31.96 0 00-48.3 0L156 545.5a7.97 7.97 0 006 13.2h81c4.6 0 9-2 12.1-5.5L474 300.9V864c0 4.4 3.6 8 8 8h60c4.4 0 8-3.6 8-8V300.9l218.9 252.3c3 3.5 7.4 5.5 12.1 5.5h81c6.8 0 10.5-8 6-13.2z"></path></svg>`;
const DELETE_THREAD_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="delete" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72zm504 72H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z"></path></svg>`;
const FRAME_CANVAS_POPUP = `<svg width="12" height="12" viewBox="0 0 105 105" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M67.0901 42.9797L47.5056 29.9234C47.0139 29.5953 46.4424 29.407 45.852 29.3784C45.2616 29.3498 44.6745 29.482 44.1534 29.761C43.6323 30.04 43.1967 30.4552 42.8932 30.9624C42.5897 31.4696 42.4295 32.0497 42.4299 32.6407V58.7534C42.4295 59.3445 42.5897 59.9246 42.8932 60.4318C43.1967 60.939 43.6323 61.3542 44.1534 61.6332C44.6745 61.9122 45.2616 62.0444 45.852 62.0158C46.4424 61.9872 47.0139 61.7988 47.5056 61.4708L67.0901 48.4144C67.5378 48.1165 67.905 47.7125 68.1589 47.2384C68.4129 46.7644 68.5458 46.2349 68.5458 45.6971C68.5458 45.1593 68.4129 44.6298 68.1589 44.1557C67.905 43.6817 67.5378 43.2777 67.0901 42.9797ZM48.9581 52.6537V38.7609L59.395 45.6971L48.9581 52.6537ZM88.1271 16.3203H16.3172C14.5859 16.3203 12.9254 17.0081 11.7011 18.2324C10.4768 19.4566 9.78906 21.1171 9.78906 22.8485V68.5457C9.78906 70.2771 10.4768 71.9375 11.7011 73.1618C12.9254 74.3861 14.5859 75.0739 16.3172 75.0739H88.1271C89.8585 75.0739 91.519 74.3861 92.7432 73.1618C93.9675 71.9375 94.6553 70.2771 94.6553 68.5457V22.8485C94.6553 21.1171 93.9675 19.4566 92.7432 18.2324C91.519 17.0081 89.8585 16.3203 88.1271 16.3203ZM88.1271 68.5457H16.3172V22.8485H88.1271V68.5457ZM94.6553 84.8661C94.6553 85.7318 94.3114 86.562 93.6993 87.1742C93.0871 87.7863 92.2569 88.1302 91.3912 88.1302H13.0531C12.1875 88.1302 11.3572 87.7863 10.7451 87.1742C10.133 86.562 9.78906 85.7318 9.78906 84.8661C9.78906 84.0004 10.133 83.1702 10.7451 82.5581C11.3572 81.9459 12.1875 81.602 13.0531 81.602H91.3912C92.2569 81.602 93.0871 81.9459 93.6993 82.5581C94.3114 83.1702 94.6553 84.0004 94.6553 84.8661Z" fill="#13C2C2"></path></svg>`;
const PIN_SVG = `<svg width="12" height="12" viewBox="0 0 105 105" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_7821_19692)"><path d="M95.7395 48.1237C95.3577 48.1259 94.9792 48.0527 94.6257 47.9083C94.2722 47.7639 93.9506 47.5512 93.6795 47.2822L57.1508 10.7535C56.6755 10.1985 56.4271 9.48449 56.4553 8.75427C56.4835 8.02405 56.7862 7.33137 57.3029 6.81465C57.8197 6.29792 58.5123 5.99521 59.2425 5.96701C59.9728 5.9388 60.6867 6.18718 61.2418 6.66251L97.7995 43.1913C98.1988 43.5986 98.4691 44.1145 98.5768 44.6746C98.6845 45.2347 98.6246 45.8141 98.4048 46.3404C98.185 46.8667 97.815 47.3166 97.3409 47.6337C96.8669 47.9509 96.3099 48.1213 95.7395 48.1237Z" fill="#13C2C2"></path><path d="M82.7275 45.1426L78.6365 41.0516L57.7464 61.9418C57.3734 62.314 57.1089 62.7807 56.9811 63.2918C56.8533 63.803 56.8671 64.3393 57.021 64.8432C58.2018 68.8266 58.415 73.0344 57.6429 77.1168C56.8709 81.1992 55.1358 85.0384 52.5819 88.3156L16.1692 51.8449C19.4463 49.291 23.2856 47.5559 27.368 46.7838C31.4504 46.0117 35.6581 46.2249 39.6416 47.4057C40.1455 47.5596 40.6818 47.5735 41.193 47.4457C41.7041 47.3179 42.1708 47.0533 42.543 46.6804L63.4332 25.7902L59.2841 21.6992L39.5836 41.3998C34.3392 40.1354 28.8591 40.2284 23.6607 41.6701C18.4622 43.1119 13.7171 45.8548 9.87312 49.6398C9.60118 49.9095 9.38533 50.2304 9.23803 50.584C9.09073 50.9375 9.01489 51.3168 9.01489 51.6998C9.01489 52.0828 9.09073 52.462 9.23803 52.8156C9.38533 53.1692 9.60118 53.4901 9.87312 53.7598L28.239 72.1257L6.62354 93.6832C6.31982 93.9433 6.07314 94.2634 5.89899 94.6233C5.72484 94.9833 5.62697 95.3754 5.61154 95.775C5.5961 96.1745 5.66343 96.573 5.8093 96.9453C5.95517 97.3176 6.17642 97.6558 6.45918 97.9385C6.74193 98.2213 7.08009 98.4426 7.45241 98.5884C7.82473 98.7343 8.22319 98.8016 8.62277 98.7862C9.02235 98.7708 9.41443 98.6729 9.77439 98.4987C10.1344 98.3246 10.4544 98.0779 10.7145 97.7742L32.301 76.1877L50.6669 94.5536C50.9381 94.8225 51.2596 95.0353 51.6131 95.1797C51.9666 95.324 52.3451 95.3972 52.7269 95.395C53.1108 95.3934 53.4906 95.3157 53.8442 95.1663C54.1978 95.0169 54.5182 94.7988 54.7869 94.5246C58.5581 90.6715 61.2917 85.9258 62.7326 80.7304C64.1735 75.535 64.2748 70.0593 63.027 64.8142L82.7275 45.1426Z" fill="#13C2C2"></path></g><defs><clipPath id="clip0_7821_19692"><rect width="104.451" height="104.451" fill="white"></rect></clipPath></defs></svg>`;
const SIDEBAR_EXIT_ARROW = `<svg viewBox="64 64 896 896" focusable="false" data-icon="right" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z"></path></svg>`;

// New Tree-Structure SVGs
const SUB_GROUP_EXPAND_SVG = `<svg viewBox="0 0 1024 1024" width="12" height="12" fill="currentColor"><path d="M328 544h152v152c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V544h152c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H544V328c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v152H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zm-40 728H184V184h656v656z"></path></svg>`;
const SUB_GROUP_COLLAPSE_SVG = `<svg viewBox="0 0 1024 1024" width="12" height="12" fill="currentColor"><path d="M328 544h368c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zm-40 728H184V184h656v656z"></path></svg>`;
const SUB_GROUP_PLUS_SVG = `<svg viewBox="0 0 1024 1024" width="12" height="12" fill="currentColor"><path d="M328 544h152v152c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V544h152c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H544V328c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v152H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zm-40 728H184V184h656v656z"></path></svg>`;
const SUB_GROUP_MINUS_SVG = `<svg viewBox="0 0 1024 1024" width="12" height="12" fill="currentColor"><path d="M328 544h368c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zm-40 728H184V184h656v656z"></path></svg>`;
const SUB_GROUP_CIRCLE_SVG = `<svg viewBox="0 0 1024 1024" width="13px" height="13px" fill="none" stroke="#697b8c" stroke-width="120"><circle cx="512" cy="512" r="448"/></svg>`;
const SUB_GROUP_CIRCLE_FILLED_SVG = `<svg viewBox="0 0 1024 1024" width="13px" height="13px"><circle cx="512" cy="512" r="448" fill="#5f45ff"/><circle cx="512" cy="512" r="180" fill="white"/></svg>`;
const CLOSE_CIRCLE_SVG = `<svg fill-rule="evenodd" viewBox="64 64 896 896" width="13" height="13" fill="#94a3b8" aria-hidden="true"><path d="M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm127.98 274.82h-.04l-.08.06L512 466.75 384.14 338.88c-.04-.05-.06-.06-.08-.06a.12.12 0 00-.07 0c-.03 0-.05.01-.09.05l-45.02 45.02a.2.2 0 00-.05.09.12.12 0 000 .07v.02a.27.27 0 00.06.06L466.75 512 338.88 639.86c-.05.04-.06.06-.06.08a.12.12 0 000 .07c0 .03.01.05.05.09l45.02 45.02a.2.2 0 00.09.05.12.12 0 00.07 0c.02 0 .04-.01.08-.05L512 557.25l127.86 127.87c.04.04.06.05.08.05a.12.12 0 00.07 0c.03 0 .05-.01.09-.05l45.02-45.02a.2.2 0 00.05-.09.12.12 0 000-.07v-.02a.27.27 0 00-.05-.06L557.25 512l127.87-127.86c.04-.04.05-.06.05-.08a.12.12 0 000-.07c0-.03-.01-.05-.05-.09l-45.02-45.02a.2.2 0 00-.09-.05.12.12 0 00-.07 0z"></path></svg>`;
const TREE_ELBOW_SVG = `<svg viewBox="0 0 1024 1024" width="14" height="14" fill="currentColor"><path d="M880 484H296V144c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v408c0 17.7 14.3 32 32 32h624c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8z"></path></svg>`;
const EXPAND_PLUS_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="plus-square" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M328 544h152v152c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V544h152c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H544V328c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v152H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zm-40 728H184V184h656v656z"></path></svg>`;
const EXPAND_MINUS_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="minus-square" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M328 544h368c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8z"></path><path d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zm-40 728H184V184h656v656z"></path></svg>`;
const DROPDOWN_DOWN_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="12px" height="12px" fill="currentColor" aria-hidden="true"><path d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg>`;
const DROPDOWN_SEARCH_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="12px" height="12px" fill="currentColor" aria-hidden="true"><path d="M909.6 854.5L649.9 594.8C690.2 542.7 712 479 712 412c0-80.2-31.3-155.4-87.9-212.1-56.6-56.7-132-87.9-212.1-87.9s-155.5 31.3-212.1 87.9C143.2 256.5 112 331.8 112 412c0 80.1 31.3 155.5 87.9 212.1C256.5 680.8 331.8 712 412 712c67 0 130.6-21.8 182.7-62l259.7 259.6a8.2 8.2 0 0011.6 0l43.6-43.5a8.2 8.2 0 000-11.6zM570.4 570.4C528 612.7 471.8 636 412 636s-116-23.3-158.4-65.6C211.3 528 188 471.8 188 412s23.3-116.1 65.6-158.4C296 211.3 352.2 188 412 188s116.1 23.2 158.4 65.6S636 352.2 636 412s-23.3 116.1-65.6 158.4z"></path></svg>`;
const RADIO_CIRCLE_EMPTY_SVG = `<svg viewBox="0 0 1024 1024" width="14" height="14" fill="none" stroke="currentColor" stroke-width="120"><circle cx="512" cy="512" r="448"/></svg>`;
const RADIO_CIRCLE_FILLED_SVG = `<svg viewBox="0 0 1024 1024" width="14" height="14"><circle cx="512" cy="512" r="448" fill="#5f45ff"/><circle cx="512" cy="512" r="220" fill="white"/></svg>`;
const CHECK_SQUARE_EMPTY_SVG = `<svg viewBox="0 0 1024 1024" width="14" height="14" fill="none" stroke="currentColor" stroke-width="120"><rect x="128" y="128" width="768" height="768" rx="80"/></svg>`;
const CHECK_SQUARE_FILLED_SVG = `<svg viewBox="0 0 1024 1024" width="14" height="14"><rect x="128" y="128" width="768" height="768" rx="80" fill="#5f45ff"/><path d="M280 520l160 160 320-320" stroke="white" stroke-width="120" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

const CHECKMARK_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="18" height="18" fill="#5f45ff" aria-hidden="true" style="display: block; pointer-events: none;"><path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path></svg>`;
const RIGHT_ARROW_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="18" height="18" fill="#9ca3af" aria-hidden="true" style="display: block; pointer-events: none;"><path d="M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z"></path></svg>`;

// Global Color Constants
const COLORS = {
    BRAND_PRIMARY: '#5f45ff',
    BRAND_SECONDARY: '#5e44ff',
    BRAND_SLIDER: '#5c5cff',
    BRAND_LIGHT_BG: '#f4f0ff',
    BRAND_VERY_LIGHT_BG: '#f0efff',
    GRAY_BAR: '#757575',
    BLUE_TEXT: '#1e40af',
    BLUE_BORDER: '#dbeafe',
    BLUE_LIGHT_BG: '#eff6ff'
};
// ============================================================================
// SINGLE RESPONSIBILITY PRINCIPLE - Focused, single-purpose classes
// ============================================================================

/**
 * VideoController: Manages video playback state and operations
 */
class VideoController {
    constructor(videoElement) {
        this.video = videoElement;
        this.listeners = [];
        this.frameSkip = 1; // Default to 1 frame
        this.playbackRate = 0.5; // Set initial speed to 0.5x
    }

    play() { this.video.play(); }
    pause() { this.video.pause(); }
    togglePlayPause() { this.video.paused ? this.play() : this.pause(); }

    get currentTime() { return this.video.currentTime; }
    set currentTime(value) { this.video.currentTime = Math.max(0, Math.min(value, this.duration)); }

    get duration() { return this.video.duration; }
    get playbackRate() { return this.video.playbackRate; }
    set playbackRate(value) { this.video.playbackRate = value; }
    get muted() { return this.video.muted; }
    set muted(value) { this.video.muted = value; }

    getCurrentFrame() { return Math.round(this.currentTime * CONFIG.FPS); }
    getTotalFrames() { return Math.floor(this.duration * CONFIG.FPS); }

    seekToFrame(frame) {
        this.currentTime = frame / CONFIG.FPS;
    }

    advanceFrame() {
        const format = (window.app && window.app.timestampFormat) ? window.app.timestampFormat : 'Frames';
        let jumpAmount;

        if (format === 'HH:MM:SS' || format === 'MM:SS') {
            jumpAmount = this.frameSkip * 3; // 3 seconds per skip unit
        } else if (format === 'SS.FF') {
            jumpAmount = (this.frameSkip * 3) / CONFIG.FPS; // 3 frames per skip unit
        } else {
            jumpAmount = this.frameSkip / CONFIG.FPS; // 1 frame per skip unit
        }

        this.currentTime = Math.min(this.duration, this.currentTime + jumpAmount);
    }

    rewindFrame() {
        const format = (window.app && window.app.timestampFormat) ? window.app.timestampFormat : 'Frames';
        let jumpAmount;

        if (format === 'HH:MM:SS' || format === 'MM:SS') {
            jumpAmount = this.frameSkip * 3; // 3 seconds per skip unit
        } else if (format === 'SS.FF') {
            jumpAmount = (this.frameSkip * 3) / CONFIG.FPS; // 3 frames per skip unit
        } else {
            jumpAmount = this.frameSkip / CONFIG.FPS; // 1 frame per skip unit
        }

        this.currentTime = Math.max(0, this.currentTime - jumpAmount);
    }

    addTimeUpdateListener(callback) {
        this.video.addEventListener('timeupdate', callback);
        this.listeners.push({ event: 'timeupdate', callback });
    }

    addMetadataLoadedListener(callback) {
        this.video.addEventListener('loadedmetadata', callback);
        this.listeners.push({ event: 'loadedmetadata', callback });
    }

    setSrc(src) {
        this.video.src = src;
        this.video.load();
    }
}

/**
 * VideoTransformManager: Handles zoom, rotation, filters, and image rendering
 */
class VideoTransformManager {
    constructor(videoElement) {
        this.video = videoElement;
        this.zoom = 1;
        this.rotation = 0;
        this.tx = 0;
        this.ty = 0;
        this.filters = { brightness: 100, contrast: 100, saturation: 100 };
        this.isPixelated = false;
    }

    setZoom(value) {
        this.zoom = Math.max(CONFIG.MIN_ZOOM, Math.min(CONFIG.MAX_ZOOM, value));
        if (this.zoom === 1) {
            this.tx = 0;
            this.ty = 0;
        }
        this.applyTransform();
    }

    zoomIn(step = CONFIG.ZOOM_STEP) {
        this.zoomTowards(step);
    }

    zoomOut(step = CONFIG.ZOOM_STEP) {
        this.zoomTowards(-step);
    }

    zoomTowards(step, clientX, clientY) {
        const oldZoom = this.zoom;
        const newZoom = Math.max(CONFIG.MIN_ZOOM, Math.min(CONFIG.MAX_ZOOM, oldZoom + step));
        if (oldZoom === newZoom) return;

        if (newZoom === 1) {
            this.tx = 0;
            this.ty = 0;
            this.zoom = 1;
            this.applyTransform();
            return;
        }

        const wrapper = document.getElementById('videoTransformWrapper');
        if (!wrapper) return;

        let mx = 0, my = 0;

        if (clientX !== undefined && clientY !== undefined) {
            const container = wrapper.parentElement;
            const rect = container.getBoundingClientRect();
            // Mouse coordinate relative to the container center
            mx = clientX - rect.left - rect.width / 2;
            my = clientY - rect.top - rect.height / 2;
        } else {
            // Zoom centered on the container's visual center
            mx = 0;
            my = 0;
        }

        const ratio = newZoom / oldZoom;
        this.tx = mx - (mx - this.tx) * ratio;
        this.ty = my - (my - this.ty) * ratio;

        this.zoom = newZoom;
        this.applyTransform();
    }

    getZoom() {
        return this.zoom;
    }

    setRotation(degrees) {
        this.rotation = ((degrees % 360) + 360) % 360;
        this.applyTransform();
    }

    rotate(degrees = 90) {
        this.setRotation(this.rotation + degrees);
    }

    getRotation() {
        return this.rotation;
    }

    resetTransform() {
        this.zoom = 1;
        this.rotation = 0;
        this.tx = 0;
        this.ty = 0;
        this.filters = { brightness: 100, contrast: 100, saturation: 100 };
        this.isPixelated = false;
        this.applyTransform();
        this.applyFilters();
        this.setPixelated(false);
    }

    applyTransform() {
        const wrapper = document.getElementById('videoTransformWrapper');
        if (wrapper) {
            // translate first, then scale and rotate
            wrapper.style.transform = `translate(${this.tx}px, ${this.ty}px) scale(${this.zoom}) rotate(${this.rotation}deg)`;

            // Sync issue icons scaling
            if (window.app) {
                window.app.updateIssueIconsScaling(this.zoom);
            }
        }
    }

    setFilters(brightness, contrast, saturation) {
        this.filters = { brightness, contrast, saturation };
        this.applyFilters();
    }

    applyFilters() {
        const { brightness, contrast, saturation } = this.filters;
        this.video.style.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
    }

    getFilters() {
        return { ...this.filters };
    }

    setPixelated(enabled) {
        this.isPixelated = enabled;
        if (enabled) {
            this.video.style.imageRendering = 'pixelated';
            this.video.style.setProperty('image-rendering', 'pixelated', 'important');
            this.video.style.setProperty('image-rendering', 'crisp-edges', 'important');
        } else {
            this.video.style.imageRendering = 'auto';
            this.video.style.removeProperty('image-rendering');
        }
    }

    isPixelatedEnabled() {
        return this.isPixelated;
    }
}

/**
 * AnnotationModel: Manages annotation data
 */
class AnnotationModel {
    constructor() {
        this.active = false;
        this.className = 'Description';
        this.value = '';
        this.start = 0;
        this.end = 0;
        this.instructions = [];
    }

    activate(value, totalFrames) {
        this.active = true;
        this.value = value;
        this.start = 0;
        this.end = totalFrames;
    }

    deactivate() {
        this.active = false;
        this.start = 0;
        this.end = 0;
    }

    setRange(start, end) {
        this.start = start;
        this.end = end;
    }

    getRange() {
        return { start: this.start, end: this.end };
    }

    setValue(value) {
        this.value = value;
    }

    getValue() {
        return this.value;
    }

    save(customFrames) {
        if (this.value.trim() === "") return false;
        this.instructions.push({
            className: this.className, // Ensure this property is saved
            frames: customFrames || `${this.start} - ${this.end}`,
            text: this.value,
            timestamp: Date.now()
        });
        return true;
    }

    setInstructions(instructions) {
        this.instructions = Array.isArray(instructions) ? [...instructions] : [];
    }

    getInstructions() {
        return [...this.instructions];
    }

    deleteInstruction(idx) {
        if (idx >= 0 && idx < this.instructions.length) {
            this.instructions.splice(idx, 1);
            return true;
        }
        return false;
    }

    deleteInstructions(indices) {
        // Sort indices in descending order to avoid index shift when splicing
        const sortedIndices = [...indices].sort((a, b) => b - a);
        sortedIndices.forEach(idx => {
            if (idx >= 0 && idx < this.instructions.length) {
                this.instructions.splice(idx, 1);
            }
        });
        return true;
    }

    clearInstructions() {
        this.instructions = [];
    }

    isActive() {
        return this.active;
    }
}

/**
 * DragState: Manages drag operation state
 */
class DragState {
    constructor() {
        this.isDragging = false;
        this.dragType = null; // 'playhead', 'knobStart', 'knobEnd'
    }

    startDrag(type) {
        this.isDragging = true;
        this.dragType = type;
        document.body.style.userSelect = 'none';
    }

    endDrag() {
        this.isDragging = false;
        this.dragType = null;
        document.body.style.userSelect = '';
    }

    isActive() {
        return this.isDragging;
    }

    getType() {
        return this.dragType;
    }
}

/**
 * ProgressBarView: Updates progress bar UI
 */
class ProgressBarView {
    constructor(fillElement, knobElement, trackElement, hoverPillElement) {
        this.fill = fillElement;
        this.knob = knobElement;
        this.track = trackElement;
        this.hoverPill = hoverPillElement;
    }

    update(percent) {
        this.fill.style.width = (percent * 100) + '%';
        this.knob.style.left = (percent * 100) + '%';
    }

    showHoverPill(percent, frame) {
        this.hoverPill.innerText = (window.app && window.app.formatDisplay) ? window.app.formatDisplay(frame) : frame;
        this.hoverPill.style.left = (percent * 100) + '%';
        this.hoverPill.classList.remove('hidden');
    }

    hideHoverPill() {
        this.hoverPill.classList.add('hidden');
    }
}

/**
 * TimelineView: Manages timeline rendering and playhead
 */
class TimelineView {
    constructor(rulerElement, tracksContainer, playheadElement, elements) {
        this.ruler = rulerElement;
        this.tracks = tracksContainer;
        this.playhead = playheadElement;
        this.elements = elements; // { labelsBody, tracksContainer, videoDataContainer, videoLabelContainer }
        this.currentPPS = CONFIG.INITIAL_PPS;
        this.videoDuration = 0;
    }

    initialize(duration, pps = this.currentPPS) {
        this.currentPPS = pps;
        this.videoDuration = duration;

        const timelineWidth = duration * this.currentPPS;

        // Update widths of all horizontal layers
        this.ruler.style.width = timelineWidth + 'px';
        this.tracks.style.width = timelineWidth + 'px';

        const videoContainer = document.getElementById('videoTrackContainer');
        if (videoContainer) videoContainer.style.width = timelineWidth + 'px';

        this.renderRuler(duration, timelineWidth);
    }

    renderRuler(duration, timelineWidth) {
        this.ruler.innerHTML = '';
        const fragment = document.createDocumentFragment();

        // Calculate step size based on zoom level
        let majorStep = 2;
        if (this.currentPPS < 60) majorStep = 10;
        else if (this.currentPPS < 120) majorStep = 5;
        else if (this.currentPPS > 300) majorStep = 1;

        const minorStep = majorStep / 2;

        for (let i = 0; i <= duration; i += minorStep) {
            const isMajor = i % majorStep === 0;
            const xPos = i * this.currentPPS;

            const tick = document.createElement('div');
            tick.style.left = `${xPos}px`;
            tick.style.position = 'absolute';
            tick.style.bottom = '0';

            if (isMajor) {
                tick.className = 'h-3 border-l border-black z-10';
                const label = document.createElement('span');
                label.className = `absolute -top-7 left-0 ${i === 0 ? '' : '-translate-x-1/2'} text-[10px] text-gray-500 font-[450] pointer-events-none`;

                const labelText = (window.app && window.app.formatDisplay) ? window.app.formatDisplay(i * CONFIG.FPS) : i;
                label.innerText = labelText;
                tick.appendChild(label);
            } else {
                tick.className = 'h-2.5 border-l border-black opacity-30';
            }
            fragment.appendChild(tick);
        }
        this.ruler.appendChild(fragment);
    }

    updatePlayhead(percent, timelineWidth) {
        if (!this.playhead) return;
        this.playhead.style.left = (percent * timelineWidth) + 'px';
    }

    /**
 * TimelineView.renderTracks
 * Renders individual rows for every annotation and includes robust tooltip positioning.
 */
    /**
     * Renders the timeline tracks.
     * Updates: Handles selection state passing and full re-rendering.
     */
    renderTracks(instructions = [], pps = this.currentPPS, selectedIdx = -1) {
        this.currentPPS = pps;
        this.selectedTrackIndex = selectedIdx; // Store selection state

        const { labelsBody, tracksContainer, videoDataContainer, videoLabelContainer } = this.elements;

        if (!labelsBody || !tracksContainer || !videoDataContainer || !videoLabelContainer) return;

        // 1. Clear UI
        labelsBody.innerHTML = '';
        tracksContainer.innerHTML = '';
        videoDataContainer.innerHTML = '';
        videoLabelContainer.innerHTML = '';

        const timelineWidth = (this.videoDuration || 0) * pps;
        videoDataContainer.style.width = timelineWidth + 'px';
        tracksContainer.style.width = timelineWidth + 'px';

        // 2. ALWAYS RENDER VIDEO TRACK (Row 0)
        // Pass 'instructions' and check if index 0 is selected
        let videoName = this.videoName || (window.sageMakerData && window.sageMakerData.videoName) || "Video";

        // If videoName contains template syntax (unrendered), try to extract from video source
        if (videoName.includes('{{')) {
            const videoElement = document.getElementById('mainVideo');
            if (videoElement && videoElement.src) {
                videoName = videoElement.src.split('/').pop() || "Video";
            } else if (videoElement && videoElement.querySelector('source')) {
                const srcAttr = videoElement.querySelector('source').getAttribute('src');
                videoName = srcAttr ? srcAttr.split('/').pop() : "Video";
            } else {
                videoName = "Video";
            }
        }
        // If local, ensure only the filename is shown (remove paths)
        else if (videoName && videoName.includes('/')) {
            videoName = videoName.split('/').pop() || videoName;
        }

        const videoRow = this.createRowContainer("video", videoName, 0, selectedIdx === 0, instructions);
        videoLabelContainer.appendChild(videoRow.label);
        videoDataContainer.appendChild(videoRow.data);

        // 3. RENDER ONE ROW PER INDIVIDUAL ANNOTATION
        instructions.forEach((ins, i) => {
            const trackIdx = i + 1; // Offset by 1 because of the video row

            // Pass the specific instruction data (ins) to the helper
            const row = this.createRowContainer("class", ins.className, trackIdx, selectedIdx === trackIdx, instructions, ins);

            labelsBody.appendChild(row.label);
            tracksContainer.appendChild(row.data);
        });
    }

    /**
     * Helper to create the Label (Left) and Data (Right) DOM elements for a row.
     * Updates: 
     * - Applied specific #ecedfa background for selection
     * - Enforced fixed heights (h-[40px]) to ensure scroll synchronization works perfectly
     * - Added click-to-select logic on the empty track space
     */
    createRowContainer(type, name, idx, isSelected, instructions, instructionData = null) {
        const isVideo = type === 'video';
        const label = document.createElement('div');
        const cursorClass = isVideo ? 'cursor-default' : 'cursor-pointer';
        const bgClass = (!isVideo && isSelected) ? 'bg-[#ecedfa] font-[500]' : (isVideo ? '' : 'hover:bg-gray-50');

        label.className = `label-row ${cursorClass} px-3 text-[13px] text-gray-700 border-b border-gray-100 flex items-center h-[40px] shrink-0 transition-colors ${bgClass}`;
        label.innerHTML = `<div class="flex items-center gap-2 text-gray-20">${isVideo ? VIDEO_ICON_SVG : PARTITION_ICON_SVG}<span class="truncate text-gray-600">${name}</span></div>`;

        if (!isVideo) {
            label.onclick = () => {
                this.renderTracks(instructions, this.currentPPS, idx);
                window.app.openFullEditSidebar(idx - 1);
            };
        }

        const data = document.createElement('div');
        const dataBgClass = (!isVideo && isSelected) ? 'bg-[#ecedfa]' : '';
        data.className = `data-row relative w-full h-[40px] border-b border-gray-100 transition-colors ${dataBgClass}`;

        if (!isVideo) {
            data.onclick = (e) => {
                if (e.target === data) {
                    this.renderTracks(instructions, this.currentPPS, idx);
                    window.app.openFullEditSidebar(idx - 1);
                }
            };
        }

        if (isVideo) {
            const bar = document.createElement('div');
            bar.className = 'absolute h-[15px] bg-[#5e44ff] w-full top-1/2 -translate-y-1/2 pointer-events-none';
            data.appendChild(bar);
        } else if (instructionData) {
            const ranges = instructionData.frames.split(' | ');
            ranges.forEach(rangeStr => {
                const parts = rangeStr.split(' - ').map(Number);
                if (parts.length !== 2 || isNaN(parts[0]) || isNaN(parts[1])) return;
                const [s, e] = parts;

                const startX = (s / CONFIG.FPS) * this.currentPPS;
                const widthX = ((e - s) / CONFIG.FPS) * this.currentPPS;

                const bar = document.createElement('div');
                bar.className = 'absolute h-[20px] bg-[#757575] rounded-[2px] cursor-pointer transition-colors';
                bar.style.left = startX + 'px';
                bar.style.width = widthX + 'px';
                bar.style.top = '50%';
                bar.style.transform = 'translateY(-50%)';

                bar.onmouseenter = (event) => {
                    event.stopPropagation();
                    const tooltip = document.getElementById('timelineTooltip');

                    if (tooltip) {
                        clearTimeout(window.app.tooltipTimeout);

                        // --- START OF FIX ---
                        const tooltipFramesContainer = document.getElementById('tooltipFrames');

                        // 1. Clear any old classes from the placeholder span to prevent style conflicts.
                        if (tooltipFramesContainer) {
                            tooltipFramesContainer.className = '';
                        }

                        // 2. Use innerHTML to render the clickable, styled span from our function.
                        document.getElementById('tooltipFrames').innerHTML = window.app.formatClickableFrames(rangeStr);
                        // --- END OF FIX ---

                        document.getElementById('tooltipClass').innerText = instructionData.className;
                        document.getElementById('tooltipText').innerHTML = window.app.formatAnnotationValue(instructionData.text, instructionData.className);

                        tooltip.classList.add('is-active');
                        tooltip.style.opacity = '0';

                        requestAnimationFrame(() => {
                            const barRect = bar.getBoundingClientRect();
                            const tooltipRect = tooltip.getBoundingClientRect();
                            const timelineWindow = document.getElementById('timelineContentColumn');
                            const windowRect = timelineWindow.getBoundingClientRect();
                            const visibleBarLeft = Math.max(barRect.left, windowRect.left);
                            const visibleBarRight = Math.min(barRect.right, windowRect.right);

                            if (visibleBarRight < visibleBarLeft) {
                                tooltip.classList.remove('is-active');
                                return;
                            }

                            const centerX = (visibleBarLeft + visibleBarRight) / 2;
                            let top = barRect.top - tooltipRect.height - 12;
                            let left = centerX - (tooltipRect.width / 2);

                            if (top < 10) top = barRect.bottom + 12;
                            left = Math.max(10, Math.min(left, window.innerWidth - tooltipRect.width - 10));

                            tooltip.style.left = `${left}px`;
                            tooltip.style.top = `${top}px`;
                            tooltip.style.opacity = '1';
                        });
                    }
                };

                bar.onmouseleave = (event) => {
                    event.stopPropagation();
                    window.app.tooltipTimeout = setTimeout(() => {
                        const tooltip = document.getElementById('timelineTooltip');
                        if (tooltip) {
                            tooltip.classList.remove('is-active');
                            tooltip.style.opacity = '';
                        }
                    }, 300);
                };

                bar.onclick = (e) => {
                    e.stopPropagation();
                    this.renderTracks(instructions, this.currentPPS, idx);
                    window.app.openFullEditSidebar(idx - 1);
                };

                data.appendChild(bar);
            });
        }
        return { label, data };
    }
}

/**
 * AnnotationPanelView: Manages annotation panel UI and slider
 */
class AnnotationPanelView {
    constructor(elements) {
        this.elements = elements;
    }

    show() {
        this.elements.overlay.classList.remove('hidden');
        this.elements.videoBadge.classList.add('hidden'); // Hide badge to avoid overlap

        // Reset position before showing
        this.elements.overlay.style.opacity = "0";
        this.elements.overlay.style.transform = "translateY(20px)";

        requestAnimationFrame(() => {
            this.elements.overlay.style.transition = "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)";
            this.elements.overlay.style.opacity = "1";
            this.elements.overlay.style.transform = "translateY(0)";
        });
    }

    hide() {
        this.elements.overlay.style.opacity = "0";
        this.elements.overlay.style.transform = "translateY(20px)";

        setTimeout(() => {
            this.elements.overlay.classList.add('hidden');
            this.elements.videoBadge.classList.remove('hidden');
        }, 300);
    }

    updateSlider(start, end, current, totalFrames, ranges = []) {
        const startPct = (start / totalFrames) * 100;
        const endPct = (end / totalFrames) * 100;
        const currentPct = (current / totalFrames) * 100;

        this.elements.knobStart.style.left = startPct + '%';
        this.elements.knobEnd.style.left = endPct + '%';
        this.elements.knobCurrent.style.left = currentPct + '%';

        // FIX: Ensure highlight bar always draws correctly even if start > end while typing
        const highlightLeft = Math.min(startPct, endPct);
        const highlightWidth = Math.abs(endPct - startPct);

        this.elements.sliderHighlight.style.left = highlightLeft + '%';
        this.elements.sliderHighlight.style.width = highlightWidth + '%';

        const format = (val) => (window.app && window.app.formatDisplay) ? window.app.formatDisplay(val) : val;
        const formattedStart = format(start);
        const formattedEnd = format(end);

        this.elements.valLabelStart.innerText = formattedStart;
        this.elements.valLabelEnd.innerText = formattedEnd;
        this.elements.staticLabelEnd.innerText = format(totalFrames);

        // Update tooltips for knobs
        this.elements.knobStart.setAttribute('data-tooltip', formattedStart);
        this.elements.knobEnd.setAttribute('data-tooltip', formattedEnd);

        // If a knob is active in the tooltip manager, re-show it to update content/position
        if (window.tooltipManager) {
            if (window.tooltipManager.activeElement === this.elements.knobStart ||
                window.tooltipManager.activeElement === this.elements.knobEnd) {
                window.tooltipManager.show(window.tooltipManager.activeElement);
            }
        }

        if (document.activeElement !== this.elements.inputStart) this.elements.inputStart.value = formattedStart;
        if (document.activeElement !== this.elements.inputEnd) this.elements.inputEnd.value = formattedEnd;

        // 5. Handle "current" point styling
        // Purple border/text if occupied by ANY range, grey if not
        const isOccupied = ranges.length > 0
            ? ranges.some(r => current >= r.start && current <= r.end)
            : (current >= start && current <= end);

        Object.assign(this.elements.knobCurrent.style, {
            display: 'block',
            position: 'absolute',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: 'white',
            border: `2px solid ${isOccupied ? '#5f45ff' : '#d1d5db'}`,
            zIndex: '20'
        });

        if (this.elements.currentBadge) {
            Object.assign(this.elements.currentBadge.style, {
                position: 'absolute',
                left: '50%',
                top: '100%',
                transform: 'translateX(-50%)',
                marginTop: '4px',
                fontSize: '10px',
                whiteSpace: 'nowrap',
                color: isOccupied ? 'black' : '#9ca3af',
                pointerEvents: 'none'
            });

            // Hide only at starting point, ending point, or range knobs
            // Hide only at starting point, ending point, or range knobs
            const rangesToCheck = ranges.length > 0 ? ranges : [{ start, end }];
            // Use small epsilon for robustness
            const atKnob = rangesToCheck.some(r => Math.abs(current - r.start) < 0.1 || Math.abs(current - r.end) < 0.1);
            const atEdge = (current <= 0 || current >= totalFrames);

            if (atKnob || atEdge) {
                this.elements.currentBadge.style.opacity = "0";
                this.elements.currentBadge.style.display = "none";
            } else {
                this.elements.currentBadge.style.opacity = "1";
                this.elements.currentBadge.style.display = "block";
            }
        }

        // Handle static label opacity to avoid overlap at boundaries
        if (this.elements.staticLabelStart) {
            const rangeStart = ranges.length > 0 ? Math.min(...ranges.map(r => r.start)) : start;
            this.elements.staticLabelStart.style.opacity = (rangeStart === 0) ? "0" : "1";
        }
        if (this.elements.staticLabelEnd) {
            const rangeEnd = ranges.length > 0 ? Math.max(...ranges.map(r => r.end)) : end;
            this.elements.staticLabelEnd.style.opacity = (rangeEnd === totalFrames) ? "0" : "1";
        }
    }

    updateClassTag(value) {
        try {
            const parsed = JSON.parse(value);
            const className = window.app.annotationModel.className;
            const cls = CONFIG.CLASSES.find(c => c.name === className);
            if (cls && cls.subInputs) {
                const badges = cls.subInputs
                    .filter(sub => parsed[sub.id] && parsed[sub.id].trim() !== '')
                    .map(sub => {
                        const label = sub.label || sub.name;
                        const val = parsed[sub.id].trim();
                        return `<span class="inline-flex items-center px-[8px] py-[2px] bg-[#f0f5ff] border border-[#adc6ff] rounded-md gap-1.5 mr-1">
  <span class="font-[600] text-[#1d39c4] text-[12px]">${label}</span>
  <span class="font-[480] text-[#1d39c4] text-[12px]">${val}</span>
</span>
`;
                    })
                    .join('');

                // Image 4 style: Badges for each sub-input
                this.elements.activeClassTagDisplay.innerHTML = badges;
                return;
            }
        } catch (e) {
            // Not JSON or no sub-inputs, fall through
        }

        // Single input case: Use class name as prefix
        const className = window.app.annotationModel.className;
        this.elements.activeClassTagDisplay.innerHTML = `<span class="inline-flex items-center px-[8px] py-[2px] bg-[#f0f5ff] border border-[#adc6ff] rounded-md gap-1.5 mr-1">
  <span class="font-[600] text-[#1d39c4] text-[12px]">${className}</span>
  <span class="font-[480] text-[#1d39c4] text-[12px]">${value}</span>
</span>`;
    }
}

/**
 * InstructionListRenderer Class
 * FINAL FIX: Isolates the dropdown state between "All" and "Frame" tabs.
 * - Manages two separate state variables: `expandedGroupsAll` and `expandedGroupsFrame`.
 * - `toggleGroup` now modifies the state for the currently active view only.
 * - `render` now reads from the state corresponding to the active view.
 */
class InstructionListRenderer {
    constructor(containerElement) {
        this.container = containerElement;

        // STATE ISOLATION: Create separate state for each view's dropdowns
        this.expandedGroupsAll = new Set(['Description', 'Action tags']);
        this.expandedGroupsFrame = new Set(['Description', 'Action tags']);

        this.lastData = null; // Cache to know the current mode for toggling
    }

    toggleGroup(className) {
        // Use the cached mode to determine which state Set to modify
        if (!this.lastData) return;
        const currentMode = this.lastData.mode;
        const targetSet = currentMode === 'all' ? this.expandedGroupsAll : this.expandedGroupsFrame;

        if (targetSet.has(className)) {
            targetSet.delete(className);
        } else {
            targetSet.add(className);
        }

        // Re-render with the updated state for the current view
        this.render(this.lastData.instructions, this.lastData.mode, this.lastData.currentFrame);
    }

    /**
     * InstructionListRenderer.render
     * UPDATED: Conditional styling for gray background and header text color.
     * If 1 item in Frame mode: background is transparent and text is gray-20.
     */
    render(instructions, mode = 'all', currentFrame = 0) {
        this.lastData = { instructions, mode, currentFrame };
        if (!this.container) return;

        // 1. CLONE, SORT & FILTER (Logic remains the same)
        let displayItems = [...instructions];
        displayItems.sort((a, b) => {
            let valA, valB;
            if (window.app.labelSort.by === 'frame') {
                valA = parseInt(a.frames.split(' | ')[0].split(' - ')[0]);
                valB = parseInt(b.frames.split(' | ')[0].split(' - ')[0]);
            } else { valA = a.timestamp || 0; valB = b.timestamp || 0; }
            return window.app.labelSort.order === 'asc' ? valA - valB : valB - valA;
        });

        if (window.app && window.app.labelFilter && window.app.labelFilter.active) {
            displayItems = displayItems.filter(item => {
                const ranges = item.frames.split(' | ');
                return ranges.some(rangeStr => {
                    const [s, e] = rangeStr.split(' - ').map(Number);
                    return s <= window.app.labelFilter.end && e >= window.app.labelFilter.start;
                });
            });
        }

        if (mode === 'frame') {
            displayItems = displayItems.filter(item => {
                const ranges = item.frames.split(' | ');
                return ranges.some(rangeStr => {
                    const [s, e] = rangeStr.split(' - ').map(Number);
                    return currentFrame >= s && currentFrame <= e;
                });
            });
        }

        // Locate this block in your render() method and replace it:
        if (displayItems.length === 0) {
            this.container.innerHTML = `
        <div class="flex flex-col items-center justify-center pt-10">
            <svg width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg">
                <title>Simple Empty</title>
                <g transform="translate(0 1)" fill="none" fill-rule="evenodd">
                    <ellipse fill="#f5f5f5" cx="32" cy="33" rx="32" ry="7"></ellipse>
                    <g fill-rule="nonzero" stroke="#d9d9d9">
                        <path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path>
                        <path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" fill="#fafafa"></path>
                    </g>
                </g>
            </svg>
            <div class="mt-4 text-[#bfbfbf] text-[14px]">No classifications or objects</div>
        </div>
    `;
            return;
        }

        const groups = displayItems.reduce((acc, item) => {
            const cls = item.className || 'Description';
            if (!acc[cls]) acc[cls] = [];
            acc[cls].push(item);
            return acc;
        }, {});

        // 2. GENERATE HTML
        let html = '';
        Object.keys(groups).forEach(className => {
            const groupItems = groups[className];
            const targetSet = mode === 'all' ? this.expandedGroupsAll : this.expandedGroupsFrame;

            // CONDITION: Show header if All tab OR > 1 items
            const showGroupHeader = (mode === 'all' || groupItems.length > 1);

            const isExpanded = showGroupHeader ? targetSet.has(className) : true;
            const arrowIcon = isExpanded ? CHEVRON_DOWN_SVG : CHEVRON_RIGHT_SVG;

            html += `<div class="group-wrapper border-gray-100">`;

            if (showGroupHeader) {
                html += `
            <div onclick="window.app.instructionRenderer.toggleGroup('${className}')" 
                class="flex items-center gap-2 px-3 py-2 pl-2 hover:bg-gray-50 cursor-pointer select-none">
                <div class="flex items-center gap-2">
                    <div class="text-gray-20 flex items-center justify-center">${arrowIcon}</div>
                    <div class="text-gray-20 flex items-center justify-center">${PARTITION_ICON_SVG}</div>
                    <span class="text-[14px] font-[400] text-gray-20">${className}</span>
                </div>
                <div class="w-5 h-5 flex items-center justify-center border border-[#e7e4e4] rounded-full text-[11px] text-gray-20 bg-[#fafafa]">
                    ${groupItems.length}
                </div>
            </div>`;
            }

            if (isExpanded) {
                // FIX: Conditional background and padding
                const nestedContainerClasses = showGroupHeader
                    ? 'bg-[#00000005] pb-1 pl-5 space-y-1'
                    : 'bg-transparent pb-1 px-3 space-y-1';

                html += `<div class="${nestedContainerClasses}">`;

                groupItems.forEach(item => {
                    const actualIdx = instructions.indexOf(item);

                    // Locate this line inside the groupItems.forEach loop:
                    const framesHTML = mode === 'all' ? `
                    <div class="flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px] text-gray-500 mt-1">
                        <span class="shrink-0">Frames</span> ${window.app.formatClickableFrames(item.frames)}
                    </div>` : '';

                    // FIX: Conditional text color for card header
                    const cardHeaderTextColor = 'text-gray-700';

                    html += `
                <div class="annotation-card group py-1 border-b border-gray-50 last:border-0 relative hover:bg-gray-50 transition-colors">
                    <div class="flex items-start justify-between px-2">
                        <div class="flex items-center gap-2 ${cardHeaderTextColor}">
                            <div class="flex items-center justify-center">${PARTITION_ICON_SVG}</div>
                            <span class="text-[14px] font-[400]">${className}</span>
                        </div>
                        <div class="flex items-center gap-0.5 invisible group-hover:visible transition-opacity">
                            <div onclick="window.app.toggleOptionsMenu(event, ${actualIdx})" class="more-vert-btn text-gray-500 hover:text-black cursor-pointer p-1.5 rounded-full hover:bg-black/5">${MORE_VERT_ICON_SVG}</div>
                            <div onclick="window.app.openFullEditSidebar(${actualIdx})" class="text-gray-500 hover:text-black cursor-pointer p-1.5 rounded-full hover:bg-black/5">${PENCIL_EDIT_ICON_SVG}</div>
                        </div>
                    </div>
                    ${framesHTML}
                    <div class="px-2 pb-1.5 mt-1.5 text-[12px] text-[#1d39c4]">
                        ${window.app.formatAnnotationValue(item.text, className)}
                    </div>
                    <div id="optionsMenu-${actualIdx}" class="hidden"></div>
                </div>`;
                });
                html += `</div>`;
            }
            html += `</div>`;
        });

        this.container.innerHTML = html;

        // Menu injection (Remains same)
        this.container.querySelectorAll('[id^="optionsMenu-"]').forEach(menuPlaceholder => {
            const idx = menuPlaceholder.id.split('-')[1];
            menuPlaceholder.innerHTML = `
            <div class="menu-item" onclick="window.app.hideAllMenus()">${COPY_ICON_SVG} <span>Copy identifier</span></div>
            <div class="menu-item" onclick="window.app.hideAllMenus()">${LINK_ICON_SVG} <span>Copy URL</span></div>
            <div class="menu-divider"></div>
            <div onclick="window.app.goToClassification(${idx})" class="menu-item">${GO_TO_ICON_SVG} <span>Go to classification</span></div>
            <div onclick="window.app.editRange(${idx})" class="menu-item">${EDIT_ICON_SVG} <span>Edit range</span></div>
            <div onclick="window.app.showDeleteConfirmation(${idx})" class="menu-item text-red-600">${DELETE_ICON_SVG} <span>Delete</span></div>
        `;
        });
    }
}

/**
 * MenuManager: Base class for menu behavior
 */
class MenuManager {
    constructor(menuElement, buttonElement) {
        this.menu = menuElement;
        this.button = buttonElement;
        this.isOpen = false;
    }

    toggle() {
        this.isOpen ? this.close() : this.open();
    }

    open() {
        this.menu.classList.remove('hidden');
        this.button.parentElement.classList.add('menu-active');
        this.isOpen = true;
    }

    close() {
        this.menu.classList.add('hidden');
        this.button.parentElement.classList.remove('menu-active');
        this.isOpen = false;
    }

    isVisible() {
        return this.isOpen;
    }
}

/**
 * FilterMenuManager: Manages filter menu with sliders
 */
class FilterMenuManager extends MenuManager {
    constructor(menuElement, buttonElement, transformManager, elements) {
        super(menuElement, buttonElement);
        this.transformManager = transformManager;
        this.sliders = elements.sliders || {};
        this.subMenu = elements.subMenu;
        this.subTrigger = elements.subTrigger;
        this.pixelToggle = elements.pixelToggle;
    }

    initialize() {
        this.setupSubMenu();
        this.setupSliders();
        this.setupPixelToggle();
        this.setupFilterOptions();
    }

    setupSubMenu() {

        if (this.subTrigger) {
            this.subTrigger.onmouseenter = () => this.subMenu.classList.remove('hidden');
        }

        const sliderSection = this.menu.querySelector('.p-4');
        if (sliderSection) {
            sliderSection.onmouseenter = () => this.subMenu.classList.add('hidden');
        }

        this.menu.onmouseleave = () => this.subMenu.classList.add('hidden');
    }

    setupSliders() {
        Object.entries(this.sliders).forEach(([id, el]) => {
            if (el) {
                el.addEventListener("input", () => this.applyFilters());
                this.updateSliderFill(el);
            }
        });
    }

    applyFilters() {
        const b = this.sliders.brightRange?.value || 100;
        const c = this.sliders.contrastRange?.value || 100;
        const s = this.sliders.gammaRange?.value || 100;

        this.transformManager.setFilters(b, c, s);

        Object.values(this.sliders).forEach(el => this.updateSliderFill(el));
    }

    updateSliderFill(el) {
        const val = (el.value - el.min) / (el.max - el.min) * 100;
        // We use background-image to create the fill effect on the 4px track
        el.style.backgroundImage = `linear-gradient(to right, #5f45ff ${val}%, #e5e7eb ${val}%)`;
        el.style.backgroundColor = '#e5e7eb'; // Fallback
    }

    setupPixelToggle() {
        if (this.pixelToggle) {
            this.pixelToggle.onchange = (e) => {
                this.transformManager.setPixelated(e.target.checked);
            };

            this.pixelToggle.closest('div').onmouseenter = () => {
                if (this.subMenu) this.subMenu.classList.add('hidden');
            };
        }
    }

    setupFilterOptions() {
        document.querySelectorAll(CONFIG.FILTER_OPTIONS_SELECTOR).forEach(opt => {
            opt.onclick = (e) => {
                e.stopPropagation();
                // Update checkmarks
                this.menu.querySelectorAll('.check-mark').forEach(cm => cm.classList.add('hidden'));
                opt.querySelector('.check-mark').classList.remove('hidden');

                const filterType = opt.dataset.filter;
                const current = this.transformManager.getFilters();

                if (filterType === 'none') {
                    this.applyFilters(); // Reset to slider values
                } else {
                    // Apply specific channel filters
                    // Note: These logic settings depend on your CSS filter implementation in VideoTransformManager
                    if (filterType === 'red') this.transformManager.setFilters(current.brightness, current.contrast, 0, 'red');
                    if (filterType === 'green') this.transformManager.setFilters(current.brightness, current.contrast, 0, 'green');
                    if (filterType === 'blue') this.transformManager.setFilters(current.brightness, current.contrast, 0, 'blue');
                }
            };
        });
    }
}

/**
 * SettingsMenuManager: Manages settings menu and frame skip submenu
 */
class SettingsMenuManager extends MenuManager {
    constructor(menuElement, buttonElement, elements) {
        super(menuElement, buttonElement);
        this.subMenu = elements.subMenu;
        this.subTrigger = elements.subTrigger;
        // Timestamp format elements
        this.timestampSubMenu = elements.timestampSubMenu;
        this.timestampTrigger = elements.timestampTrigger;

        // New elements for the control bar selector
        this.pillMenu = elements.pillMenu;
        this.pillOptionsContainer = elements.pillOptionsContainer;
        this.pillDisplay = elements.pillDisplay;

        this.currentFrameSkip = CONFIG.DEFAULT_FRAME_SKIP;
        this.currentTimestampFormat = CONFIG.DEFAULT_TIMESTAMP_FORMAT || ''; // "" means Frames
    }

    initialize() {
        this.renderFrameSkipOptions();
        this.renderTimestampFormatOptions();
        this.updatePillDisplay();
    }

    renderTimestampFormatOptions() {
        if (!this.timestampSubMenu) return;
        this.timestampSubMenu.innerHTML = '';

        // Render options from CONFIG.TIMESTAMP_FORMATS
        const options = CONFIG.TIMESTAMP_FORMATS;

        options.forEach(optVal => {
            const val = optVal;
            const opt = document.createElement('div');
            opt.className = 'flex items-center justify-between w-full px-4 py-2 text-[13px] hover:bg-gray-50 cursor-pointer transition-colors';
            opt.innerText = optVal;

            if (val === this.currentTimestampFormat) {
                opt.classList.add('bg-[#f4f0ff]', 'text-[#5f45ff]', 'font-semibold');
            }

            opt.onclick = (e) => {
                e.stopPropagation();
                this.setTimestampFormat(val);
            };
            this.timestampSubMenu.appendChild(opt);
        });
    }

    setTimestampFormat(format) {
        this.currentTimestampFormat = format;
        if (window.app) {
            window.app.displayTimestamps = (format !== 'Frames');
            window.app.timestampFormat = format;
            window.app.updateSettingsCheckmarks();
            window.app.refreshTimeDisplays();
        }
        this.renderTimestampFormatOptions();
        console.log(`Timestamp format set to: ${format || 'Frames'}`);
    }

    renderFrameSkipOptions() {
        // 1. FILL THE SETTINGS GEAR HOVER MENU (#frameSkipSubMenu)
        const subMenu = document.getElementById('frameSkipSubMenu');
        if (subMenu) {
            subMenu.innerHTML = '';
            CONFIG.FRAME_SKIP_VALUES.forEach(val => {
                const isSelected = (val === this.currentFrameSkip);
                const item = document.createElement('div');
                item.className = `sub-skip-btn ${isSelected ? 'active' : ''}`;
                item.innerText = val;

                item.onclick = (e) => {
                    e.stopPropagation();
                    this.setFrameSkip(val);
                    if (window.app) window.app.hideAllMenus();
                };
                subMenu.appendChild(item);
            });
        }

        // 2. FILL THE TIMELINE PILL MENU (#frameSkipOptionsContainer)
        const pillContainer = document.getElementById('frameSkipOptionsContainer');
        if (pillContainer) {
            pillContainer.innerHTML = '';
            CONFIG.FRAME_SKIP_VALUES.forEach(val => {
                const isSelected = (val === this.currentFrameSkip);
                const btn = document.createElement('div');
                btn.className = `skip-item-btn ${isSelected ? 'is-active' : ''}`;
                btn.innerText = val;
                btn.title = val;

                btn.onclick = (e) => {
                    e.stopPropagation();
                    this.setFrameSkip(val);
                    if (window.app) window.app.toggleFrameSkipSelectorMenu(null, false);
                };
                pillContainer.appendChild(btn);
            });
        }

        this.updatePillDisplay();
    }

    updatePillDisplay() {
        if (this.pillDisplay) {
            this.pillDisplay.innerText = this.currentFrameSkip;
        }
    }

    setFrameSkip(val) {
        this.currentFrameSkip = val;
        // Update VideoController's skip frame value
        if (window.app && window.app.videoController) {
            window.app.videoController.frameSkip = val;
        }
        this.renderFrameSkipOptions();
        console.log(`Frame skip set to: ${val}`);
    }
}

/**
 * SpeedMenuManager: Manages playback speed menu and state
 */
class SpeedMenuManager extends MenuManager {
    constructor(videoController, speedBtn, speedMenu) {
        super(speedMenu, speedBtn);
        this.videoController = videoController;
        this.speedBtn = speedBtn;
        this.speedMenu = speedMenu;
    }

    initialize() {
        this.renderSpeedOptions();
        this.updateButtonText();
    }

    renderSpeedOptions() {
        if (!this.speedMenu) return;
        this.speedMenu.innerHTML = '';
        CONFIG.PLAYBACK_SPEEDS.forEach(s => {
            const opt = document.createElement('div');
            const isActive = Math.abs(this.videoController.playbackRate - s) < 0.01;

            opt.className = `px-4 py-2 text-[13px] cursor-pointer transition-colors text-center font-[480]
            ${isActive ? 'bg-[#f4f0ff] text-[#5f45ff] rounded-lg' : 'text-gray-700  hover:bg-gray-50 rounded-lg hover:text-[#5f45ff]'}`;

            opt.innerText = s + 'x';

            opt.onclick = (e) => {
                e.stopPropagation();
                this.setSpeed(s);
                this.close();
            };
            this.speedMenu.appendChild(opt);
        });
    }

    updateButtonText() {
        if (this.speedBtn) {
            this.speedBtn.innerText = this.videoController.playbackRate + 'x';
        }
    }

    setSpeed(val) {
        this.videoController.playbackRate = val;
        this.updateButtonText();
        this.renderSpeedOptions();
    }

    step(direction) {
        const speeds = CONFIG.PLAYBACK_SPEEDS;
        const current = this.videoController.playbackRate;
        let index = speeds.findIndex(s => Math.abs(s - current) < 0.01);

        if (index === -1) {
            // Find closest speed if not exactly in list
            index = speeds.reduce((prev, curr, idx) =>
                Math.abs(curr - current) < Math.abs(speeds[prev] - current) ? idx : prev, 0);
        }

        if (direction === 'up' && index < speeds.length - 1) {
            this.setSpeed(speeds[index + 1]);
        } else if (direction === 'down' && index > 0) {
            this.setSpeed(speeds[index - 1]);
        }
    }
}

/**
 * ZoomToolManager: Manages zoom in/out tools
 */
class ZoomToolManager {
    constructor(containerElement, transformManager) {
        this.container = containerElement;
        this.transformManager = transformManager;
    }

    handleWheel(deltaY, clientX, clientY) {
        if (deltaY < 0) {
            this.transformManager.zoomTowards(CONFIG.ZOOM_STEP, clientX, clientY);
        } else {
            this.transformManager.zoomTowards(-CONFIG.ZOOM_STEP, clientX, clientY);
        }
    }

    reset() {
        this.transformManager.resetTransform();
    }
}

/**
 * ScrollSynchronizer: Syncs timeline scroll with playhead
 */
class ScrollSynchronizer {
    constructor(scrollContainer, playheadElement) {
        this.scrollContainer = scrollContainer;
        this.playhead = playheadElement;
    }

    sync(currentTime, duration, currentPPS, forceCenter = false) {
        if (!duration || !currentPPS || !this.scrollContainer) return;

        const timelineWidth = duration * currentPPS;
        const percent = currentTime / duration;
        const playheadX = percent * timelineWidth;

        const visibleWidth = this.scrollContainer.clientWidth;
        const scrollLeft = this.scrollContainer.scrollLeft;
        const padding = CONFIG.SCROLL_PADDING || 100;

        if (forceCenter) {
            // When jumping to a frame, center the ruler on that frame
            this.scrollContainer.scrollTo({
                left: playheadX - (visibleWidth / 2),
                behavior: 'smooth'
            });
        } else {
            // During normal playback, only scroll if playhead goes out of bounds
            if (playheadX > (scrollLeft + visibleWidth - padding)) {
                this.scrollContainer.scrollLeft = playheadX - (visibleWidth - padding);
            } else if (playheadX < scrollLeft + padding) {
                this.scrollContainer.scrollLeft = Math.max(0, playheadX - padding);
            }
        }
    }
}

/**
 * OPEN/CLOSED PRINCIPLE - Event handler factories
 */

/**
 * Creates playback control handlers
 */
function createPlaybackHandlers(videoController, annotationModel, animationPanel) {
    return {
        playPause: () => videoController.togglePlayPause(),
        next: () => videoController.advanceFrame(),
        previous: () => videoController.rewindFrame(),

        // UPDATE THIS FUNCTION:
        // Updated logic stored in memory
        volume: (e) => {
            if (e) e.stopPropagation();

            // Toggle state
            videoController.muted = !videoController.muted;

            const btnVolume = document.getElementById('btnVolume');

            // Update Icon
            btnVolume.innerHTML = videoController.muted ? VOLUME_OFF_SVG : VOLUME_UP_SVG;

            // Updated Styling logic
            if (videoController.muted) {
                // Use comma-separated arguments for classList
                btnVolume.classList.add('text-gray-20');
            } else {
                btnVolume.classList.remove('text-gray-20');
            }
        }
    };
}


/**
 * Creates rotation handlers
 */
function createRotationHandlers(transformManager) {
    document.getElementById('rotateActionBtn').onclick = () => {
        transformManager.rotate(90);
    };

    document.querySelectorAll(CONFIG.ROTATE_OPTIONS_SELECTOR).forEach(opt => {
        opt.onclick = (e) => {
            e.stopPropagation();
            const deg = parseInt(opt.dataset.deg);
            transformManager.setRotation(isNaN(deg) ? 0 : deg);
            document.getElementById('rotateMenu').classList.add('hidden');
        };
    });
}

/**
 * LISKOV SUBSTITUTION & DEPENDENCY INVERSION - Main application controller
 */

class VideoAnnotationApp {
    constructor() {
        this.videoController = null;
        this.transformManager = null;
        this.annotationModel = null;
        this.dragState = null;
        this.selectedTrackIndex = -1;

        this.progressBarView = null;
        this.timelineView = null;
        this.annotationPanelView = null;
        this.instructionRenderer = null;

        this.labelListMode = 'all';

        this.scrollSync = null;
        this.zoomToolManager = null;
        this.filterMenuManager = null;
        this.rotateMenuManager = null;
        this.settingsMenuManager = null;
        this.speedMenuManager = null;

        this.frameInput = null;
        this.totalFramesText = null;
        this.labelFilter = { start: 0, end: 0, active: false };
        this.labelSort = { by: 'date', order: 'asc' };
        this.videoName = "";
        this.editingAnnotationIndex = -1;
        this.expandedSubGroups = {}; // ID: subID -> boolean
        this.displayTimestamps = CONFIG.DEFAULT_TIMESTAMP_FORMAT !== 'Frames';
        this.timestampFormat = CONFIG.DEFAULT_TIMESTAMP_FORMAT; // "Frames", "HH:MM:SS", or "MM:SS"
        this.showFrameSkipSelector = false;
        this.isUpdatingUI = false;
        this.tooltipTimeout = null;
        this.updateSliderFill = () => { };
        this.issues = [];
        this.issueFilterState = {
            status: 'All',
            type: null
        };
        // Multi-range slider state
        // Each entry: { start: Number, end: Number }
        // Index 0 is always the primary range (synced with annotationModel.start/end)
        this.sliderRanges = [];
        this.activeDragRangeIndex = 0; // Which range index is currently being dragged
        this.selectedIssueTypes = [];
        this.selectedNewIssueTag = 'high';
        this.selectedApplyTo = 'current';
        this.isPinningIssue = false;
        this.pinningCoords = null; // {x, y}
        this.pendingCanvasComment = ''; // New: maintain text between moves
        this.tagPopoverSearchActive = false; // New: track search state for tag popover
        this.activeIssueId = null; // Track selected card for border highlighting
        console.log("VideoAnnotationApp v1.1.0 (Fixed Toggles) loaded");
    }
    // --- ISSUE FILTERING & TYPE SELECTION LOGIC ---
    focusTypeSearch(event) {
        if (event.target.closest('.remove-tag')) return;
        document.getElementById('typeSearchInput').focus();
        this.toggleIssueSubDropdown(event, 'type');
    }

    // State: Focused/Open -> Show Close icon
    handleTypeFocus(isFocused) {
        const expandIcon = document.getElementById('typeExpandIcon');
        const searchIcon = document.getElementById('typeSearchIcon');
        const clearBtn = document.getElementById('typeSearchClearBtn');
        const input = document.getElementById('typeSearchInput');

        if (isFocused) {
            // Show Close, Hide Others
            expandIcon.classList.add('hidden');
            searchIcon.classList.add('hidden');
            clearBtn.classList.remove('hidden');
        } else {
            // Blurred: Show Arrow, Hide Others
            setTimeout(() => {
                if (document.activeElement !== input) {
                    expandIcon.classList.remove('hidden');
                    searchIcon.classList.add('hidden');
                    clearBtn.classList.add('hidden');
                }
            }, 150);
        }
    }

    // Typing still shows Close icon
    handleTypeSearchInput(query) {
        const expandIcon = document.getElementById('typeExpandIcon');
        const searchIcon = document.getElementById('typeSearchIcon');
        const clearBtn = document.getElementById('typeSearchClearBtn');

        expandIcon.classList.add('hidden');
        searchIcon.classList.add('hidden');
        clearBtn.classList.remove('hidden');

        this.filterIssueTypes(query);
    }

    clearTypeSearch(event) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        const input = document.getElementById('typeSearchInput');
        input.value = '';

        // Reset all selected types
        this.selectedIssueTypes = [];
        this.updateTypeUI();

        // Keep Close icon visible as we remain focused
        document.getElementById('typeSearchClearBtn').classList.remove('hidden');
        document.getElementById('typeSearchIcon').classList.add('hidden');
        document.getElementById('typeExpandIcon').classList.add('hidden');

        this.filterIssueTypes('');
        if (input) input.focus();
    }

    toggleTypeSelection(event, value) {
        if (event) event.stopPropagation();

        const index = this.selectedIssueTypes.indexOf(value);
        if (index > -1) {
            this.selectedIssueTypes.splice(index, 1);
        } else {
            this.selectedIssueTypes.push(value);
        }

        this.updateTypeUI();
        document.getElementById('typeSearchInput').focus();
    }

    updateTypeUI() {
        const container = document.getElementById('typeTagsContainer');
        const input = document.getElementById('typeSearchInput');

        const tagsHtml = this.selectedIssueTypes.map(type => `
            <div class="type-tag rounded-lg">
                ${type}
                <span class="remove-tag" onclick="window.app.toggleTypeSelection(event, '${type}')">
                    <svg fill-rule="evenodd" viewBox="64 64 896 896" focusable="false" data-icon="close" width="10" height="10" fill="currentColor" aria-hidden="true">
                        <path d="M799.86 166.31c.02 0 .04.02.08.06l57.69 57.7c.04.03.05.05.06.08a.12.12 0 010 .06c0 .03-.02.05-.06.09L569.93 512l287.7 287.7c.04.04.05.06.06.09a.12.12 0 010 .07c0 .02-.02.04-.06.08l-57.7 57.69c-.03.04-.05.05-.07.06a.12.12 0 01-.07 0c-.03 0-.05-.02-.09-.06L512 569.93l-287.7 287.7c-.04.04-.06.05-.09.06a.12.12 0 01-.07 0c-.02 0-.04-.02-.08-.06l-57.69-57.7c-.04-.03-.05-.05-.06-.07a.12.12 0 010-.07c0-.03.02-.05.06-.09L454.07 512l-287.7-287.7c-.04-.04-.05-.06-.06-.09a.12.12 0 010-.07c0-.02.02-.04.06-.08l57.7-57.69c.03-.04.05-.05.07-.06a.12.12 0 01.07 0c.03 0 .05.02.09.06L512 454.07l287.7-287.7c.04-.04.06-.05.09-.06a.12.12 0 01.07 0z"></path>
                    </svg>
                </span>
            </div>
        `).join('');

        container.innerHTML = tagsHtml;
        if (input) container.appendChild(input);

        input.placeholder = this.selectedIssueTypes.length > 0 ? "" : "Filter by issue types";

        document.querySelectorAll('.type-opt').forEach(opt => {
            const val = opt.getAttribute('data-val');
            const isSelected = this.selectedIssueTypes.includes(val);
            opt.classList.toggle('selected', isSelected);
            opt.querySelector('.check-mark')?.classList.toggle('hidden', !isSelected);
        });

        this.refreshIssuesUI();
        this.updateFilterBadge();
    }

    filterIssueTypes(query) {
        const term = query.toLowerCase().trim();
        const options = document.querySelectorAll('.type-opt');
        const noDataEl = document.getElementById('typeNoData');
        const menu = document.getElementById('typeDropdownMenu');

        let visibleCount = 0;
        options.forEach(opt => {
            const text = opt.innerText.toLowerCase();
            if (text.includes(term)) {
                opt.classList.remove('hidden');
                visibleCount++;
            } else {
                opt.classList.add('hidden');
            }
        });

        if (noDataEl) noDataEl.classList.toggle('hidden', visibleCount > 0);
        menu?.classList.remove('hidden');
    }

    // --- POPOVER & SUB-DROPDOWN TOGGLES ---

    toggleIssueFilterPopover(event) {
        if (event) event.stopPropagation();
        const popover = document.getElementById('issueFilterPopover');
        // Check actual visibility (must check both class and inline style)
        const isVisible = !popover.classList.contains('hidden') && popover.style.display !== 'none';

        // Close other popup menus (issueFilterPopover is NOT in hideAllMenus)
        this.hideAllMenus();

        if (isVisible) {
            // Was open -> close it
            popover.classList.add('hidden');
            popover.style.display = 'none';
        } else {
            // Was closed -> open it
            popover.classList.remove('hidden');
            popover.style.display = 'block';
        }
    }

    toggleIssueSubDropdown(event, type) {
        if (event) event.stopPropagation();
        const statusMenu = document.getElementById('statusDropdownMenu');
        const typeMenu = document.getElementById('typeDropdownMenu');
        const statusSelect = document.getElementById('statusSelectBox');
        const typeSelect = document.getElementById('typeSelectBox');

        let isRequestedVisible = false;
        if (type === 'status') {
            isRequestedVisible = statusMenu?.classList.contains('hidden');
        } else {
            isRequestedVisible = typeMenu?.classList.contains('hidden');
        }

        // Hide ALL other menus first
        this.hideAllMenus();

        if (isRequestedVisible) {
            if (type === 'status' && statusMenu) {
                statusMenu.classList.remove('hidden');
                statusMenu.style.display = 'block';
                statusSelect?.classList.add('is-active');
                document.getElementById('statusSearchInput')?.focus();
            } else if (type === 'type' && typeMenu) {
                typeMenu.classList.remove('hidden');
                typeMenu.style.display = 'block';
                typeSelect?.classList.add('is-active');
                document.getElementById('typeSearchInput')?.focus();
            }
        }
        this.updateStatusIcons();
    }

    focusStatusSearch(event) {
        if (event) event.stopPropagation();
        this.toggleIssueSubDropdown(null, 'status');
    }

    focusTypeSearch(event) {
        if (event) event.stopPropagation();
        this.toggleIssueSubDropdown(null, 'type');
    }

    handleTypeFocus(isFocused) {
        const selectBox = document.getElementById('typeSelectBox');
        if (isFocused) {
            selectBox?.classList.add('is-active');
        } else {
            const menuOpen = !document.getElementById('typeDropdownMenu')?.classList.contains('hidden');
            if (!menuOpen) {
                selectBox?.classList.remove('is-active');
            }
        }
    }

    handleTypeSearchInput(value) {
        this.filterIssueTypes(value);
        document.getElementById('typeDropdownMenu')?.classList.remove('hidden');
        document.getElementById('typeSelectBox')?.classList.add('is-active');
    }

    handleStatusFocus(isFocused) {
        const selectBox = document.getElementById('statusSelectBox');
        if (isFocused) {
            selectBox?.classList.add('is-active');
        } else {
            // Keep active if value is selected or menu is open
            const menuOpen = !document.getElementById('statusDropdownMenu')?.classList.contains('hidden');
            if (!menuOpen) {
                selectBox?.classList.remove('is-active');
            }
        }
        this.updateStatusIcons();
    }

    handleStatusSearchInput(event) {
        const query = event.target.value.toLowerCase();
        this.filterIssueStatus(query);
        // Ensure menu is open when typing
        document.getElementById('statusDropdownMenu')?.classList.remove('hidden');
        document.getElementById('statusSelectBox')?.classList.add('is-active');
        this.updateStatusIcons();
    }

    filterIssueStatus(query) {
        const options = document.querySelectorAll('.status-opt');
        let hasVisible = false;
        options.forEach(opt => {
            const text = opt.innerText.toLowerCase();
            const visible = text.includes(query);
            opt.classList.toggle('hidden', !visible);
            if (visible) hasVisible = true;
        });

        // Toggle no-data state for status if needed (optional)
    }

    clearStatusSearch(event) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        const input = document.getElementById('statusSearchInput');
        if (input) {
            input.value = '';
            input.focus();
        }
        this.setIssueFilter('status', 'All');
        this.filterIssueStatus('');
        this.hideAllMenus();
    }

    setIssueFilter(event, key, value) {
        // Prevent background listeners from seeing this click
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }

        this.issueFilterState[key] = value;

        if (key === 'status') {
            const input = document.getElementById('statusSearchInput');
            if (input) {
                if (value === 'All') {
                    input.value = '';
                    input.placeholder = 'Filter by issue status';
                } else {
                    input.value = value;
                }
            }

            // Visual checkmark logic
            document.querySelectorAll('.status-opt').forEach(opt => {
                const optText = opt.querySelector('span')?.innerText || opt.innerText;
                const isActive = optText.trim() === value;
                opt.classList.toggle('active', isActive);
                opt.querySelector('.check-mark')?.classList.toggle('hidden', !isActive);
            });

            // Close ONLY the sub-dropdown, keep the main Filters popover open
            document.getElementById('statusDropdownMenu').classList.add('hidden');
            document.getElementById('statusSelectBox').classList.remove('is-active');
        }

        // Refresh UI data
        this.refreshIssuesUI();
        this.updateFilterBadge();
        this.updateStatusIcons();
    }

    setInitialFilterUI() {
        // Sync the status dropdown checkmarks with the initial state (Unresolved)
        const initialStatus = this.issueFilterState.status;
        document.querySelectorAll('.status-opt').forEach(opt => {
            const optText = opt.querySelector('span')?.innerText || opt.innerText;
            const isActive = optText.trim() === initialStatus;
            opt.classList.toggle('active', isActive);
            opt.querySelector('.check-mark')?.classList.toggle('hidden', !isActive);
        });

        // Ensure the input value matches initial status
        const input = document.getElementById('statusSearchInput');
        if (input) {
            if (initialStatus === 'All') {
                input.value = '';
                input.placeholder = 'Filter by issue status';
            } else {
                input.value = initialStatus;
            }
        }
    }

    updateFilterBadge() {
        let count = 0;
        if (this.issueFilterState.status !== 'All') count++;
        count += this.selectedIssueTypes.length;

        const badge = document.getElementById('activeFilterBadge');
        if (badge) {
            if (count > 0) {
                badge.innerText = `+${count}`;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        }
    }

    updateStatusIcons() {
        const searchIcon = document.getElementById('statusSearchIcon');
        const expandIcon = document.getElementById('statusExpandIcon');
        const clearBtn = document.getElementById('statusClearBtn');
        const statusSelect = document.getElementById('statusSelectBox');

        const isActive = statusSelect?.classList.contains('is-active');
        const hasValue = this.issueFilterState.status !== 'All';

        if (!hasValue) {
            searchIcon?.classList.remove('hidden');
            expandIcon?.classList.add('hidden');
            clearBtn?.classList.add('hidden');
        } else {
            searchIcon?.classList.add('hidden');
            if (isActive) {
                expandIcon?.classList.add('hidden');
                clearBtn?.classList.remove('hidden');
            } else {
                expandIcon?.classList.remove('hidden');
                clearBtn?.classList.add('hidden');
            }
        }
    }

    clearStatusFilter(event) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        this.setIssueFilter('status', 'All');
    }

    clearIssueFilters() {
        this.selectedIssueTypes = [];
        this.issueFilterState = { status: 'All', type: null };

        const statusInput = document.getElementById('statusSearchInput');
        if (statusInput) {
            statusInput.value = '';
            statusInput.placeholder = "Filter by issue status";
        }

        const typeSearchInput = document.getElementById('typeSearchInput');
        if (typeSearchInput) {
            typeSearchInput.value = '';
            typeSearchInput.placeholder = "Filter by issue types";
        }

        this.updateTypeUI();
        this.filterIssueTypes('');
        this.filterIssueStatus('');

        document.querySelectorAll('.status-opt').forEach(opt => {
            const optText = opt.querySelector('span')?.innerText || opt.innerText;
            const isAll = optText.trim() === 'All';
            opt.classList.toggle('active', isAll);
            opt.querySelector('.check-mark')?.classList.toggle('hidden', !isAll);
            opt.classList.remove('hidden');
        });

        this.refreshIssuesUI();
        this.selectedApplyTo = 'current';
        this.hideAllMenus();
    }
    // Inside VideoAnnotationApp class constructor or initialization area
    createIssue(x = null, y = null, commentText = null) {
        const applyTo = commentText ? 'canvas' : this.selectedApplyTo;
        const comment = commentText || document.getElementById('issueComment').value.trim();
        const currentFrame = this.videoController.getCurrentFrame();

        if (!comment) return;

        const newIssue = {
            id: Date.now(),
            type: applyTo, // 'entire', 'current', or 'canvas'
            frame: applyTo === 'current' || applyTo === 'canvas' ? currentFrame : null,
            text: comment,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            resolved: false,
            comments: [], // New: support for replies
            userName: 'L', // Mock user initial
            tags: this.selectedNewIssueTag ? [this.selectedNewIssueTag] : [], // Save selected tag
            x: x !== null ? x : 5, // Default to top-left if via sidebar
            y: y !== null ? y : 5  // Default to top-left if via sidebar
        };

        this.issues.push(newIssue);
        this.hideAllMenus();
        this.activeIssueId = newIssue.id;
        this.toggleIssueForm(false); // Close form
        this.refreshIssuesUI();

        // Clear selected state and hide menus
        this.selectedNewIssueTag = 'high';
        this.selectedApplyTo = 'current';
        this.pendingCanvasComment = ''; // Reset pending text

        // If it was a pinning operation, deactivate it
        if (this.isPinningIssue) {
            this.togglePinIssueMode(false);
        }
    }

    refreshIssuesUI() {
        this.renderIssueCards();
        this.updateIssueBadges();
        this.renderVideoIssueOverlay();
    }

    updateIssueBadges() {
        // activeCount is for the header badge (always unresolved count)
        const activeIssues = this.issues.filter(i => !i.resolved);
        const activeCount = activeIssues.length;

        // shownCount is for the sidebar (respects filters)
        const shownIssues = this.issues.filter(issue => {
            const statusMatch = this.issueFilterState.status === 'All' ||
                (this.issueFilterState.status === 'Resolved' && issue.resolved) ||
                (this.issueFilterState.status === 'Unresolved' && !issue.resolved);
            const typeMatch = this.selectedIssueTypes.length === 0 || this.selectedIssueTypes.includes(issue.type);
            return statusMatch && typeMatch;
        });
        const shownCount = shownIssues.length;

        // Update Header Badge
        const headerBadge = document.getElementById('issueHeaderBadge');
        if (headerBadge) {
            headerBadge.innerText = activeCount;
            headerBadge.classList.toggle('hidden', activeCount === 0);
        }

        // Update Sidebar Text
        const sidebarCountSpan = document.getElementById('sidebarIssueCount');
        if (sidebarCountSpan) {
            sidebarCountSpan.innerText = `${shownCount} shown`;
        }

        // Toggle Filter Row Visibility
        const filterRow = document.getElementById('headerFilterRow');
        if (filterRow) {
            filterRow.classList.toggle('hidden', this.issues.length === 0);
        }
    }


    renderIssueCards() {
        const container = document.getElementById('issueCardsContainer');
        const listWrapper = document.getElementById('issuesList');
        const emptyState = document.getElementById('issuesEmptyState');

        if (this.issues.length === 0) {
            listWrapper.classList.add('hidden');
            emptyState.classList.remove('hidden');
            return;
        }

        const filtered = this.issues.filter(issue => {
            const statusMatch = this.issueFilterState.status === 'All' ||
                (this.issueFilterState.status === 'Resolved' && issue.resolved) ||
                (this.issueFilterState.status === 'Unresolved' && !issue.resolved);

            // Map UI filter labels to internal issue.type values
            const typeMap = {
                'Pinned': 'canvas',
                'Frame': 'current',
                'File': 'entire'
            };

            const typeMatch = this.selectedIssueTypes.length === 0 ||
                this.selectedIssueTypes.some(uiType => issue.type === typeMap[uiType]);

            return statusMatch && typeMatch;
        });

        if (filtered.length === 0) {
            container.innerHTML = `
                <div class="flex flex-col items-center justify-center py-12 px-4 select-none animate-in fade-in duration-500">
                    <div class="mb-4">
                        <svg width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg">
                <title>Simple Empty</title>
                <g transform="translate(0 1)" fill="none" fill-rule="evenodd">
                    <ellipse fill="#f5f5f5" cx="32" cy="33" rx="32" ry="7"></ellipse>
                    <g fill-rule="nonzero" stroke="#d9d9d9">
                        <path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path>
                        <path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" fill="#fafafa"></path>
                    </g>
                </g>
            </svg>
                    </div>
                    <div class="text-[#bfbfbf] text-[14px] opacity-70">No issues match the current filters</div>
                </div>
            `;
            emptyState.classList.add('hidden');
            listWrapper.classList.remove('hidden');
            return;
        }

        emptyState.classList.add('hidden');
        listWrapper.classList.remove('hidden');

        container.innerHTML = filtered.map((issue) => {
            // Find original index for "Issue 0X" label
            const originalIdx = this.issues.indexOf(issue);
            const isActive = issue.id === this.activeIssueId;
            const borderClass = isActive ? 'border-[#5f45ff]' : 'border-[#f0f0f0]';

            return `
    <div onclick="window.app.handleIssueCardClick(event, ${issue.id})" class="bg-white border ${borderClass} rounded-lg p-0 relative group/card mb-3 overflow-hidden cursor-pointer transition-colors">
        <!-- Header Row -->
        <div class="flex items-center justify-between px-3 py-3 pb-2">
            <div class="flex items-center gap-2">
                <span class="text-[14px] font-[580] text-gray-800">Issue 0${originalIdx + 1}</span>
                ${(issue.tags || []).map(tagId => {
                const tag = CONFIG.ISSUE_TAGS.find(t => t.id === tagId);
                if (!tag) return '';
                return `<span class="issue-tag-pill ml-2" style="background-color: ${tag.bgColor}; color: ${tag.color}; border-color: ${tag.borderColor}; font-weight: ${tag.fontWeight}">${tag.name}</span>`;
            }).join('')}
            ${issue.type === 'canvas' ? `
                <span class="bg-[#e6fffb] border border-[#87e8de] flex items-center gap-1 text-[#13c2c2] px-2 py-0.5 rounded text-[11.5px] font-[580] mr-2">
                    ${PIN_SVG}
                    Pinned
                </span>
            ` : `
                <span class="bg-[#e6fffb] border border-[#87e8de] flex items-center gap-1 text-[#13c2c2] px-1.5 rounded text-[11.5px] font-[580] mr-2">
                    ${FRAME_CANVAS_POPUP}
                    Frame
                </span>
            `}
            </div>
            <div class="flex items-center gap-1">
                ${issue.resolved ? `
                <button type="button" onclick="window.app.reopenIssue(${issue.id})" class="px-2.5 py-0.5 rounded-md border bg-[#ffffff] border-[#d9d9d9] text-[13.5px] font-[490] text-gray-800 hover:border-[#5f45ff] hover:text-[#5f45ff] transition-colors cursor-pointer">Reopen</button>
                ` : `
                <button type="button" onclick="window.app.resolveIssue(${issue.id})" data-tooltip="Resolve thread"
                            data-tooltip-pos="top" class="w-6 h-6 flex items-center justify-center rounded-full border border-[#d9d9d9] bg-[#ffffff] text-gray-20 hover:bg-gray-50">
                    <svg viewBox="64 64 896 896" focusable="false" data-icon="check" width="14" height="14" fill="currentColor" aria-hidden="true" class="cursor-pointer"><path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path></svg>
                </button>
                `}
                <button type="button" onclick="window.app.toggleIssueMenu(event, ${issue.id})" class="w-6 h-6 flex items-center justify-center text-gray-20 hover:text-black more-vert-btn cursor-pointer">
                    ${MORE_VERT_ICON_SVG}
                </button>
            </div>
        </div>

        <hr class="border-gray-100 mx-3">

        <!-- Body Content -->
        <div class="px-3 pt-3 pb-4">
            ${issue.frame !== null ? `
                <div class="flex items-center gap-2 text-[13px] text-gray-400 mb-3">
                    Frame <span class="bg-[#f0f0f0] px-1 rounded text-gray-800 font-medium">${issue.frame}</span>
                </div>
            ` : ''}

            <div class="space-y-4 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
                ${this._renderActivityLog(issue, 'sidebar')}
            </div>

            <div class="mt-4 flex items-center gap-2">
                <div onclick="event.stopPropagation()" class="flex-1 flex items-center bg-white border border-gray-200 rounded-md px-2 py-0.5 focus-within:border-[#5f45ff] transition-all">
                    <input type="text" id="sidebarReply-${issue.id}" oninput="window.app.handleReplyInput('sidebarReply-${issue.id}', 'sidebarReplyBtn-${issue.id}')" placeholder="Leave a reply..." class="bg-transparent border-none outline-none text-[13px] w-full placeholder:text-[#d9d9d9] select-text cursor-text">
                </div>
                <button type="button" id="sidebarReplyBtn-${issue.id}" onclick="event.stopPropagation(); window.app.addComment(${issue.id}, 'sidebarReply-${issue.id}')" class="w-6 h-6 rounded-full border border-gray-200 flex items-center justify-center bg-white text-gray-300 transition-colors">
                    <span class="material-icons-outlined !text-[15px] cursor-pointer">north</span>
                </button>
            </div>
        </div>
        
        <!-- Context Menu Hidden -->
        <div id="issueMenu-${issue.id}" class="hidden absolute right-2 top-10 z-50 bg-white border border-gray-100 shadow-xl rounded-lg py-1 min-w-[130px] w-max">
             <div onclick="window.app.deleteIssue(${issue.id})" class="flex items-center gap-2 px-3 py-1.5 text-[12px] font-medium text-red-500 hover:bg-[#f64d62] hover:text-white cursor-pointer mx-1 rounded-md transition-colors group/delete">
                <svg viewBox="64 64 896 896" focusable="false" data-icon="delete" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72zm504 72H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z"></path></svg>
                <div class="whitespace-nowrap">Delete thread</div>
            </div>
        </div>
    </div>
`;
        }).join('');
    }

    _getIssueIconSvg(issue) {

        return issue.resolved ? ISSUE_RESOLVED_SVG : ISSUE_UNRESOLVED_SVG;
    }

    renderVideoIssueOverlay() {
        const overlay = document.getElementById('videoIssueOverlay');
        const video = document.getElementById('mainVideo');
        const currentFrame = this.videoController.getCurrentFrame();

        overlay.innerHTML = '';
        if (!video) return;

        // Group issues by location
        const groups = {};
        this.issues.forEach(issue => {
            const statusMatch = this.issueFilterState.status === 'All' ||
                (this.issueFilterState.status === 'Resolved' && issue.resolved) ||
                (this.issueFilterState.status === 'Unresolved' && !issue.resolved);
            const typeMatch = this.selectedIssueTypes.length === 0 ||
                this.selectedIssueTypes.includes(issue.type);

            if (!statusMatch || !typeMatch) return;

            const isVisibleOnFrame = (issue.type === 'entire') ||
                ((issue.type === 'current' || issue.type === 'canvas') && issue.frame === currentFrame);

            if (isVisibleOnFrame) {
                const x = issue.x ?? 5;
                const y = issue.y ?? 5;
                const key = `${Math.round(x)}-${Math.round(y)}`;
                if (!groups[key]) groups[key] = [];
                groups[key].push(issue);
            }
        });

        // Loop through each group
        // Loop through each group
        Object.values(groups).forEach(issueGroup => {
            const firstIssue = issueGroup[0];
            const isSidebar = firstIssue.type !== 'canvas';

            const iconWrapper = document.createElement('div');
            iconWrapper.className = 'issue-icon-wrapper absolute pointer-events-none z-[101]';
            iconWrapper.dataset.issueIds = issueGroup.map(i => i.id).join(',');

            if (isSidebar) {
                // Sidebar issues are at a fixed position
                iconWrapper.style.left = '-12px';
                iconWrapper.style.top = '-13px';
            } else {
                // Canvas pins are at percentages
                iconWrapper.style.left = `${firstIssue.x ?? 5}%`;
                iconWrapper.style.top = `${firstIssue.y ?? 5}%`;
            }

            const container = document.createElement('div');
            container.className = 'absolute pointer-events-auto cursor-pointer transition-transform hover:scale-110 flex items-center group';

            // Only translate(-50%, -50%) for pinned canvas issues to center them on the point
            // Sidebar issues are anchored at top-left
            if (!isSidebar && (firstIssue.x ?? 5) !== null) {
                container.style.transform = 'translate(-50%, -50%)';
            }

            // Split group by subtype for different styling
            const sidebarIssues = issueGroup.filter(i => i.type !== 'canvas');
            const canvasIssues = issueGroup.filter(i => i.type === 'canvas');

            // 1. Sidebar group in a white box (User removed shadow-md)
            if (sidebarIssues.length > 0) {
                const box = document.createElement('div');
                box.className = 'bg-white rounded-lg p-1 flex items-center gap-1';
                sidebarIssues.forEach(sIssue => {
                    const icon = document.createElement('div');
                    icon.className = 'flex items-center justify-center';
                    icon.innerHTML = this._getIssueIconSvg(sIssue, false); // No internal fill for boxed icons
                    icon.onclick = (e) => {
                        e.stopPropagation();
                        // If mousedown already closed this popup this tick, don't reopen
                        const justClosed = this._lastClosedIssueId === sIssue.id &&
                            (Date.now() - (this._lastClosedAt || 0)) < 150;
                        if (justClosed) return;
                        const existing = document.querySelector(`[data-issue-id="${sIssue.id}"][data-popup-type="canvasIssue"]`);
                        if (existing) {
                            this.hideCanvasIssuePopup();
                        } else {
                            this.showCanvasIssuePopup(sIssue, iconWrapper);
                        }
                    };
                    box.appendChild(icon);
                });
                container.appendChild(box);
            }

            // 2. Canvas issues as individual pins (internal white fill)
            canvasIssues.forEach(cIssue => {
                const icon = document.createElement('div');
                icon.className = 'flex items-center justify-center';
                icon.innerHTML = this._getIssueIconSvg(cIssue, true); // Internal fill for pins
                icon.onclick = (e) => {
                    e.stopPropagation();
                    // If mousedown already closed this popup this tick, don't reopen
                    const justClosed = this._lastClosedIssueId === cIssue.id &&
                        (Date.now() - (this._lastClosedAt || 0)) < 150;
                    if (justClosed) return;
                    const existing = document.querySelector(`[data-issue-id="${cIssue.id}"][data-popup-type="canvasIssue"]`);
                    if (existing) {
                        this.hideCanvasIssuePopup();
                    } else {
                        this.showCanvasIssuePopup(cIssue, iconWrapper);
                    }
                };
                container.appendChild(icon);
            });

            iconWrapper.appendChild(container);
            overlay.appendChild(iconWrapper);
        });

        // After rebuilding all icon wrappers, re-attach the active canvas popup
        // to the new anchor element so it survives the re-render.
        if (this.activeIssueId !== null) {
            const activeIssue = this.issues.find(i => i.id === this.activeIssueId);
            if (activeIssue) {
                // Use a microtask so the new DOM nodes are fully in place
                setTimeout(() => {
                    const existingPopup = document.querySelector(`[data-issue-id="${this.activeIssueId}"][data-popup-type="canvasIssue"]`);
                    if (!existingPopup) {
                        // Popup was destroyed by re-render (seekToFrame timeupdate), re-show it
                        const anchor = this._findIssueAnchor(this.activeIssueId);
                        if (anchor) this.showCanvasIssuePopup(activeIssue, anchor);
                    }
                }, 0);
            }
        }

        // Apply initial scaling based on current zoom
        this.updateIssueIconsScaling(this.transformManager.zoom);
    }

    updateIssueIconsScaling(zoom) {
        const scale = 1 / zoom;
        document.querySelectorAll('.issue-icon-wrapper').forEach(wrapper => {
            wrapper.style.transform = `scale(${scale})`;
            wrapper.style.transformOrigin = 'center center';
        });
    }

    togglePinIssueMode(force = null) {
        this.isPinningIssue = (force !== null) ? force : !this.isPinningIssue;
        const mainArea = document.querySelector('main');

        if (this.isPinningIssue) {
            mainArea.classList.add('pinning-mode');
            // Ensure no other menu is interfering
            this.hideAllMenus();
            // Optional: Close annotation panel if open
            if (this.annotationModel.active) closeAnnotationPanel();
        } else {
            mainArea.classList.remove('pinning-mode');
            // Remove any pending comment pill
            const pill = document.getElementById('canvasCommentPill');
            if (pill) pill.remove();
            this.pendingCanvasComment = ''; // Reset on exit
            this.selectedNewIssueTag = 'high'; // Reset tag to default
        }
    }

    handleVideoClick(e) {
        if (!this.isPinningIssue) return;

        const wrapper = document.getElementById('videoTransformWrapper');
        const rect = wrapper.getBoundingClientRect();

        // Calculate click position as percentage of the transformed wrapper
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;

        this.showCanvasCommentInput(x, y, e.clientX, e.clientY);
    }

    showCanvasCommentInput(xPercent, yPercent, clientX, clientY) {
        // Remove existing pill if any
        const existing = document.getElementById('canvasCommentPill');
        if (existing) existing.remove();

        const pill = document.createElement('div');
        pill.id = 'canvasCommentPill';
        pill.className = 'canvas-comment-pill fixed z-[200]';

        const isFlipped = xPercent > 50;
        if (isFlipped) {
            pill.classList.add('is-flipped');
        }

        // Position slightly offset from click for better visibility
        pill.style.left = `${clientX}px`;
        pill.style.top = `${clientY}px`;

        // Normal: translate(-20px, -50%) -> icon is at cursor, pill extends right
        // Flipped: translate(calc(-100% + 20px), -50%) -> icon is at cursor, pill extends left
        pill.style.transform = isFlipped ? 'translate(calc(-100% + 20px), -50%)' : 'translate(-20px, -50%)';

        pill.innerHTML = `
            <div class="outer-icon">
                ${OUTSIDE_OF_PIN_ICON}
            </div>
            <div class="pill-inner relative">
                <input type="text" placeholder="Add comment" id="canvasCommentInput" autocomplete="off" value="${this.pendingCanvasComment}">
                <div class="icon-btn" onclick="window.app.toggleCanvasTagPopover(event)">
                    ${INSIDE_PIN_TAG_SVG}
                </div>
                <div id="submitCanvasIssueBtn" class="icon-btn submit-btn ${this.pendingCanvasComment ? '' : 'disabled'}">
                    <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                        <line x1="12" y1="19" x2="12" y2="5"></line>
                        <polyline points="5 12 12 5 19 12"></polyline>
                    </svg>
                </div>
                <!-- Tag Popover -->
                <div id="canvasTagPopover" class="canvas-tag-popover hidden"></div>
            </div>
        `;

        document.body.appendChild(pill);

        const input = document.getElementById('canvasCommentInput');
        const submitBtn = document.getElementById('submitCanvasIssueBtn');

        input.focus();

        input.oninput = () => {
            this.pendingCanvasComment = input.value;
            const hasText = input.value.trim().length > 0;
            submitBtn.classList.toggle('disabled', !hasText);
        };

        input.onkeydown = (e) => {
            if (e.key === 'Enter' && input.value.trim()) {
                this.createIssue(xPercent, yPercent, input.value.trim());
                pill.remove();
            }
            if (e.key === 'Escape') {
                pill.remove();
                this.togglePinIssueMode(false);
            }
        };

        submitBtn.onclick = () => {
            if (!submitBtn.classList.contains('disabled')) {
                this.createIssue(xPercent, yPercent, input.value.trim());
                pill.remove();
            }
        };

        // Initialize popover content
        this.renderCanvasTagPopover();
    }

    toggleCanvasTagPopover(event) {
        if (event) event.stopPropagation();
        const popover = document.getElementById('canvasTagPopover');
        const wasVisible = !popover.classList.contains('hidden') && popover.style.display !== 'none';

        // Hide other menus but NOT the pill itself
        this.hideAllMenus();

        if (!wasVisible) {
            popover.classList.remove('hidden');
            popover.style.display = 'flex';
            this.tagPopoverSearchActive = false; // Always start with placeholder state
            this.renderCanvasTagPopover();
        }
    }

    renderCanvasTagPopover(filterQuery = '') {
        const popover = document.getElementById('canvasTagPopover');
        if (!popover) return;

        // STATE 1: Default Dropdown appearance
        const currentTag = CONFIG.ISSUE_TAGS.find(t => t.id === this.selectedNewIssueTag);
        const label = currentTag ? currentTag.name : "Select issue tags";

        popover.innerHTML = `
            <div class="tag-placeholder-box" onclick="window.app.activateTagSearch(event)">
                <span class="placeholder-text ${!currentTag ? 'text-gray-400' : 'text-gray-800'}">${label}</span>
                <svg viewBox="64 64 896 896" focusable="false" data-icon="down" width="12" height="12" fill="currentColor" aria-hidden="true" class="arrowColor"><path d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg>
            </div>
        `;

        // If we were already in search mode, append the search list
        if (this.tagPopoverSearchActive) {
            // STATE 1: Placeholder/Dropdown appearance (Matching Image 2)
            popover.innerHTML = `
                <div class="tag-placeholder-box" onclick="window.app.activateTagSearch(event)">
                    <span class="placeholder-text">Select issue tags</span>
                    <svg viewBox="64 64 896 896" focusable="false" data-icon="down" width="12" height="12" fill="currentColor" aria-hidden="true" class="arrowColor"><path d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg>
                </div>
            `;
            return;
        }

        // STATE 2: Search mode (Matching Image 2)
        const term = filterQuery.toLowerCase().trim();
        const filteredTags = CONFIG.ISSUE_TAGS.filter(tag =>
            tag.name.toLowerCase().includes(term)
        );

        let html = `
            <div class="canvas-tag-search-container">
                <span class="material-icons-outlined !text-[18px] text-gray-400">search</span>
                <input type="text" id="canvasTagSearchInput" placeholder="Search tags..." 
                    oninput="window.app.handleCanvasTagSearch(event)" 
                    autocomplete="off"
                    value="${filterQuery}">
            </div>
            <div class="tag-options-list">
        `;

        if (filteredTags.length > 0) {
            html += filteredTags.map(tag => {
                const isSelected = this.selectedNewIssueTag === tag.id;
                return `
                    <div class="tag-option ${isSelected ? 'selected' : ''}" onclick="window.app.setCanvasTag(event, '${tag.id}')">
                        <span class="text-[13.5px]">${tag.name}</span>
                    </div>
                `;
            }).join('');
        } else {
            html += `<div class="none-found">None found</div>`;
        }

        html += `</div>`;
        popover.innerHTML = html;

        // Auto-focus the input
        const input = document.getElementById('canvasTagSearchInput');
        if (input) {
            input.focus();
            if (filterQuery) {
                input.setSelectionRange(input.value.length, input.value.length);
            }
        }
    }

    activateTagSearch(event) {
        if (event) event.stopPropagation();
        this.tagPopoverSearchActive = true;
        this.renderCanvasTagPopover();
    }

    handleCanvasTagSearch(event) {
        event.stopPropagation();
        const query = event.target.value;
        this.renderCanvasTagPopover(query);
    }

    setCanvasTag(event, tagId) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }

        this.selectedNewIssueTag = tagId;

        // Update the visual text in the placeholder box before closing
        const tag = CONFIG.ISSUE_TAGS.find(t => t.id === tagId);
        const placeholderText = document.querySelector('.tag-placeholder-box .placeholder-text');
        if (placeholderText && tag) {
            placeholderText.innerText = tag.name;
            placeholderText.classList.remove('text-gray-400');
            placeholderText.classList.add('text-gray-800');
        }

        // Close the menu
        this.tagPopoverSearchActive = false;
        const popover = document.getElementById('canvasTagPopover');
        if (popover) {
            popover.classList.add('hidden');
            popover.style.display = 'none';
        }
    }

    handleIssueCardClick(event, issueId) {
        if (event) event.stopPropagation();

        // 1. If the same card is already active and its popup is visible, do nothing.
        if (issueId === this.activeIssueId) {
            const existingPopup = document.querySelector(`[data-issue-id="${issueId}"][data-popup-type="canvasIssue"]`);
            if (existingPopup) return; // Popup already open for this card — don't toggle it off
        }

        // 2. Find the issue object
        const issue = this.issues.find(i => i.id === issueId);
        if (!issue) return;

        // 3. Update active state
        const previousId = this.activeIssueId;
        this.activeIssueId = issueId;

        // 4. Update sidebar card borders directly without a full re-render.
        //    This avoids destroying and re-creating the canvas overlay (which caused
        //    double-click issues when switching cards).
        if (previousId !== null && previousId !== issueId) {
            // Remove highlight from previously active card
            const prevCards = document.querySelectorAll('#issueCardsContainer > div');
            prevCards.forEach(card => {
                card.classList.remove('border-[#5f45ff]');
                card.classList.add('border-[#f0f0f0]');
            });
        }
        // Highlight the newly active card
        const allCards = document.querySelectorAll('#issueCardsContainer > div');
        allCards.forEach(card => {
            // Each card has onclick="window.app.handleIssueCardClick(event, <id>)"
            // We detect the active card by checking its onclick attribute
            const onclickAttr = card.getAttribute('onclick') || '';
            if (onclickAttr.includes(String(issueId))) {
                card.classList.add('border-[#5f45ff]');
                card.classList.remove('border-[#f0f0f0]');
            }
        });

        // 5. Remove any open canvas popup for a DIFFERENT issue
        const otherPopup = document.querySelector('[data-popup-type="canvasIssue"]');
        if (otherPopup && otherPopup.dataset.issueId !== String(issueId)) {
            otherPopup.remove();
        }

        // 6. If issue has a frame, jump to it
        if (issue.frame !== null) {
            this.videoController.seekToFrame(issue.frame);
        }

        // 7. Find the anchor on the canvas overlay and open the popup.
        //    Small delay ensures seekToFrame overlay update has settled.
        setTimeout(() => {
            const wrappers = document.querySelectorAll('.issue-icon-wrapper');
            let anchor = null;
            for (const w of wrappers) {
                if (w.dataset.issueIds && w.dataset.issueIds.split(',').includes(issueId.toString())) {
                    anchor = w;
                    break;
                }
            }
            if (anchor) {
                this.showCanvasIssuePopup(issue, anchor);
            }
        }, 50);
    }

    showCanvasIssuePopup(issue, anchorElement) {
        const popupId = `canvasIssuePopup-${issue.id}`;

        // If a popup for THIS exact issue is already visible, don't re-create it.
        // (Prevents re-click toggle behaviour — same-card re-click is a no-op.)
        const existing = document.querySelector(`[data-issue-id="${issue.id}"][data-popup-type="canvasIssue"]`);
        if (existing) return;

        // Remove any open canvas popup for a DIFFERENT issue (only one at a time)
        const otherPopup = document.querySelector('[data-popup-type="canvasIssue"]');
        if (otherPopup) otherPopup.remove();

        const popup = document.createElement('div');
        popup.id = popupId;
        popup.dataset.issueId = issue.id;
        popup.dataset.popupType = 'canvasIssue';

        popup.onmousedown = (e) => e.stopPropagation();
        popup.onclick = (e) => e.stopPropagation();

        // Absolute position inside anchor, high z-index to stay above everything
        popup.className = 'absolute z-[9999] bg-white border border-gray-100 rounded-md p-3 w-[380px] pointer-events-auto';
        popup.style.top = '50px';
        popup.style.left = '20px';

        const originalIdx = this.issues.indexOf(issue);
        const issueNum = (originalIdx + 1);

        popup.innerHTML = `
        <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
                <span class="text-[13.5px] font-[600] text-gray-20">Issue ${issueNum < 10 ? '0' + issueNum : issueNum}</span>
                ${(issue.tags || []).map(tagId => {
            const tag = CONFIG.ISSUE_TAGS.find(t => t.id === tagId);
            if (!tag) return '';
            return `<span class="issue-tag-pill ml-1" style="background-color: ${tag.bgColor}; color: ${tag.color}; border-color: ${tag.borderColor}; font-weight: ${tag.fontWeight}">${tag.name}</span>`;
        }).join('')}
                <span class="bg-[#e6fffb] text-[#08979c] border border-[#87e8de] flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-[580]">
                    ${issue.type === 'canvas' ? PIN_SVG + ' Pinned' : FRAME_CANVAS_POPUP + ' Frame'}
                </span>
            </div>
            <div class="flex items-center gap-3">
                ${issue.resolved ?
                `<button type="button" onclick="window.app.reopenIssue(${issue.id})" data-tooltip="Reopen thread" data-tooltip-pos="top" class="px-2.5 py-0.5 rounded-md border bg-[#ffffff] border-[#d9d9d9] text-[13.5px] font-[490] text-gray-800 hover:border-[#5f45ff] hover:text-[#5f45ff] transition-colors cursor-pointer ">Reopen</button>` :
                `<div onclick="window.app.resolveIssue(${issue.id})" data-tooltip="Resolve thread" data-tooltip-pos="top" class="w-6 h-6 rounded-full bg-[#ffffff] border border-[#d9d9d9] flex items-center justify-center text-gray-20 hover:border-[#5f45ff] hover:text-[#5f45ff] cursor-pointer transition-colors">${CHECK_SVG}</div>`
            }
                <div class="relative">
                    <div class="text-gray-20 hover:text-black cursor-pointer more-vert-btn cursor-pointer" onclick="window.app.toggleIssueMenu(event, 'canvas-${issue.id}')">
                        ${MORE_VERT_ICON_SVG}
                    </div>
                    <div id="issueMenu-canvas-${issue.id}" class="hidden absolute top-[20px] z-[10000] bg-white border border-gray-100 shadow-xl rounded-lg py-1 min-w-[130px] w-max">
                        <div onclick="window.app.deleteIssue(${issue.id})" class="flex items-center gap-2 px-3 py-1.5 text-[12px] font-medium text-red-500 hover:bg-[#f64d62] hover:text-white cursor-pointer mx-1 rounded-md transition-colors">
                            ${DELETE_THREAD_SVG}
                            <div class="whitespace-nowrap">Delete thread</div>
                        </div>
                    </div>
                </div>
                <div class="text-gray-20 hover:text-black cursor-pointer" onclick="window.app.hideCanvasIssuePopup()">
                    ${CLOSE_X_SVG}
                </div>
            </div>
        </div>
        <hr class="border-gray-100 mb-2">

        <div class="flex items-center gap-2 text-[13px] text-gray-400 mb-5">
            Frame <span class="bg-gray-100 px-2 py-0.5 rounded text-gray-800 font-medium">${issue.frame || 0}</span>
        </div>

        <div class="space-y-5 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar mb-5">
            ${this._renderActivityLog(issue, 'canvas')}
        </div>

        <div class="flex items-center gap-2 pt-1">
            <div class="flex-1 bg-white border border-[#d9d9d9] rounded-md px-2 focus-within:border-[#5f45ff] transition-all">
                <input type="text" id="canvasReply-${issue.id}" 
                    oninput="window.app.handleReplyInput('canvasReply-${issue.id}', 'canvasReplyBtn-${issue.id}')" 
                    placeholder="Leave a reply..." 
                    class="bg-transparent border-none outline-none text-[13.5px] w-full placeholder:text-gray-300">
            </div>
            <button type="button" id="canvasReplyBtn-${issue.id}" 
                onclick="window.app.addComment(${issue.id}, 'canvasReply-${issue.id}')" 
                class="w-6 h-6 rounded-full bg-[#0000000a] border border-[#d9d9d9] flex items-center justify-center text-[#00000040] transition-all hover:bg-gray-100 cursor-pointer">
                ${ARROW_UP_SVG}
            </button>
        </div>
    `;

        // Append to the iconWrapper anchor for consistent positioning
        const targetAnchor = anchorElement || this._findIssueAnchor(issue.id);
        if (targetAnchor) {
            targetAnchor.appendChild(popup);
        }
    }

    hideCanvasIssuePopup() {
        const popup = document.querySelector('[data-popup-type="canvasIssue"]');
        if (popup) {
            // Record which issue was just closed (and when) so icon toggle
            // can detect the mousedown-then-onclick race and skip re-opening
            this._lastClosedIssueId = parseInt(popup.dataset.issueId);
            this._lastClosedAt = Date.now();
            popup.remove();
        }

        // Also reset activeIssueId and refresh UI to reset sidebar border
        if (this.activeIssueId !== null) {
            this.activeIssueId = null;
            this.refreshIssuesUI();
        }
    }

    // Helper: find the .issue-icon-wrapper element for a given issueId
    _findIssueAnchor(issueId) {
        return document.querySelector(`.issue-icon-wrapper[data-issue-ids*="${issueId}"]`);
    }

    // Support functions
    resolveIssue(id) {
        const issue = this.issues.find(i => i.id === id);
        if (!issue || issue.resolved) return;

        // Hide any lingering tooltip (the global .custom-tooltip element)
        const tooltip = document.querySelector('.custom-tooltip');
        if (tooltip) {
            tooltip.classList.remove('visible');
        }

        issue.resolved = true;
        issue.resolvedTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        // Add "Resolved this issue" activity entry
        if (!issue.comments) issue.comments = [];
        issue.comments.push({
            id: Date.now(),
            type: 'resolved',
            text: '',
            time: '< 1m',
            userName: 'L'
        });

        // Check if canvas popup is open before refresh
        const popupEl = document.querySelector('[data-popup-type="canvasIssue"]');

        this.refreshIssuesUI();

        // Re-show canvas popup if it was open
        if (popupEl) {
            this.showCanvasIssuePopup(issue, this._findIssueAnchor(issue.id));
        }
    }

    reopenIssue(id) {
        const issue = this.issues.find(i => i.id === id);
        if (!issue || !issue.resolved) return;

        issue.resolved = false;
        issue.resolvedTime = null;

        // Add "Reopened this issue" activity entry
        if (!issue.comments) issue.comments = [];
        issue.comments.push({
            id: Date.now(),
            type: 'reopened',
            text: '',
            time: '< 1m',
            userName: 'L'
        });

        // Check if canvas popup is open before refresh
        const popupEl = document.querySelector('[data-popup-type="canvasIssue"]');

        this.refreshIssuesUI();

        // Re-show canvas popup if it was open
        if (popupEl) {
            this.showCanvasIssuePopup(issue, this._findIssueAnchor(issue.id));
        }
    }

    // Helper: Renders the full activity log for an issue with Show/Minimise collapsing
    _renderActivityLog(issue, context) {
        const allItems = [];

        // 1. Initial Open Entry
        allItems.push(`
            <div class="flex gap-2">
                <div class="w-6 h-6 rounded-full bg-[#1890ff] text-white flex items-center justify-center text-[12px] font-bold shrink-0">L</div>
                <div class="flex-1">
                    <div class="text-[13px] text-gray-800 leading-none">
                        <span class="font-[600]">Opened this issue</span>
                        <span class="text-gray-400 ml-1 text-[11.5px]">1h</span>
                    </div>
                    <div class="text-[13.5px] text-gray-700 mt-2">${issue.text}</div>
                </div>
            </div>
        `);

        // 2. Comments/Actions
        (issue.comments || []).forEach(comment => {
            const isAction = comment.type === 'resolved' || comment.type === 'reopened';
            allItems.push(`
                <div class="flex gap-3 relative group/comment">
                    <div class="w-6 h-6 rounded-full bg-[#1890ff] text-white flex items-center justify-center text-[12px] font-bold shrink-0">L</div>
                    <div class="flex-1">
                        <div class="text-[13.5px] text-gray-800 flex items-center justify-between leading-none">
                            <div>
                                <span class="font-[600]">${comment.type === 'resolved' ? 'Resolved this issue' : comment.type === 'reopened' ? 'Reopened this issue' : 'Commented'}</span>
                                <span class="text-gray-400 ml-1 text-[11.5px]">${comment.time || '< 1m'}</span>
                            </div>
                            ${!isAction ? `<div class="text-gray-400 hover:text-gray-600 cursor-pointer more-vert-btn" onclick="window.app.toggleCommentMenu(event, ${issue.id}, ${comment.id})">${MORE_VERT_ICON_SVG}</div>` : ''}
                        </div>
                        ${!isAction ? `<div class="text-[13.5px] text-gray-700 mt-2">${comment.text}</div>` : ''}
                    </div>
                </div>
            `);
        });

        // 3. If 2 or fewer items, just return flat list (no collapse needed)
        if (allItems.length <= 2) {
            return allItems.join('');
        }

        // 4. Collapsible: ensure hidden count is always EVEN
        const collapseId = `activity-${context}-${issue.id}`;
        const naturalOlder = allItems.length - 1; // everything except last
        // If naturalOlder is odd, show 2 items visible (to make hidden count even)
        const visibleCount = (naturalOlder % 2 !== 0) ? 2 : 1;
        const olderItems = allItems.slice(0, allItems.length - visibleCount);
        const visibleItems = allItems.slice(allItems.length - visibleCount);
        const olderCount = olderItems.length;

        return `
            <!-- Toggle button (collapsed state by default) -->
            <div id="${collapseId}-toggle">
                <div onclick="window.app.toggleActivityCollapse('${collapseId}')" class="flex items-center gap-1.5 cursor-pointer text-[#5f45ff] text-[12px] font-[400] mb-2 hover:opacity-80">
                    ${EXPAND_PLUS_SVG}
                    <span>Show ${olderCount} older activit${olderCount === 1 ? 'y' : 'ies'}</span>
                </div>
            </div>
            <!-- Older items (hidden by default) -->
            <div id="${collapseId}" class="hidden space-y-5">
                ${olderItems.join('')}
            </div>
            <!-- Visible items (always shown) -->
            ${visibleItems.join('')}
        `;
    }

    toggleActivityCollapse(collapseId) {
        const olderBlock = document.getElementById(collapseId);
        const toggle = document.getElementById(`${collapseId}-toggle`);
        if (!olderBlock || !toggle) return;

        const isCollapsed = olderBlock.classList.contains('hidden');

        if (isCollapsed) {
            // Expand: show older items, switch to "Minimise"
            olderBlock.classList.remove('hidden');
            const count = olderBlock.querySelectorAll(':scope > div.flex').length;
            toggle.innerHTML = `
                <div onclick="window.app.toggleActivityCollapse('${collapseId}')" class="flex items-center gap-1.5 cursor-pointer text-[#5f45ff] text-[12px] font-[400] mb-2 hover:opacity-80">
                    ${EXPAND_MINUS_SVG}
                    <span>Minimise</span>
                </div>
            `;
        } else {
            // Collapse: hide older items, switch to "Show N older activities"
            olderBlock.classList.add('hidden');
            const count = olderBlock.querySelectorAll(':scope > div.flex').length;
            toggle.innerHTML = `
                <div onclick="window.app.toggleActivityCollapse('${collapseId}')" class="flex items-center gap-1.5 cursor-pointer text-[#5f45ff] text-[12px] font-[400] mb-2 hover:opacity-80">
                    ${EXPAND_PLUS_SVG}
                    <span>Show ${count} older activit${count === 1 ? 'y' : 'ies'}</span>
                </div>
            `;
        }
    }

    deleteIssue(id) {
        this.issues = this.issues.filter(i => i.id !== id);
        this.refreshIssuesUI();
    }
    toggleIssueMenu(event, id) {
        event.stopPropagation();
        const menu = document.getElementById(`issueMenu-${id}`);
        if (!menu) return;

        // 1. Check if it's already visible before hiding everything
        const isCurrentlyVisible = !menu.classList.contains('hidden') && menu.style.display !== 'none';

        // 2. Close all first
        this.hideAllMenus();

        // 3. If it was NOT visible, show it now.
        // If it WAS visible, it remains hidden (toggled off).
        if (!isCurrentlyVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'block';
        }
    }

    addComment(issueId, inputId) {
        const input = document.getElementById(inputId);
        const text = input.value.trim();
        if (!text) return;

        const issue = this.issues.find(i => i.id === issueId);
        if (!issue) return;

        const newComment = {
            id: Date.now(),
            text: text,
            time: '< 1m',
            userName: 'L'
        };

        if (!issue.comments) issue.comments = [];
        issue.comments.push(newComment);

        input.value = '';

        // Refresh sidebar cards and badges, but keep overlay intact
        this.renderIssueCards();
        this.updateIssueBadges();

        // Update popup content in-place (no re-render of overlay)
        this.refreshCanvasIssuePopup(issue);

        // Re-focus the input field so the user can continue typing if they want
        const nextInput = document.getElementById(inputId);
        if (nextInput) nextInput.focus();
    }

    handleReplyInput(inputId, btnId) {
        const input = document.getElementById(inputId);
        const btn = document.getElementById(btnId);
        if (!input || !btn) return;

        if (input.value.trim().length > 0) {
            btn.classList.add('!bg-[#5f45ff]', '!text-white', '!border-[#5f45ff]');
            btn.classList.remove('text-gray-300');
        } else {
            btn.classList.remove('!bg-[#5f45ff]', '!text-white', '!border-[#5f45ff]');
            btn.classList.add('text-gray-300');
        }
    }

    toggleCommentMenu(event, issueId, commentId) {
        if (event) event.stopPropagation();
        const menu = document.getElementById('sharedCommentMenu');
        if (!menu) return;

        const isVisible = !menu.classList.contains('hidden') && menu.style.display !== 'none';
        const isSameToggle = isVisible && this._activeCommentId === commentId && this._activeIssueId === issueId;

        this.hideAllMenus();

        if (!isSameToggle) {
            // Position the menu
            const rect = event.currentTarget.getBoundingClientRect();
            menu.style.top = `${rect.bottom + 5}px`;
            menu.style.left = `${rect.left - 100}px`;
            menu.style.right = 'auto';

            // Store context as class properties (not DOM dataset)
            this._activeIssueId = issueId;
            this._activeCommentId = commentId;

            menu.classList.remove('hidden');
            menu.style.display = 'block';

            // Attach fresh mousedown listener to the delete button
            // (replaces any prior listener to avoid duplicates)
            const oldBtn = document.getElementById('deleteCommentBtn');
            if (oldBtn) {
                const newBtn = oldBtn.cloneNode(true);
                oldBtn.parentNode.replaceChild(newBtn, oldBtn);
                newBtn.addEventListener('mousedown', (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    console.log('[deleteCommentBtn mousedown] issueId:', this._activeIssueId, 'commentId:', this._activeCommentId);
                    this.deleteCommentFromSharedMenu();
                });
            }
        }
    }

    deleteCommentFromSharedMenu() {
        const issueId = this._activeIssueId;
        const commentId = this._activeCommentId;

        console.log('[deleteCommentFromSharedMenu] issueId:', issueId, 'commentId:', commentId);
        console.log('[deleteCommentFromSharedMenu] issues count:', this.issues.length);

        // Clear stored context
        this._activeIssueId = null;
        this._activeCommentId = null;

        if (issueId != null && commentId != null) {
            this.deleteComment(issueId, commentId);
        } else {
            console.warn('[deleteCommentFromSharedMenu] issueId or commentId is null, aborting');
        }

        // Only hide the shared comment menu — do NOT call hideAllMenus() which closes the canvas popup
        const sharedMenu = document.getElementById('sharedCommentMenu');
        if (sharedMenu) {
            sharedMenu.classList.add('hidden');
            sharedMenu.style.display = 'none';
        }
    }

    deleteComment(issueId, commentId) {
        console.log('[deleteComment] looking for issue:', issueId, 'type:', typeof issueId);
        console.log('[deleteComment] all issue ids:', this.issues.map(i => ({ id: i.id, type: typeof i.id })));
        const issue = this.issues.find(i => i.id === issueId);
        if (!issue) {
            console.warn('[deleteComment] issue NOT FOUND for id:', issueId);
            return;
        }
        console.log('[deleteComment] found issue, comments before:', issue.comments.length);
        console.log('[deleteComment] comment ids:', issue.comments.map(c => ({ id: c.id, type: typeof c.id })));

        issue.comments = issue.comments.filter(c => c.id !== commentId);
        console.log('[deleteComment] comments after filter:', issue.comments.length);

        // Check if canvas popup is open BEFORE refreshIssuesUI destroys the overlay
        const popupEl = document.querySelector('[data-popup-type="canvasIssue"]');

        this.refreshIssuesUI();

        // Re-show the canvas popup after the overlay re-rendered (it was destroyed by renderVideoIssueOverlay)
        if (popupEl) {
            this.showCanvasIssuePopup(issue, this._findIssueAnchor(issue.id));
        }
    }


    // Refreshes only the inner content of the canvas popup without removing/repositioning it
    refreshCanvasIssuePopup(issue) {
        const popup = document.querySelector(`[data-issue-id="${issue.id}"][data-popup-type="canvasIssue"]`);
        if (!popup) return;

        const issueIdx = this.issues.findIndex(i => i.id === issue.id);
        const issueNum = (issueIdx + 1);

        // Re-render only the innerHTML — popup element stays in DOM at same position
        popup.innerHTML = `
        <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
                <span class="text-[13.5px] font-[600] text-gray-20">Issue ${issueNum < 10 ? '0' + issueNum : issueNum}</span>
                <span class="bg-[#e6fffb] text-[#08979c] border border-[#87e8de] flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-[580]">
                    ${issue.type === 'canvas' ? PIN_SVG + ' Pinned' : FRAME_CANVAS_POPUP + ' Frame'}
                </span>
            </div>
            <div class="flex items-center gap-3">
                ${issue.resolved ?
                `<button type="button" onclick="window.app.reopenIssue(${issue.id})" class="px-2.5 py-0.5 rounded-md border bg-[#ffffff] border-[#d9d9d9] text-[13.5px] font-[490] text-gray-800 hover:border-[#5f45ff] hover:text-[#5f45ff] transition-colors cursor-pointer">Reopen</button>` :
                `<div onclick="window.app.resolveIssue(${issue.id})" class="w-6 h-6 rounded-full border border-gray-200 flex items-center justify-center text-gray-20 hover:text-black hover:bg-gray-50 cursor-pointer transition-colors">${CHECK_SVG}</div>`
            }
                <div class="relative">
                    <div class="text-gray-20 hover:text-black cursor-pointer more-vert-btn" onclick="window.app.toggleIssueMenu(event, 'canvas-${issue.id}')">
                        ${MORE_VERT_ICON_SVG}
                    </div>
                    <div id="issueMenu-canvas-${issue.id}" class="hidden absolute top-[20px] z-[10000] bg-white border border-gray-100 shadow-xl rounded-lg py-1 min-w-[130px] w-max">
                        <div onclick="window.app.deleteIssue(${issue.id})" class="flex items-center gap-2 px-3 py-1.5 text-[12px] font-medium text-red-500 hover:bg-[#f64d62] hover:text-white cursor-pointer mx-1 rounded-md transition-colors">
                            ${DELETE_THREAD_SVG}
                            <div class="whitespace-nowrap">Delete thread</div>
                        </div>
                    </div>
                </div>
                <div class="text-gray-20 hover:text-black cursor-pointer" onclick="document.querySelector('[data-popup-type=canvasIssue]')?.remove()">
                    ${CLOSE_X_SVG}
                </div>
            </div>
        </div>

        <hr class="border-gray-100 mb-2">

        <div class="flex items-center gap-2 text-[13px] text-gray-400 mb-5">
            Frame <span class="bg-gray-100 px-2 py-0.5 rounded text-gray-800 font-medium">${issue.frame || 0}</span>
        </div>

        <div class="space-y-5 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar mb-5">
            ${this._renderActivityLog(issue, 'canvas')}
        </div>

        <div class="flex items-center gap-2 pt-1">
            <div class="flex-1 bg-white border border-[#d9d9d9] rounded-md px-2 focus-within:border-[#5f45ff] transition-all">
                <input type="text" id="canvasReply-${issue.id}" 
                    oninput="window.app.handleReplyInput('canvasReply-${issue.id}', 'canvasReplyBtn-${issue.id}')" 
                    placeholder="Leave a reply..." 
                    class="bg-transparent border-none outline-none text-[13.5px] w-full placeholder:text-gray-300">
            </div>
            <button type="button" id="canvasReplyBtn-${issue.id}" 
                onclick="window.app.addComment(${issue.id}, 'canvasReply-${issue.id}')" 
                class="w-6 h-6 rounded-full bg-[#0000000a] border border-[#d9d9d9] flex items-center justify-center text-[#00000040] transition-all hover:bg-gray-100 cursor-pointer">
                ${ARROW_UP_SVG}
            </button>
        </div>
    `;
    }

    toggleIssueTagDropdown(event) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        const menu = document.getElementById('issueTagDropdownMenu');
        const trigger = document.getElementById('issueTagTrigger');
        const isCurrentlyHidden = menu.classList.contains('hidden');

        this.hideAllMenus(); // Close other menus first

        if (isCurrentlyHidden) {
            menu.classList.remove('hidden');
            menu.style.display = 'block';
            trigger.classList.add('is-active'); // Add purple border
            this.renderIssueTagDropdown();
        }
    }

    renderIssueTagDropdown() {
        const menu = document.getElementById('issueTagDropdownMenu');
        menu.innerHTML = CONFIG.ISSUE_TAGS.map(tag => {
            const isSelected = this.selectedNewIssueTag === tag.id;
            return `
                <div class="tag-option ${isSelected ? 'selected' : ''}" onclick="window.app.toggleIssueTagSelection(event, '${tag.id}')">
                    <span class="text-[13.5px] ${isSelected ? 'text-[#5f45ff] font-medium' : 'text-gray-700'}">
                        ${tag.name}
                    </span>
                    ${isSelected ? '<span class="material-icons-outlined !text-[16px] text-[#5f45ff] font-bold">check</span>' : ''}
                </div>
            `;
        }).join('');
    }

    toggleIssueTagSelection(event, tagId) {
        if (event) event.stopPropagation();
        if (this.selectedNewIssueTag === tagId) {
            this.selectedNewIssueTag = null;
        } else {
            this.selectedNewIssueTag = tagId;
        }
        this.renderIssueTagSelector();
        this.renderIssueTagDropdown();

        // Close menu after selection
        document.getElementById('issueTagDropdownMenu').classList.add('hidden');
    }

    renderIssueTagSelector() {
        const container = document.getElementById('selectedTagsContainer');
        if (!this.selectedNewIssueTag) {
            container.innerHTML = '<span class="text-gray-300 text-[13px]">Select issue tags</span>';
            return;
        }

        const tag = CONFIG.ISSUE_TAGS.find(t => t.id === this.selectedNewIssueTag);
        container.innerHTML = `<span class="text-gray-800 text-[13px]">${tag.name}</span>`;
    }

    toggleIssueForm(show) {
        const emptyState = document.getElementById('issuesEmptyState');
        const form = document.getElementById('newIssueForm');
        const editBtn = document.getElementById('openIssueFormBtn');
        const commentInput = document.getElementById('issueComment');

        if (show) {
            emptyState.classList.add('hidden');
            form.classList.remove('hidden');
            // Disable the header button while editing
            editBtn.disabled = true;
            editBtn.classList.add('opacity-30', 'cursor-not-allowed');
            commentInput.focus();
            // Hide any other open menus
            this.hideAllMenus();
            // Reset state when opening
            this.selectedNewIssueTag = 'high';
            this.selectedApplyTo = 'current';
            this.renderIssueTagSelector();
            this.renderApplyToSelector();
        } else {
            emptyState.classList.remove('hidden');
            form.classList.add('hidden');
            editBtn.disabled = false;
            editBtn.classList.remove('opacity-30', 'cursor-not-allowed');
            // Reset form values
            commentInput.value = '';
            this.validateIssueForm();
        }
    }

    toggleApplyToDropdown(event) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        const menu = document.getElementById('issueApplyToDropdownMenu');
        const trigger = document.getElementById('issueApplyToTrigger');
        const isCurrentlyHidden = menu.classList.contains('hidden');

        this.hideAllMenus(); // Close other menus first

        if (isCurrentlyHidden) {
            menu.classList.remove('hidden');
            menu.style.display = 'block';
            trigger.classList.add('is-active'); // Add purple border
            this.renderApplyToDropdown();
        }
    }

    renderApplyToDropdown() {
        const menu = document.getElementById('issueApplyToDropdownMenu');
        const options = [
            { value: 'entire', label: 'Entire file' },
            { value: 'current', label: 'Current frame' },
            { value: 'canvas', label: 'Pin on canvas' }
        ];

        menu.innerHTML = options.map(opt => {
            const isSelected = this.selectedApplyTo === opt.value;
            return `
                <div class="tag-option ${isSelected ? 'selected' : ''}" onclick="window.app.selectApplyTo(event, '${opt.value}')">
                    <span class="text-[13.5px] ${isSelected ? 'text-[#5f45ff] font-medium' : 'text-gray-700'}">
                        ${opt.label}
                    </span>
                    ${isSelected ? '<span class="material-icons-outlined !text-[16px] text-[#5f45ff] font-bold">check</span>' : ''}
                </div>
            `;
        }).join('');
    }

    selectApplyTo(event, value) {
        if (event) event.stopPropagation();
        this.selectedApplyTo = value;
        this.renderApplyToSelector();

        // Close menu after selection
        document.getElementById('issueApplyToDropdownMenu').classList.add('hidden');
    }

    renderApplyToSelector() {
        const container = document.getElementById('selectedApplyToContainer');
        const options = [
            { value: 'entire', label: 'Entire file' },
            { value: 'current', label: 'Current frame' },
            { value: 'canvas', label: 'Pin on canvas' }
        ];
        const selected = options.find(o => o.value === this.selectedApplyTo);
        container.innerHTML = `<span class="text-gray-800 text-[13px]">${selected.label}</span>`;
    }

    validateIssueForm() {
        const comment = document.getElementById('issueComment').value.trim();
        const btn = document.getElementById('createIssueBtn');

        if (comment.length > 0) {
            btn.disabled = false;
            // Switch from Grey state to Purple/Blue active state (Image 6)
            btn.classList.remove('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
            btn.classList.add('bg-[#5f45ff]', 'text-white', 'cursor-pointer', 'hover:bg-[#4a36cc]');
        } else {
            btn.disabled = true;
            btn.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
            btn.classList.remove('bg-[#5f45ff]', 'text-white', 'cursor-pointer', 'hover:bg-[#4a36cc]');
        }
    }
    switchLabelView(mode) {
        this.labelListMode = mode;
        this.renderInstructions();
    }
    // --- Navigation Menu Logic ---
    resetRotation() {
        // --- THIS IS A NEW METHOD ---
        const slider = document.getElementById('customRotateSlider');
        const input = document.getElementById('customRotateInput');

        if (slider) slider.value = 0;
        if (input) input.value = 0;

        // Manually trigger the sync and fill update
        this.updateSliderFill(slider);
        this.transformManager.setRotation(0);
    }
    toggleFilterBar() {
        const bar = document.getElementById('labelsFilterBar');
        if (bar) {
            bar.classList.toggle('hidden');
        }
    }
    toggleIssuesSidebar() {
        const sidebar = document.getElementById('issuesSidebar');
        const resizer = document.getElementById('issuesVResizer'); // Add this line

        if (!sidebar || !resizer) return;

        const isHidden = sidebar.classList.contains('hidden');

        if (isHidden) {
            // Show both
            sidebar.classList.remove('hidden');
            resizer.classList.remove('hidden');
        } else {
            // Hide both
            sidebar.classList.add('hidden');
            resizer.classList.add('hidden');

            // Optional: Reset any canvas popup if closing
            this.hideCanvasIssuePopup();
        }
    }
    toggleMoreNavMenu(event) {
        if (event) event.stopPropagation();
        const menu = document.getElementById('moreNavMenu');
        const btn = document.getElementById('moreNavBtn');
        const isVisible = !menu.classList.contains('hidden');

        this.hideAllMenus(); // Close other open menus

        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'flex'; // Ensure flex display

            const rect = btn.getBoundingClientRect();

            // --- SMART POSITIONING (DYNAMICAL) ---
            // 1. Temporarily show to measure height
            menu.style.visibility = 'hidden';
            menu.style.display = 'flex';
            const menuHeight = menu.offsetHeight;
            menu.style.visibility = 'visible';

            const offset = 10;
            const spaceBelow = window.innerHeight - rect.bottom;

            if (spaceBelow > menuHeight + offset + 20) {
                // ENOUGH SPACE BELOW (Image 2 Style)
                menu.style.top = `${rect.bottom + offset}px`;
                menu.style.bottom = 'auto';
            } else {
                // NOT ENOUGH SPACE (Flip to Image 1 Style)
                menu.style.top = 'auto';
                menu.style.bottom = `${window.innerHeight - rect.top + offset}px`;
            }
            menu.style.left = `${rect.left}px`;
        }
    }

    toggleSettingsMenu(event) {
        if (event) event.stopPropagation();
        const menu = document.getElementById('settingsMenu');
        const btn = document.getElementById('settingsBtn');
        const isVisible = !menu.classList.contains('hidden');

        this.hideAllMenus();

        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'flex';

            const rect = btn.getBoundingClientRect();

            // --- SMART POSITIONING (DYNAMICAL) ---
            menu.style.visibility = 'hidden';
            menu.style.display = 'flex';
            const menuHeight = menu.offsetHeight;
            menu.style.visibility = 'visible';

            const offset = 10;
            const spaceBelow = window.innerHeight - rect.bottom;
            const rightFromWindow = window.innerWidth - rect.right;

            if (spaceBelow > menuHeight + offset + 20) {
                // ENOUGH SPACE BELOW (Image 2 Style)
                menu.style.top = `${rect.bottom + offset}px`;
                menu.style.bottom = 'auto';
            } else {
                // NOT ENOUGH SPACE (Flip to Image 1 Style)
                menu.style.top = 'auto';
                menu.style.bottom = `${window.innerHeight - rect.top + offset}px`;
            }

            menu.style.right = `${rightFromWindow}px`;
            menu.style.left = 'auto';
        }
    }

    updateSettingsCheckmarks() {
        const tsCheck = document.getElementById('checkmark-timestamps');
        const skipCheck = document.getElementById('checkmark-skipselector');

        // Toggle checkmark for Timestamps
        if (tsCheck) {
            if (this.displayTimestamps) {
                tsCheck.classList.remove('hidden');
            } else {
                tsCheck.classList.add('hidden');
            }
        }

        // Toggle checkmark for Skip Selector (THIS IS THE FIX)
        if (skipCheck) {
            if (this.showFrameSkipSelector) {
                skipCheck.classList.remove('hidden');
            } else {
                skipCheck.classList.add('hidden');
            }
        }

        // Ensure the timeline pill visibility is also updated
        this.updateFrameSkipSelectorVisibility();
    }

    formatDisplay(frame) {
        if (this.displayTimestamps && this.timestampFormat) {
            const totalSeconds = frame / CONFIG.FPS;
            if (isNaN(totalSeconds)) return this.timestampFormat === 'HH:MM:SS' ? "00:00:00" : "00:00";

            if (this.timestampFormat === 'HH:MM:SS') {
                const hrs = Math.floor(totalSeconds / 3600);
                const mins = Math.floor((totalSeconds % 3600) / 60);
                const secs = Math.floor(totalSeconds % 60);
                return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            } else if (this.timestampFormat === 'MM:SS') {
                const mins = Math.floor(totalSeconds / 60);
                const secs = Math.floor(totalSeconds % 60);
                return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            } else if (this.timestampFormat === 'SS.FF') {
                const mins = Math.floor(totalSeconds / 60);
                const secs = Math.floor(totalSeconds % 60);
                const frames = Math.round(frame % CONFIG.FPS);

                const frameStr = frames.toString().padStart(2, '0');
                if (mins === 0) {
                    return `${secs}.${frameStr}`;
                }
                return `${mins}:${secs.toString().padStart(2, '0')}.${frameStr}`;
            }
        }
        return Math.round(frame).toString();
    }

    formatTimeStandard(seconds) {
        if (isNaN(seconds)) return "0:00";
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    parseDisplay(value) {
        if (typeof value !== 'string') return parseInt(value) || 0;
        value = value.trim();

        if (this.displayTimestamps && this.timestampFormat) {
            if (value.includes(':')) {
                const parts = value.split(':');
                if (parts.length === 3 && this.timestampFormat === 'HH:MM:SS') {
                    const hrs = parseInt(parts[0]);
                    const mins = parseInt(parts[1]);
                    const secsPart = parts[2];
                    if (secsPart.includes('.')) {
                        const sub = secsPart.split('.');
                        const secs = parseInt(sub[0]);
                        const frames = parseInt(sub[1]);
                        if (!isNaN(hrs) && !isNaN(mins) && !isNaN(secs) && !isNaN(frames)) {
                            return (hrs * 3600 * CONFIG.FPS) + (mins * 60 * CONFIG.FPS) + (secs * CONFIG.FPS) + frames;
                        }
                    } else {
                        const secs = parseInt(secsPart);
                        if (!isNaN(hrs) && !isNaN(mins) && !isNaN(secs)) {
                            return (hrs * 3600 * CONFIG.FPS) + (mins * 60 * CONFIG.FPS) + (secs * CONFIG.FPS);
                        }
                    }
                } else if (parts.length === 2 && (this.timestampFormat === 'MM:SS' || this.timestampFormat === 'SS.FF')) {
                    const mins = parseInt(parts[0]);
                    const secsPart = parts[1];
                    if (secsPart.includes('.') && this.timestampFormat === 'SS.FF') {
                        const sub = secsPart.split('.');
                        const secs = parseInt(sub[0]);
                        const frames = parseInt(sub[1]);
                        if (!isNaN(mins) && !isNaN(secs) && !isNaN(frames)) {
                            return (mins * 60 * CONFIG.FPS) + (secs * CONFIG.FPS) + frames;
                        }
                    } else {
                        const secs = parseFloat(secsPart);
                        if (!isNaN(mins) && !isNaN(secs)) {
                            return Math.round((mins * 60 + secs) * CONFIG.FPS);
                        }
                    }
                }
            } else if (value.includes('.') && this.timestampFormat === 'SS.FF') {
                const parts = value.split('.');
                const secs = parseInt(parts[0]);
                const frames = parseInt(parts[1]);
                if (!isNaN(secs) && !isNaN(frames)) {
                    return (secs * CONFIG.FPS) + frames;
                }
            } else if (this.timestampFormat === 'HH:MM:SS' || this.timestampFormat === 'MM:SS' || this.timestampFormat === 'SS.FF') {
                const secs = parseFloat(value);
                if (!isNaN(secs)) {
                    return Math.round(secs * CONFIG.FPS);
                }
            }
        }
        return parseInt(value) || 0;
    }

    toggleDisplayTimestamps() {
        console.log("toggleDisplayTimestamps called");

        const formats = CONFIG.TIMESTAMP_FORMATS;
        const currentIndex = formats.indexOf(this.timestampFormat);
        const nextIndex = (currentIndex + 1) % formats.length;

        this.timestampFormat = formats[nextIndex];
        this.displayTimestamps = (this.timestampFormat !== 'Frames');

        // Sync with settingsMenuManager
        if (this.settingsMenuManager) {
            this.settingsMenuManager.currentTimestampFormat = this.timestampFormat;
            this.settingsMenuManager.renderTimestampFormatOptions();
        }

        console.log("New displayTimestamps state:", this.displayTimestamps, "Format:", this.timestampFormat);
        this.updateSettingsCheckmarks();
        this.refreshTimeDisplays();
    }

    toggleFrameSkipSelector() {
        console.log("toggleFrameSkipSelector called");
        this.showFrameSkipSelector = !this.showFrameSkipSelector;
        console.log("New showFrameSkipSelector state:", this.showFrameSkipSelector);
        this.updateSettingsCheckmarks();
        this.updateFrameSkipSelectorVisibility();
    }

    updateFrameSkipSelectorVisibility() {
        const pill = document.getElementById('frameSkipSelectorPill');
        if (pill) {
            if (this.showFrameSkipSelector) {
                pill.classList.remove('hidden');
            } else {
                pill.classList.add('hidden');
                // Also hide the menu if it was open
                const menu = document.getElementById('frameSkipSelectorMenu');
                if (menu) menu.classList.add('hidden');
            }
        }
    }

    toggleFrameSkipSelectorMenu(event, forceState) {
        if (event) event.stopPropagation();
        const menu = document.getElementById('frameSkipSelectorMenu');
        if (!menu) return;

        if (forceState !== undefined) {
            if (forceState) menu.classList.remove('hidden');
            else menu.classList.add('hidden');
        } else {
            menu.classList.toggle('hidden');
        }
    }

    updateSettingsCheckmarks() {
        const tsCheck = document.getElementById('checkmark-timestamps');
        const skipCheck = document.getElementById('checkmark-skipselector');

        if (tsCheck) {
            if (this.displayTimestamps) tsCheck.classList.remove('hidden');
            else tsCheck.classList.add('hidden');
        }

        if (skipCheck) {
            if (this.showFrameSkipSelector) skipCheck.classList.remove('hidden');
            else skipCheck.classList.add('hidden');
        }
    }

    addCustomFrameSkip(event) {
        if (event) event.stopPropagation();
        const input = document.getElementById('customFrameSkipInput');
        if (!input) return;

        const val = parseInt(input.value);
        if (isNaN(val) || val <= 0) {
            alert("Please enter a valid frame number.");
            return;
        }

        if (!CONFIG.FRAME_SKIP_VALUES.includes(val)) {
            CONFIG.FRAME_SKIP_VALUES.push(val);
            CONFIG.FRAME_SKIP_VALUES.sort((a, b) => a - b);
        }

        this.settingsMenuManager.setFrameSkip(val);
        input.value = '';
    }

    refreshTimeDisplays() {
        console.log("refreshTimeDisplays starting...");
        try {
            // Force immediate UI update without requestAnimationFrame to guarantee sync
            const currentTime = this.videoController.currentTime;
            const duration = this.videoController.duration;
            const totalFrames = this.videoController.getTotalFrames();
            const currentFrame = this.videoController.getCurrentFrame();

            // 1. Update Header Input
            this.frameInput.value = this.formatDisplay(currentFrame);

            // 2. Update Total Frames Display
            this.totalFramesText.innerText = this.formatDisplay(totalFrames);
            document.getElementById('staticLabelEnd').innerText = this.formatDisplay(totalFrames);

            // 3. Update Bounding Box Slider Inputs (if open)
            if (this.annotationPanelView.elements.inputStart) {
                this.annotationPanelView.elements.inputStart.value = this.formatDisplay(this.annotationModel.start);
            }
            if (this.annotationPanelView.elements.inputEnd) {
                this.annotationPanelView.elements.inputEnd.value = this.formatDisplay(this.annotationModel.end);
            }

            // 4. Update Filter Inputs
            const filterStart = document.getElementById('filterStartInput');
            const filterEnd = document.getElementById('filterEndInput');
            if (filterStart) filterStart.value = this.formatDisplay(this.labelFilter.start);
            if (filterEnd) filterEnd.value = this.formatDisplay(this.labelFilter.end);

            // 5. Update Annotation Slider and Ranges (if active)
            if (this.annotationModel.isActive()) {
                this.updateAnnotationSlider();
                this.renderSliderRanges();
            }

            // 6. Update Timeline Ruler
            if (this.timelineView) {
                this.timelineView.initialize(duration, this.timelineView.currentPPS);
            }

            // 7. Update timeline tooltips and tracks
            this.onVideoTimeUpdate();
            this.renderInstructions(); // This updates the sidebar labels list

            // 8. Update Full Edit Sidebar Frames (if open)
            this.updateEditSidebarFrames();

            console.log("refreshTimeDisplays completed successfully");
        } catch (e) {
            console.error("Error in refreshTimeDisplays:", e);
        }
    }

    /**
     * navTo: Handles jumping to next/previous annotation/classification boundaries (starts and ends)
     * @param {string} direction 'next' or 'prev'
     * @param {string} type 'annotation' or 'classification'.
     */
    navTo(direction, type = 'classification') {
        const currentFrame = this.videoController.getCurrentFrame();
        const instructions = this.annotationModel.instructions;
        if (instructions.length === 0) return;

        // Collect all boundaries (starts and ends)
        let boundaries = [];
        instructions.forEach(ins => {
            const parts = ins.frames.split(' - ');
            const start = parseInt(parts[0]);
            const end = parseInt(parts[1]);
            if (!isNaN(start)) boundaries.push(start);
            if (!isNaN(end)) boundaries.push(end);
        });

        // Unique and Sorted
        boundaries = [...new Set(boundaries)].sort((a, b) => a - b);

        let targetFrame = -1;
        if (direction === 'next') {
            targetFrame = boundaries.find(f => f > currentFrame);
            // If no next, loop to start
            if (targetFrame === undefined) targetFrame = boundaries[0];
        } else {
            const prevBoundaries = boundaries.filter(f => f < currentFrame);
            targetFrame = prevBoundaries.length > 0 ?
                prevBoundaries[prevBoundaries.length - 1] :
                boundaries[boundaries.length - 1];
        }

        if (targetFrame !== -1 && targetFrame !== undefined) {
            this.jumpToFrame(targetFrame);
        }
    }

    jumpToFirstFrame() {
        this.jumpToFrame(0);
    }

    jumpToLastFrame() {
        const total = this.videoController.getTotalFrames();
        if (total > 0) {
            this.jumpToFrame(total);
        }
    }
    jumpToFrame(frame) {
        const f = parseInt(frame);
        if (isNaN(f)) return;

        // 1. Seek Video
        this.videoController.seekToFrame(f);

        // 2. Center Timeline on the frame
        const currentTime = f / CONFIG.FPS;
        this.scrollSync.sync(
            currentTime,
            this.videoController.duration,
            this.timelineView.currentPPS,
            true // forceCenter: true
        );

        // 3. Update UI (Input, progress bar, etc)
        this.onVideoTimeUpdate();
    }
    formatClickableFrames(framesString) {
        if (!framesString || typeof framesString !== 'string' || framesString.trim() === '') {
            return `<span class="bg-gray-100 text-gray-400 px-2 py-0.5 rounded-md text-[12px]">No frames</span>`;
        }
        const ranges = framesString.split(' | ');
        return ranges.map(rangeStr => {
            const parts = rangeStr.split(' - ');
            if (parts.length !== 2) return `<span class="bg-[#f0f5ff] text-[#5f45ff] px-2 py-0.5 rounded-md text-[12px] font-[500]">${rangeStr}</span>`;

            const startFrameRaw = parts[0];
            const endFrameRaw = parts[1];
            const startDisplay = this.formatDisplay(parseInt(startFrameRaw));
            const endDisplay = this.formatDisplay(parseInt(endFrameRaw));

            const startSpan = `<span class="cursor-pointer" onclick="event.stopPropagation(); window.app.jumpToFrame(${startFrameRaw})">${startDisplay}</span>`;
            const endSpan = `<span class="cursor-pointer" onclick="event.stopPropagation(); window.app.jumpToFrame(${endFrameRaw})">${endDisplay}</span>`;

            // --- FIX: Changed "rounded" to "rounded-md" for the desired pill shape ---
            return `<span class="bg-[#f0f5ff] text-[#5f45ff] px-2 py-0.5 rounded-md text-[12px] font-[500] inline-flex items-center gap-1">${startSpan}<span>&nbsp;-&nbsp;</span>${endSpan}</span>`;
        }).join('');
    }

    formatAnnotationValue(text, className) {
        try {
            const parsed = JSON.parse(text);
            const cls = CONFIG.CLASSES.find(c => c.name === className);

            if (cls && cls.subInputs) {
                const badges = cls.subInputs.map(sub => {
                    let val = parsed[sub.id];
                    if (!val || (typeof val === 'string' && val.trim() === '')) return '';
                    if (Array.isArray(val)) val = val.join(', ');
                    const label = sub.label || sub.name;

                    // --- INLINE COMPACT BADGE (MATCHING IMAGE 2) ---
                    // 'inline-block' allows the badge to shrink to the size of the text.
                    // 'max-w-full' ensures that if the text is long, it respects the sidebar width.
                    return `
                <div class="inline-block px-[8px] py-[1.5px] bg-[#f0f5ff] border border-[#adc6ff] rounded-[4px] max-w-full text-[12px] leading-[1.4] mb-1 mr-1" style="word-break: break-word; vertical-align: top;">
                    <span class="font-[600] text-[#1d39c4] lowercase mr-1.5">${label}</span>
                    <span class="font-[480] text-[#1d39c4]">${val}</span>
                </div>`;
                }).join('');

                if (badges) {
                    // 'flex-wrap' ensures multiple compact badges sit side-by-side if they fit
                    return `<div class="flex flex-row flex-wrap w-full mt-1.5">${badges}</div>`;
                }
            }
        } catch (e) {
            // Fallback for non-JSON text
        }

        // Fallback for single inputs
        return `
    <div class="inline-block px-[8px] py-[1.5px] bg-[#f0f5ff] border border-[#adc6ff] rounded-[4px] max-w-full mt-1.5 text-[12px] leading-[1.4]" style="word-break: break-word;">
        <span class="font-[600] text-[#1d39c4] lowercase mr-1.5">${className}</span>
        <span class="font-[480] text-[#1d39c4]">${text}</span>
    </div>`;
    }
    // Add this helper to auto-resize textareas when content is loaded programmatically
    syncTextareaHeight(elementId, defaultHeight = 18) {
        const el = document.getElementById(elementId);
        if (el) {
            el.style.height = 'auto';
            // We use Math.max to ensure it doesn't get smaller than our 18px target
            // but scrollHeight will correctly identify single lines as ~18-20px
            const newHeight = el.scrollHeight;
            el.style.height = (newHeight > 0 ? newHeight : defaultHeight) + 'px';

            // Also ensure the parent wrapper matches the height
            if (el.parentElement && el.parentElement.classList.contains('tree-input-field-wrapper')) {
                el.parentElement.style.height = 'auto';
            }
        }
    }

    // ======================================================================= //
    // == START: NEW METHODS FOR EDIT/DELETE FUNCTIONALITY                  == //
    // ======================================================================= //
    hideAllMenus() {
        // NOTE: The canvas issue popup is intentionally NOT closed here.
        // It has its own explicit X button (hideCanvasIssuePopup) and should
        // persist independently of other menus.
        this.openDropdownId = null;
        this.focusedDropdownId = null;

        const menus = [
            ...document.querySelectorAll('[id^="optionsMenu-"]'),
            ...document.querySelectorAll('[id^="issueMenu-"]'),
            ...document.querySelectorAll('[id^="commentMenu-"]'),
            document.getElementById('sharedCommentMenu'),
            document.getElementById('sidebarDropdownMenu'),
            document.getElementById('labelsSortMenu'),
            document.getElementById('timelineSortMenu'),
            document.getElementById('moreNavMenu'),
            document.getElementById('settingsMenu'),
            document.getElementById('issueSortPopover'),
            document.getElementById('sortMethodList'),
            document.getElementById('sortOrderList'),
            document.getElementById('statusDropdownMenu'),
            document.getElementById('typeDropdownMenu'),
            document.getElementById('issueApplyToDropdownMenu'),
            document.getElementById('issueTagDropdownMenu'),
            document.getElementById('canvasTagPopover')
        ];

        menus.forEach(m => {
            if (m) {
                m.classList.add('hidden');
                m.style.display = 'none';
            }
        });

        // Reset Icon Colors
        document.getElementById('labelSortToggle')?.classList.remove('filter-active');
        document.getElementById('timelineSortBtn')?.classList.remove('filter-active');
        document.querySelectorAll('.issue-sort-select-box').forEach(box => {
            box.classList.remove('is-active');
        });
    }
    // --- UPDATED ISSUE SORT LOGIC ---

    toggleIssueSortPopover(event) {
        if (event) event.stopPropagation();
        const popover = document.getElementById('issueSortPopover');
        const isVisible = !popover.classList.contains('hidden');
        this.hideAllMenus();
        if (!isVisible) {
            popover.classList.remove('hidden');
            popover.style.display = 'block';
        }
    }

    toggleIssueSubSortDropdown(event, type) {
        if (event) event.stopPropagation();
        const methodList = document.getElementById('sortMethodList');
        const orderList = document.getElementById('sortOrderList');
        const methodBox = document.getElementById('sortMethodSelect');
        const orderBox = document.getElementById('sortOrderSelect');

        if (type === 'method') {
            orderList.classList.add('hidden');
            orderBox.classList.remove('is-active');
            methodList.classList.toggle('hidden');
            methodBox.classList.toggle('is-active');
            if (!methodList.classList.contains('hidden')) methodList.style.display = 'block';
        } else {
            methodList.classList.add('hidden');
            methodBox.classList.remove('is-active');
            orderList.classList.toggle('hidden');
            orderBox.classList.toggle('is-active');
            if (!orderList.classList.contains('hidden')) orderList.style.display = 'block';
        }
    }

    selectIssueSort(type, value) {
        if (window.event) window.event.stopPropagation();

        const triggerIcon = document.getElementById('issueSortTriggerIcon');

        if (type === 'method') {
            document.getElementById('currentSortMethod').innerText = value;
            document.getElementById('activeSortDisplay').innerText = value;
            this._updateSortItemActive('sortMethodList', value);
        } else {
            document.getElementById('currentSortOrder').innerText = value;
            this._updateSortItemActive('sortOrderList', value);

            // --- ARROW DIRECTION LOGIC ---
            if (value === 'Oldest first') {
                triggerIcon.innerText = 'north'; // Point Up
            } else {
                triggerIcon.innerText = 'south'; // Point Down (Newest)
            }
        }

        // Close sub-menus
        document.querySelectorAll('.issue-sort-list').forEach(l => l.classList.add('hidden'));
        document.querySelectorAll('.issue-sort-select-box').forEach(b => b.classList.remove('is-active'));

        this._checkSortDefaultState();
    }

    resetIssueSort(event) {
        if (event) event.stopPropagation();

        // Restore Default Labels
        document.getElementById('currentSortMethod').innerText = 'Last updated';
        document.getElementById('activeSortDisplay').innerText = 'Last updated';
        document.getElementById('currentSortOrder').innerText = 'Newest first';
        document.getElementById('issueSortTriggerIcon').innerText = 'south';

        // Update Active states in lists
        this._updateSortItemActive('sortMethodList', 'Last updated');
        this._updateSortItemActive('sortOrderList', 'Newest first');

        this._checkSortDefaultState();
    }

    _checkSortDefaultState() {
        const method = document.getElementById('currentSortMethod').innerText;
        const order = document.getElementById('currentSortOrder').innerText;
        const resetBtn = document.getElementById('issueSortResetBtn');

        // Default is "Last updated" and "Newest first"
        if (method === 'Last updated' && order === 'Newest first') {
            resetBtn.classList.add('hidden');
        } else {
            resetBtn.classList.remove('hidden');
        }
    }

    _updateSortItemActive(listId, value) {
        const items = document.querySelectorAll(`#${listId} .issue-sort-item`);
        items.forEach(item => {
            if (item.innerText === value) item.classList.add('active');
            else item.classList.remove('active');
        });
    }
    toggleTimelineSortMenu(event) {
        event.stopPropagation();
        const menu = document.getElementById('timelineSortMenu');
        const btn = document.getElementById('timelineSortBtn');

        // 1. Check if it's already open
        const isVisible = !menu.classList.contains('hidden');

        // 2. Hide everything first
        this.hideAllMenus();

        // 3. If it was NOT visible, show it now. 
        // (If it WAS visible, we do nothing else, effectively "closing" it)
        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'block';
            btn.classList.add('filter-active'); // Optional: makes icon purple

            const rect = btn.getBoundingClientRect();

            // --- SMART POSITIONING (DYNAMICAL) ---
            menu.style.visibility = 'hidden';
            menu.style.display = 'block';
            const menuHeight = menu.offsetHeight;
            menu.style.visibility = 'visible';

            const offset = 10;
            const spaceBelow = window.innerHeight - rect.bottom;

            if (spaceBelow > menuHeight + offset + 20) {
                // ENOUGH SPACE BELOW (Image 2 Style)
                menu.style.top = `${rect.bottom + offset}px`;
                menu.style.bottom = 'auto';
            } else {
                // NOT ENOUGH SPACE (Flip to Image 1 Style)
                menu.style.top = 'auto';
                menu.style.bottom = `${window.innerHeight - rect.top + offset}px`;
            }
            menu.style.left = `${rect.left - 10}px`;
        }
    }

    sortTimeline(by, order) {
        this.hideAllMenus();
        const instructions = this.annotationModel.instructions;

        instructions.sort((a, b) => {
            let valA, valB;
            if (by === 'date') {
                valA = a.timestamp || 0;
                valB = b.timestamp || 0;
            } else {
                valA = (a.className || '').toLowerCase();
                valB = (b.className || '').toLowerCase();
            }

            if (order === 'asc') return valA > valB ? 1 : -1;
            return valA < valB ? 1 : -1;
        });

        // Re-render everything with the new order
        this.renderInstructions();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
    }
    toggleSortMenu(event) {
        if (event) event.stopPropagation();

        const menu = document.getElementById('labelsSortMenu');
        const icon = document.getElementById('labelSortToggle');

        // Check if currently open
        const isVisible = !menu.classList.contains('hidden');

        this.hideAllMenus(); // Reset other menus

        if (!isVisible) {
            // --- POSITIONING ---
            document.body.appendChild(menu);
            menu.classList.remove('hidden');
            menu.style.display = 'flex';
            icon.classList.add('filter-active');

            const rect = icon.getBoundingClientRect();
            menu.style.top = `${rect.bottom + 12}px`;
            menu.style.left = `${rect.left - 28}px`;

            // --- THE FIX ---
            // Force the highlight logic to run as soon as the menu opens
            this.updateSortUI();
        }
    }

    setSort(type, value) {
        this.labelSort[type] = value;
        this.updateSortUI();
        this.renderInstructions();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
    }

    updateSortUI() {
        // 1. Clear highlight from ALL items first
        const items = ['sort-date', 'sort-frame', 'order-asc', 'order-desc'];
        items.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.remove('sort-item-active');
        });

        // 2. Add the highlight to the currently active state items
        // If by is 'date', it finds 'sort-date'. If order is 'asc', it finds 'order-asc'
        const activeSortId = `sort-${this.labelSort.by}`;
        const activeOrderId = `order-${this.labelSort.order}`;

        document.getElementById(activeSortId)?.classList.add('sort-item-active');
        document.getElementById(activeOrderId)?.classList.add('sort-item-active');
    }
    toggleLabelsFilter() {
        const bar = document.getElementById('labelsFilterBar');
        const icon = document.getElementById('labelFilterToggle');
        this.labelFilter.active = !this.labelFilter.active;

        if (this.labelFilter.active) {
            bar.classList.remove('hidden');
            icon.classList.add('filter-active');

            const total = this.videoController.getTotalFrames();
            if (this.labelFilter.end === 0) {
                this.labelFilter.end = total;
            }

            // Ensure inputs are always synced with formatted values when opening
            const startInput = document.getElementById('filterStartInput');
            const endInput = document.getElementById('filterEndInput');
            if (startInput) startInput.value = this.formatDisplay(this.labelFilter.start);
            if (endInput) endInput.value = this.formatDisplay(this.labelFilter.end);
        } else {
            bar.classList.add('hidden');
            icon.classList.remove('filter-active');
        }
        this.renderInstructions();
    }

    setupFilterInputListeners() {
        const startIn = document.getElementById('filterStartInput');
        const endIn = document.getElementById('filterEndInput');
        if (!startIn || !endIn) return;

        const updateFilter = () => {
            this.labelFilter.start = this.parseDisplay(startIn.value);
            this.labelFilter.end = this.parseDisplay(endIn.value);
            this.renderInstructions();
        };

        startIn.addEventListener('input', updateFilter);
        endIn.addEventListener('input', updateFilter);
    }
    goToClassification(index) {
        this.hideAllMenus(); // Close menu immediately
        if (index < 0 || index >= this.annotationModel.instructions.length) return;
        const instruction = this.annotationModel.instructions[index];
        const startFrame = parseInt(instruction.frames.split(' - ')[0], 10);
        this.videoController.seekToFrame(startFrame);
    }

    editRange(index) {
        this.hideAllMenus(); // Close context menu
        if (index < 0 || index >= this.annotationModel.instructions.length) return;

        const instruction = this.annotationModel.instructions[index];
        this.editingAnnotationIndex = index;

        // Support consolidated format: "s1 - e1 | s2 - e2"
        const rangeStrings = instruction.frames.split(' | ');
        this.sliderRanges = rangeStrings.map(rangeStr => {
            const parts = rangeStr.split(' - ').map(Number);
            return { start: parts[0], end: parts[1] };
        });

        // 1. Set the correct class name in the model
        this.annotationModel.className = instruction.className;

        // 2. Activate the model with existing text
        this.annotationModel.activate(instruction.text, this.videoController.getTotalFrames());

        // Use the first range for the primary model state
        const firstRange = this.sliderRanges[0];
        this.annotationModel.setRange(firstRange.start, firstRange.end);

        // 3. FIX: SYNC TEXT TO SIDEBAR INPUT
        // This ensures that when saveAnnotation() is called, it finds the existing text.
        const activeClass = CONFIG.CLASSES.find(c => c.name === instruction.className);
        if (activeClass) {
            this.activeClassId = activeClass.id;

            // Ensure dynamicInputValues block exists
            if (!this.dynamicInputValues) {
                this.dynamicInputValues = {};
            }
            this.dynamicInputValues[activeClass.id] = {};
            let values = {};

            if (activeClass.subInputs && activeClass.subInputs.length > 0) {
                try {
                    values = JSON.parse(instruction.text);
                } catch (e) {
                    values[activeClass.subInputs[0].id] = instruction.text;
                }

                // Store in dynamicInputValues for renderClassList
                this.dynamicInputValues[activeClass.id] = values;

                // Select and expand the first subInput option automatically
                const firstSub = activeClass.subInputs[0];
                const groupKey = `${activeClass.id}-${firstSub.id}`;
                this.activeSubInputKey = groupKey;
                this.expandedSubGroups[groupKey] = true;
            } else {
                this.dynamicInputValues[activeClass.id] = instruction.text;
                values = instruction.text;
            }

            this.renderClassList();

            // FIX: Set explicit DOM values AFTER rendering the list
            setTimeout(() => {
                if (activeClass.subInputs && activeClass.subInputs.length > 0) {
                    activeClass.subInputs.forEach(sub => {
                        const inputField = document.getElementById(`input-field-${activeClass.id}-${sub.id}`);
                        if (inputField) {
                            inputField.value = values[sub.id] || '';
                            inputField.style.height = '24px';
                            inputField.style.height = (inputField.scrollHeight) + 'px';
                        }
                    });
                } else {
                    const inputField = document.getElementById(`input-field-${activeClass.id}`);
                    if (inputField) {
                        inputField.value = values;
                        inputField.style.height = '24px';
                        inputField.style.height = (inputField.scrollHeight) + 'px';
                    }
                }
            }, 0);
        }

        // 4. Update the Header in the Bottom Overlay
        const overlayHeader = document.querySelector('#annotationOverlay .annotation-overlay-header');
        if (overlayHeader) {
            overlayHeader.innerHTML = `${PARTITION_ICON_SVG} Add classification: ${instruction.className}`;
        }

        // 5. Update UI components
        this.annotationPanelView.updateClassTag(instruction.text);
        this.annotationPanelView.show();
        this.renderSliderRanges();
        this.updateAnnotationSlider();
    }

    showDeleteConfirmation(index) {
        this.hideAllMenus();
        this.editingAnnotationIndex = index;
        const instruction = this.annotationModel.instructions[index];
        const modal = document.getElementById('deleteConfirmationModal');
        const targetNameEl = document.getElementById('deleteTargetName');

        if (targetNameEl && instruction) {
            targetNameEl.innerText = instruction.className;
        }

        // Remove hidden, add flex to trigger the CSS positioning
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
    toggleOptionsMenu(event, index) {
        event.stopPropagation();
        const trigger = event.currentTarget;
        const menu = document.getElementById(`optionsMenu-${index}`);

        // Check if THIS specific menu is already visible
        const isVisible = menu && !menu.classList.contains('hidden') && menu.style.display === 'block';

        // Always hide everything first to clean up
        this.hideAllMenus();

        // If it wasn't visible before, show it now
        if (menu && !isVisible) {
            document.body.appendChild(menu);
            const rect = trigger.getBoundingClientRect();

            menu.style.left = `${rect.right - 19}px`;
            menu.style.top = `${rect.top + 19}px`;

            menu.classList.remove('hidden');
            menu.style.display = 'block';

            // Only close when an item inside is clicked
            menu.onclick = () => this.hideAllMenus();
        }
    }
    // Add these inside the VideoAnnotationApp class
    saveThisFrame() {
        const frame = this.videoController.getCurrentFrame();
        this.annotationModel.setRange(frame, frame);
        this.saveAnnotation();
    }

    setThisFrame() {
        const frame = this.videoController.getCurrentFrame();
        this.annotationModel.setRange(frame, frame);
        this.updateAnnotationSlider();
    }

    resetRange() {
        const total = this.videoController.getTotalFrames();
        this.annotationModel.setRange(0, total);
        this.updateAnnotationSlider();
    }

    // ============================================================================
    // MULTI-RANGE SLIDER SUPPORT
    // ============================================================================

    /**
     * addNewRange: Called by the "Add range" button.
     * Finds the largest free gap not covered by existing sliderRanges,
     * inserts a new range in that gap, then re-renders.
     */
    addNewRange() {
        const total = this.videoController ? this.videoController.getTotalFrames() : 0;
        if (!total || total <= 0) return;

        // Use a more permissive minimum size (1% instead of 5%)
        const MIN_RANGE_SIZE = Math.max(5, Math.floor(total * 0.01));

        // Sort ALL existing ranges
        const sorted = [...this.sliderRanges].sort((a, b) => a.start - b.start);

        // Build list of free gaps across the full [0, total] window, handling overlaps robustly
        const gaps = [];
        let currentPos = 0;
        for (const range of sorted) {
            if (range.start > currentPos) {
                gaps.push({ start: currentPos, end: range.start });
            }
            currentPos = Math.max(currentPos, range.end);
        }
        if (currentPos < total) {
            gaps.push({ start: currentPos, end: total });
        }

        // Find the largest gap
        const largestGap = gaps.reduce((best, gap) => {
            const size = gap.end - gap.start;
            return (size > (best ? best.end - best.start : -1)) ? gap : best;
        }, null);

        if (!largestGap || (largestGap.end - largestGap.start) < MIN_RANGE_SIZE) {
            return; // No space for a minimum range
        }

        // Place new range at the center of the largest gap (~40% of it)
        const gapSize = largestGap.end - largestGap.start;
        const newRangeSize = Math.max(MIN_RANGE_SIZE, Math.floor(gapSize * 0.4));
        const newStart = largestGap.start + Math.floor((gapSize - newRangeSize) / 2);
        const newEnd = newStart + newRangeSize;

        this.sliderRanges.push({ start: newStart, end: newEnd });

        this.renderSliderRanges();
        this.updateAddRangeButton();
    }

    /**
     * removeRange: Remove a range by index (index > 0 only; primary cannot be removed here)
     */
    removeRange(index) {
        if (index < 0 || index >= this.sliderRanges.length) return;
        this.sliderRanges.splice(index, 1);
        // Sync annotationModel to the first remaining range (or reset if none)
        if (this.sliderRanges.length > 0) {
            const p = this.sliderRanges[0];
            this.annotationModel.setRange(p.start, p.end);
        }
        this.renderSliderRanges();
        this.updateAddRangeButton();
    }

    /**
     * updateAddRangeButton: Enable or disable the "Add range" button
     * based on whether there is still free space in the slider.
     */
    updateAddRangeButton() {
        const total = this.videoController ? this.videoController.getTotalFrames() : 0;
        if (!total) {
            this.setAddRangeButtonDisabled(true);
            return;
        }

        const MIN_RANGE_SIZE = Math.max(5, Math.floor(total * 0.01));
        const sorted = [...this.sliderRanges].sort((a, b) => a.start - b.start);

        let currentPos = 0;
        let hasSpace = false;

        for (const range of sorted) {
            if (range.start - currentPos >= MIN_RANGE_SIZE) {
                hasSpace = true;
                break;
            }
            currentPos = Math.max(currentPos, range.end);
        }

        if (!hasSpace && (total - currentPos >= MIN_RANGE_SIZE)) {
            hasSpace = true;
        }

        this.setAddRangeButtonDisabled(!hasSpace);
    }

    /**
     * setAddRangeButtonDisabled: Toggle the disabled state of the "Add range" button
     */
    setAddRangeButtonDisabled(disabled) {
        const btn = document.querySelector('[data-add-range-btn]');
        if (!btn) return;
        btn.disabled = disabled;
        if (disabled) {
            btn.classList.add('opacity-40', 'cursor-not-allowed');
            btn.classList.remove('hover:border-[#5f45ff]', 'hover:text-[#5f45ff]');
        } else {
            btn.classList.remove('opacity-40', 'cursor-not-allowed');
            btn.classList.add('hover:border-[#5f45ff]', 'hover:text-[#5f45ff]');
        }
    }

    /**
     * renderSliderRanges: Renders all ranges as isolated segments on the grey track.
     * ALL ranges (index 0+) are equal — no "primary" full-span baseline.
     * - Hides knobStart / knobEnd / sliderHighlight (the old primary range widgets)
     * - Shows pill badges in #rangesPillRow for each range
     * - Renders each range as: highlight bar + start knob + end knob + frame tick labels
     */
    renderSliderRanges() {
        const total = this.videoController ? this.videoController.getTotalFrames() : 0;
        if (!total) return;

        const track = document.getElementById('sliderTrackBase');
        if (!track) return;

        // ── 1. Hide the legacy primary-range widgets ──────────────────────────────
        const legacyIds = ['knobStart', 'knobEnd', 'sliderHighlight'];
        legacyIds.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });

        // staticLabelStart (shows "0") and staticLabelEnd (shows totalFrames) are
        // permanent edge markers — always keep them visible.
        const sls = document.getElementById('staticLabelStart');
        const sle = document.getElementById('staticLabelEnd');
        if (sls) { sls.style.display = ''; sls.style.opacity = '1'; }
        if (sle) { sle.style.display = ''; sle.style.opacity = '1'; }

        // ── 2. Switch pill row ↔ input block ─────────────────────────────────────
        const pillRow = document.getElementById('rangesPillRow');
        const inputBlock = document.getElementById('rangesInputBlock');
        const hasRanges = this.sliderRanges.length > 0;
        if (pillRow) {
            pillRow.classList.toggle('hidden', !hasRanges);
            pillRow.style.display = hasRanges ? 'flex' : 'none';
            pillRow.style.alignItems = 'center';
            pillRow.style.gap = '8px';
        }
        if (inputBlock) {
            inputBlock.style.display = hasRanges ? 'none' : '';
        }

        // ── 3. Rebuild pill badges ────────────────────────────────────────────────
        if (pillRow) {
            pillRow.innerHTML = '';

            this.sliderRanges.forEach((range, i) => {
                const pill = document.createElement('span');
                pill.style.cssText = [
                    'display:inline-flex', 'align-items:center', 'gap:2px',
                    'background:#f0f5ff', 'border:1px solid #adc6ff', 'border-radius:6px',
                    'padding:0px 4px 0px 8px', 'font-size:12px', 'height:24px',
                    'color:#597ef7', 'white-space:nowrap', 'cursor:default'
                ].join(';');
                pill.dataset.pillIdx = i;

                // Start Frame Input
                const startIn = document.createElement('input');
                startIn.type = 'text';
                startIn.value = this.formatDisplay(range.start);
                startIn.style.cssText = 'width:46px; background:transparent; border:1px solid transparent; border-radius:4px; outline:none; color:inherit; font-size:inherit; font-weight:inherit; text-align:center; padding:0; transition: all 0.2s;';

                startIn.addEventListener('focus', () => {
                    startIn.style.background = 'white';
                    startIn.style.border = '2px solid black';
                    startIn.style.margin = '-1px'; // Compensate for 2px border vs 1px gap
                });
                startIn.addEventListener('blur', () => {
                    startIn.style.background = 'transparent';
                    startIn.style.border = '1px solid transparent';
                    startIn.style.margin = '0';
                });
                startIn.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') startIn.blur();
                });

                startIn.addEventListener('change', (e) => {
                    const val = this.parseDisplay(e.target.value);
                    if (!isNaN(val)) {
                        this.sliderRanges[i].start = Math.max(0, Math.min(val, this.sliderRanges[i].end - 1));
                        this.renderSliderRanges();
                        this.updateAnnotationSlider();
                    }
                });

                // Separator
                const sep = document.createElement('span');
                sep.textContent = '-';
                sep.style.margin = '0 1px';

                // End Frame Input
                const endIn = document.createElement('input');
                endIn.type = 'text';
                endIn.value = this.formatDisplay(range.end);
                endIn.style.cssText = 'width:46px; background:transparent; border:1px solid transparent; border-radius:4px; outline:none; color:inherit; font-size:inherit; font-weight:inherit; text-align:center; padding:0; transition: all 0.2s;';

                endIn.addEventListener('focus', () => {
                    endIn.style.background = 'white';
                    endIn.style.border = '2px solid black';
                    endIn.style.margin = '-1px';
                });
                endIn.addEventListener('blur', () => {
                    endIn.style.background = 'transparent';
                    endIn.style.border = '1px solid transparent';
                    endIn.style.margin = '0';
                });
                endIn.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') endIn.blur();
                });

                endIn.addEventListener('change', (e) => {
                    const val = this.parseDisplay(e.target.value);
                    if (!isNaN(val)) {
                        this.sliderRanges[i].end = Math.max(this.sliderRanges[i].start + 1, Math.min(val, total));
                        this.renderSliderRanges();
                        this.updateAnnotationSlider();
                    }
                });

                pill.appendChild(startIn);
                pill.appendChild(sep);
                pill.appendChild(endIn);

                if (this.sliderRanges.length > 1) {
                    const closeBtn = document.createElement('button');
                    closeBtn.style.cssText = [
                        'display:inline-flex', 'align-items:center', 'justify-content:center',
                        'width:14px', 'height:14px', 'border-radius:50%', 'border:none',
                        'background:transparent', 'color:#bfbfbf', 'font-size:12px',
                        'cursor:pointer', 'padding:0', 'line-height:1', 'margin-left:2px',
                        'flex-shrink:0', 'transition:color 0.2s', 'margin-bottom:3px'
                    ].join(';');
                    closeBtn.innerHTML = '&#8855;'; // Using the circled cross symbol
                    closeBtn.title = 'Remove range';
                    closeBtn.onmouseover = () => closeBtn.style.color = '#000000e0';
                    closeBtn.onmouseout = () => closeBtn.style.color = '#bfbfbf';
                    closeBtn.addEventListener('mousedown', (e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        this.removeRange(i);
                    });
                    pill.appendChild(closeBtn);
                }
                pillRow.appendChild(pill);
            });
        }

        // ── 4. Remove all previously rendered dynamic range segments ──────────────
        track.querySelectorAll('.range-segment').forEach(el => el.remove());

        // ── 5. Render each range as an isolated segment ───────────────────────────
        this.sliderRanges.forEach((range, i) => {
            const startPct = (range.start / total) * 100;
            const endPct = (range.end / total) * 100;
            const widthPct = endPct - startPct;

            // Highlight bar
            const highlight = document.createElement('div');
            highlight.className = 'range-segment';
            highlight.style.cssText = [
                `position:absolute`, `top:0`, `height:100%`,
                `left:${startPct}%`, `width:${widthPct}%`,
                `background:#5f45ff`, `opacity:0.8`,
                `pointer-events:none`, `border-radius:2px`, `z-index:15`
            ].join(';');
            highlight.dataset.rangeIdx = i;
            highlight.dataset.segType = 'highlight';

            // Start knob
            const knobS = document.createElement('div');
            knobS.className = 'range-segment';
            knobS.style.cssText = this._knobStyle(startPct);
            knobS.dataset.rangeIdx = i;
            knobS.dataset.knobType = 'start';
            knobS.setAttribute('data-tooltip', this.formatDisplay(range.start));

            // Tick label below start knob
            const tickS = document.createElement('span');
            tickS.className = 'range-segment';
            tickS.style.cssText = [
                `position:absolute`, `left:${startPct}%`, `top:calc(100% + 4px)`,
                `transform:translateX(-50%)`, `font-size:12px`, `color:#000000e0 !important`,
                `white-space:nowrap`, `pointer-events:none`, `user-select:none`, `font-weight:480`
            ].join(';');
            tickS.dataset.rangeIdx = i;
            tickS.dataset.segType = 'tickStart';
            tickS.textContent = this.formatDisplay(range.start);

            // End knob
            const knobE = document.createElement('div');
            knobE.className = 'range-segment';
            knobE.style.cssText = this._knobStyle(endPct);
            knobE.dataset.rangeIdx = i;
            knobE.dataset.knobType = 'end';
            knobE.setAttribute('data-tooltip', this.formatDisplay(range.end));

            // Tick label below end knob
            const tickE = document.createElement('span');
            tickE.className = 'range-segment';
            tickE.style.cssText = [
                `position:absolute`, `left:${endPct}%`, `top:calc(100% + 4px)`,
                `transform:translateX(-50%)`, `font-size:12px`, `color:#000000e0 !important`,
                `white-space:nowrap`, `pointer-events:none`, `user-select:none`, `font-weight:480`
            ].join(';');
            tickE.dataset.rangeIdx = i;
            tickE.dataset.segType = 'tickEnd';
            tickE.textContent = this.formatDisplay(range.end);

            track.appendChild(highlight);
            track.appendChild(knobS);
            track.appendChild(tickS);
            track.appendChild(knobE);
            track.appendChild(tickE);

            // Wire drag listeners
            this._createDynamicKnobListeners(knobS, knobE, i);
        });

        // ── 6. Sync annotationModel to range[0] ───────────────────────────────────
        if (this.sliderRanges.length > 0) {
            const p = this.sliderRanges[0];
            this.annotationModel.setRange(p.start, p.end);
            // Sync input fields (hidden but still needed for save path)
            const startIn = document.getElementById('inputStartFrame');
            const endIn = document.getElementById('inputEndFrame');
            if (startIn) startIn.value = p.start;
            if (endIn) endIn.value = p.end;
        }
    }

    _knobStyle(pct) {
        return `position: absolute; left: ${pct}%; top: 50%; transform: translate(-50%, -50%); width: 14px; height: 14px; border-radius: 50%; background: white; border: 2px solid #5f45ff; box-shadow: 0 1px 4px rgba(95,69,255,0.4); cursor: pointer; z-index: 30;`;
    }

    /** Internal: apply visual knob styling */
    _styleKnob(el) {
        el.style.position = 'absolute';
    }

    /**
     * _createDynamicKnobListeners: Wire up mousedown → drag for an extra range segment
     */
    _createDynamicKnobListeners(knobStart, knobEnd, rangeIndex) {
        const startDrag = (e, type) => {
            e.stopPropagation();
            e.preventDefault();
            this.activeDragRangeIndex = rangeIndex;
            this.dragState.startDrag(type === 'start' ? 'extraRangeStart' : 'extraRangeEnd');
            if (window.tooltipManager) window.tooltipManager.show(e.currentTarget);
        };

        knobStart.addEventListener('mousedown', (e) => startDrag(e, 'start'));
        knobEnd.addEventListener('mousedown', (e) => startDrag(e, 'end'));
    }
    openFullEditSidebar(index) {
        this.hideAllMenus();
        if (index < 0 || index >= this.annotationModel.instructions.length) return;

        this.editingAnnotationIndex = index;
        const instruction = this.annotationModel.instructions[index];

        // Update the header title and frames display
        this.updateEditSidebarFrames();

        // Show sidebar
        document.getElementById('fullEditSidebar').classList.remove('hidden');
        document.getElementById('classesSection').classList.add('hidden');
        document.getElementById('labelsSection').classList.add('hidden');

        // 3. FIX: Update TOP Header Title
        const headerTitle = document.getElementById('sidebarHeaderTitle');
        if (headerTitle) {
            headerTitle.innerText = instruction.className;
        }

        this.renderFullEditSidebarContent();

        // 4. Set first sub-input as active by default for multi-input classes
        const activeClass = CONFIG.CLASSES.find(c => c.name === instruction.className);
        if (activeClass && activeClass.subInputs && activeClass.subInputs.length > 0) {
            const firstGroupKey = `fullEdit-${activeClass.id}-${activeClass.subInputs[0].id}`;
            this.activeSubInputKey = firstGroupKey;
            this.expandedSubGroups[firstGroupKey] = true;
            this.renderFullEditSidebarContent(); // Re-render once with active key
        }
    }

    renderFullEditSidebarContent() {
        if (this.editingAnnotationIndex === -1) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        const activeClass = CONFIG.CLASSES.find(c => c.name === instruction.className);
        const container = document.getElementById('fullEditSidebarInputContainer');
        if (!container) return;

        if (activeClass && activeClass.subInputs && activeClass.subInputs.length > 0) {
            let values = {};
            try { values = JSON.parse(instruction.text); } catch (e) { values[activeClass.subInputs[0].id] = instruction.text; }

            container.innerHTML = `
            <div class="tree-container-wrapper !p-0 !m-0">
                ${activeClass.subInputs.map((sub, idx) => {
                const groupKey = `fullEdit-${activeClass.id}-${sub.id}`;
                const storedVal = (this.dynamicInputValues[activeClass.id] && this.dynamicInputValues[activeClass.id][sub.id]) !== undefined ?
                    this.dynamicInputValues[activeClass.id][sub.id] : (values[sub.id] || '');

                if (!this.dynamicInputValues[activeClass.id]) this.dynamicInputValues[activeClass.id] = {};
                if (this.dynamicInputValues[activeClass.id][sub.id] === undefined) this.dynamicInputValues[activeClass.id][sub.id] = storedVal;

                const isExpanded = this.expandedSubGroups[groupKey] !== false;
                const isActive = (this.activeSubInputKey === groupKey);
                const isLast = idx === activeClass.subInputs.length - 1;
                const type = sub.type || 'text';
                const id = `input-field-fullEdit-${activeClass.id}-${sub.id}`;

                return `
                    <div class="tree-item-block ${isLast ? 'is-last' : ''} !pb-2">
                        <div class="tree-item-spine"></div>
                        <div class="tree-item-header">
                            <div class="tree-toggle-btn" onclick="window.app.toggleSubGroup(event, '${activeClass.id}', '${sub.id}', 'fullEdit-')">
                                ${isExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
                            </div>
                            <div class="custom-radio-circle ${isActive ? 'is-active' : ''}" onclick="window.app.selectSubGroup('${activeClass.id}', '${sub.id}', 'fullEdit-')"></div>
                            <div class="flex items-center gap-2 flex-1 cursor-pointer" onclick="window.app.selectSubGroup('${activeClass.id}', '${sub.id}', 'fullEdit-')">
                                <span class="text-[13px] text-gray-800 font-[400]">${sub.name}</span>
                                <span class="kbd-key text-[10px] scale-90">${sub.shortcut || ''}</span>
                            </div>
                        </div>
                        <div class="tree-expanded-area ${isExpanded ? '' : 'hidden'} !pl-0">
                            ${(type !== 'radio' && type !== 'checklist') ? `
        <div class="tree-elbow-line" style="left: 28.5px;"></div>
        <div class="flex items-center gap-2" style="padding-left: 45px;">
            <span class="tree-nested-label !pl-0">${sub.label}</span>
            ${isActive ? `
            <div class="si-clear-btn cursor-pointer" onclick="window.app.clearSubInput(event, '${activeClass.id}', '${sub.id}', true, 'fullEdit-')">
                ${CLOSE_CIRCLE_SVG}
            </div>
            ` : ''}
        </div>
    ` : ''}
                            
                            ${type === 'text' ? `
                                <div class="flex items-center gap-2" style="margin-left: 45px; padding-right: 12px;">
                                    <div class="tree-input-field-wrapper ${isActive ? 'is-active' : ''} flex-1" 
                                         style="min-height: 20px; height: auto; padding: 1px 10px;">
                                        <textarea id="${id}" name="${id}" 
                                            class="tree-input-textarea" 
                                            placeholder="Type..." 
                                            rows="1"
                                            style="height: 18px; min-height: 18px; line-height: 1.4; display: block; width: 100%;"
                                            ${!isActive ? 'disabled' : ''}
                                            oninput="window.app.handleDynamicInput(this, '${activeClass.id}', '${activeClass.name}', '${sub.id}', 'fullEdit-')">${storedVal}</textarea>
                                    </div>
                                    ${isActive && sub.optionShortcuts && sub.optionShortcuts[0] ? `
                                        <div class="kbd-key shrink-0 text-[10px] scale-90" style="color: #bfbfbf;">${sub.optionShortcuts[0]}</div>
                                    ` : ''}
                                </div>
                            ` : `<div style="${type === 'dropdown' ? 'margin-left: 45px; padding-right: 12px;' : ''}">${this.renderSubInput(activeClass, sub, isActive, storedVal, 'fullEdit-')}</div>`}
                        </div>
                    </div>`;
            }).join('')}
            </div>
        `;
            setTimeout(() => {
                activeClass.subInputs.forEach(sub => this.syncTextareaHeight(`input-field-fullEdit-${activeClass.id}-${sub.id}`, 22));
            }, 50);
        } else {
            // --- SINGLE INPUT EDIT VIEW (MATCHING IMAGE 1) ---
            container.innerHTML = `
        <div class="single-input-container !ml-0 !pl-0 !mt-2" style="position: relative;">
            <div class="single-input-content relative !pl-0" style="margin-left: 0px;">
                
                <!-- 1. The L-Shaped Elbow Line (Aligned to 6.5px spine) -->
                ${(activeClass?.type !== 'radio' && activeClass?.type !== 'dropdown' && activeClass?.type !== 'checklist') ? `
                <div class="single-input-elbow" style="
                    position: absolute; 
                    left: 6.5px; 
                    top: -18px; 
                    width: 16px; 
                    height: 32px; 
                    border-left: 1px solid #e5e7eb; 
                    border-bottom: 1px solid #e5e7eb; 
                    pointer-events: none;">
                </div>` : ''}
                
                ${(activeClass?.type === 'dropdown') ? `
                    <div style="width:100%; padding-left: 22.5px;" class="mt-1">
                        ${this.renderDropDown(activeClass, activeClass, true, this.dynamicInputValues[activeClass?.id] || instruction.text, 'fullEdit-')}
                    </div>
                ` : activeClass?.type === 'radio' ? `
                    <div style="width:100%;">
                        <div class="si-radio-system si-options-container" style="padding-top: 4px; border-left: 1px solid #e5e7eb; margin-left: 6.5px;">
                            <div class="si-options-list" style="margin-left: -5px;">
                                ${activeClass.options.map((opt, idx) => {
                                    const isChecked = (this.dynamicInputValues[activeClass.id] || instruction.text) === opt;
                                    const shortcut = (activeClass.optionShortcuts) ? (activeClass.optionShortcuts[idx] || '') : '';
                                    return `
                                        <div class="si-option-row" onclick="window.app.handleRadioSingleClick('${activeClass.id}', '${activeClass.name}', '${opt}')" style="cursor:pointer; margin-bottom:4px;">
                                            <div class="si-tree-h"></div>
                                            <label class="cursor-pointer flex items-center gap-2 w-full">
                                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}"></div>
                                                <span class="text-[13.5px] ${isChecked ? 'text-gray-800' : 'text-gray-500'}">${opt}</span>
                                                ${shortcut ? `<div class="kbd-key scale-90 ml-2">${shortcut}</div>` : ''}
                                            </label>
                                        </div>`;
                                }).join('')}
                            </div>
                        </div>
                    </div>
                ` : activeClass?.type === 'checklist' ? `
                    <div style="width:100%;">
                        <div class="si-check-system si-options-container" style="padding-top: 4px; border-left: 1px solid #e5e7eb; margin-left: 6.5px;">
                            <div class="si-options-list" style="margin-left: -5px;">
                                ${activeClass.options.map((opt, idx) => {
                                    const currentValues = Array.isArray(this.dynamicInputValues[activeClass.id] || instruction.text) ? (this.dynamicInputValues[activeClass.id] || instruction.text) : ((this.dynamicInputValues[activeClass.id] || instruction.text) ? (this.dynamicInputValues[activeClass.id] || instruction.text).split(', ') : []);
                                    const isChecked = currentValues.includes(opt);
                                    const shortcut = (activeClass.optionShortcuts) ? (activeClass.optionShortcuts[idx] || '') : '';
                                    return `
                                        <div class="si-option-row" onclick="window.app.handleChecklistSingleClick('${activeClass.id}', '${activeClass.name}', '${opt}')" style="cursor:pointer; margin-bottom:4px;">
                                            <div class="si-tree-h"></div>
                                            <label class="cursor-pointer flex items-center gap-2 w-full">
                                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}" style="border-radius: 3px;"></div>
                                                <span class="text-[13.5px] ${isChecked ? 'text-gray-800' : 'text-gray-500'}">${opt}</span>
                                                ${shortcut ? `<div class="kbd-key scale-90 ml-2">${shortcut}</div>` : ''}
                                            </label>
                                        </div>`;
                                }).join('')}
                            </div>
                        </div>
                    </div>
                ` : `
                <div class="flex items-center gap-2 pr-2" style="padding-left: 22.5px;">
                    <!-- 2. Input Wrapper with Purple Border (is-active) -->
                    <div class="single-input-field-wrapper is-active flex-1" style="min-height: 28px; display: flex; align-items: center;">
                        <textarea id="fullEditSidebarInput" rows="1"
                            class="single-input-textarea"
                            style="width: 100%; border: none; outline: none; background: transparent; font-size: 13px;"
                            oninput="window.app.handleDynamicInput(this, '${activeClass?.id}', '${activeClass?.name}', null, 'fullEdit-')">${this.dynamicInputValues[activeClass?.id] || instruction.text}</textarea>
                    </div>
                    
                    <!-- 3. Shortcut Badge -->
                    <span class="kbd-key shrink-0" style="color: #bfbfbf;">${activeClass?.shortcut || '1'}</span>
                </div>`}
            </div>
        </div>
    `;

            // Ensure the height adjusts immediately if there is text
            setTimeout(() => {
                this.syncTextareaHeight('fullEditSidebarInput', 22);
            }, 0);
        }
    }


    updateEditSidebarFrames() {
        if (this.editingAnnotationIndex === -1) return;
        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        const el = document.getElementById('editSidebarFrames');
        if (el && instruction) {
            el.innerHTML = this.formatClickableFrames(instruction.frames);
        }
    }

    closeFullEditSidebar() {
        this.editingAnnotationIndex = -1;
        // Hide the edit sidebar and show the regular ones
        document.getElementById('fullEditSidebar').classList.add('hidden');
        document.getElementById('classesSection').classList.remove('hidden');
        document.getElementById('labelsSection').classList.remove('hidden');
    }



    saveFullEditSidebar() {
        if (this.editingAnnotationIndex === -1) return;

        const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
        const activeClass = CONFIG.CLASSES.find(c => c.name === instruction.className);

        let newText = "";
        if (activeClass && activeClass.subInputs && activeClass.subInputs.length > 0) {
            const values = {};
            activeClass.subInputs.forEach(sub => {
                values[sub.id] = (this.dynamicInputValues[activeClass.id] && this.dynamicInputValues[activeClass.id][sub.id]) || "";
            });
            newText = JSON.stringify(values);
        } else {
            const input = document.getElementById('fullEditSidebarInput');
            newText = (this.dynamicInputValues[activeClass?.id] !== undefined && typeof this.dynamicInputValues[activeClass?.id] === 'string') ?
                this.dynamicInputValues[activeClass.id] : (input ? input.value : '');
        }

        if (newText.trim() === "") return;

        // Update the data model
        this.annotationModel.instructions[this.editingAnnotationIndex].text = newText;

        // Sync data and re-render the list
        this.renderInstructions();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        const output = document.getElementById('annotations_output');
        if (output) {
            output.value = JSON.stringify(this.annotationModel.getInstructions());
        }

        // Close the sidebar
        this.closeFullEditSidebar();
    }
    enterEditMode(index) {
        this.editingAnnotationIndex = index;
        this.renderInstructions(); // Re-render the list to show the edit UI
    }

    cancelInPlaceEdit() {
        this.editingAnnotationIndex = -1;
        this.renderInstructions(); // Re-render to revert to view mode
    }

    saveInPlaceEdit() {
        if (this.editingAnnotationIndex === -1) return;

        const input = document.getElementById(`inlineEditText-${this.editingAnnotationIndex}`);
        const newText = input.value;

        if (newText.trim() === "") return; // Prevent saving empty text

        // Update the data model
        this.annotationModel.instructions[this.editingAnnotationIndex].text = newText;

        // Reset the editing state
        this.editingAnnotationIndex = -1;

        // Re-render and sync data
        this.renderInstructions();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        const output = document.getElementById('annotations_output');
        if (output) {
            output.value = JSON.stringify(this.annotationModel.getInstructions());
        }

    }


    hideDeleteConfirmation() {
        const modal = document.getElementById('deleteConfirmationModal');
        // Re-hide the modal
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        // REMOVED: this.editingAnnotationIndex = -1; 
        // We keep the index so the sidebar remains stable if user cancels.
    }

    // ======================================================================= //
    // == END: NEW METHODS FOR EDIT/DELETE FUNCTIONALITY                    == //
    // ======================================================================= //

    initialize() {
        this.initializeComponents();
        this.setupEventListeners();
        this.setupKeyboardShortcuts();
        this.updateSettingsCheckmarks(); // Initial checkmark state

        // Inject Sidebar Exit Icon
        const exitIcon = document.getElementById('sidebarExitIcon');
        if (exitIcon) {
            exitIcon.innerHTML = SIDEBAR_EXIT_ARROW;
        }

        // Ensure UI is initialized with default values even before video loads
        if (this.frameInput) this.frameInput.value = this.formatDisplay(0);
        if (this.totalFramesText) this.totalFramesText.innerText = this.formatDisplay(0);

        if (this.annotationPanelView.elements.inputStart) {
            this.annotationPanelView.elements.inputStart.value = this.formatDisplay(0);
        }
        if (this.annotationPanelView.elements.inputEnd) {
            this.annotationPanelView.elements.inputEnd.value = this.formatDisplay(0);
        }
        if (this.annotationPanelView.elements.valLabelStart) {
            this.annotationPanelView.elements.valLabelStart.innerText = this.formatDisplay(0);
        }
        if (this.annotationPanelView.elements.valLabelEnd) {
            this.annotationPanelView.elements.valLabelEnd.innerText = this.formatDisplay(0);
        }

        this.loadVideo();

        // Initial filter state UI update
        this.updateFilterBadge();
        this.updateStatusIcons();

        // Ensure "Unresolved" checkmark is shown in the dropdown initially
        this.setInitialFilterUI();

        // Prevent dropdowns from closing when clicking inside them
        ['statusDropdownMenu', 'typeDropdownMenu', 'issueApplyToDropdownMenu', 'issueTagDropdownMenu'].forEach(id => {
            const menu = document.getElementById(id);
            if (menu) {
                menu.onclick = (e) => e.stopPropagation();
            }
        });

        // Restore State from previous annotations or SageMaker native restore
        let rawAnnotations = null;
        const outputField = document.getElementById('annotations_output');

        // 1. Check hidden input (SageMaker native restore point)
        if (outputField && outputField.value) {
            const value = outputField.value.trim();
            // Ignore unprocessed template tags or empty arrays
            const isUnprocessedTag = value.includes('{{') && value.includes('}}');
            if (value && value !== '[]' && !isUnprocessedTag) {
                rawAnnotations = value;
            }
        }
        // 2. Fallback to sageMakerData
        if (!rawAnnotations && window.sageMakerData && window.sageMakerData.prev_annotations) {
            const value = typeof window.sageMakerData.prev_annotations === 'string' ? window.sageMakerData.prev_annotations.trim() : '';
            const isUnprocessedTag = typeof value === 'string' && value.includes('{{') && value.includes('}}');
            if (value && value !== '[]' && !isUnprocessedTag) {
                rawAnnotations = window.sageMakerData.prev_annotations;
            }
        }

        if (rawAnnotations && rawAnnotations !== '[]') {
            try {
                let parsed = rawAnnotations;

                // Robust parsing for possible double-stringified JSON
                for (let i = 0; i < 2; i++) {
                    if (typeof parsed === 'string') {
                        // Trim whitespace before parsing
                        const trimmed = parsed.trim();
                        if (trimmed) {
                            parsed = JSON.parse(trimmed);
                        } else {
                            parsed = [];
                            break;
                        }
                    } else {
                        break;
                    }
                }

                // --- DATA ADAPTER START ---
                // Detect SageMaker/Custom format and convert to Internal Field-Mountain format
                let sourceArray = null;
                if (parsed && !Array.isArray(parsed) && Array.isArray(parsed.annotations)) {
                    sourceArray = parsed.annotations;
                } else if (Array.isArray(parsed) && parsed.length > 0 && !parsed[0].className && (parsed[0].segment_id || parsed[0].original_start_time)) {
                    sourceArray = parsed;
                }

                if (sourceArray) {
                    console.log("SageMaker/Custom format detected. Translating to Internal Format...");
                    parsed = sourceArray.map(ann => {
                        // Helper to convert MM:SS or HH:MM:SS to frames
                        const timeToFrame = (timeStr) => {
                            if (typeof timeStr !== 'string') return 0;
                            const parts = timeStr.split(':').map(Number);
                            const fps = CONFIG.FPS || 30;
                            if (parts.length === 2) return Math.round((parts[0] * 60 + parts[1]) * fps);
                            if (parts.length === 3) return Math.round((parts[0] * 3600 + parts[1] * 60 + parts[2]) * fps);
                            return parseInt(timeStr) || 0;
                        };

                        const startFrame = ann.frames ? parseInt(ann.frames.split(' - ')[0]) : timeToFrame(ann.original_start_time || ann.start_time);
                        const endFrame = ann.frames ? parseInt(ann.frames.split(' - ')[1]) : timeToFrame(ann.original_end_time || ann.end_time);

                        // Normalize common SageMaker keys to template IDs
                        // e.g., 'task' (SageMaker) -> 'task_name' (Template CONFIG)
                        const normalizedAnn = { ...ann };
                        if (ann.task && !ann.task_name) normalizedAnn.task_name = ann.task;

                        // If the text field is missing, use the normalized object
                        let textValue = ann.text;
                        if (!textValue) {
                            textValue = JSON.stringify(normalizedAnn);
                        }

                        return {
                            className: ann.className || 'Segment',
                            frames: `${startFrame} - ${endFrame}`,
                            text: textValue,
                            timestamp: ann.timestamp || Date.now()
                        };
                    });
                }
                // --- DATA ADAPTER END ---

                if (Array.isArray(parsed) && parsed.length > 0) {
                    console.log("Restoring annotations:", parsed);
                    this.annotationModel.setInstructions(parsed);
                    this.timelineView.renderTracks(this.annotationModel.getInstructions());
                    this.renderInstructions();

                    // Ensure hidden field matches loaded data
                    if (outputField) {
                        outputField.value = JSON.stringify(this.annotationModel.getInstructions());
                    }
                }
            } catch (e) {
                console.error("Error restoring annotations:", e, "Raw value:", rawAnnotations);
                // Set to empty array on error to allow the button to work
                if (outputField) {
                    outputField.value = '[]';
                }
            }
        }
    }

    initializeComponents() {
        const video = document.getElementById('mainVideo');

        // Core models and controllers
        this.videoController = new VideoController(video);
        this.transformManager = new VideoTransformManager(video);
        this.annotationModel = new AnnotationModel();
        this.dragState = new DragState();
        this.activeClassId = null; // Track which class is currently expanded
        this.dynamicInputValues = {}; // Track input values for persistence
        this.videoController.muted = false;

        // 1. First, render the sidebar classes based on CONFIG
        this.renderClassList();

        // Views
        this.progressBarView = new ProgressBarView(
            document.getElementById('progressFill'),
            document.getElementById('progressKnob'),
            document.getElementById('progressTrack'),
            document.getElementById('hoverPill')
        );

        this.timelineView = new TimelineView(
            document.getElementById('timeRuler'),
            document.getElementById('tracksContainer'),
            document.getElementById('vPlayhead'),
            {
                labelsBody: document.getElementById('labelsBody'),
                tracksContainer: document.getElementById('tracksContainer'),
                videoDataContainer: document.getElementById('videoTrackContainer'),
                videoLabelContainer: document.getElementById('videoLabelContainer')
            }
        );

        this.annotationPanelView = new AnnotationPanelView({
            overlay: document.getElementById('annotationOverlay'),
            videoBadge: document.querySelector('[onclick="copyVideoName()"]').parentElement,
            knobStart: document.getElementById('knobStart'),
            knobEnd: document.getElementById('knobEnd'),
            knobCurrent: document.getElementById('knobCurrent'),
            sliderHighlight: document.getElementById('sliderHighlight'),
            valLabelStart: document.getElementById('valLabelStart'),
            valLabelEnd: document.getElementById('valLabelEnd'),
            inputStart: document.getElementById('inputStartFrame'),
            inputEnd: document.getElementById('inputEndFrame'),
            staticLabelStart: document.getElementById('staticLabelStart'),
            staticLabelEnd: document.getElementById('staticLabelEnd'),
            currentBadge: document.getElementById('currentTextSpan'),
            activeClassTagDisplay: document.getElementById('activeClassTagDisplay')
        });

        this.instructionRenderer = new InstructionListRenderer(
            document.getElementById('instructionContainer')
        );

        // Utilities
        this.scrollSync = new ScrollSynchronizer(
            document.getElementById('timelineContentColumn'),
            document.getElementById('vPlayhead')
        );

        this.zoomToolManager = new ZoomToolManager(
            video.parentElement,
            this.transformManager
        );

        this.filterMenuManager = new FilterMenuManager(
            document.getElementById('filterMenu'),
            document.getElementById('filterBtn'),
            this.transformManager,
            {
                sliders: {
                    brightRange: document.getElementById('brightRange'),
                    contrastRange: document.getElementById('contrastRange'),
                    gammaRange: document.getElementById('gammaRange')
                },
                subMenu: document.getElementById('filterSubMenu'),
                subTrigger: document.getElementById('filterSubTrigger'),
                pixelToggle: document.getElementById('pixelatedToggle')
            }
        );
        this.filterMenuManager.initialize();

        this.rotateMenuManager = new MenuManager(
            document.getElementById('rotateMenu'),
            document.getElementById('rotateDropdownBtn')
        );

        this.settingsMenuManager = new SettingsMenuManager(
            document.getElementById('settingsMenu'),
            document.getElementById('moreActionBtn'),
            {
                subMenu: document.getElementById('frameSkipSubMenu'),
                subTrigger: document.getElementById('frameSkipTrigger'),
                timestampSubMenu: document.getElementById('timestampFormatSubMenu'),
                timestampTrigger: document.getElementById('timestampFormatTrigger'),
                pillMenu: document.getElementById('frameSkipSelectorPill'),
                pillOptionsContainer: document.getElementById('frameSkipOptionsContainer'),
                pillDisplay: document.getElementById('currentFrameSkipDisplay')
            }
        );
        this.settingsMenuManager.initialize();

        this.speedMenuManager = new SpeedMenuManager(
            this.videoController,
            document.getElementById('currentSpeedBtn'),
            document.getElementById('speedMenu')
        );

        // Element references
        this.frameInput = document.getElementById('currentFrameInput');
        this.totalFramesText = document.getElementById('totalFramesText');

        // SYNC VERTICAL SCROLL
        const tracksArea = document.getElementById('tracksContainer');
        const labelsArea = document.getElementById('labelsBody');
        if (tracksArea && labelsArea) {
            tracksArea.addEventListener('scroll', () => {
                labelsArea.scrollTop = tracksArea.scrollTop;
            });
        }
        // Add this at the end of initializeComponents() in VideoAnnotationApp class:
        document.getElementById('videoTransformWrapper')?.addEventListener('click', (e) => this.handleVideoClick(e));
        const tooltipEl = document.getElementById('timelineTooltip');
        if (tooltipEl) {
            tooltipEl.onmouseenter = () => {
                clearTimeout(this.tooltipTimeout); // User is inside, don't hide
            };
            tooltipEl.onmouseleave = () => {
                this.tooltipTimeout = setTimeout(() => {
                    tooltipEl.classList.remove('is-active');
                }, 300); // User left, hide after delay
            };
        }
    }

    // --- NEW DYNAMIC CLASS METHODS (Defined outside initializeComponents) ---

    renderClassList() {
        const container = document.getElementById('classListContainer');
        if (!container) return;

        container.innerHTML = CONFIG.CLASSES.map(cls => {
            const hasSubInputs = cls.subInputs && cls.subInputs.length > 0;
            const isActiveClass = (this.activeClassId === cls.id);
            let inputAreaContent = "";

            // --- 1. MULTI-INPUT (TREE UI) - e.g. TwoInput AND Mixed ---
            if (hasSubInputs && cls.subInputs.length >= 2) {
                const isDisabled = !isActiveClass;
                const itemsHtml = cls.subInputs.map((sub, idx) => {
                    const groupKey = `${cls.id}-${sub.id}`;
                    const isExpanded = this.expandedSubGroups[groupKey] === true;
                    const isActive = (this.activeSubInputKey === groupKey);
                    const isLast = idx === cls.subInputs.length - 1;
                    let storedVal = (this.dynamicInputValues[cls.id] && this.dynamicInputValues[cls.id][sub.id]) || '';

                    let innerContent = '';
                    if (!sub.type || sub.type === 'text' || sub.type === 'dropdown') {
                        innerContent = `
                            <div class="tree-elbow-line"></div>
                            <div class="flex items-center gap-2">
                                <span class="tree-nested-label">${sub.label}</span>
                                ${isActive ? `
                                    <div class="si-clear-btn cursor-pointer" onclick="window.app.clearSubInput(event, '${cls.id}', '${sub.id}', true)">
                                        ${CLOSE_CIRCLE_SVG}
                                    </div>
                                ` : ''}
                            </div>
                            <div class="flex items-center gap-2 pr-2">
                                ${(!sub.type || sub.type === 'text') ? `
                                <div class="tree-input-field-wrapper ${isActive ? 'is-active' : ''} flex-1">
                                    <textarea id="input-field-${cls.id}-${sub.id}" name="input-field-${cls.id}-${sub.id}" 
                                        class="tree-input-textarea" placeholder="Type..." rows="1"
                                        ${!isActive ? 'disabled' : ''}
                                        oninput="window.app.handleDynamicInput(this, '${cls.id}', '${cls.name}', '${sub.id}')">${storedVal}</textarea>
                                </div>
                                ${isActive && sub.optionShortcuts && sub.optionShortcuts[0] ? `
                                    <div class="kbd-key shrink-0 text-[10px] scale-90" style="color: #bfbfbf;">${sub.optionShortcuts[0]}</div>
                                ` : ''}
                                ` : `
                                <div class="flex-1" style="margin-left: 16px; margin-bottom: 4px; padding-right: 4px;">${this.renderSubInput(cls, sub, isActive, storedVal)}</div>
                                `}
                            </div>
                        `;
                    } else {
                        innerContent = this.renderSubInput(cls, sub, isActive, storedVal);
                    }

                    return `
                    <div class="tree-item-block ${isLast ? 'is-last' : ''}">
                        <div class="tree-item-spine"></div>
                        <div class="tree-item-header">
                            <div class="tree-toggle-btn" onclick="window.app.toggleSubGroup(event, '${cls.id}', '${sub.id}')">
                                ${isExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
                            </div>
                            <div class="custom-radio-circle ${isActive ? 'is-active' : ''} ${isDisabled ? 'is-disabled' : ''}" 
                                 onclick="${isDisabled ? '' : `window.app.selectSubGroup('${cls.id}', '${sub.id}')`}">
                            </div>
                            <div class="flex items-center gap-2 flex-1 ${isDisabled ? 'cursor-not-allowed' : 'cursor-pointer'}" 
                                 onclick="${isDisabled ? '' : `window.app.selectSubGroup('${cls.id}', '${sub.id}')`}">
                                <span class="text-[13px] text-gray-800 font-[400]">${sub.name}</span>
                                <span class="kbd-key text-[10px] scale-90">${sub.shortcut}</span>
                            </div>
                        </div>
                        <div class="tree-expanded-area ${isExpanded ? '' : 'hidden'}">
                            ${innerContent}
                        </div>
                    </div>`;
                }).join('');

                inputAreaContent = `<div class="tree-container-wrapper">${itemsHtml}</div>`;
            }
            // --- 2. SINGLE INPUT ---
            else if (!hasSubInputs) {
                let storedVal = this.dynamicInputValues[cls.id] || '';
                const baseType = cls.type || 'text';

                if (baseType === 'text') {
                    inputAreaContent = `
                        <div class="single-input-container">
                            <div class="single-input-content" style="align-items: flex-start; margin-top: 4px;">
                                <div class="single-input-elbow"></div>
                                <div class="single-input-row" style="width: 100%;">
                                    <div class="single-input-field-wrapper is-active" style="flex:1;">
                                        <textarea id="input-field-${cls.id}" name="input-field-${cls.id}" class="single-input-textarea" placeholder="Type..." rows="1"
                                            oninput="window.app.handleDynamicInput(this, '${cls.id}', '${cls.name}')">${storedVal}</textarea>
                                    </div>
                                    <div class="kbd-key">${cls.shortcut || ''}</div>
                                </div>
                            </div>
                        </div>
                    `;
                } else if (baseType === 'dropdown') {
                    // --- SINGLE DROPDOWN (SYNCHRONIZED WITH FULL EDIT) ---
                    inputAreaContent = `
                        <div class="tree-expanded-area" style="position: relative; padding-left: 0; margin-top: 4px;">
                            <div class="tree-elbow-line" style="left: 6.5px; top: -14px; height: 26px;"></div>
                            <div style="padding-left: 22.5px; padding-right: 12px; width: 100%;">
                                ${this.renderDropDown(cls, cls, isActiveClass, storedVal)}
                            </div>
                        </div>
                    `;
                } else if (baseType === 'radio' && cls.options) {
                    inputAreaContent = `
                        <div class="si-radio-system si-options-container" style="padding-top: 4px;">
                            <div class="si-options-list" style="margin-left: -5px;">
                                <div class="si-tree-v" style="bottom: 14px; top: -14px;"></div>
                                ${cls.options.map((opt, idx) => {
                        const isChecked = storedVal === opt;
                        const shortcut = (cls.optionShortcuts) ? (cls.optionShortcuts[idx] || '') : '';
                        return `
                                        <div class="si-option-row" onclick="window.app.handleRadioSingleClick('${cls.id}', '${cls.name}', '${opt}')" style="cursor:pointer; margin-bottom:4px;">
                                            <div class="si-tree-h"></div>
                                            <label class="cursor-pointer flex items-center gap-2 w-full">
                                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}"></div>
                                                <span class="text-[13.5px] ${isChecked ? 'text-gray-800' : 'text-gray-500'}">${opt}</span>
                                                ${shortcut ? `<div class="kbd-key scale-90 ml-2">${shortcut}</div>` : ''}
                                            </label>
                                        </div>`;
                    }).join('')}
                            </div>
                        </div>
                    `;
                } else if (baseType === 'checklist' && cls.options) {
                    const currentValues = Array.isArray(storedVal) ? storedVal : (storedVal ? storedVal.split(', ') : []);
                    inputAreaContent = `
                        <div class="si-check-system si-options-container" style="padding-top: 4px;">
                            <div class="si-options-list" style="margin-left: -5px;">
                                <div class="si-tree-v" style="bottom: 14px; top: -14px;"></div>
                                ${cls.options.map((opt, idx) => {
                        const isChecked = currentValues.includes(opt);
                        const shortcut = (cls.optionShortcuts) ? (cls.optionShortcuts[idx] || '') : '';
                        return `
                                        <div class="si-option-row" onclick="window.app.handleChecklistSingleClick('${cls.id}', '${cls.name}', '${opt}')" style="cursor:pointer; margin-bottom:4px;">
                                            <div class="si-tree-h"></div>
                                            <label class="cursor-pointer flex items-center gap-2 w-full">
                                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}" style="border-radius: 3px;"></div>
                                                <span class="text-[13.5px] ${isChecked ? 'text-gray-800' : 'text-gray-500'}">${opt}</span>
                                                ${shortcut ? `<div class="kbd-key scale-90 ml-2">${shortcut}</div>` : ''}
                                            </label>
                                        </div>`;
                    }).join('')}
                            </div>
                        </div>
                    `;
                }
            }
            // --- 3. OTHER TYPES (Radio/Checklist/Dropdown) ---
            else {
                const isDisabled = !isActiveClass;
                inputAreaContent = cls.subInputs.map((sub, idx) => {
                    const groupKey = `${cls.id}-${sub.id}`;
                    const isExpanded = this.expandedSubGroups[groupKey] === true;
                    const isActive = (this.activeSubInputKey === groupKey);
                    let storedVal = (this.dynamicInputValues[cls.id] && this.dynamicInputValues[cls.id][sub.id]) || '';

                    return `
                    <div class="sub-group-wrapper ${idx === cls.subInputs.length - 1 ? 'is-last' : ''}">
                        <div class="sub-group-header-row">
                            <div class="collapse-btn" onclick="window.app.toggleSubGroup(event, '${cls.id}', '${sub.id}')">
                                ${isExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
                            </div>
                            <div class="custom-radio-circle ${isActive ? 'is-active' : ''} ${isDisabled ? 'is-disabled' : ''}" 
                                 onclick="${isDisabled ? '' : `window.app.selectSubGroup('${cls.id}', '${sub.id}')`}">
                            </div>
                            <div class="flex items-center gap-1.5 flex-1 ${isDisabled ? 'cursor-not-allowed' : 'cursor-pointer'}" 
                                 onclick="${isDisabled ? '' : `window.app.selectSubGroup('${cls.id}', '${sub.id}')`}">
                                <span class="text-[13px] text-gray-800 font-[450]">${sub.name}</span>
                                <div class="kbd-key scale-90">${sub.shortcut || ''}</div>
                            </div>
                        </div>
                        <div class="sub-group-content ${isExpanded ? '' : 'hidden'}">
                            ${(sub.type === 'dropdown') ? `
                                <div class="tree-expanded-area" style="position: relative; padding-left: 0;">
                                    <div class="tree-elbow-line" style="left: 22.5px; top: -6px; height: 16px;"></div>
                                    <div class="flex items-center gap-2 mb-1" style="padding-left: 41px;">
                                        <span class="tree-nested-label" style="padding-left: 0; margin: 0; color: #9ca3af; font-size: 13px;">${sub.label || sub.name}</span>
                                        ${isActive ? `<div class="si-clear-btn cursor-pointer ml-1" onclick="window.app.clearSubInput(event, '${cls.id}', '${sub.id}', true)">${CLOSE_CIRCLE_SVG}</div>` : ''}
                                    </div>
                                    <div style="padding-left: 45px; padding-right: 8px; padding-bottom: 4px;">
                                        ${this.renderSubInput(cls, sub, isActive, storedVal)}
                                    </div>
                                </div>
                            ` : this.renderSubInput(cls, sub, isActive, storedVal)}
                        </div>
                    </div>`;
                }).join('');
            }

            return `
            <div class="class-group mb-1">
                <div onclick="window.app.toggleDynamicClassInput('${cls.id}')" class="flex justify-between items-center p-1 pl-2 rounded-md cursor-pointer hover:bg-gray-100 transition-colors">
                    <div class="flex items-center gap-2 text-[14px] text-gray-800">
                        <div class="text-gray-20 flex items-center justify-center">${PARTITION_ICON_SVG}</div>
                        ${cls.name}
                    </div>
                    <div class="flex items-center gap-2">
                        ${isActiveClass ? `
                            <div onclick="event.stopPropagation(); window.app.clearDynamicClassInput('${cls.id}')"
                                 class="text-gray-300 hover:text-gray-500 cursor-pointer flex items-center justify-center mr-1">
                                ${CLOSE_CIRCLE_FILLED_SVG}
                            </div>` : ''}
                        <div class="kbd-key">${cls.classShortcut || ''}</div>
                    </div>
                </div>
                <div id="input-area-${cls.id}" class="${isActiveClass ? '' : 'hidden'}">
                    ${inputAreaContent}
                </div>
            </div>`;
        }).join('');

        // Sync heights for all textareas
        setTimeout(() => {
            container.querySelectorAll('textarea').forEach(ta => {
                this.syncTextareaHeight(ta.id, 22);
            });
        }, 0);
    }

    toggleDynamicClassInput(classId) {
        if (this.activeClassId === classId) {
            this.activeClassId = null;
        } else {
            this.activeClassId = classId;

            // Do NOT auto-select or auto-expand first sub-input. Leave them unselected/minimized.
            const cls = CONFIG.CLASSES.find(c => c.id === classId);
            if (cls && cls.subInputs && cls.subInputs.length > 0) {
                this.activeSubInputKey = null; // Ensure nothing is selected initially
            }
        }

        this.renderClassList();

        // Focus the input after re-render
        setTimeout(() => {
            const area = document.getElementById(`input-area-${classId}`);
            if (area && !area.classList.contains('hidden')) {
                area.querySelector('textarea')?.focus();
            }
        }, 0);
    }
    handleDropdownFocus(classId, subId, state) {
        const key = `${classId}-${subId}`;
        if (state) {
            // If already open, don't do anything
            if (this.openDropdownId === key) return;

            this.focusedDropdownId = key;
            this.openDropdownId = key;
            this.activeSubInputKey = key;
            if (!this.dropdownFilterTerms) this.dropdownFilterTerms = {};
            this.dropdownFilterTerms[key] = '';

            // Re-render to show the menu
            this.renderClassList();
        } else {
            // Blur: Wait a bit to see if we clicked an option
            setTimeout(() => {
                // If the user clicked inside the menu or container, don't close via blur
                const activeEl = document.activeElement;
                if (activeEl && activeEl.id === `drop-input-${key}`) return;

                // Only close if focus truly left the component
                if (this.focusedDropdownId === key) {
                    this.focusedDropdownId = null;
                    this.openDropdownId = null;
                    this.renderClassList();
                }
            }, 200);
        }
    }

    handleDropdownSearch(event, classId, subId, idPrefix = '') {
        const key = `${idPrefix}${classId}-${subId}`;
        if (!this.dropdownFilterTerms) this.dropdownFilterTerms = {};
        this.dropdownFilterTerms[key] = event.target.value;

        if (idPrefix === 'fullEdit-') {
            this.renderFullEditSidebarContent();
        } else {
            this.renderClassList();
        }

        // Keep cursor at end
        const input = document.getElementById(`drop-input-${key}`);
        if (input) {
            input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
        }
    }

    clearDropdownSelection(event, classId, subId, className, idPrefix = '') {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }

    if (!this.dynamicInputValues) return;
    
    const cls = CONFIG.CLASSES.find(c => c.id === classId);
    const hasSubInputs = cls && cls.subInputs && cls.subInputs.length > 0;

    if (hasSubInputs) {
        if (this.dynamicInputValues[classId]) {
            this.dynamicInputValues[classId][subId] = '';
        }
    } else {
        this.dynamicInputValues[classId] = '';
    }

    const key = `${idPrefix}${classId}-${subId}`;
    if (this.dropdownFilterTerms) this.dropdownFilterTerms[key] = '';

    if (idPrefix === 'fullEdit-') {
        this.renderFullEditSidebarContent();
    } else {
        this.renderClassList();
        this.syncAnnotationPanel(classId, className);
    }
}

    handleCustomSelect(classId, className, subInputId, value, idPrefix = '') {
    if (!this.dynamicInputValues) this.dynamicInputValues = {};
    
    // Check if this class actually uses sub-inputs or if it's a top-level dropdown
    const cls = CONFIG.CLASSES.find(c => c.id === classId);
    const hasSubInputs = cls && cls.subInputs && cls.subInputs.length > 0;

    if (hasSubInputs) {
        // Multi-input: store as key-value pair inside an object
        if (typeof this.dynamicInputValues[classId] !== 'object') this.dynamicInputValues[classId] = {};
        this.dynamicInputValues[classId][subInputId] = value;
    } else {
        // Single-input: store directly as a string
        this.dynamicInputValues[classId] = value;
    }

    this.openDropdownId = null;
    this.focusedDropdownId = null;

    if (idPrefix === 'fullEdit-') {
        this.renderFullEditSidebarContent();
    } else {
        this.renderClassList();
        this.syncAnnotationPanel(classId, className);
    }
}
    toggleSearchableDropdown(event, classId, subId, idPrefix = '') {
    const key = `${idPrefix}${classId}-${subId}`;

    if (event.target.closest('.clear-selection-btn')) return;

    // If it's already open, don't restart the logic
    if (this.openDropdownId === key) {
        event.stopPropagation();
        return;
    }

    event.stopPropagation(); // Prevent the mousedown listener above from triggering

    this.hideAllMenus();
    this.openDropdownId = key;
    this.focusedDropdownId = key;
    this.activeSubInputKey = key;

    if (idPrefix === 'fullEdit-') {
        this.renderFullEditSidebarContent();
    } else {
        this.renderClassList();
    }

    setTimeout(() => {
        document.getElementById(`drop-input-${key}`)?.focus();
    }, 50);
}
    toggleSubGroup(event, classId, subId, idPrefix = '') {
        if (event) event.stopPropagation();
        const groupKey = `${idPrefix}${classId}-${subId}`;
        this.expandedSubGroups[groupKey] = this.expandedSubGroups[groupKey] === false ? true : false;

        if (idPrefix === 'fullEdit-') {
            this.renderFullEditSidebarContent();
        } else {
            this.renderClassList();
        }
    }

    selectSubGroup(classId, subId, idPrefix = '') {
        const groupKey = `${idPrefix}${classId}-${subId}`;

        // Toggle selection if already active
        if (this.activeSubInputKey === groupKey) {
            this.activeSubInputKey = null;
        } else {
            this.activeSubInputKey = groupKey;
            // Expand if it was collapsed (Maximize on select)
            this.expandedSubGroups[groupKey] = true;
        }

        if (idPrefix === 'fullEdit-') {
            this.renderFullEditSidebarContent();
        } else {
            this.renderClassList();
        }

        // Focus the newly active textarea
        if (this.activeSubInputKey === groupKey) {
            setTimeout(() => {
                const textarea = document.getElementById(`input-field-${idPrefix}${classId}-${subId}`);
                if (textarea) {
                    textarea.focus();
                }
            }, 10);
        }
    }

    clearSubInput(event, classId, subId, keepSelected = false, idPrefix = '') {
        if (event) event.stopPropagation();
        if (!this.dynamicInputValues[classId]) return;

        // 1. Clear the value in the state object
        this.dynamicInputValues[classId][subId] = '';

        // 2. IMPORTANT: Keep the sidebar expanded and focused
        const groupKey = `${idPrefix}${classId}-${subId}`;
        this.activeSubInputKey = groupKey;
        this.expandedSubGroups[groupKey] = true;

        // 3. Re-render the correct list
        if (idPrefix === 'fullEdit-') {
            this.renderFullEditSidebarContent();
        } else {
            this.renderClassList();
        }

        // 4. Check if there is ANY content left in other sub-inputs for this class
        const values = this.dynamicInputValues[classId];
        const hasAnyContent = Object.values(values).some(v => v && v.trim().length > 0);

        if (!hasAnyContent) {
            // Only hide the bottom panel visuals, don't reset the sidebar
            this.annotationPanelView.hide();
            this.annotationModel.deactivate();
            this.sliderRanges = [];
        } else {
            // If other sub-inputs still have text, just update the bottom panel tag
            const className = CONFIG.CLASSES.find(c => c.id === classId).name;
            this.syncAnnotationPanel(classId, className);
        }

        // 5. Refocus the input so the user can type again immediately
        setTimeout(() => {
            document.getElementById(`input-field-${classId}-${subId}`)?.focus();
        }, 10);
    }

    renderSubInput(cls, sub, isActive, storedVal, idPrefix = '') {
        const type = sub.type || 'text';
        const id = `input-field-${idPrefix}${cls.id}-${sub.id}`;
        const isEdit = idPrefix !== '';

        switch (type) {
            case 'radio':
                return this.renderRadioGroup(cls, sub, isActive, storedVal, idPrefix);
            case 'dropdown':
                return this.renderDropDown(cls, sub, isActive, storedVal, idPrefix);
            case 'checklist':
                return this.renderChecklist(cls, sub, isActive, storedVal, idPrefix);
            default:
                const eventHandler = isEdit ? '' : `oninput="window.app.handleDynamicInput(this, '${cls.id}', '${cls.name}', '${sub.id}')"`;
                return `
                <textarea id="${id}"
                    name="annotation_value_${idPrefix}${cls.id}_${sub.id}"
                    data-sub-id="${sub.id}"
                    placeholder="Type..." rows="1"
                    class="sub-input-textarea"
                    ${!isActive ? 'disabled' : ''} 
                    ${eventHandler}>${storedVal}</textarea>
            `;
        }
    }

    renderRadioGroup(cls, sub, isActive, storedVal, idPrefix = '') {
        const isEdit = idPrefix !== '';
        const isFullEdit = idPrefix === 'fullEdit-';
        // Define shortcuts variable correctly
        const shortcuts = sub.optionShortcuts || [];

        if (isFullEdit) {
            const internalKey = `fullEditInternal-${cls.id}-${sub.id}`;
            const isSubExpanded = this.expandedSubGroups[internalKey] !== false;

            return `
        <div style="position: relative; margin-left: 22.5px; margin-top: -6px; pointer-events: auto;">
            <div style="position: absolute; left: 6.5px; top: -10px; width: 1px; height: 16px; background: #e5e7eb; z-index: 1;"></div>
            <div class="flex items-center gap-2 h-[28px] relative" style="z-index: 10; background: white;">
                <div class="flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded" 
                     style="width: 18px; height: 18px; margin-left: -2.5px; color: #374151;"
                     onclick="event.stopPropagation(); window.app.toggleSubGroup(event, '${cls.id}', '${sub.id}', 'fullEditInternal-'); window.app.renderFullEditSidebarContent();">
                    ${isSubExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
                </div>
                <span class="text-gray-300 text-[13px] font-normal">${sub.label}</span>
                ${isActive ? `<div class="si-clear-btn" onclick="window.app.clearSubInput(event, '${cls.id}', '${sub.id}', true, '${idPrefix}')">${CLOSE_CIRCLE_SVG}</div>` : ''}
            </div>
            <div class="${isSubExpanded ? '' : 'hidden'} relative" style="padding-top: 2px; margin-left:27px;">
                <div style="position: absolute; left: 6.5px; top: -2px; bottom: 14px; width: 1px; background: #e5e7eb; z-index: 1;"></div>
                ${sub.options.map((opt, idx) => {
                const isChecked = storedVal === opt;
                const shortcut = shortcuts[idx] || ''; // Fixed variable name
                return `
                    <div class="flex items-center h-[28px] relative ${!isActive ? 'opacity-50 pointer-events-none' : ''}" 
                         onmousedown="if(${isActive}) { window.app.handleRadioChange({value: '${opt}'}, '${cls.id}', '${cls.name}', '${sub.id}', '${idPrefix}'); window.app.renderFullEditSidebarContent(); }">
                        <div style="position: absolute; left: 6.5px; width: 11px; height: 1px; background: #e5e7eb; top: 14px; z-index: 1;"></div>
                        <label class="flex items-center gap-2 ${isActive ? 'cursor-pointer' : 'cursor-default'} w-full" style="padding-left: 24px; z-index: 2;">
                            <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}"></div>
                            <span class="text-[13.5px] ${isChecked ? 'text-gray-800' : 'text-gray-500'}">${opt}</span>
                            ${shortcut ? `<div class="kbd-key scale-90 mr-1">${shortcut}</div>` : ''}
                        </label>
                    </div>`;
            }).join('')}
            </div>
        </div>`;
        }

        const internalKey = `${idPrefix}internal-${cls.id}-${sub.id}`;
        const isSubExpanded = this.expandedSubGroups[internalKey] !== false;

        return `
    <div class="si-system-container si-radio-system ${!isActive ? 'opacity-60' : ''}">
        <div class="si-header-row">
            <div class="si-collapse-btn" onclick="window.app.toggleSubGroup(event, '${cls.id}', '${sub.id}', '${idPrefix}internal-')">
                ${isSubExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
            </div>
            <span class="text-gray-400 !font-normal">${sub.label}</span>
            ${isActive ? `<div class="si-clear-btn ml-1" onclick="window.app.clearSubInput(event, '${cls.id}', '${sub.id}', true)">${CLOSE_CIRCLE_SVG}</div>` : ''}
        </div>
        <div class="si-options-container ${!isSubExpanded ? 'hidden' : ''} ${!isActive ? 'pointer-events-none' : ''}">
            <div class="si-options-list">
                <div class="si-tree-v"></div>
                ${sub.options.map((opt, idx) => {
            const isChecked = storedVal === opt;
            const shortcut = shortcuts[idx] || '';
            return `
                        <div class="si-option-row" onclick="window.app.handleRadioCircleClick('${cls.id}', '${cls.name}', '${sub.id}', '${opt}')">
                            <div class="si-tree-h"></div>
                            <label class="${isActive ? 'cursor-pointer' : 'cursor-default'}">
                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}"></div>
                                <span>${opt}</span>
                                ${shortcut ? `<div class="kbd-key ml-2">${shortcut}</div>` : ''}
                            </label>
                        </div>`;
        }).join('')}
            </div>
        </div>
    </div>`;
    }

    renderDropDown(cls, sub, isActive, storedVal, idPrefix = '') {
        const groupKey = `${idPrefix}${cls.id}-${sub.id}`;
        const isOpen = this.openDropdownId === groupKey;
        const isFocused = this.focusedDropdownId === groupKey;
        const filterTerm = this.dropdownFilterTerms?.[groupKey] || '';

        // Choose icon based on focus state
        let mainIcon = isFocused ? DROPDOWN_SEARCH_SVG : DROPDOWN_DOWN_SVG;

        const filteredOptions = sub.options.filter(opt =>
            opt.toLowerCase().includes(filterTerm.toLowerCase())
        );

        return `
        <div class="searchable-dropdown-wrap" style="padding-left: 0; padding-right: 0; margin-top: 0;">
            <div class="searchable-input-container ${isOpen ? 'is-active' : ''} ${!isActive ? 'opacity-50 pointer-events-none' : ''} ${storedVal ? 'has-value' : ''}"
                 onmousedown="window.app.toggleSearchableDropdown(event, '${cls.id}', '${sub.id}', '${idPrefix}')">
                
                <input type="text" 
                    id="drop-input-${groupKey}"
                    placeholder="Search or select..." 
                    value="${isFocused ? filterTerm : (storedVal || '')}"
                    onfocus="this.select()"
                    oninput="window.app.handleDropdownSearch(event, '${cls.id}', '${sub.id}', '${idPrefix}')"
                    ${!isActive ? 'disabled' : ''}
                    autocomplete="off">
                
                <div class="dropdown-icon-stack">
                    <span class="expand-icon">${mainIcon}</span>
                </div>
                
                <!-- The Clear (X) Button -->
                <div class="clear-selection-btn" onmousedown="window.app.clearDropdownSelection(event, '${cls.id}', '${sub.id}', '${cls.name}', '${idPrefix}')">
                    ${CLOSE_CIRCLE_FILLED_SVG}
                </div>
            </div>

            ${isOpen ? `
                <div class="searchable-menu" onmousedown="event.preventDefault()">
                    ${filteredOptions.length > 0 ? filteredOptions.map(opt => `
                        <div class="searchable-opt ${storedVal === opt ? 'selected' : ''}" 
                             onmousedown="event.preventDefault(); window.app.handleCustomSelect('${cls.id}', '${cls.name}', '${sub.id}', '${opt}', '${idPrefix}')">
                            <span>${opt}</span>
                            ${storedVal === opt ? '<span class="check-mark">✓</span>' : ''}
                        </div>
                    `).join('') : '<div class="px-3 py-2 text-gray-400 text-[12px] text-center">No results found</div>'}
                </div>
            ` : ''}
        </div>
    `;
    }


    renderChecklist(cls, sub, isActive, storedVal, idPrefix = '') {
        const isFullEdit = idPrefix === 'fullEdit-';
        const currentValues = Array.isArray(storedVal) ? storedVal : (storedVal ? storedVal.split(', ') : []);
        const shortcuts = sub.optionShortcuts || [];

        // FIX: Define groupKey and isExpanded at the top so they are available to both views
        const groupKey = `${idPrefix}${cls.id}-${sub.id}`;
        const isExpanded = this.expandedSubGroups[groupKey] !== false;

        if (isFullEdit) {
            const internalKey = `fullEditInternal-${cls.id}-${sub.id}`;
            const isSubExpanded = this.expandedSubGroups[internalKey] !== false;

            return `
        <div class="si-system-container si-check-system" style="margin-top: -4px;">
            <div class="si-header-row">
                <div class="si-collapse-btn" onclick="event.stopPropagation(); window.app.toggleSubGroup(event, '${cls.id}', '${sub.id}', 'fullEditInternal-'); window.app.renderFullEditSidebarContent();">
                    ${isSubExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
                </div>
                <span class="text-gray-400 !font-normal">${sub.name}</span>
                ${isActive ? `<div class="si-clear-btn ml-1" onclick="window.app.clearSubInput(event, '${cls.id}', '${sub.id}', true, '${idPrefix}')">${CLOSE_CIRCLE_SVG}</div>` : ''}
            </div>
            <div class="${isSubExpanded ? '' : 'hidden'} si-options-container">
                <div class="si-options-list">
                    <div class="si-tree-v" style="bottom: 14px;"></div>
                    ${sub.options.map((opt, idx) => {
                const isChecked = currentValues.includes(opt);
                const shortcut = shortcuts[idx] || '';
                return `
                        <div class="si-option-row" onmousedown="window.app.handleChecklistChange({checked: ${!isChecked}, value: '${opt}'}, '${cls.id}', '${cls.name}', '${sub.id}', '${idPrefix}'); window.app.renderFullEditSidebarContent();">
                            <div class="si-tree-h"></div>
                            <label>
                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}" style="border-radius: 3px;"></div>
                                <span>${opt}</span>
                                ${shortcut ? `<div class="kbd-key mr-1">${shortcut}</div>` : ''}
                            </label>
                        </div>`;
            }).join('')}
                </div>
            </div>
        </div>`;
        }

        const internalKey = `${idPrefix}internal-${cls.id}-${sub.id}`;
        const isSubExpanded = this.expandedSubGroups[internalKey] !== false;

        // Standard sidebar view
        return `
    <div class="si-system-container si-check-system">
        <div class="si-header-row">
            <!-- FIXED: Added onclick and dynamic icon selection -->
            <div class="si-collapse-btn" onclick="window.app.toggleSubGroup(event, '${cls.id}', '${sub.id}', '${idPrefix}internal-')">
                ${isSubExpanded ? EXPAND_MINUS_SVG : EXPAND_PLUS_SVG}
            </div>
            <span class="text-gray-400 !font-normal">${sub.name || sub.label}</span>
            ${isActive ? `<div class="si-clear-btn ml-1" onclick="window.app.clearSubInput(event, '${cls.id}', '${sub.id}', true)">${CLOSE_CIRCLE_SVG}</div>` : ''}
        </div>
        <!-- FIXED: Added dynamic hidden class -->
        <div class="si-options-container ${isSubExpanded ? '' : 'hidden'}">
            <div class="si-options-list">
                <div class="si-tree-v"></div>
                ${sub.options.map((opt, idx) => {
            const isChecked = currentValues.includes(opt);
            const shortcut = shortcuts[idx] || '';
            return `
                        <div class="si-option-row" onclick="window.app.handleChecklistSquareClick('${cls.id}', '${cls.name}', '${sub.id}', '${opt}')">
                            <div class="si-tree-h"></div>
                            <label class="${isActive ? 'cursor-pointer' : 'cursor-default'}">
                                <div class="custom-radio-circle ${isChecked ? 'is-active' : ''}" style="border-radius: 3px;"></div>
                                <span>${opt}</span>
                                ${shortcut ? `<div class="kbd-key ml-2">${shortcut}</div>` : ''}
                            </label>
                        </div>`;
        }).join('')}
            </div>
        </div>
    </div>`;
    }

    handleRadioChange(input, classId, className, subInputId, idPrefix = '') {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};
        if (!this.dynamicInputValues[classId]) this.dynamicInputValues[classId] = {};

        // Requirement: Toggling logic
        if (this.dynamicInputValues[classId][subInputId] === input.value) {
            this.dynamicInputValues[classId][subInputId] = "";
        } else {
            this.dynamicInputValues[classId][subInputId] = input.value;
        }

        if (idPrefix !== 'fullEdit-') {
            this.syncAnnotationPanel(classId, className);
        }
    }

    handleRadioCircleClick(classId, className, subInputId, value, idPrefix = '') {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};
        if (!this.dynamicInputValues[classId]) this.dynamicInputValues[classId] = {};

        const groupKey = `${idPrefix}${classId}-${subInputId}`;

        // Requirement: Only allow selection if the group is actually active/expanded
        // If clicking manually via UI, we set it as active first if it wasn't
        if (this.activeSubInputKey !== groupKey) {
            this.activeSubInputKey = groupKey;
            this.expandedSubGroups[groupKey] = true;
        }

        // Toggling logic: if already selected, clear it
        if (this.dynamicInputValues[classId][subInputId] === value) {
            this.dynamicInputValues[classId][subInputId] = "";
        } else {
            this.dynamicInputValues[classId][subInputId] = value;
        }

        this.renderClassList();
        this.renderFullEditSidebarContent();
        this.syncAnnotationPanel(classId, className);
    }

    handleChecklistSquareClick(classId, className, subInputId, value, idPrefix = '') {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};
        if (!this.dynamicInputValues[classId]) this.dynamicInputValues[classId] = {};

        const groupKey = `${idPrefix}${classId}-${subInputId}`;

        // Ensure group is active if clicking manually
        if (this.activeSubInputKey !== groupKey) {
            this.activeSubInputKey = groupKey;
            this.expandedSubGroups[groupKey] = true;
        }

        let currentValues = this.dynamicInputValues[classId][subInputId];
        if (!Array.isArray(currentValues)) {
            currentValues = currentValues ? currentValues.split(', ') : [];
        }

        if (currentValues.includes(value)) {
            currentValues = currentValues.filter(v => v !== value);
        } else {
            currentValues.push(value);
        }

        this.dynamicInputValues[classId][subInputId] = currentValues.join(', ');
        this.activeSubInputKey = `${idPrefix}${classId}-${subInputId}`;
        this.renderClassList();
        this.renderFullEditSidebarContent();
        this.syncAnnotationPanel(classId, className);
    }

    handleDropDownChange(select, classId, className, subInputId) {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};
        if (!this.dynamicInputValues[classId]) this.dynamicInputValues[classId] = {};

        this.dynamicInputValues[classId][subInputId] = select.value;
        this.syncAnnotationPanel(classId, className);
    }

    handleChecklistChange(checkbox, classId, className, subInputId, idPrefix = '') {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};
        if (!this.dynamicInputValues[classId]) this.dynamicInputValues[classId] = {};

        let currentValues = this.dynamicInputValues[classId][subInputId];
        if (!Array.isArray(currentValues)) {
            currentValues = currentValues ? currentValues.split(', ') : [];
        }

        if (checkbox.checked) {
            if (!currentValues.includes(checkbox.value)) {
                currentValues.push(checkbox.value);
            }
        } else {
            currentValues = currentValues.filter(v => v !== checkbox.value);
        }

        this.dynamicInputValues[classId][subInputId] = currentValues.join(', ');
        if (idPrefix !== 'fullEdit-') {
            this.syncAnnotationPanel(classId, className);
        }
    }

    handleRadioSingleClick(classId, className, value) {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};

        if (this.dynamicInputValues[classId] === value) {
            this.dynamicInputValues[classId] = ''; // Toggle off
        } else {
            this.dynamicInputValues[classId] = value;
        }

        this.renderClassList();

        const val = this.dynamicInputValues[classId] || '';
        if (val) {
            this.annotationModel.className = className;
            this.openAnnotationPanel(val);
        } else {
            this.annotationPanelView.hide();
            this.annotationModel.deactivate();
            this.sliderRanges = [];
        }
    }

    handleChecklistSingleClick(classId, className, value) {
        if (!this.dynamicInputValues) this.dynamicInputValues = {};

        let currentValues = this.dynamicInputValues[classId];
        if (!Array.isArray(currentValues)) {
            currentValues = currentValues ? currentValues.split(', ') : [];
        }

        if (currentValues.includes(value)) {
            currentValues = currentValues.filter(v => v !== value);
        } else {
            currentValues.push(value);
        }

        this.dynamicInputValues[classId] = currentValues.join(', ');
        this.renderClassList();

        const val = this.dynamicInputValues[classId] || '';
        if (val) {
            this.annotationModel.className = className;
            this.openAnnotationPanel(val);
        } else {
            this.annotationPanelView.hide();
            this.annotationModel.deactivate();
            this.sliderRanges = [];
        }
    }

    syncAnnotationPanel(classId, className) {
        const cls = CONFIG.CLASSES.find(c => c.id === classId);
        const values = {};

        cls.subInputs.forEach(sub => {
            const val = (this.dynamicInputValues[classId] && this.dynamicInputValues[classId][sub.id]) || '';
            values[sub.id] = val;
        });

        const combinedValue = JSON.stringify(values);
        this.annotationModel.className = className;
        this.openAnnotationPanel(combinedValue);
    }

    handleDynamicInput(textarea, classId, className, subInputId = null, idPrefix = '') {
        // Auto-resize textarea height
        textarea.style.overflow = 'hidden';
        textarea.style.height = 'auto';
        textarea.style.height = (textarea.scrollHeight) + 'px';

        // Update state
        if (!this.dynamicInputValues) this.dynamicInputValues = {};
        if (!this.dynamicInputValues[classId]) {
            this.dynamicInputValues[classId] = subInputId ? {} : '';
        }

        if (subInputId) {
            this.dynamicInputValues[classId][subInputId] = textarea.value;
        } else {
            this.dynamicInputValues[classId] = textarea.value;
        }

        if (idPrefix === 'fullEdit-') {
            // No need to sync bottom panel for sidebar edits
            return;
        }

        // Check for any remaining content across all sub-inputs (drop-downs, radio, etc.)
        let hasContent = false;
        if (subInputId) {
            // Multi-input class: check all sub-input values stored in state
            hasContent = Object.values(this.dynamicInputValues[classId] || {}).some(v => v && v.trim().length > 0);
        } else {
            // Single-input class: check the value directly
            const val = this.dynamicInputValues[classId];
            hasContent = (typeof val === 'string' && val.trim().length > 0);
        }

        if (hasContent) {
            this.annotationModel.className = className;
            if (subInputId) {
                // Rebuild the combined JSON using ALL stored values (correctly handles dropdowns)
                this.syncAnnotationPanel(classId, className);
            } else {
                this.openAnnotationPanel(this.dynamicInputValues[classId] || '');
            }
        } else {
            // ALL TEXT IS EMPTY (Manual Backspace and no dropdown selection):
            // Hide the bottom panel, but DO NOT call this.closeAnnotationPanel()
            // because that method wipes the activeClassId and collapses the tree.
            this.annotationPanelView.hide();
            this.annotationModel.deactivate();
            this.sliderRanges = [];

            // Just update the bullet icons in the tree
            if (subInputId) {
                const groupHeader = textarea.closest('.sub-group-wrapper')?.querySelector('.sub-group-header-row');
                if (groupHeader) {
                    groupHeader.children[1].innerHTML = SUB_GROUP_CIRCLE_SVG;
                }
            }
        }
    }

    clearDynamicClassInput(classId) {
        // 1. Reset the internal data for this specific class
        if (this.dynamicInputValues) {
            // Reset based on config type
            const cls = CONFIG.CLASSES.find(c => c.id === classId);
            if (cls && cls.subInputs) {
                this.dynamicInputValues[classId] = {};
            } else {
                this.dynamicInputValues[classId] = '';
            }
            this.activeSubInputKey = null; // Ensure nothing is selected initially
        }

        // 2. Clear values in the actual UI elements
        const area = document.getElementById(`input-area-${classId}`);
        if (area) {
            // Clear all textareas
            area.querySelectorAll('textarea').forEach(ta => {
                ta.value = '';
                ta.style.height = '18px'; // Reset height to default
            });

            // Clear checkboxes/radios
            area.querySelectorAll('input').forEach(input => {
                if (input.type === 'checkbox' || input.type === 'radio') {
                    input.checked = false;
                }
            });

            // Clear selects
            area.querySelectorAll('select').forEach(select => select.value = '');
        }

        // 3. Hide the "Add classification" overlay panel
        // We call this to reset slider state and hide the purple UI
        this.annotationPanelView.hide();
        this.annotationModel.deactivate();
        this.sliderRanges = [];

        // 4. Refresh the class list 
        // We DON'T change activeClassId, so the tree stays visible
        this.renderClassList();

        // 5. Put focus back into the textarea so user can start typing again
        if (area) {
            setTimeout(() => {
                area.querySelector('textarea')?.focus();
            }, 10);
        }
    }

    setupEventListeners() {
        this.setupVideoListeners();
        this.setupPlaybackControls();
        this.setupProgressBarListeners();
        this.setupTimelineListeners();
        this.setupAnnotationListeners();
        this.setupResizerListeners();
        this.initSettingsToggles();
        this.updateSettingsCheckmarks();
        this.updateFrameSkipSelectorVisibility();
        this.setupMenuListeners();
        this.setupZoomListeners();
        this.setupRotationListeners();
        this.setupFilterListeners();

        // Listen for clicks on the Delete Modal buttons
        document.getElementById('fullEditSidebarDoneBtn').onclick = () => this.saveFullEditSidebar();
        document.getElementById('cancelDeleteBtn').onclick = () => this.hideDeleteConfirmation();
        document.getElementById('confirmDeleteBtn').onclick = () => this.deleteAnnotation();

        // Global listener to close the options menu when clicking anywhere else
        document.addEventListener('click', (event) => {
            const timelineSortMenu = document.getElementById('timelineSortMenu');
            const timelineSortBtn = document.getElementById('timelineSortBtn');

            // 1. Handle Timeline Sort Menu click-outside
            if (timelineSortMenu && !timelineSortMenu.classList.contains('hidden')) {
                // If the click is NOT the button AND NOT inside the menu, hide it
                if (!timelineSortBtn.contains(event.target) && !timelineSortMenu.contains(event.target)) {
                    timelineSortMenu.classList.add('hidden');
                    timelineSortMenu.style.display = 'none';
                }
            }

            // 2. Handle Label List menus (existing logic)
            const openOptionsMenu = document.querySelector('[id^="optionsMenu-"]:not(.hidden)');
            if (openOptionsMenu) {
                if (!event.target.closest('.more-vert-btn') && !openOptionsMenu.contains(event.target)) {
                    openOptionsMenu.classList.add('hidden');
                    openOptionsMenu.style.display = 'none';
                }
            }

            // 3. Handle Sidebar Dropdown (existing logic)
            const sidebarMenu = document.getElementById('sidebarDropdownMenu');
            if (sidebarMenu && !sidebarMenu.classList.contains('hidden')) {
                if (!event.target.closest('.more-vert-btn') && !sidebarMenu.contains(event.target)) {
                    sidebarMenu.classList.add('hidden');
                    sidebarMenu.style.display = 'none';
                }
            }
            // 4. Handle Settings Menu click-outside
            const settingsMenu = document.getElementById('settingsMenu');
            const settingsBtn = document.getElementById('settingsBtn');
            if (settingsMenu && !settingsMenu.classList.contains('hidden')) {
                const isClickInside = settingsMenu.contains(event.target) || settingsBtn.contains(event.target);
                if (!isClickInside) {
                    settingsMenu.classList.add('hidden');
                    settingsMenu.style.display = 'none';
                }
            }

            // 5. Handle Frame Skip Selector Menu click-outside
            const skipMenu = document.getElementById('frameSkipSelectorMenu');
            const skipPill = document.getElementById('frameSkipSelectorPill');
            if (skipMenu && !skipMenu.classList.contains('hidden')) {
                const isClickInside = skipMenu.contains(event.target) || skipPill.contains(event.target);
                if (!isClickInside) {
                    this.toggleFrameSkipSelectorMenu(null, false);
                }
            }

            // 6. Handle Searchable Dropdowns (isClickInsideMenu / isClickOnToggleBtn)
            // Inside document.addEventListener('click', (event) => { ... })
            if (this.openDropdownId) {
                const isClickOnContainer = event.target.closest('.searchable-input-container');
                const isClickInsideMenu = event.target.closest('.searchable-menu');

                // If the user clicked the actual input box or the menu, do NOT close it
                if (isClickOnContainer || isClickInsideMenu) {
                    return;
                }

                this.openDropdownId = null;
                this.focusedDropdownId = null;
                this.renderClassList();
            }
        }, false);
    }

    initSettingsToggles() {
        console.log("initSettingsToggles starting...");
        const settingsMenu = document.getElementById('settingsMenu');

        // --- Sub-menu Event Helper ---
        const setupSubMenuHover = (triggerId, subMenuId) => {
            const trigger = document.getElementById(triggerId);
            const subMenu = document.getElementById(subMenuId);
            if (!trigger || !subMenu) return;

            trigger.onmouseenter = () => {
                subMenu.classList.remove('hidden');
                subMenu.style.display = 'flex';
            };
            trigger.onmouseleave = (e) => {
                // Only hide if we're not moving into the submenu itself
                if (!subMenu.contains(e.relatedTarget)) {
                    subMenu.classList.add('hidden');
                    subMenu.style.display = 'none';
                }
            };
            subMenu.onmouseleave = (e) => {
                if (!trigger.contains(e.relatedTarget)) {
                    subMenu.classList.add('hidden');
                    subMenu.style.display = 'none';
                }
            };
        };

        // 1. PREVENT INTERNAL CLICKS FROM CLOSING MENU
        if (settingsMenu) {
            settingsMenu.onclick = (e) => e.stopPropagation();
            settingsMenu.onmousedown = (e) => e.stopPropagation();
        }

        // 2. TIMESTAMPS TOGGLE & SUBMENU
        const tsTrigger = document.getElementById('timestampFormatTrigger');
        if (tsTrigger) {
            // Clicking the left part (checkmark/label) toggles the boolean
            // Clicking the right part (chevron) usually just opens the submenu (via hover)
            // But let's make the whole row toggle the boolean for simplicity, or just use the checkmark?
            // User requested dropdown for Display timestamps.
            // Let's make the checkmark/label toggle the master switch, and the chevron/row hover show formats.
            const labelArea = tsTrigger.querySelector('.flex.items-center');
            if (labelArea) {
                labelArea.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.toggleDisplayTimestamps();
                };
            }
            setupSubMenuHover('timestampFormatTrigger', 'timestampFormatSubMenu');
        }

        // 3. FRAME SKIP INTERVAL (Submenu trigger)
        setupSubMenuHover('frameSkipTrigger', 'frameSkipSubMenu');

        // 4. SHOW FRAME SKIP SELECTOR TOGGLE
        const skipSelectorRow = document.getElementById('toggle-skipselector-row');
        if (skipSelectorRow) {
            skipSelectorRow.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleFrameSkipSelector();
            };
        }
    }

    initFrameSkipMenu() {
        if (this.settingsMenuManager) {
            this.settingsMenuManager.renderFrameSkipOptions();
        }
    }

    setupVideoListeners() {
        this.videoController.addTimeUpdateListener(() => this.onVideoTimeUpdate());
        this.videoController.addMetadataLoadedListener(() => this.onVideoMetadataLoaded());

        const playBtn = document.getElementById('btnPlayPause');

        this.videoController.video.addEventListener('play', () => {
            playBtn.innerHTML = PAUSE_ICON_SVG;
        });

        this.videoController.video.addEventListener('pause', () => {
            playBtn.innerHTML = PLAY_ICON_SVG;
        });

        // Disable right-click on the main area
        const mainArea = document.querySelector('main');
        if (mainArea) {
            mainArea.addEventListener('contextmenu', (e) => {
                e.preventDefault();
            });
        }
    }

    onVideoTimeUpdate() {
        if (!this.videoController.duration || this.isUpdatingUI) return;

        this.isUpdatingUI = true;
        requestAnimationFrame(() => {
            const currentTime = this.videoController.currentTime;
            const duration = this.videoController.duration;
            const percent = currentTime / duration;
            const pps = this.timelineView.currentPPS;
            const timelineWidth = duration * pps;

            this.progressBarView.update(percent);
            this.timelineView.updatePlayhead(percent, timelineWidth);

            if (document.activeElement !== this.frameInput) {
                this.frameInput.value = this.formatDisplay(this.videoController.getCurrentFrame());
            }

            if (this.annotationModel.isActive()) {
                this.updateAnnotationSlider();
            }

            this.scrollSync.sync(currentTime, duration, pps);

            // NEW: If in 'Frame' view, re-render labels list to show valid items
            if (this.labelListMode === 'frame') {
                this.renderInstructions();
            }

            this.isUpdatingUI = false;
        });
        this.renderVideoIssueOverlay();
    }

    onVideoMetadataLoaded() {
        const totalFrames = this.videoController.getTotalFrames();
        this.totalFramesText.innerText = this.formatDisplay(totalFrames);
        document.getElementById('staticLabelEnd').innerText = this.formatDisplay(totalFrames);

        // Populate classification inputs
        if (this.annotationPanelView.elements.inputStart) {
            this.annotationPanelView.elements.inputStart.value = this.formatDisplay(0);
        }
        if (this.annotationPanelView.elements.inputEnd) {
            this.annotationPanelView.elements.inputEnd.value = this.formatDisplay(totalFrames);
        }
        if (this.annotationPanelView.elements.valLabelStart) {
            this.annotationPanelView.elements.valLabelStart.innerText = this.formatDisplay(0);
        }
        if (this.annotationPanelView.elements.valLabelEnd) {
            this.annotationPanelView.elements.valLabelEnd.innerText = this.formatDisplay(totalFrames);
        }
        // NEW: Initialize filter defaults
        const filterEndIn = document.getElementById('filterEndInput');
        if (filterEndIn) filterEndIn.value = totalFrames;
        this.labelFilter.end = totalFrames;
        this.setupFilterInputListeners();

        this.timelineView.initialize(this.videoController.duration);
        this.timelineView.renderTracks(this.annotationModel.getInstructions());
        this.renderInstructions();
    }

    setupPlaybackControls() {
        const handlers = createPlaybackHandlers(this.videoController, this.annotationModel, this.annotationPanelView);
        const btnIds = ['btnStart', 'btnPlayPause', 'btnNext'];
        const frameInput = document.getElementById('currentFrameInput');
        document.getElementById('btnVolume').onclick = (e) => handlers.volume(e);
        btnIds.forEach(id => {
            const btn = document.getElementById(id);
            if (!btn) return;

            btn.addEventListener('mouseenter', () => {
                frameInput.classList.add('input-highlight-border');
            });
            btn.addEventListener('mouseleave', () => {
                frameInput.classList.remove('input-highlight-border');
            });

            if (id === 'btnStart') btn.onclick = handlers.previous;
            if (id === 'btnPlayPause') btn.onclick = handlers.playPause;
            if (id === 'btnNext') btn.onclick = handlers.next;
        });

        document.getElementById('btnVolume').onclick = handlers.volume;
        this.speedMenuManager.initialize();
    }

    setupProgressBarListeners() {
        const progressTrack = document.getElementById('progressTrack');

        const applyManualFrameSeek = () => {
            const val = this.frameInput.value.trim();
            if (val === '') return; // Skip if empty, let blur handle it

            const frame = this.parseDisplay(val);
            const totalFrames = this.videoController.getTotalFrames();

            if (!isNaN(frame) && this.videoController.duration) {
                const safeFrame = Math.max(0, Math.min(frame, totalFrames));
                this.videoController.seekToFrame(safeFrame);
                const currentTime = safeFrame / CONFIG.FPS;
                const duration = this.videoController.duration;
                const pps = this.timelineView.currentPPS;
                this.scrollSync.sync(currentTime, duration, pps, true);
                this.onVideoTimeUpdate();
            }
        };

        progressTrack.addEventListener('mousemove', (e) => {
            if (!this.videoController.duration) return;
            const rect = progressTrack.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const percent = Math.max(0, Math.min(1, x / rect.width));
            const hoveredFrame = Math.round(percent * this.videoController.getTotalFrames());
            this.progressBarView.showHoverPill(percent, hoveredFrame);
        });

        progressTrack.addEventListener('mouseleave', () => {
            this.progressBarView.hideHoverPill();
        });

        progressTrack.addEventListener('click', (e) => {
            if (document.activeElement instanceof HTMLElement) {
                document.activeElement.blur();
            }

            if (!this.videoController.duration || isNaN(this.videoController.duration)) return;

            const rect = progressTrack.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const percent = Math.max(0, Math.min(1, clickX / rect.width));

            this.progressBarView.update(percent);
            this.videoController.currentTime = percent * this.videoController.duration;
        });

        this.frameInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                applyManualFrameSeek();
                e.target.blur();
            }
        });

        this.frameInput.addEventListener('blur', () => {
            const val = this.frameInput.value.trim();
            if (val === '') {
                // If empty, reset to current frame
                this.frameInput.value = this.formatDisplay(this.videoController.getCurrentFrame());
            } else {
                // If not empty, parse and seek (this ensures value is valid/clamped)
                applyManualFrameSeek();
            }
        });

        this.frameInput.addEventListener('input', (e) => {
            // Allow only numbers and ':' (if timestamps are enabled)
            const allowedPattern = this.displayTimestamps ? /[^0-9:]/g : /[^0-9]/g;
            if (allowedPattern.test(e.target.value)) {
                e.target.value = e.target.value.replace(allowedPattern, '');
            }
        });
    }

    setupTimelineListeners() {
        const contentColumn = document.getElementById('timelineContentColumn');
        const playheadHandle = document.getElementById('playheadHandle');

        contentColumn.addEventListener('mousedown', (e) => {
            if (document.activeElement instanceof HTMLElement) {
                document.activeElement.blur();
            }

            if (e.target.closest('#playheadHandle')) return;

            const rect = contentColumn.getBoundingClientRect();
            const scrollLeft = contentColumn.scrollLeft;
            let x = e.clientX - rect.left + scrollLeft;

            const duration = this.videoController.duration;
            const timelineWidth = duration * this.timelineView.currentPPS;

            x = Math.max(0, Math.min(timelineWidth, x));
            this.videoController.currentTime = (x / timelineWidth) * duration;
            this.dragState.startDrag('playhead');
            e.preventDefault();
        });

        playheadHandle.addEventListener('mousedown', (e) => {
            if (document.activeElement instanceof HTMLElement) {
                document.activeElement.blur();
            }
            this.dragState.startDrag('playhead');
            e.stopPropagation();
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (this.dragState.isActive() && this.dragState.getType() === 'playhead') {
                this.handlePlayheadDrag(e);
            }
        });
        document.addEventListener('mousedown', (event) => {
            const fullEditSidebar = document.getElementById('fullEditSidebar');

    // 1. Sidebar closing logic (Keep your existing code here)
    if (fullEditSidebar && !fullEditSidebar.classList.contains('hidden')) {
        const isClickInsideSidebar = fullEditSidebar.contains(event.target);
        const isClickOnTrigger = event.target.closest('.annotation-card') ||
            event.target.closest('.data-row') ||
            event.target.closest('.more-vert-btn') ||
            event.target.closest('#sidebarDropdownMenu');

        const isClickInsideModal = event.target.closest('#deleteConfirmationModal');

        if (!isClickInsideSidebar && !isClickOnTrigger && !isClickInsideModal) {
            this.closeFullEditSidebar();
        }
    }

    // --- FIX START: DROPDOWN CLOSURE LOGIC ---
    if (this.openDropdownId) {
        const isClickOnDropdownWrap = event.target.closest('.searchable-dropdown-wrap');
        const isClickInsideDropdownMenu = event.target.closest('.searchable-menu');

        // If we clicked anywhere that is NOT the dropdown or its menu
        if (!isClickOnDropdownWrap && !isClickInsideDropdownMenu) {
            const idToClear = this.openDropdownId;
            this.openDropdownId = null;
            this.focusedDropdownId = null;

            // Re-render the specific view to actually hide the HTML menu
            if (idToClear.startsWith('fullEdit-')) {
                this.renderFullEditSidebarContent();
            } else {
                this.renderClassList();
            }
        }
    }


            const isClickOnToggleBtn = event.target.closest('#timelineSortBtn') ||
                event.target.closest('#labelSortToggle') ||
                event.target.closest('#moreNavBtn') ||
                event.target.closest('#frameSkipSelectorPill') ||
                event.target.closest('#issueSortTrigger') ||
                event.target.closest('#issueApplyToTrigger') ||
                event.target.closest('#issueTagTrigger') ||
                event.target.closest('.issue-icon-wrapper') ||
                event.target.closest('.more-vert-btn') ||
                event.target.closest('#issueCardsContainer'); // Protect all issue cards

            const isClickInsideMenu = event.target.closest('[id^="optionsMenu-"]') ||
                event.target.closest('[id^="issueMenu-"]') ||
                event.target.closest('[data-popup-type="canvasIssue"]') || // Protect dynamic popup
                event.target.closest('.searchable-input-container') ||
                event.target.closest('.searchable-menu') ||
                event.target.closest('#sidebarDropdownMenu') ||
                event.target.closest('#timelineSortMenu') ||
                event.target.closest('#labelsSortMenu') ||
                event.target.closest('#moreNavMenu') ||
                event.target.closest('#frameSkipSelectorMenu') ||
                event.target.closest('#issueSortPopover') ||
                event.target.closest('#sortMethodList') ||
                event.target.closest('#sortOrderList') ||
                event.target.closest('#issueFilterPopover') ||
                event.target.closest('#statusDropdownMenu') ||
                event.target.closest('#typeDropdownMenu') ||
                event.target.closest('#issueApplyToDropdownMenu') ||
                event.target.closest('#issueTagDropdownMenu') ||
                event.target.closest('#canvasIssuePopup') ||
                event.target.closest('#canvasTagPopover') ||
                event.target.closest('.tag-option') ||
                event.target.closest('.tag-placeholder-box') ||
                event.target.closest('#settingsMenu'); // FIX: Don't close settings if clicked inside

            if (!isClickOnToggleBtn && !isClickInsideMenu) {
                this.hideAllMenus();
            }

            // Close canvas issue popup when clicking outside the popup,
            // outside any issue card. Note: icon clicks are NOT in this zone
            // because the icon onclick handles toggle (open/close) itself.
            const isInsidePopupZone =
                event.target.closest('[data-popup-type="canvasIssue"]') ||
                event.target.closest('#issueCardsContainer');

            // Use live DOM check — works whether popup was opened via icon OR sidebar card
            const openPopup = document.querySelector('[data-popup-type="canvasIssue"]');
            if (!isInsidePopupZone && openPopup) {
                this.hideCanvasIssuePopup();
            }
        }, true);

        // Added: Also handle 'blur' if the window loses focus (like switching tabs)
        window.addEventListener('blur', () => {
            document.querySelectorAll('[id^="optionsMenu-"], #sidebarDropdownMenu').forEach(m => {
                m.classList.add('hidden');
            });
        });
        document.addEventListener('mouseup', () => this.dragState.endDrag());

        document.getElementById('zoomInTimeline').onclick = (e) => {
            e.stopPropagation();
            this.handleTimelineZoom(20);
        };
        document.getElementById('zoomOutTimeline').onclick = (e) => {
            e.stopPropagation();
            this.handleTimelineZoom(-20);
        };
    }

    handleTimelineZoom(delta) {
        if (!this.videoController.duration) return;
        const newPPS = Math.max(CONFIG.MIN_PPS, Math.min(CONFIG.MAX_PPS, this.timelineView.currentPPS + delta));
        this.timelineView.initialize(this.videoController.duration, newPPS);
        this.timelineView.renderTracks(this.annotationModel.getInstructions(), newPPS);
        this.onVideoTimeUpdate();
    }

    handlePlayheadDrag(e) {
        const contentColumn = document.getElementById('timelineContentColumn');
        const rect = contentColumn.getBoundingClientRect();
        const scrollLeft = contentColumn.scrollLeft;
        let x = e.clientX - rect.left + scrollLeft;
        const duration = this.videoController.duration;
        const timelineWidth = duration * this.timelineView.currentPPS;
        x = Math.max(0, Math.min(timelineWidth, x));
        this.videoController.currentTime = (x / timelineWidth) * duration;
    }

    setupAnnotationListeners() {
        // 1. REMOVED: classValueInput (This is now handled by handleDynamicInput)
        const sliderTrack = document.getElementById('sliderTrackBase');
        const startInput = document.getElementById('inputStartFrame');
        const endInput = document.getElementById('inputEndFrame');

        // Handle Clicks on Track (Including uncolored line)
        sliderTrack.addEventListener('mousedown', (e) => {
            const target = e.target;
            if (target.id === 'knobStart' || target.closest('#knobStart')) {
                const knob = document.getElementById('knobStart');
                knob.classList.add('dragging');
                this.dragState.startDrag('knobStart');
                if (window.tooltipManager) window.tooltipManager.show(knob);
                return;
            }
            if (target.id === 'knobEnd' || target.closest('#knobEnd')) {
                const knob = document.getElementById('knobEnd');
                knob.classList.add('dragging');
                this.dragState.startDrag('knobEnd');
                if (window.tooltipManager) window.tooltipManager.show(knob);
                return;
            }
            this.handleSliderTrackClick(e);
        });

        document.addEventListener('mousemove', (e) => {
            if (this.dragState.isActive()) {
                const type = this.dragState.getType();
                if (type === 'knobStart' || type === 'knobEnd') {
                    this.handleKnobDrag(e);
                } else if (type === 'extraRangeStart' || type === 'extraRangeEnd') {
                    this.handleExtraRangeKnobDrag(e);
                }
            }
        });

        document.addEventListener('mouseup', () => {
            const ks = document.getElementById('knobStart');
            const ke = document.getElementById('knobEnd');
            if (ks) ks.classList.remove('dragging');
            if (ke) ke.classList.remove('dragging');
            // Also remove dragging class from any extra range knobs
            document.querySelectorAll('.extra-range-segment.dragging').forEach(el => el.classList.remove('dragging'));
            this.dragState.endDrag();
            this.updateAddRangeButton();
        });

        // Handle Input Fields (Fixed to not overwrite each other while typing)
        [startInput, endInput].forEach(el => {
            el.addEventListener('input', (e) => {
                let val = this.parseDisplay(e.target.value);
                if (isNaN(val)) return;

                const total = this.videoController.getTotalFrames();
                const isStart = e.target.id === 'inputStartFrame';
                const { start, end } = this.annotationModel.getRange();

                if (isStart) {
                    this.annotationModel.setRange(Math.max(0, Math.min(val, total)), end);
                } else {
                    this.annotationModel.setRange(start, Math.max(0, Math.min(val, total)));
                }
                this.updateAnnotationSlider();
            });

            el.addEventListener('change', (e) => {
                const { start, end } = this.annotationModel.getRange();
                let finalStart = Math.min(start, end);
                let finalEnd = Math.max(start, end);

                this.annotationModel.setRange(finalStart, finalEnd);

                // FIX: Use parseDisplay to handle formatted timestamps correctly
                const seekMark = this.parseDisplay(e.target.value);
                this.videoController.seekToFrame(seekMark);

                this.updateAnnotationSlider();
            });
        });
    }

    // Helper for setupAnnotationListeners
    validateAndRefreshRange() {
        const { start, end } = this.annotationModel.getRange();
        const total = this.videoController.getTotalFrames();

        let s = Math.max(0, Math.min(start, end));
        let e = Math.min(total, Math.max(start, end));

        this.annotationModel.setRange(s, e);
        this.updateAnnotationSlider(); // Full update (syncs inputs too)
    }

    // Helper to update visual slider without fighting the user's typing focus
    updateSliderUIOnly() {
        const { start, end } = this.annotationModel.getRange();
        const total = this.videoController.getTotalFrames();
        const current = this.videoController.getCurrentFrame();

        const startPct = (start / total) * 100;
        const endPct = (end / total) * 100;
        const currentPct = (current / total) * 100;

        document.getElementById('knobStart').style.left = startPct + '%';
        document.getElementById('knobEnd').style.left = endPct + '%';
        document.getElementById('knobCurrent').style.left = currentPct + '%';
        document.getElementById('sliderHighlight').style.left = startPct + '%';
        document.getElementById('sliderHighlight').style.width = (endPct - startPct) + '%';
    }

    handleSliderTrackClick(e) {
        const sliderTrack = document.getElementById('sliderTrackBase');
        const rect = sliderTrack.getBoundingClientRect();
        const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const frame = Math.round(pct * this.videoController.getTotalFrames());

        const { start, end } = this.annotationModel.getRange();

        // Move the knob that is closer to the click point
        if (Math.abs(frame - start) < Math.abs(frame - end)) {
            this.annotationModel.setRange(frame, end);
        } else {
            this.annotationModel.setRange(start, frame);
        }
        this.updateAnnotationSlider();
    }

    handleKnobDrag(e) {
        const sliderTrack = document.getElementById('sliderTrackBase');
        if (!sliderTrack) return;

        const rect = sliderTrack.getBoundingClientRect();
        const totalFrames = this.videoController.getTotalFrames();

        // Calculate frame based on mouse position relative to track
        const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const frame = Math.round(pct * totalFrames);

        const { start, end } = this.annotationModel.getRange();
        const type = this.dragState.getType();

        // Constrain against other ranges if overwrite_validate is on
        if (CONFIG.overwrite_validate && this.sliderRanges.length > 1) {
            const sorted = [...this.sliderRanges].map((r, i) => ({ ...r, i }))
                .sort((a, b) => a.start - b.start);
            const pos = sorted.findIndex(r => r.i === 0);

            if (type === 'knobStart') {
                const prev = sorted[pos - 1];
                const min = prev ? prev.end : 0;
                this.annotationModel.setRange(Math.max(min, Math.min(frame, end)), end);
            } else if (type === 'knobEnd') {
                const next = sorted[pos + 1];
                const max = next ? next.start : totalFrames;
                this.annotationModel.setRange(start, Math.min(max, Math.max(frame, start)));
            }
        } else {
            if (type === 'knobStart') {
                this.annotationModel.setRange(Math.min(frame, end), end);
            } else if (type === 'knobEnd') {
                this.annotationModel.setRange(start, Math.max(frame, start));
            }
        }

        // Sync sliderRanges[0]
        if (this.sliderRanges[0]) {
            const r = this.annotationModel.getRange();
            this.sliderRanges[0].start = r.start;
            this.sliderRanges[0].end = r.end;
        }

        // Update the visual UI immediately
        this.updateAnnotationSlider();
        this._updateExtraRangeDOMPositions(0, totalFrames);

        // SYNC TOOLTIP: Notify tooltipManager to update position
        if (window.tooltipManager) {
            const knobId = (type === 'knobStart') ? 'knobStart' : 'knobEnd';
            const knobEl = document.getElementById(knobId);
            if (knobEl) window.tooltipManager.updatePosition(knobEl);
        }
    }

    /**
     * handleExtraRangeKnobDrag: Handles dragging of dynamically created extra-range knobs.
     * Uses a lightweight in-place DOM update so the dragged element is never destroyed mid-drag.
     */
    handleExtraRangeKnobDrag(e) {
        const sliderTrack = document.getElementById('sliderTrackBase');
        if (!sliderTrack) return;

        const rect = sliderTrack.getBoundingClientRect();
        const totalFrames = this.videoController.getTotalFrames();

        const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const frame = Math.round(pct * totalFrames);

        const idx = this.activeDragRangeIndex;
        if (idx < 0 || idx >= this.sliderRanges.length) return;

        const range = this.sliderRanges[idx];

        // Overlap Prevention Logic
        let newStart = range.start;
        let newEnd = range.end;

        if (this.dragState.getType() === 'extraRangeStart') {
            newStart = Math.max(0, Math.min(frame, range.end - 1));

            // Constrain against previous range if overwrite_validate is on
            if (CONFIG.overwrite_validate) {
                // Find nearest neighbors in terms of frame values
                const sorted = [...this.sliderRanges].map((r, i) => ({ ...r, i }))
                    .sort((a, b) => a.start - b.start);
                const pos = sorted.findIndex(r => r.i === idx);
                const prev = sorted[pos - 1];
                if (prev) {
                    newStart = Math.max(prev.end, newStart);
                }
            }
            this.sliderRanges[idx].start = newStart;
        } else if (this.dragState.getType() === 'extraRangeEnd') {
            newEnd = Math.min(totalFrames, Math.max(frame, range.start + 1));

            // Constrain against next range
            if (CONFIG.overwrite_validate) {
                const sorted = [...this.sliderRanges].map((r, i) => ({ ...r, i }))
                    .sort((a, b) => a.start - b.start);
                const pos = sorted.findIndex(r => r.i === idx);
                const next = sorted[pos + 1];
                if (next) {
                    newEnd = Math.min(next.start, newEnd);
                }
            }
            this.sliderRanges[idx].end = newEnd;
        }

        // If dragging range 0, keep annotationModel in sync
        if (idx === 0) {
            const r = this.sliderRanges[0];
            this.annotationModel.setRange(r.start, r.end);
        }

        // Move existing DOM elements in-place — do NOT call renderSliderRanges() here
        this._updateExtraRangeDOMPositions(idx, totalFrames);
        this.updateAnnotationSlider();
    }

    /**
     * _updateExtraRangeDOMPositions: Move existing range DOM nodes without recreating them.
     * Pass idx to update one segment, omit to update all segments.
     */
    _updateExtraRangeDOMPositions(idx, totalFrames) {
        const track = document.getElementById('sliderTrackBase');
        if (!track || !totalFrames) return;

        const indices = (idx !== undefined)
            ? [idx]
            : this.sliderRanges.map((_, k) => k);

        indices.forEach(i => {
            if (i < 0 || i >= this.sliderRanges.length) return;
            const range = this.sliderRanges[i];
            const startPct = (range.start / totalFrames) * 100;
            const endPct = (range.end / totalFrames) * 100;
            const widthPct = endPct - startPct;

            track.querySelectorAll(`.range-segment[data-range-idx="${i}"]`).forEach(el => {
                const knobType = el.dataset.knobType;
                const segType = el.dataset.segType;
                if (knobType === 'start') {
                    el.style.left = startPct + '%';
                    el.setAttribute('data-tooltip', this.formatDisplay(range.start));
                } else if (knobType === 'end') {
                    el.style.left = endPct + '%';
                    el.setAttribute('data-tooltip', this.formatDisplay(range.end));
                } else if (segType === 'highlight') {
                    el.style.left = startPct + '%';
                    el.style.width = widthPct + '%';
                } else if (segType === 'tickStart') {
                    el.style.left = startPct + '%';
                    el.style.fontWeight = '480';
                    el.style.color = '#000000e0';
                    el.textContent = this.formatDisplay(range.start);
                } else if (segType === 'tickEnd') {
                    el.style.left = endPct + '%';
                    el.style.fontWeight = '480';
                    el.style.color = '#000000e0';
                    el.textContent = this.formatDisplay(range.end);
                }

                // SYNC TOOLTIP: If this knob is being dragged, update its tooltip position
                if (window.tooltipManager && window.tooltipManager.activeElement === el) {
                    window.tooltipManager.updatePosition(el);
                }
            });

            // Also update pill inputs if visible
            const pillRow = document.getElementById('rangesPillRow');
            if (pillRow) {
                const pill = pillRow.querySelector(`[data-pill-idx="${i}"]`);
                if (pill) {
                    const inputs = pill.querySelectorAll('input');
                    if (inputs.length === 2) {
                        if (document.activeElement !== inputs[0]) inputs[0].value = this.formatDisplay(range.start);
                        if (document.activeElement !== inputs[1]) inputs[1].value = this.formatDisplay(range.end);
                    }
                }
            }
        });
    }


    validateStartInput() {
        const startInput = document.getElementById('inputStartFrame');
        let val = parseInt(startInput.value) || 0;
        if (val < 0) val = 0;
        if (val > this.annotationModel.end) val = this.annotationModel.end;
        this.annotationModel.setRange(val, this.annotationModel.end);
        this.updateAnnotationSlider();
    }

    validateEndInput() {
        const endInput = document.getElementById('inputEndFrame');
        const totalFrames = this.videoController.getTotalFrames();
        let val = parseInt(endInput.value) || 0;
        if (val > totalFrames) val = totalFrames;
        if (val < this.annotationModel.start) val = this.annotationModel.start;
        this.annotationModel.setRange(this.annotationModel.start, val);
        this.updateAnnotationSlider();
    }

    setupMenuListeners() {
        const toggleMenu = (menuId) => {
            const menus = [
                { id: 'filterMenu', manager: this.filterMenuManager },
                { id: 'rotateMenu', manager: this.rotateMenuManager },
                { id: 'speedMenu', manager: this.speedMenuManager }
            ];
            menus.forEach(m => {
                if (m.id === menuId) m.manager.toggle();
                else m.manager.close();
            });
        };

        document.getElementById('filterBtn').onclick = (e) => {
            e.stopPropagation();
            toggleMenu('filterMenu');
        };
        document.getElementById('rotateDropdownBtn').onclick = (e) => {
            e.stopPropagation();
            toggleMenu('rotateMenu');
        };
        document.getElementById('currentSpeedBtn').onclick = (e) => {
            e.stopPropagation();
            toggleMenu('speedMenu');
        };
        document.getElementById('filterMenu').onclick = (e) => e.stopPropagation();
        document.getElementById('rotateMenu').onclick = (e) => e.stopPropagation();
        document.getElementById('speedMenu').onclick = (e) => e.stopPropagation();

        document.addEventListener('click', (e) => {
            const filterMenu = document.getElementById('filterMenu');
            const rotateMenu = document.getElementById('rotateMenu');
            const speedMenu = document.getElementById('speedMenu');

            if (!filterMenu.contains(e.target) && !e.target.closest('#filterBtn')) {
                this.filterMenuManager.close();
            }
            if (!rotateMenu.contains(e.target) && !e.target.closest('#rotateDropdownBtn')) {
                this.rotateMenuManager.close();
            }

            const speedBtn = document.getElementById('currentSpeedBtn');
            if (speedMenu && !speedMenu.contains(e.target) && !e.target.closest('#currentSpeedBtn')) {
                this.speedMenuManager.close();
            }
        });
    }

    setupFilterListeners() {
        const startInput = document.getElementById('filterStartInput');
        const endInput = document.getElementById('filterEndInput');
        const startInc = document.getElementById('filterStartIncrement');
        const startDec = document.getElementById('filterStartDecrement');
        const endInc = document.getElementById('filterEndIncrement');
        const endDec = document.getElementById('filterEndDecrement');

        if (!startInput || !endInput || !startInc || !startDec || !endInc || !endDec) return;

        const updateFilter = () => {
            const startVal = startInput.value.trim();
            const endVal = endInput.value.trim();

            if (startVal === '' || endVal === '') return;

            this.labelFilter = {
                start: this.parseDisplay(startVal),
                end: this.parseDisplay(endVal),
                active: true
            };
            this.renderInstructions();
        };

        const adjustValue = (input, delta) => {
            let currentFrames = this.parseDisplay(input.value.trim());
            let newFrames = Math.max(0, currentFrames + delta);
            input.value = this.formatDisplay(newFrames);
            updateFilter();
        };

        startInput.onchange = updateFilter;
        endInput.onchange = updateFilter;

        startInc.onclick = () => adjustValue(startInput, 1);
        startDec.onclick = () => adjustValue(startInput, -1);
        endInc.onclick = () => adjustValue(endInput, 1);
        endDec.onclick = () => adjustValue(endInput, -1);

        // Mouse wheel to increment/decrement filter inputs
        startInput.addEventListener('wheel', (e) => {
            e.preventDefault();
            adjustValue(startInput, e.deltaY < 0 ? 1 : -1);
        }, { passive: false });

        endInput.addEventListener('wheel', (e) => {
            e.preventDefault();
            adjustValue(endInput, e.deltaY < 0 ? 1 : -1);
        }, { passive: false });

        // Blur validation to prevent empty fields
        startInput.addEventListener('blur', () => {
            if (startInput.value.trim() === '') {
                startInput.value = this.formatDisplay(this.labelFilter.start);
            }
        });
        endInput.addEventListener('blur', () => {
            if (endInput.value.trim() === '') {
                endInput.value = this.formatDisplay(this.labelFilter.end);
            }
        });

        // REMOVED: Restrictive digit-only validation
    }

    updateZoomIconStates() {
        const zoom = this.transformManager.zoom;
        const btnIn = document.getElementById('zoomIn');
        const btnOut = document.getElementById('zoomOut');

        // Reset all first
        [btnIn, btnOut].forEach(btn => {
            if (!btn) return;
            btn.classList.remove('bg-gray-100', 'text-[#5f45ff]');
            btn.classList.add('text-gray-600');
        });

        if (zoom > 1) {
            btnIn.classList.add('bg-gray-100');
            if (zoom >= CONFIG.MAX_ZOOM) {
                btnIn.classList.add('text-[#5f45ff]');
            }
        } else if (zoom < 1) {
            btnOut.classList.add('bg-gray-100');
            if (zoom <= CONFIG.MIN_ZOOM) {
                btnOut.classList.add('text-[#5f45ff]');
            }
        }
    }

    setupZoomListeners() {
        const zoomContainer = document.getElementById('mainVideo').parentElement;
        zoomContainer.addEventListener('wheel', (e) => {
            e.preventDefault();
            // Scale step proportionally with scroll speed, clamped for control
            const rawDelta = Math.abs(e.deltaY);
            const step = Math.min(0.5, Math.max(0.1, rawDelta * 0.003));
            const direction = e.deltaY < 0 ? step : -step;
            this.transformManager.zoomTowards(direction, e.clientX, e.clientY);
            this.updateZoomIconStates();
        }, { passive: false });

        document.querySelectorAll(CONFIG.ZOOM_TOOLS_SELECTOR).forEach(btn => {
            btn.onclick = (e) => {
                e.stopPropagation();
                const mode = btn.dataset.mode;
                if (mode === 'in') {
                    this.transformManager.zoomIn(0.5);
                } else if (mode === 'out') {
                    this.transformManager.zoomOut(0.5);
                }
                this.updateZoomIconStates();
            };
        });

        document.getElementById('zoomFit').onclick = (e) => {
            e.stopPropagation();
            this.zoomToolManager.reset();
            zoomContainer.style.cursor = 'default';
            this.updateZoomIconStates();
        };

        // Initialize icon states
        this.updateZoomIconStates();
    }
    resetRotation() {
        const slider = document.getElementById('customRotateSlider');
        if (slider) slider.value = 0;
        if (input) input.value = 0;
        this.transformManager.setRotation(0);
        if (this.updateSliderFill) this.updateSliderFill(slider);
    }

    setupCustomRotationListeners() {
        // --- THIS METHOD IS REPLACED ---
        const app = this;
        const slider = document.getElementById('customRotateSlider');
        const input = document.getElementById('customRotateInput');
        const customMenu = document.getElementById('customRotateMenu');
        const resetBtn = document.getElementById('customRotateResetBtn');
        const incrementBtn = document.getElementById('rotateIncrementBtn');
        const decrementBtn = document.getElementById('rotateDecrementBtn');

        if (!slider || !input || !customMenu || !resetBtn || !incrementBtn || !decrementBtn) return;

        // Function to update the slider's background fill
        this.updateSliderFill = (targetSlider) => {
            if (!targetSlider) return;
            const val = (targetSlider.value - targetSlider.min) / (targetSlider.max - targetSlider.min) * 100;
            targetSlider.style.background = `linear-gradient(to right, #5f45ff ${val}%, #e5e7eb ${val}%)`;
        };

        // Function to handle value changes
        const syncRotation = (degrees) => {
            degrees = Math.max(0, Math.min(360, parseInt(degrees) || 0));

            // Update models and UI
            slider.value = degrees;
            input.value = degrees;
            app.transformManager.setRotation(degrees);

            // Update visual fill
            this.updateSliderFill(slider);
        };

        // Event Listeners
        slider.addEventListener('input', () => syncRotation(slider.value));
        input.addEventListener('input', () => syncRotation(input.value));

        incrementBtn.onclick = () => syncRotation(parseInt(input.value) + 1);
        decrementBtn.onclick = () => syncRotation(parseInt(input.value) - 1);

        // Mouse wheel to increment/decrement rotation input
        input.addEventListener('wheel', (e) => {
            e.preventDefault();
            syncRotation((parseInt(input.value) || 0) + (e.deltaY < 0 ? 1 : -1));
        }, { passive: false });

        resetBtn.ondblclick = () => this.resetRotation();

        // Close menu on click-away
        document.addEventListener('click', (e) => {
            if (!customMenu.contains(e.target) && !e.target.closest('#rotateDropdownBtn')) {
                customMenu.classList.add('hidden');
            }
        });

        // Initial fill
        this.updateSliderFill(slider);
    }
    setupRotationListeners() {
        // --- THIS METHOD IS REPLACED ---
        const app = this;
        document.getElementById('rotateActionBtn').onclick = () => {
            app.transformManager.rotate(90);
        };

        // Handle the preset degree options
        document.querySelectorAll('.rotate-opt').forEach(opt => {
            opt.onclick = (e) => {
                e.stopPropagation();
                const customRotateMenu = document.getElementById('customRotateMenu');
                const rotateMenu = document.getElementById('rotateMenu');

                // Check if this is the "Custom" button
                if (opt.innerText.toLowerCase() === 'custom') {
                    rotateMenu.classList.add('hidden'); // Hide the main menu
                    customRotateMenu.classList.remove('hidden'); // Show the custom slider
                } else {
                    const deg = parseInt(opt.dataset.deg);
                    app.transformManager.setRotation(isNaN(deg) ? 0 : deg);
                    rotateMenu.classList.add('hidden');
                }
            };
        });

        // Add the new listener setup for the custom slider
        this.setupCustomRotationListeners();
    }

    setupKeyboardShortcuts() {
        window.addEventListener('keydown', (e) => {
            // ESC Key: Blur any active input/textarea to allow switching shortcuts
            if (e.key === 'Escape') {
                const isTyping = document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA';
                if (isTyping) {
                    document.activeElement.blur();
                    e.preventDefault();
                    return;
                }
            }

            // Ignore shortcuts if the user is typing in an INPUT or a TEXTAREA
            const isTyping = document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA';
            if (isTyping) return;
            const key = e.key.toUpperCase();

            // 0. SPECIAL OVERRIDES (Enter for FullEdit Done)
            if (e.key === 'Enter' && this.editingAnnotationIndex !== -1) {
                e.preventDefault();
                this.saveFullEditSidebar();
                return;
            }

            // 1. Determine Context (Active Class or Full Edit)
            let currentClassId = this.activeClassId;
            const isFullEditMode = this.editingAnnotationIndex !== -1;

            if (isFullEditMode) {
                const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
                const cls = CONFIG.CLASSES.find(c => c.name === instruction.className);
                if (cls) currentClassId = cls.id;
            }

            // 2. CLASS-INTERNAL SHORTCUTS (PRIORITIZED)
            if (currentClassId) {
                const currentCls = CONFIG.CLASSES.find(c => c.id === currentClassId);

                // --- A. HANDLE SINGLE-INPUT TYPES (SingleText, SingleRadio, SingleChecklist) ---
                if (!currentCls.subInputs || currentCls.subInputs.length === 0) {

                    // A1. Focus Text Field Shortcut (e.g., 'Q')
                    if (currentCls.shortcut === key) {
                        e.preventDefault();
                        const inputId = isFullEditMode ? 'fullEditSidebarInput' : `input-field-${currentCls.id}`;
                        const input = document.getElementById(inputId);
                        if (input) {
                            input.focus();
                            // If it's a textarea, trigger the height sync
                            this.syncTextareaHeight(inputId, 22);
                        }
                        return;
                    }

                    // A2. Option Selection Shortcuts (e.g., 'W', 'E', 'A', 'S' for Radios/Checklists)
                    if (currentCls.optionShortcuts) {
                        const optIdx = currentCls.optionShortcuts.indexOf(key);
                        if (optIdx !== -1 && currentCls.options[optIdx]) {
                            e.preventDefault();
                            const val = currentCls.options[optIdx];
                            const type = currentCls.type || 'text';

                            if (type === 'radio') {
                                this.handleRadioSingleClick(currentCls.id, currentCls.name, val);
                            } else if (type === 'checklist') {
                                this.handleChecklistSingleClick(currentCls.id, currentCls.name, val);
                            }

                            // If in Full Edit, we need to refresh that specific UI
                            if (isFullEditMode) {
                                this.renderFullEditSidebarContent();
                            }
                            return;
                        }
                    }
                }

                // --- B. HANDLE MULTI-INPUT TYPES (With subInputs) ---
                else {
                    // Option Focus / Text Input Shortcuts (Dedicated Focus for active sub-input)
                    if (this.activeSubInputKey) {
                        const idPrefix = this.activeSubInputKey.startsWith('fullEdit-') ? 'fullEdit-' : '';
                        const baseKey = idPrefix ? this.activeSubInputKey.substring(idPrefix.length) : this.activeSubInputKey;

                        if (baseKey.startsWith(currentClassId + '-')) {
                            const subId = baseKey.substring(currentClassId.length + 1);
                            const activeSub = currentCls?.subInputs?.find(s => s.id === subId);

                            if (activeSub && activeSub.type === 'text' && activeSub.optionShortcuts?.includes(key)) {
                                e.preventDefault();
                                document.getElementById(`input-field-${this.activeSubInputKey}`)?.focus();
                                return;
                            }
                        }
                    }

                    // Sub-input Level Toggle (e.g., 'Q' for Task)
                    const targetSub = currentCls?.subInputs?.find(s => s.shortcut === key);
                    if (targetSub) {
                        e.preventDefault();
                        const idPrefix = isFullEditMode ? 'fullEdit-' : '';
                        this.selectSubGroup(currentClassId, targetSub.id, idPrefix);
                        return;
                    }

                    // Option Level Selection for Radios/Checklists inside a subInput
                    if (this.activeSubInputKey) {
                        const idPrefix = this.activeSubInputKey.startsWith('fullEdit-') ? 'fullEdit-' : '';
                        const baseKey = idPrefix ? this.activeSubInputKey.substring(idPrefix.length) : this.activeSubInputKey;

                        if (baseKey.startsWith(currentClassId + '-')) {
                            const subId = baseKey.substring(currentClassId.length + 1);
                            const activeSub = currentCls.subInputs?.find(s => s.id === subId);

                            if (activeSub && activeSub.optionShortcuts) {
                                const optIdx = activeSub.optionShortcuts.indexOf(key);
                                if (optIdx !== -1 && activeSub.options[optIdx]) {
                                    e.preventDefault();
                                    const val = activeSub.options[optIdx];
                                    if (activeSub.type === 'radio') {
                                        this.handleRadioCircleClick(currentClassId, currentCls.name, subId, val, idPrefix);
                                    } else if (activeSub.type === 'checklist') {
                                        this.handleChecklistSquareClick(currentClassId, currentCls.name, subId, val, idPrefix);
                                    }
                                    return;
                                }
                            }
                        }
                    }
                }
            }

            // 3. GLOBAL CLASS LEVEL SHORTCUT (To open/toggle the class)
            const targetClass = CONFIG.CLASSES.find(c => c.classShortcut === key);
            if (targetClass) {
                e.preventDefault();
                this.toggleDynamicClassInput(targetClass.id);
                return;
            }

            // 4. NAVIGATION & PLAYBACK CONTROLS
            if (e.altKey && key === 'T') { e.preventDefault(); this.toggleDisplayTimestamps(); return; }

            if (e.ctrlKey && e.shiftKey) {
                if (e.key === 'ArrowRight') { e.preventDefault(); this.navTo('next'); return; }
                if (e.key === 'ArrowLeft') { e.preventDefault(); this.navTo('prev'); return; }
            }

            if (e.ctrlKey) {
                if (key === 'I') { e.preventDefault(); this.togglePinIssueMode(); return; }
                if (e.key === 'ArrowRight') { e.preventDefault(); this.jumpToLastFrame(); return; }
                if (e.key === 'ArrowLeft') { e.preventDefault(); this.jumpToFirstFrame(); return; }
            }

            if (e.shiftKey) {
                if (e.key === 'ArrowRight') { e.preventDefault(); this.navTo('next', 'classification'); return; }
                if (e.key === 'ArrowLeft') { e.preventDefault(); this.navTo('prev', 'classification'); return; }
            }

            if (e.key === ' ') { this.videoController.togglePlayPause(); e.preventDefault(); }
            if (e.key === 'ArrowRight') { e.preventDefault(); this.videoController.advanceFrame(); }
            if (e.key === 'ArrowLeft') { e.preventDefault(); this.videoController.rewindFrame(); }
            if (e.key === 'ArrowUp') { e.preventDefault(); this.speedMenuManager.step('up'); }
            if (e.key === 'ArrowDown') { e.preventDefault(); this.speedMenuManager.step('down'); }

            // 5. ANNOTATION OVERLAY SHORTCUTS
            if (this.annotationModel.isActive()) {
                if (key === 'Z') this.saveThisFrame();
                if (key === 'X') this.setThisFrame();
                if (key === 'C') this.setStartToCurrent();
                if (key === 'V') this.setEndToCurrent();
                if (key === 'N') this.addNewRange();
                if (key === 'M') this.saveAnnotation();
            }
        });
    }

    openAnnotationPanel(value) {
        if (!this.videoController.duration || isNaN(this.videoController.duration)) return;

        const totalFrames = this.videoController.getTotalFrames();
        const currentClass = this.annotationModel.className; // e.g., "Action tags"

        const wasActive = this.annotationModel.isActive();
        this.annotationModel.activate(value, totalFrames);

        // Start with ONE adjustable range spanning the whole video ONLY if freshly opening
        if (!wasActive) {
            this.sliderRanges = [{ start: 0, end: totalFrames }];
        }

        // UPDATE UI HEADERS
        const overlayHeader = document.querySelector('#annotationOverlay .annotation-overlay-header');
        if (overlayHeader) {
            overlayHeader.innerHTML = `${PARTITION_ICON_SVG} Add classification: ${currentClass}`;
        }

        this.annotationPanelView.updateClassTag(value);
        this.annotationPanelView.show();

        // Render the (empty) slider — shows clean grey track with pill row hidden
        this.renderSliderRanges();
        this.updateAddRangeButton();
        this.updateAnnotationSlider();
    }

    closeAnnotationPanel() {
        this.annotationPanelView.hide();
        this.annotationModel.deactivate();
        this.editingAnnotationIndex = -1; // Reset editing state on close/cancel

        // Reset dynamic class input UI state
        this.activeClassId = null;
        this.activeSubInputKey = null;
        this.expandedSubGroups = {};
        this.dynamicInputValues = {};
        this.renderClassList();

        // Clear multi-range state and remove all dynamic range segments
        this.sliderRanges = [];
        const track = document.getElementById('sliderTrackBase');
        if (track) track.querySelectorAll('.range-segment').forEach(el => el.remove());
        this.setAddRangeButtonDisabled(false); // Re-enable for next open

        // Restore the legacy primary-range widgets so the slider shows cleanly on next open
        ['knobStart', 'knobEnd', 'sliderHighlight', 'knobCurrent'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = '';
        });

        // Always keep static edge labels visible
        ['staticLabelStart', 'staticLabelEnd'].forEach(id => {
            const el = document.getElementById(id);
            if (el) { el.style.display = ''; el.style.opacity = '1'; }
        });

        // Also hide the pill row and restore input block
        const pillRow = document.getElementById('rangesPillRow');
        const inputBlock = document.getElementById('rangesInputBlock');
        if (pillRow) { pillRow.style.display = 'none'; pillRow.innerHTML = ''; }
        if (inputBlock) inputBlock.style.display = '';

        // Safely clear dynamic input values globally when panel closes
        this.dynamicInputValues = {};

        // Update DOM inputs without hiding the active area so UI doesn't collapse
        CONFIG.CLASSES.forEach(cls => {
            const inputArea = document.getElementById(`input-area-${cls.id}`);
            if (inputArea) {
                const textareas = inputArea.querySelectorAll('textarea');
                textareas.forEach(ta => {
                    ta.value = '';
                    ta.style.height = '24px';
                });
            }
        });
    }

    updateAnnotationSlider() {
        if (!this.annotationModel.isActive() || !this.videoController.duration) return;
        const totalFrames = this.videoController.getTotalFrames();
        const currentFrame = this.videoController.getCurrentFrame();
        const { start, end } = this.annotationModel.getRange();

        // Pass sliderRanges to support multi-range segments in UI styling
        this.annotationPanelView.updateSlider(start, end, currentFrame, totalFrames, this.sliderRanges);
    }

    setStartToCurrent() {
        const frame = this.videoController.getCurrentFrame();
        // Target the latest added range specifically
        if (this.sliderRanges.length > 0) {
            const idx = this.sliderRanges.length - 1;
            const range = this.sliderRanges[idx];
            this.sliderRanges[idx].start = Math.max(0, Math.min(frame, range.end - 1));

            // Sync model if it's the primary range
            if (idx === 0) this.annotationModel.setRange(this.sliderRanges[0].start, range.end);

            this.renderSliderRanges();
            this.updateAnnotationSlider();
            this.updateAddRangeButton();
        }
    }

    setEndToCurrent() {
        const frame = this.videoController.getCurrentFrame();
        // Target the latest added range specifically
        if (this.sliderRanges.length > 0) {
            const idx = this.sliderRanges.length - 1;
            const range = this.sliderRanges[idx];
            this.sliderRanges[idx].end = Math.min(this.videoController.getTotalFrames(), Math.max(frame, range.start + 1));

            // Sync model if it's the primary range
            if (idx === 0) this.annotationModel.setRange(range.start, this.sliderRanges[0].end);

            this.renderSliderRanges();
            this.updateAnnotationSlider();
            this.updateAddRangeButton();
        }
    }

    saveAnnotation(event) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }

        // 1. Find the active class
        const activeClass = CONFIG.CLASSES.find(c => c.name === this.annotationModel.className);
        if (!activeClass) return;

        // 2. Collect values
        let val = '';
        const hasSubInputs = activeClass.subInputs && activeClass.subInputs.length > 0;

        if (hasSubInputs) {
            const values = {};
            activeClass.subInputs.forEach(sub => {
                // Check internal values first (for radio, dropdown, checklist)
                const storedVal = (this.dynamicInputValues[activeClass.id] && this.dynamicInputValues[activeClass.id][sub.id]);
                if (storedVal !== undefined && storedVal !== '') {
                    values[sub.id] = storedVal;
                } else {
                    // Fallback to DOM for text types if not in internal state
                    const field = document.getElementById(`input-field-${activeClass.id}-${sub.id}`);
                    values[sub.id] = field ? field.value : '';
                }
            });
            val = JSON.stringify(values);
        } else {
            const inputEl = document.getElementById(`input-field-${activeClass.id}`);
            val = inputEl ? inputEl.value : '';
        }

        if (this.editingAnnotationIndex === -1) {
            if (hasSubInputs) {
                try {
                    const parsed = JSON.parse(val);
                    const anyContent = Object.values(parsed).some(v => v && v.trim().length > 0);
                    if (!anyContent) return;
                } catch (e) { return; }
            } else if (!val.trim()) {
                return;
            }
        }

        const { start, end } = this.annotationModel.getRange();

        // Overwrite Validation
        if (CONFIG.overwrite_validate) {
            // FIX: Pass all ranges (sliderRanges) or the single model range to the detector
            const rangesToCheck = this.sliderRanges.length > 0 
                ? this.sliderRanges 
                : [this.annotationModel.getRange()];

            const overlaps = this.detectOverlaps(this.annotationModel.className, rangesToCheck, this.editingAnnotationIndex);
            
            if (overlaps.length > 0) {
                this.showOverwriteValidation(overlaps, () => {
                    const indicesToDelete = overlaps.map(o => o.index);
                    this.annotationModel.deleteInstructions(indicesToDelete);
                    
                    // Adjust index if we deleted items appearing before our current edit
                    if (this.editingAnnotationIndex > -1) {
                        const deletedBefore = indicesToDelete.filter(idx => idx < this.editingAnnotationIndex).length;
                        this.editingAnnotationIndex -= deletedBefore;
                    }
                    this.performSave(val);
                });
                return;
            }
        }

        this.performSave(val);
    }

    performSave(val) {
        // Consolidate all ranges in sliderRanges into a single string "s1 - e1 | s2 - e2"
        const consolidatedFrames = this.sliderRanges.length > 0
            ? this.sliderRanges.map(r => `${r.start} - ${r.end}`).join(' | ')
            : `${this.annotationModel.getRange().start} - ${this.annotationModel.getRange().end}`;

        if (this.editingAnnotationIndex > -1) {
            const instruction = this.annotationModel.instructions[this.editingAnnotationIndex];
            instruction.text = val;
            instruction.frames = consolidatedFrames;
        } else {
            this.annotationModel.setValue(val);
            if (!this.annotationModel.save(consolidatedFrames)) return;
        }

        this.renderInstructions();
        this.timelineView.renderTracks(this.annotationModel.getInstructions());

        const output = document.getElementById('annotations_output');
        if (output) {
            output.value = JSON.stringify(this.annotationModel.getInstructions());
        }

        // RESET STATE
        this.editingAnnotationIndex = -1;
        const activeClass = CONFIG.CLASSES.find(c => c.name === this.annotationModel.className);
        if (activeClass) {
            if (activeClass.subInputs && activeClass.subInputs.length > 0) {
                activeClass.subInputs.forEach(sub => {
                    const inputEl = document.getElementById(`input-field-${activeClass.id}-${sub.id}`);
                    if (inputEl) {
                        inputEl.value = '';
                        inputEl.style.height = '24px';
                        inputEl.blur();
                    }
                });
            } else {
                const inputEl = document.getElementById(`input-field-${activeClass.id}`);
                if (inputEl) {
                    inputEl.value = '';
                    inputEl.style.height = '24px'; // Reset height
                    inputEl.blur();
                }
            }
        }

        this.closeAnnotationPanel();
        this.closeFullEditSidebar();
    }

    detectOverlaps(className, activeRanges, excludeIndex = -1) {
        const overlaps = [];
        this.annotationModel.instructions.forEach((instr, idx) => {
            if (idx === excludeIndex) return;
            if (instr.className !== className) return;

            // Existing ranges in the saved label
            const existingRanges = instr.frames.split(' | ');
            
            // Check if ANY of our current new ranges overlap ANY of the saved ranges
            const hasOverlap = activeRanges.some(newRange => {
                return existingRanges.some(existRangeStr => {
                    const [instrStart, instrEnd] = existRangeStr.split(' - ').map(Number);
                    // Geometric overlap check
                    return newRange.start < instrEnd && newRange.end > instrStart;
                });
            });

            if (hasOverlap) {
                overlaps.push({ index: idx, frames: instr.frames, text: instr.text });
            }
        });
        return overlaps;
    }

    showOverwriteValidation(conflicts, onConfirm) {
        const modal = document.getElementById('overwriteValidationModal');
        const detailsContainer = document.getElementById('overlapDetails');
        const confirmBtn = document.getElementById('confirmOverwriteBtn');

        if (!modal || !detailsContainer || !confirmBtn) return;

        detailsContainer.innerHTML = conflicts.map(c => {
            // Split all ranges for the conflicting annotation (handles multiple segments)
            const rangeTags = c.frames.split(' | ').map(rangeStr => {
                const [s, e] = rangeStr.split(' - ').map(Number);
                // Convert frames to MM:SS using formatDisplay
                return `<span class="frame-tag-box line-through">${this.formatDisplay(s)} - ${this.formatDisplay(e)}</span>`;
            }).join('');

            return `
            <div class="overwrite-card">
                <div class="flex items-center gap-2 mb-1 text-gray-700">
                    <div class="text-gray-400 flex items-center justify-center">${PARTITION_ICON_SVG}</div>
                    <span class="text-[14px] font-medium">${this.annotationModel.className}</span>
                </div>
                
                <div class="flex items-start gap-2 mb-2 text-[13px] text-gray-500">
                    <span class="shrink-0">Time</span> 
                    <div class="flex flex-wrap gap-1">
                        ${rangeTags}
                    </div>
                </div>

                <div class="flex flex-wrap w-full gap-y-1">
                    ${this.formatAnnotationValue(c.text, this.annotationModel.className)}
                </div>
            </div>
        `;
        }).join('');

        confirmBtn.onclick = () => {
            this.hideOverwriteValidation();
            onConfirm();
        };

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    hideOverwriteValidation() {
        const modal = document.getElementById('overwriteValidationModal');
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    }

    renderInstructions() {
        const currentFrame = this.videoController ? this.videoController.getCurrentFrame() : 0;
        this.instructionRenderer.render(
            this.annotationModel.getInstructions(),
            this.labelListMode,
            currentFrame
        );
    }

    deleteAnnotation(idx) {
        const indexToDelete = (idx !== undefined) ? idx : this.editingAnnotationIndex;

        if (this.annotationModel.deleteInstruction(indexToDelete)) {
            this.renderInstructions();
            this.timelineView.renderTracks(this.annotationModel.getInstructions());

            const output = document.getElementById('annotations_output');
            if (output) {
                output.value = JSON.stringify(this.annotationModel.getInstructions());
            }

            // Ensure everything closes and state resets
            this.closeAnnotationPanel();
            this.closeFullEditSidebar();
        }
        this.hideDeleteConfirmation();
        this.hideAllMenus();
    }

    clearSidebarInput() {
        const input = document.getElementById('classValueInput');
        if (input) input.value = '';
        this.closeAnnotationPanel();
    }

    loadVideo() {
        const isLocal = window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1";
        const video = document.getElementById('mainVideo');

        if (isLocal) {
            this.videoController.setSrc("episode_4.mp4");
            this.videoName = "episode_4.mp4";
            document.getElementById('videoNameDisplay').innerText = "episode_4.mp4";
        } else {
            const rawRef = "{{ task.input['source-ref'] }}";
            if (window.sageMakerData && window.sageMakerData.videoName) {
                this.videoName = window.sageMakerData.videoName;
                document.getElementById('videoNameDisplay').innerText = window.sageMakerData.videoName;
            } else if (rawRef && !rawRef.includes('{' + '{')) {
                this.videoName = rawRef.split('/').pop();
                document.getElementById('videoNameDisplay').innerText = this.videoName;
            }
            video.load();
        }
    }

    setupResizerListeners() {
        const sidebarResizer = document.getElementById('sidebarHResizer');
        const classesSection = document.getElementById('classesSection');
        const sidebarVResizer = document.getElementById('sidebarVResizer');
        const sidebar = document.getElementById('sidebar');
        const mainResizer = document.getElementById('resizer');
        const timelineSection = document.getElementById('timelineSection');
        const issuesVResizer = document.getElementById('issuesVResizer');
        const issuesSidebar = document.getElementById('issuesSidebar');
        const videoArea = document.getElementById('mainVideo')?.parentElement;
        if (issuesVResizer && issuesSidebar) {
            issuesVResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startX = e.clientX;
                const startWidth = issuesSidebar.offsetWidth;
                document.body.style.cursor = 'ew-resize';
                document.body.classList.add('select-none');
                if (videoArea) videoArea.style.pointerEvents = 'none';

                const onMouseMove = (moveEvent) => {
                    // Moving left increases width (since it's pinned to the right)
                    const deltaX = startX - moveEvent.clientX;
                    const newWidth = Math.max(260, Math.min(600, startWidth + deltaX));
                    issuesSidebar.style.width = `${newWidth}px`;
                    issuesSidebar.style.flex = 'none';
                    issuesSidebar.style.flexShrink = '0';

                    // Force re-fit on resize (Center Content behavior)
                    if (this.transformManager) {
                        requestAnimationFrame(() => {
                            this.transformManager.resetTransform();
                            this.updateZoomIconStates();
                        });
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                    if (videoArea) videoArea.style.pointerEvents = 'auto';
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        if (sidebarResizer && classesSection) {
            sidebarResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startY = e.clientY;
                const startHeight = classesSection.offsetHeight;
                document.body.style.cursor = 'ns-resize';
                document.body.classList.add('select-none');
                if (videoArea) videoArea.style.pointerEvents = 'none';

                const onMouseMove = (moveEvent) => {
                    const deltaY = moveEvent.clientY - startY;
                    const newHeight = Math.max(80, Math.min(window.innerHeight - 200, startHeight + deltaY));
                    classesSection.style.height = `${newHeight}px`;
                    classesSection.style.flex = 'none';
                    classesSection.classList.remove('h-[48%]');

                    // Force re-fit on resize
                    if (this.transformManager) {
                        requestAnimationFrame(() => {
                            this.transformManager.resetTransform();
                            this.updateZoomIconStates();
                        });
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                    if (videoArea) videoArea.style.pointerEvents = 'auto';
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        if (sidebarVResizer && sidebar) {
            sidebarVResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startX = e.clientX;
                const startWidth = sidebar.offsetWidth;
                document.body.style.cursor = 'ew-resize';
                document.body.classList.add('select-none');
                if (videoArea) videoArea.style.pointerEvents = 'none';

                const onMouseMove = (moveEvent) => {
                    const deltaX = moveEvent.clientX - startX;
                    const newWidth = Math.max(CONFIG.SIDEBAR_MIN_WIDTH, Math.min(CONFIG.SIDEBAR_MAX_WIDTH, startWidth + deltaX));
                    sidebar.style.width = `${newWidth}px`;
                    sidebar.style.flex = 'none';
                    sidebar.style.flexShrink = '0';

                    // Force re-fit on resize
                    if (this.transformManager) {
                        requestAnimationFrame(() => {
                            this.transformManager.resetTransform();
                            this.updateZoomIconStates();
                        });
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                    if (videoArea) videoArea.style.pointerEvents = 'auto';
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        if (mainResizer && timelineSection) {
            mainResizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const startY = e.clientY;
                const startHeight = timelineSection.offsetHeight;
                document.body.style.cursor = 'ns-resize';
                document.body.classList.add('select-none');
                if (videoArea) videoArea.style.pointerEvents = 'none';

                const onMouseMove = (moveEvent) => {
                    const deltaY = startY - moveEvent.clientY;
                    const newHeight = Math.max(CONFIG.TIMELINE_MIN_HEIGHT, Math.min(window.innerHeight - 150, startHeight + deltaY));
                    timelineSection.style.height = `${newHeight}px`;
                    timelineSection.classList.remove('h-[350px]');
                    // Remove any height classes that might come from media queries if possible, 
                    // though inline style usually wins if !important is removed from CSS.
                    timelineSection.style.setProperty('height', `${newHeight}px`, 'important');

                    // Force re-fit on resize
                    if (this.transformManager) {
                        requestAnimationFrame(() => {
                            this.transformManager.resetTransform();
                            this.updateZoomIconStates();
                        });
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    document.body.style.cursor = '';
                    document.body.classList.remove('select-none');
                    if (videoArea) videoArea.style.pointerEvents = 'auto';
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }
    }

    toggleSearchClasses() {
        const title = document.getElementById('classesHeaderTitle');
        const searchWrapper = document.getElementById('classesSearchWrapper');
        const input = document.getElementById('classesSearchInput');

        if (!title || !searchWrapper || !input) return;

        if (searchWrapper.classList.contains('hidden')) {
            title.classList.add('hidden');
            searchWrapper.classList.remove('hidden');
            input.focus();
        } else {
            title.classList.remove('hidden');
            searchWrapper.classList.add('hidden');
            input.value = '';
            this.filterClasses(''); // Reset filter
        }
    }

    filterClasses(query) {
        const listContainer = document.getElementById('classListContainer');
        if (!listContainer) return;

        const items = listContainer.querySelectorAll('.class-group');
        const searchTerm = query.toLowerCase().trim();

        items.forEach(item => {
            const nameEl = item.querySelector('.flex.items-center.gap-2');
            const name = nameEl ? nameEl.textContent.toLowerCase() : '';
            if (name.includes(searchTerm)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }

}

// ============================================================================
// APPLICATION BOOTSTRAP
// ============================================================================

document.addEventListener('DOMContentLoaded', () => {
    window.app = new VideoAnnotationApp();
    window.app.initialize();
    // Expose global functions for backward compatibility with HTML onclick handlers
    window.toggleSidebarDropdown = (event) => {
        event.stopPropagation();
        const menu = document.getElementById('sidebarDropdownMenu');
        const isVisible = !menu.classList.contains('hidden') && menu.style.display === 'block';

        window.app.hideAllMenus();

        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'block';
            // Close when an item inside is clicked
            menu.onclick = () => window.app.hideAllMenus();
        }
    };

    // Ensure dropdowns close when clicking elsewhere
    document.addEventListener('click', (e) => {
        if (window.app) {
            // Prevent sudden closing: If the element clicked was removed from DOM during event bubble
            // (e.g. by re-rendering the sidebar), ignore the click at the document level.
            if (!document.body.contains(e.target)) return;
            const isClickInsideDropdown = e.target.closest('.searchable-dropdown-wrap');
            const isClickInsideMenu = e.target.closest('.searchable-menu');

            // 2. If a dropdown is open AND the click is OUTSIDE of it
            if (window.app.openDropdownId && !isClickInsideDropdown && !isClickInsideMenu) {
                if (!document.body.contains(event.target)) return;

                const currentDropdownId = window.app.openDropdownId;
                window.app.openDropdownId = null;
                window.app.focusedDropdownId = null;

                // FIX: If the dropdown was in the Full Edit sidebar, refresh that. 
                // Otherwise refresh the main class list.
                if (currentDropdownId.startsWith('fullEdit-')) {
                    window.app.renderFullEditSidebarContent();
                } else {
                    window.app.renderClassList();
                }
            }
            const isClickOnCard = e.target.closest('.group\\/card');
            const isClickOnPopup = e.target.closest('[data-popup-type="canvasIssue"]');
            const isClickOnIcon = e.target.closest('.issue-icon-wrapper');
            const isClickOnForm = e.target.closest('#newIssueForm');

            // If we clicked outside relevant interaction areas, reset active state
            if (!isClickOnCard && !isClickOnPopup && !isClickOnIcon && !isClickOnForm) {
                if (window.app.activeIssueId !== null) {
                    window.app.activeIssueId = null;
                    window.app.refreshIssuesUI();
                }

                // Close all standard menus
                window.app.hideAllMenus();

                // Also close the filter popover on outside click
                const popover = document.getElementById('issueFilterPopover');
                if (popover) {
                    popover.classList.add('hidden');
                    popover.style.display = 'none';
                }
            }
        }
    });
    window.copyVideoName = () => {
        const name = document.getElementById('videoNameDisplay').innerText;
        navigator.clipboard.writeText(name).then(() => {
            const btn = document.querySelector('[onclick="copyVideoName()"]');
            // Change to green for success
            btn.classList.replace('text-[#5f45ff]', 'text-[#5f45ff]');
            setTimeout(() => {
                btn.classList.replace('text-[#5f45ff] text-shadow-xl', 'text-[#5f45ff]');
            }, 1000);
        });
    };
    window.submitToSageMaker = () => {
        // 1. Get the raw instructions from the model
        const rawData = window.app.annotationModel.getInstructions();

        // Helper: convert frame number -> "MM:SS" string (always MM:SS for output)
        const toMMSS = (frame) => {
            const totalSeconds = frame / CONFIG.FPS;
            const mins = Math.floor(totalSeconds / 60);
            const secs = Math.floor(totalSeconds % 60);
            return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        };

        // 2. Transform each instruction into the expected output format
        const annotations = rawData.map((ins, idx) => {
            // Parse the stored "start - end" frame string (e.g. "0 - 152")
            const frameParts = (ins.frames || '').split(' - ').map(s => parseInt(s.trim(), 10));
            const startFrame = isNaN(frameParts[0]) ? 0 : frameParts[0];
            const endFrame   = isNaN(frameParts[1]) ? 0 : frameParts[1];

            // Parse text: may be a JSON string (multi-input) or plain string
            let textObj = {};
            try {
                textObj = (typeof ins.text === 'string') ? JSON.parse(ins.text) : (ins.text || {});
            } catch (e) {
                textObj = { task_name: ins.text };
            }

            return {
                segment_id:          `seg_${String(idx + 1).padStart(3, '0')}`,
                original_start_time: toMMSS(startFrame),
                original_end_time:   toMMSS(endFrame),
                environment:         textObj.environment   || textObj.location_select || '',
                task:                textObj.task_name     || '',
                action_label:        textObj.action_label  || ''
            };
        });

        // 3. Write transformed output to the hidden field
        const outputField = document.getElementById('annotations_output');
        if (outputField) {
            outputField.value = JSON.stringify({ annotations });
        }

        // 4. Submit the form
        const form = document.querySelector('crowd-form');
        if (form) {
            form.submit();
        }
    };

    window.finalSubmit = () => {
        const progressStatus = document.getElementById('progress_status');
        if (progressStatus) {
            progressStatus.value = "completed";
        }
        window.submitToSageMaker();
    };

    // Intercept ALL crowd-form submits (including the crowd-button direct submit)
    // and pre-fill annotations_output with the transformed format before submission.
    const crowdForm = document.querySelector('crowd-form');
    if (crowdForm) {
        crowdForm.addEventListener('submit', () => {
            const rawData = window.app.annotationModel.getInstructions();

            const toMMSS = (frame) => {
                const totalSeconds = frame / CONFIG.FPS;
                const mins = Math.floor(totalSeconds / 60);
                const secs = Math.floor(totalSeconds % 60);
                return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
            };

            const annotations = rawData.map((ins, idx) => {
                const frameParts = (ins.frames || '').split(' - ').map(s => parseInt(s.trim(), 10));
                const startFrame = isNaN(frameParts[0]) ? 0 : frameParts[0];
                const endFrame   = isNaN(frameParts[1]) ? 0 : frameParts[1];

                let textObj = {};
                try {
                    textObj = (typeof ins.text === 'string') ? JSON.parse(ins.text) : (ins.text || {});
                } catch (e) {
                    textObj = { task_name: ins.text };
                }

                return {
                    segment_id:          `seg_${String(idx + 1).padStart(3, '0')}`,
                    original_start_time: toMMSS(startFrame),
                    original_end_time:   toMMSS(endFrame),
                    environment:         textObj.environment   || textObj.location_select || '',
                    task:                textObj.task_name     || '',
                    action_label:        textObj.action_label  || ''
                };
            });

            const outputField = document.getElementById('annotations_output');
            if (outputField) {
                outputField.value = JSON.stringify({ annotations });
            }
        });
    }

    window.setStartToCurrent = () => app.setStartToCurrent();
    window.setEndToCurrent = () => app.setEndToCurrent();
    window.saveAnnotation = () => app.saveAnnotation();
    window.clearSidebarInput = (e) => {
        if (e) e.stopPropagation(); // Prevent toggling the parent row

        const input = document.getElementById('classValueInput');
        input.value = '';

        if (window.app) {
            window.app.closeAnnotationPanel();
        }
    };
    document.getElementById('classValueInput')?.addEventListener('input', (e) => {
        const tagText = document.querySelector('#activeClassTag').firstChild;
    });
    window.toggleSidebarInput = () => {
        const area = document.getElementById('sidebarInputArea');
        area.classList.toggle('hidden');
    };

    window.openAnnotationPanel = (value) => app.openAnnotationPanel(value);
    window.closeAnnotationPanel = () => app.closeAnnotationPanel();
    window.switchTab = (el) => {
        // 1. Visual Toggle
        const tabs = el.parentElement.querySelectorAll('.tab-item');
        tabs.forEach(t => {
            t.classList.remove('active', 'bg-white', 'shadow-sm', 'text-black', 'font-normal');
            t.classList.add('text-gray-500');
        });
        el.classList.add('active', 'bg-white', 'shadow-sm', 'text-black', 'font-normal');
        el.classList.remove('text-gray-500');

        // 2. Logic Toggle
        const modeText = el.innerText.trim().toLowerCase(); // 'all' or 'frame'
        if (window.app) {
            window.app.switchLabelView(modeText);
        }
    };
});

/**
 * TooltipManager: Handles the display, positioning, and animation of custom tooltips
 */
class TooltipManager {
    constructor() {
        this.tooltip = null;
        this.activeElement = null;
        this.hideTimeout = null;
        this.init();
    }

    init() {
        // Create tooltip element if it doesn't exist
        if (!document.querySelector('.custom-tooltip')) {
            this.tooltip = document.createElement('div');
            this.tooltip.className = 'custom-tooltip';
            document.body.appendChild(this.tooltip);
        } else {
            this.tooltip = document.querySelector('.custom-tooltip');
        }

        // Global event listeners for tooltip triggers
        document.addEventListener('mouseover', (e) => {
            const target = e.target.closest('[data-tooltip]');
            if (target) {
                this.show(target);
            }
        });

        document.addEventListener('mouseout', (e) => {
            const target = e.target.closest('[data-tooltip]');
            if (target && target === this.activeElement) {
                // If we are dragging a knob, don't hide the tooltip even if mouse leaves it
                if (window.app && window.app.dragState && window.app.dragState.isActive()) {
                    const type = window.app.dragState.getType();
                    if (type === 'knobStart' || type === 'knobEnd') return;
                }

                // Check if we are moving to a child of the same element
                if (e.relatedTarget && target.contains(e.relatedTarget)) {
                    return;
                }
                this.hide();
            }
        });

        // Instant hide on click (unless clicking on a tooltip trigger)
        document.addEventListener('mousedown', (e) => {
            if (e.target.closest('[data-tooltip]')) return;
            this.hide(true);
        });
    }

    show(el) {
        // Clear any pending hide immediately
        if (this.hideTimeout) {
            clearTimeout(this.hideTimeout);
            this.hideTimeout = null;
        }

        const isCurrentlyVisible = this.tooltip.classList.contains('visible');

        // If clicking/holding a knob, we want it to follow.
        // We only skip if the content is exactly the same and the element is already visible
        const text = el.getAttribute('data-tooltip');
        const shortcut = el.getAttribute('data-shortcut');
        const theme = el.getAttribute('data-tooltip-theme');

        // Optimization: If same element is already active and visible, update content/position smoothly
        const mainSpan = this.tooltip.querySelector('span:first-child');
        if (this.activeElement === el && isCurrentlyVisible && mainSpan) {
            if (mainSpan.textContent !== text) {
                mainSpan.textContent = text;
            }
            this.updatePosition(el);
            return;
        }

        this.activeElement = el;

        // Reset classes
        this.tooltip.className = 'custom-tooltip';
        if (theme === 'white') {
            this.tooltip.classList.add('theme-white');
        }

        // Build content
        let content = `<span>${text}</span>`;
        if (shortcut) {
            content += `<span class="tooltip-shortcut">${shortcut}</span>`;
        }
        content += `<div class="tooltip-arrow"></div>`;

        this.tooltip.innerHTML = content;

        // Position strategy
        this.updatePosition(el);

        // Show with animation if not already visible
        if (!isCurrentlyVisible) {
            this.tooltip.classList.add('visible');
        }
    }

    hide(instant = false) {
        if (this.hideTimeout) clearTimeout(this.hideTimeout);

        if (instant) {
            this.activeElement = null;
            this.tooltip.classList.remove('visible');
            return;
        }

        this.hideTimeout = setTimeout(() => {
            this.activeElement = null;
            this.tooltip.classList.remove('visible');
            this.hideTimeout = null;
        }, 50); // Reduced from 100ms for faster response during rapid movement
    }

    updatePosition(el) {
        const rect = el.getBoundingClientRect();

        const isCurrentlyVisible = this.tooltip.classList.contains('visible');

        // SYNC CONTENT: Update text if it exists
        const content = el.getAttribute('data-tooltip');
        if (content) {
            // The tooltip structure uses a span for the main text
            const contentEl = this.tooltip.querySelector('span:first-child');
            if (contentEl && contentEl.innerText !== content) {
                contentEl.innerText = content;
            }
        }

        // Ensure tooltip is visible for measurement, but don't reset opacity if already visible
        if (!isCurrentlyVisible) {
            this.tooltip.style.opacity = '0';
            this.tooltip.style.display = 'flex';
        }

        const tooltipRect = this.tooltip.getBoundingClientRect();
        const arrow = this.tooltip.querySelector('.tooltip-arrow');

        const orientationPref = el.getAttribute('data-tooltip-pos');

        // Initial default: top
        let orientation = orientationPref === 'bottom' ? 'bottom' : 'top';
        let top, left;

        if (orientation === 'bottom') {
            top = rect.bottom + 12;
        } else {
            top = rect.top - tooltipRect.height - 12;
        }

        left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);

        // Auto-flip ONLY if no explicit preference and no space
        if (!orientationPref && top < 10) {
            top = rect.bottom + 12;
            orientation = 'bottom';
        }

        // Horizontal safety padding
        const padding = 10;
        if (left < padding) left = padding;
        if (left + tooltipRect.width > window.innerWidth - padding) {
            left = window.innerWidth - tooltipRect.width - padding;
        }

        this.tooltip.style.top = `${top}px`;
        this.tooltip.style.left = `${left}px`;
        this.tooltip.style.opacity = '';
        this.tooltip.style.display = '';

        // Update arrow class
        arrow.className = 'tooltip-arrow';
        if (orientation === 'top') {
            arrow.classList.add('tooltip-arrow-top');
        } else {
            arrow.classList.add('tooltip-arrow-bottom');
        }

        // Adjust arrow horizontal position to point to element center
        const elementCenter = rect.left + rect.width / 2;
        const arrowLeft = elementCenter - left - 6; // 6 is half of arrow width
        arrow.style.left = `${arrowLeft}px`;
    }
}

// Initialize TooltipManager on DOM content loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.tooltipManager = new TooltipManager();
    });
} else {
    window.tooltipManager = new TooltipManager();
}
