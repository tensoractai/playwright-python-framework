(() => {

    /**
     * VIDEO ANNOTATION WORKSPACE ENGINE
     * Architecture Pattern: OOP (Skeletal Structural Template)
     */

    var WORKSPACE_CONFIG = {
        ALLOW_MISSING: true,
        FPS: 30,
        DEFAULT_TIMESTAMP_FORMAT: 'Frames', // Default to Frames (FPS)
        TIMESTAMP_FORMATS: ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'],
        DEFAULT_PPS: 160,
        MIN_PPS: 40,
        MAX_PPS: 800,
        ZOOM_STEP: 0.1,
        MIN_ZOOM: 0.5,
        MAX_ZOOM: 8.0,
        DEFAULT_SPEEDS: [0.25, 0.5, 1.0, 1.5, 2.0, 4.0],
        DEFAULT_FRAME_SKIPS: [1, 2, 5, 10, 30, 60],
        DEFAULT_SPEED: 1.0,
        KEY_MAP: {
            PLAY_PAUSE: ' ',
            PREV_FRAME: 'ARROWLEFT',
            NEXT_FRAME: 'ARROWRIGHT',
            SPEED_UP: 'ARROWUP',
            SPEED_DOWN: 'ARROWDOWN',
            MARK_START: 'C',
            MARK_END: 'V',
            SAVE: 'S'
        },
        CLASSES: [
            { name: "Car", color: "#FF3838" },
            { name: "Truck", color: "#FF9D97" },
            { name: "Bus", color: "#FF701F" },
            { name: "Motorcycle", color: "#FFB21D" },
            { name: "Bicycle", color: "#CFD231" },
            { name: "Person", color: "#48F90A" },
            { name: "Animal", color: "#92CC17" },
            { name: "Fence", color: "#3DDB86" },
            { name: "Pole", color: "#1A9334" },
            { name: "Wall", color: "#00D4BB" },
            { name: "Traffic cone", color: "#2C99A8" },
            { name: "Garbage bin", color: "#00C2FF" },
            { name: "Bench", color: "#344593" },
            { name: "Mailbox", color: "#6473FF" },
            { name: "Parking meter", color: "#0018EC" },
            { name: "Bike rack", color: "#8438FF" },
            { name: "Utility box", color: "#520085" },
            { name: "Vegetation (trees/bushes)", color: "#CB38FF" },
            { name: "Any other collision-related object", color: "#FF95C8" },
            { name: "Stop sign", color: "#FF0000" },
            { name: "Fire hydrant", color: "#FF4500" },
            { name: "Planter", color: "#8B4513" },
            { name: "Ladder", color: "#A9A9A9" },
            { name: "Box", color: "#D2B48C" },
            { name: "Shopping cart", color: "#C0C0C0" },
            { name: "None", color: "#000000" }
        ]
    };

    class VideoController {
        constructor(videoElement) {
            if (!videoElement) throw new Error("Video element is required.");
            this.video = videoElement;
            this.frameSkipValue = 1;
            this._baseOffset = (this.video.readyState >= 1) ? this.video.currentTime : 0;
            this.video.addEventListener('loadedmetadata', () => {
                this._baseOffset = this.video.currentTime;
            });
        }

        getStartTime() {
            if (this.video.seekable && this.video.seekable.length > 0 && this.video.seekable.start(0) > 0) {
                return this.video.seekable.start(0);
            }
            return this._baseOffset || 0;
        }

        get currentTime() { return Math.max(0, this.video.currentTime - this.getStartTime()); }
        set currentTime(secs) { this.video.currentTime = Math.max(this.getStartTime(), Math.min(secs + this.getStartTime(), this.video.duration || 0)); }

        get duration() { 
            const d = this.video.duration || 0; 
            return Math.max(0, d - this.getStartTime());
        }
        get playbackRate() { return this.video.playbackRate; }
        set playbackRate(rate) { this.video.playbackRate = rate; }

        get muted() { return this.video.muted; }
        set muted(state) { this.video.muted = state; }

        getCurrentFrame() {
            return Math.round(this.currentTime * WORKSPACE_CONFIG.FPS);
        }

        getTotalFrames() {
            return Math.floor(this.duration * WORKSPACE_CONFIG.FPS);
        }

        seekToFrame(frameNumber) {
            this.currentTime = frameNumber / WORKSPACE_CONFIG.FPS;
        }

        stepFrames(direction = 1) {
            const targetFrame = this.getCurrentFrame() + (direction * this.frameSkipValue);
            this.seekToFrame(Math.max(0, Math.min(this.getTotalFrames(), targetFrame)));
        }

        togglePlay() {
            if (this.video.paused) {
                this.video.play().catch(e => console.error("Playback failed", e));
            } else {
                this.video.pause();
            }
            setTimeout(() => window.app?.workspace?.updatePlayState(), 50);
        }
    }

    class ViewportTransform {
        constructor(wrapperElement, videoElement) {
            this.wrapper = wrapperElement;
            this.video = videoElement;
            this.scale = 1.0;
            this.rotation = 0;       // normalized 0-359
            this.displayRotation = 0; // cumulative for smooth transitions
            this.translateX = 0;
            this.translateY = 0;
            this.isPanning = false;
            this.startX = 0;
            this.startY = 0;
            this.filters = { brightness: 100, contrast: 100, saturation: 100 };
            this.isPixelated = false;
        }

        zoom(delta, clientX = null, clientY = null) {
            const oldScale = this.scale;
            this.scale = Math.max(WORKSPACE_CONFIG.MIN_ZOOM, Math.min(WORKSPACE_CONFIG.MAX_ZOOM, this.scale + delta));

            if (clientX !== null && clientY !== null && this.wrapper) {
                const rect = this.wrapper.parentElement.getBoundingClientRect();
                const mouseX = clientX - rect.left - rect.width / 2;
                const mouseY = clientY - rect.top - rect.height / 2;
                const ratio = this.scale / oldScale;
                this.translateX = mouseX - (mouseX - this.translateX) * ratio;
                this.translateY = mouseY - (mouseY - this.translateY) * ratio;
            } else if (this.scale === 1.0) {
                this.translateX = 0;
                this.translateY = 0;
            }
            this.apply();
        }

        setZoom(scale) {
            this.scale = Math.max(WORKSPACE_CONFIG.MIN_ZOOM, Math.min(WORKSPACE_CONFIG.MAX_ZOOM, scale));
            this.apply();
        }

        /**
         * Set rotation — additive adds to current, otherwise sets absolute.
         * After rotating, syncs the slider + input UI.
         */
        rotate(degrees, additive = false) {
            if (additive) {
                this.displayRotation = (this.displayRotation + degrees) % 360;
            } else {
                this.displayRotation = degrees % 360;
            }
            // Keep normalized 0-359
            this.rotation = ((this.displayRotation % 360) + 360) % 360;
            this.apply();
            this._syncRotateUI();
        }

        /** Sync the slider and input to current rotation value */
        _syncRotateUI() {
            const val = Math.round(this.rotation);
            const slider = document.getElementById('customRotateSlider');
            const input = document.getElementById('customRotateInput');
            if (slider) {
                slider.value = val;
                _updateSliderFill(slider);
            }
            if (input) input.value = val;

            // Also update highlight for quick rotate options if exact match
            document.querySelectorAll('.rotate-opt').forEach(opt => {
                const deg = parseInt(opt.dataset.deg, 10);
                if (deg === val) opt.classList.add('active-opt');
                else opt.classList.remove('active-opt');
            });
        }

        startPan(clientX, clientY) {
            this.isPanning = true;
            this.startX = clientX - this.translateX;
            this.startY = clientY - this.translateY;
        }

        pan(clientX, clientY) {
            if (!this.isPanning) return;
            this.translateX = clientX - this.startX;
            this.translateY = clientY - this.startY;
            this.apply();
        }

        endPan() { this.isPanning = false; }

        reset() {
            this.scale = 1.0;
            this.rotation = 0;
            this.displayRotation = 0;
            this.translateX = 0;
            this.translateY = 0;
            this.apply();
            this._syncRotateUI();
        }

        apply() {
            if (!this.wrapper) return;
            this.wrapper.style.transform =
                `translate(${this.translateX}px, ${this.translateY}px) scale(${this.scale}) rotate(${this.displayRotation}deg)`;
        }

        /** Brightness/contrast/gamma (saturation) adjustment — mirrors Encord's filter panel. */
        setFilters(brightness, contrast, saturation) {
            this.filters = { brightness, contrast, saturation };
            this.applyFilters();
        }

        applyFilters() {
            if (!this.video) return;
            const { brightness, contrast, saturation } = this.filters;
            this.video.style.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
        }

        getFilters() {
            return { ...this.filters };
        }

        setPixelated(enabled) {
            this.isPixelated = enabled;
            if (!this.video) return;
            if (enabled) {
                this.video.style.setProperty('image-rendering', 'pixelated', 'important');
            } else {
                this.video.style.removeProperty('image-rendering');
            }
        }
    }

    /* -------------------------------------------------------
       Utility: update the linear-gradient fill of a range slider
       so the filled portion is purple and the rest is gray.
       ------------------------------------------------------- */
    function _updateSliderFill(slider) {
        const min = parseFloat(slider.min) || 0;
        const max = parseFloat(slider.max) || 359;
        const val = parseFloat(slider.value) || 0;
        const pct = ((val - min) / (max - min)) * 100;
        slider.style.background =
            `linear-gradient(to right, #5f45ff ${pct}%, #e5e7eb ${pct}%)`;
    }

    class UIManager {
        constructor(workspace) {
            this.workspace = workspace;
            this.activeMenuId = null;
            this.setupEventListeners();
        }

        setupEventListeners() {
            this.bindExtraToggles();

            // Menu buttons
            this._bindMenuBtn('rotateDropdownBtn', 'rotateMenu');
            this._bindMenuBtn('rotateActionBtn', 'customRotateMenu');
            this._bindMenuBtn('currentSpeedBtn', 'speedMenu');

            // Rotate quick options (45°, 90°, 180°) — absolute rotation for highlight matching
            document.querySelectorAll('.rotate-opt').forEach(opt => {
                opt.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const deg = parseInt(opt.dataset.deg, 10);
                    if (!isNaN(deg)) this.workspace.transform.rotate(deg, false);
                    this.closeAllMenus();
                });
            });

            // Zoom tools
            document.getElementById('zoomIn')?.addEventListener('click', () =>
                this.workspace.transform.zoom(WORKSPACE_CONFIG.ZOOM_STEP));
            document.getElementById('zoomOut')?.addEventListener('click', () =>
                this.workspace.transform.zoom(-WORKSPACE_CONFIG.ZOOM_STEP));
            document.getElementById('zoomFit')?.addEventListener('click', () =>
                this.workspace.transform.reset());

            // Custom Rotation Slider
            const rotateSlider = document.getElementById('customRotateSlider');
            const rotateInput = document.getElementById('customRotateInput');
            if (rotateSlider && rotateInput) {
                rotateSlider.addEventListener('input', (e) => {
                    const v = parseInt(e.target.value, 10);
                    rotateInput.value = v;
                    _updateSliderFill(rotateSlider);
                    this.workspace.transform.rotate(v, false);
                });
                rotateInput.addEventListener('input', (e) => {
                    let v = parseInt(e.target.value, 10);
                    if (isNaN(v)) v = 0;
                    v = Math.max(0, Math.min(359, v));
                    rotateSlider.value = v;
                    _updateSliderFill(rotateSlider);
                    this.workspace.transform.rotate(v, false);
                });
                // Initialize fill on load
                _updateSliderFill(rotateSlider);
            }

            // Rotate Reset Button (triangle icon inside customRotateMenu)
            const resetBtn = document.getElementById('customRotateResetBtn');
            if (resetBtn) {
                resetBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.workspace.transform.reset(); // resets rotation, zoom, translation
                });
            }

            // Rotate Increment / Decrement arrow buttons
            const incBtn = document.getElementById('rotateIncrementBtn');
            const decBtn = document.getElementById('rotateDecrementBtn');
            if (incBtn) {
                incBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const input = document.getElementById('customRotateInput');
                    let v = parseInt(input?.value || '0', 10);
                    v = ((v + 1) + 360) % 360;
                    if (input) input.value = v;
                    const slider = document.getElementById('customRotateSlider');
                    if (slider) { slider.value = v; _updateSliderFill(slider); }
                    this.workspace.transform.rotate(v, false);
                });
            }
            if (decBtn) {
                decBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const input = document.getElementById('customRotateInput');
                    let v = parseInt(input?.value || '0', 10);
                    v = ((v - 1) + 360) % 360;
                    if (input) input.value = v;
                    const slider = document.getElementById('customRotateSlider');
                    if (slider) { slider.value = v; _updateSliderFill(slider); }
                    this.workspace.transform.rotate(v, false);
                });
            }

            // Speed Menu
            const speedMenu = document.getElementById('speedMenu');
            if (speedMenu) {
                speedMenu.innerHTML = '';
                WORKSPACE_CONFIG.DEFAULT_SPEEDS.forEach(speed => {
                    const opt = document.createElement('div');
                    opt.className = 'px-3 py-1.5 text-[13px] hover:bg-gray-50 cursor-pointer rounded speed-opt text-center';
                    opt.innerText = speed + 'x';
                    opt.dataset.speed = speed;
                    opt.addEventListener('click', (e) => {
                        e.stopPropagation();
                        this.workspace.videoCtrl.playbackRate = speed;
                        const btn = document.getElementById('currentSpeedBtn');
                        if (btn) btn.innerText = speed + 'x';
                        this._updateActiveOption('speed-opt', speed.toString());
                        this.closeAllMenus();
                    });
                    speedMenu.appendChild(opt);
                });
                this._updateActiveOption('speed-opt', WORKSPACE_CONFIG.DEFAULT_SPEED.toString());
            }

            // Play Controls
            document.getElementById('btnPlayPause')?.addEventListener('click', () =>
                this.workspace.videoCtrl.togglePlay());
            document.getElementById('btnStart')?.addEventListener('click', () =>
                this.workspace.videoCtrl.stepFrames(-1));
            document.getElementById('btnNext')?.addEventListener('click', () =>
                this.workspace.videoCtrl.stepFrames(1));

            // Settings sub-menus
            this._bindSettingsSubMenus();

            // Brightness/contrast/gamma filter menu
            this._setupFilterMenu();
        }

        _updateActiveOption(className, value) {
            document.querySelectorAll('.' + className).forEach(el => {
                // Using dataset attribute matching what we assigned
                if (el.dataset.val === value || el.dataset.speed === value) {
                    el.classList.add('active-opt');
                } else {
                    el.classList.remove('active-opt');
                }
            });
        }

        /**
         * Menu button binding — stops propagation, closes other menus first.
         */
        _bindMenuBtn(btnId, menuId) {
            const btn = document.getElementById(btnId);
            const menu = document.getElementById(menuId);
            if (!btn || !menu) return;

            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = !menu.classList.contains('hidden');
                this.closeAllMenus();
                if (!isOpen) {
                    menu.classList.remove('hidden');
                    this.activeMenuId = menuId;
                }
            });

            // Prevent clicks inside menu from bubbling to document
            menu.addEventListener('click', (e) => e.stopPropagation());
        }

        /**
         * Filter menu — brightness/contrast/gamma(saturation) sliders, a
         * grayscale-channel presets submenu, and pixelated scaling. Mirrors
         * Encord's filter panel (brightness previously worked; contrast/gamma
         * and the rest of this menu did not exist at all).
         */
        _setupFilterMenu() {
            this._bindMenuBtn('filterBtn', 'filterMenu');

            const sliders = {
                brightRange: document.getElementById('brightRange'),
                contrastRange: document.getElementById('contrastRange'),
                gammaRange: document.getElementById('gammaRange'),
            };

            const applySliders = () => {
                const b = sliders.brightRange ? parseInt(sliders.brightRange.value, 10) : 100;
                const c = sliders.contrastRange ? parseInt(sliders.contrastRange.value, 10) : 100;
                const s = sliders.gammaRange ? parseInt(sliders.gammaRange.value, 10) : 100;
                this.workspace.transform.setFilters(b, c, s);
                Object.values(sliders).forEach(el => el && _updateSliderFill(el));
            };

            Object.values(sliders).forEach(el => {
                if (!el) return;
                el.addEventListener('input', applySliders);
                _updateSliderFill(el);
            });

            // Pixelated scaling checkbox
            const pixelToggle = document.getElementById('pixelatedToggle');
            if (pixelToggle) {
                pixelToggle.addEventListener('change', (e) => {
                    this.workspace.transform.setPixelated(e.target.checked);
                });
            }

            // "Filters" hover submenu (grayscale channel presets)
            const subTrigger = document.getElementById('filterSubTrigger');
            const subMenu = document.getElementById('filterSubMenu');
            const filterMenuEl = document.getElementById('filterMenu');
            if (subTrigger && subMenu) {
                const showSub = () => { subMenu.style.display = 'flex'; subMenu.style.flexDirection = 'column'; };
                const hideSub = (e) => {
                    if (!subMenu.contains(e?.relatedTarget) && !subTrigger.contains(e?.relatedTarget)) {
                        subMenu.style.display = 'none';
                    }
                };
                subTrigger.addEventListener('mouseenter', showSub);
                subTrigger.addEventListener('mouseleave', hideSub);
                subMenu.addEventListener('mouseleave', hideSub);
                subTrigger.addEventListener('click', (e) => {
                    e.stopPropagation();
                    subMenu.style.display === 'flex' ? subMenu.style.display = 'none' : showSub();
                });
                // Moving back into the slider section closes the submenu.
                filterMenuEl?.querySelector('.p-4')?.addEventListener('mouseenter', () => { subMenu.style.display = 'none'; });
            }

            this._applyFilterPreset('none'); // establish initial checkmark state
            document.querySelectorAll('.filter-opt').forEach(opt => {
                opt.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this._applyFilterPreset(opt.dataset.filter);
                });
            });
        }

        /**
         * Apply a grayscale-channel preset (or 'none' to restore the slider
         * values). The Red/Green/Blue options only desaturate — there's no true
         * per-channel tint in the underlying CSS filter — so all three currently
         * look identical. That matches the Encord reference exactly; it is not
         * something introduced here.
         */
        _applyFilterPreset(filterType) {
            document.querySelectorAll('.filter-opt').forEach(opt => {
                opt.querySelector('.check-mark')?.classList.toggle('hidden', opt.dataset.filter !== filterType);
            });
            const brightRange = document.getElementById('brightRange');
            const contrastRange = document.getElementById('contrastRange');
            const gammaRange = document.getElementById('gammaRange');
            const b = brightRange ? parseInt(brightRange.value, 10) : 100;
            const c = contrastRange ? parseInt(contrastRange.value, 10) : 100;
            const s = filterType === 'none' ? (gammaRange ? parseInt(gammaRange.value, 10) : 100) : 0;
            this.workspace.transform.setFilters(b, c, s);
        }

        /**
         * Settings menu sub-menus:
         */
        _bindSettingsSubMenus() {
            // ---- Timestamp Format SubMenu ----
            const tsTrigger = document.getElementById('timestampFormatTrigger');
            const tsSubMenu = document.getElementById('timestampFormatSubMenu');

            if (tsTrigger && tsSubMenu) {
                const formats = WORKSPACE_CONFIG.TIMESTAMP_FORMATS || ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'];
                if (tsSubMenu.children.length === 0) {
                    formats.forEach(fmt => {
                        const item = document.createElement('div');
                        item.className = 'ts-opt';
                        item.dataset.val = fmt;
                        item.style.cssText = 'padding:6px 12px;font-size:13px;cursor:pointer;border-radius:4px;color:#374151;white-space:nowrap;';
                        item.innerText = fmt;
                        item.addEventListener('mouseover', () => item.style.background = '#f9fafb');
                        item.addEventListener('mouseout', () => item.style.background = '');
                        item.addEventListener('click', (e) => {
                            e.stopPropagation();
                            this.workspace.timestampFormat = fmt;
                            document.getElementById('checkmark-timestamps')?.classList.remove('hidden');
                            this._updateActiveOption('ts-opt', fmt);
                            this.renderFrameSkipOptions();
                            this.workspace.updateWorkspaceUI(); // Force update display
                            this._hideSubMenus();
                            this.closeAllMenus();
                        });
                        tsSubMenu.appendChild(item);
                    });
                }
                this._updateActiveOption('ts-opt', WORKSPACE_CONFIG.DEFAULT_TIMESTAMP_FORMAT || 'Frames');

                const showTS = () => {
                    this._hideSubMenus();
                    tsSubMenu.style.display = 'flex';
                    tsSubMenu.style.flexDirection = 'column';
                };
                const hideTS = (e) => {
                    if (!tsSubMenu.contains(e?.relatedTarget) && !tsTrigger.contains(e?.relatedTarget)) {
                        tsSubMenu.style.display = 'none';
                    }
                };

                tsTrigger.addEventListener('mouseenter', showTS);
                tsTrigger.addEventListener('mouseleave', hideTS);
                tsSubMenu.addEventListener('mouseleave', hideTS);
                tsTrigger.addEventListener('click', (e) => {
                    e.stopPropagation();
                    tsSubMenu.style.display === 'flex' ? tsSubMenu.style.display = 'none' : showTS();
                });
            }

            // ---- Frame Skip SubMenu & Pill Options ----
            const fsTrigger = document.getElementById('frameSkipTrigger');
            const fsSubMenu = document.getElementById('frameSkipSubMenu');
            const fsContainer = document.getElementById('frameSkipOptionsContainer');

            if (fsTrigger && fsSubMenu) {
                this.renderFrameSkipOptions();

                const showFS = () => {
                    this._hideSubMenus();
                    fsSubMenu.style.display = 'flex';
                    fsSubMenu.style.flexDirection = 'column';
                };
                const hideFS = (e) => {
                    if (!fsSubMenu.contains(e?.relatedTarget) && !fsTrigger.contains(e?.relatedTarget)) {
                        fsSubMenu.style.display = 'none';
                    }
                };

                fsTrigger.addEventListener('mouseenter', showFS);
                fsTrigger.addEventListener('mouseleave', hideFS);
                fsSubMenu.addEventListener('mouseleave', hideFS);
                fsTrigger.addEventListener('click', (e) => {
                    e.stopPropagation();
                    fsSubMenu.style.display === 'flex' ? fsSubMenu.style.display = 'none' : showFS();
                });
            }

            // ---- Show frame skip selector toggle ----
            const skipRow = document.getElementById('toggle-skipselector-row');
            if (skipRow) {
                skipRow.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const pill = document.getElementById('frameSkipSelectorPill');
                    const ck = document.getElementById('checkmark-skipselector');
                    if (pill) {
                        const visible = !pill.classList.contains('hidden');
                        pill.classList.toggle('hidden', visible);
                        ck?.classList.toggle('hidden', visible);
                    }
                    this.closeAllMenus();
                });
            }

            // Prevent clicks inside settings menu from closing it
            document.getElementById('settingsMenu')?.addEventListener('click', e => e.stopPropagation());
        }

        _hideSubMenus() {
            const ts = document.getElementById('timestampFormatSubMenu');
            const fs = document.getElementById('frameSkipSubMenu');
            const filt = document.getElementById('filterSubMenu');
            if (ts) ts.style.display = 'none';
            if (fs) fs.style.display = 'none';
            if (filt) filt.style.display = 'none';
        }

        closeAllMenus() {
            ['filterMenu', 'rotateMenu', 'customRotateMenu', 'speedMenu',
                'frameSkipSelectorMenu', 'moreNavMenu', 'settingsMenu', 'interpolatePopover'].forEach(id => {
                    const m = document.getElementById(id);
                    if (m) { m.classList.add('hidden'); m.style.display = ''; }
                });
            this._hideSubMenus();
            this.activeMenuId = null;
        }

        // Extra bindings
        bindExtraToggles() {
            const btnVolume = document.getElementById('btnVolume');
            if (btnVolume) {
                btnVolume.addEventListener('click', () => {
                    const video = this.workspace.videoCtrl.video;
                    video.muted = !video.muted;
                    btnVolume.innerHTML = video.muted
                        ? `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M16 9a5 5 0 0 1 .95 2.293"></path><path d="M19.364 5.636a9 9 0 0 1 1.889 9.96"></path><path d="m2 2 20 20"></path><path d="m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11"></path><path d="M9.828 4.172A.686.686 0 0 1 11 4.657v.686"></path></svg>`
                        : `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"></path><path d="M16 9a5 5 0 0 1 0 6"></path><path d="M19.364 18.364a9 9 0 0 0 0-12.728"></path></svg>`;
                });
            }
            const btnSync = document.getElementById('btnSync');
            if (btnSync) {
                btnSync.addEventListener('click', (e) => {
                    e.stopPropagation();
                    btnSync.classList.toggle('text-brand-blue');
                });
            }
        }

        // Legacy
        bindToggle(btnId, menuId) { this._bindMenuBtn(btnId, menuId); }

        // Stub methods for HTML inline onclick handlers
        toggleFilterMenu() { document.getElementById('filterMenu')?.classList.toggle('hidden'); }
        toggleMoreNavMenu(e) {
            if (e) e.stopPropagation();
            const menu = document.getElementById('moreNavMenu');
            const btn = document.getElementById('moreNavBtn');
            if (!menu || !btn) return;
            const isVisible = !menu.classList.contains('hidden');
            this.closeAllMenus();
            if (!isVisible) {
                menu.classList.remove('hidden');
                menu.style.display = 'flex';
                const rect = btn.getBoundingClientRect();
                menu.style.visibility = 'hidden';
                const mh = menu.offsetHeight;
                menu.style.visibility = 'visible';
                const offset = 10;
                if (window.innerHeight - rect.bottom > mh + offset + 20) {
                    menu.style.top = (rect.bottom + offset) + 'px';
                    menu.style.bottom = 'auto';
                } else {
                    menu.style.top = 'auto';
                    menu.style.bottom = (window.innerHeight - rect.top + offset) + 'px';
                }
                menu.style.left = rect.left + 'px';
            }
        }
        toggleFrameSkipSelectorMenu(e) {
            if (e) e.stopPropagation();
            document.getElementById('frameSkipSelectorMenu')?.classList.toggle('hidden');
        }
        toggleSettingsMenu(e) {
            if (e) e.stopPropagation();
            const menu = document.getElementById('settingsMenu');
            const btn = document.getElementById('settingsBtn');
            if (!menu || !btn) return;
            const isVisible = !menu.classList.contains('hidden');
            this.closeAllMenus();
            if (!isVisible) {
                menu.classList.remove('hidden');
                menu.style.flexDirection = 'column';
                const rect = btn.getBoundingClientRect();
                menu.style.position = 'fixed';

                // Smart Positioning logic
                menu.style.visibility = 'hidden';
                menu.style.display = 'flex';
                const menuHeight = menu.offsetHeight;
                menu.style.visibility = 'visible';

                const offset = 10;
                const spaceBelow = window.innerHeight - rect.bottom;
                const rightFromWindow = window.innerWidth - rect.right;

                if (spaceBelow > menuHeight + offset + 20) {
                    // Space below
                    menu.style.top = `${rect.bottom + offset}px`;
                    menu.style.bottom = 'auto';
                } else {
                    // Place above
                    menu.style.top = 'auto';
                    menu.style.bottom = `${window.innerHeight - rect.top + offset}px`;
                }

                menu.style.right = `${rightFromWindow}px`;
                menu.style.left = 'auto';
                menu.style.zIndex = '999999';
            }
        }

        renderFrameSkipOptions() {
            if (!this.workspace) return;

            const fmt = this.workspace.timestampFormat;
            const fps = WORKSPACE_CONFIG.FPS || 30;

            let vals = [];
            if (fmt === 'Frames') {
                vals = [1, 2, 5, 8, 10, 15, 30];
            } else {
                vals = [
                    fps * 1,   // 1s
                    fps * 3,   // 3s
                    fps * 10,  // 10s
                    fps * 15,  // 15s
                    fps * 30,  // 30s
                    fps * 60,  // 1mins
                    fps * 300  // 5mins
                ];
            }

            const getLabel = (val) => {
                if (fmt === 'Frames') return `${val}f`;
                const num = parseInt(val, 10);
                if (num >= fps * 60 && num % (fps * 60) === 0) return `${num / (fps * 60)}mins`;
                if (num >= fps && num % fps === 0) return `${num / fps}s`;
                return `${num}f`;
            };

            const setFrameSkip = (val, e) => {
                if (e) e.stopPropagation();
                if (this.workspace.videoCtrl) {
                    this.workspace.videoCtrl.frameSkipValue = val;
                }
                this._updateActiveOption('fs-opt', val.toString());

                const pillDisplay = document.getElementById('currentFrameSkipDisplay');
                if (pillDisplay) {
                    pillDisplay.innerText = getLabel(val);
                }

                if (this._hideSubMenus) this._hideSubMenus();
                if (this.closeAllMenus) this.closeAllMenus();
            };

            const fsSubMenu = document.getElementById('frameSkipSubMenu');
            if (fsSubMenu) {
                fsSubMenu.innerHTML = '';
                vals.forEach(val => {
                    const item = document.createElement('div');
                    item.className = 'fs-opt';
                    item.dataset.val = val.toString();
                    item.style.cssText = 'padding:6px 0;font-size:13px;cursor:pointer;border-radius:4px;color:#374151;text-align:center;';
                    item.innerText = getLabel(val);
                    item.addEventListener('mouseover', () => item.style.background = '#f9fafb');
                    item.addEventListener('mouseout', () => item.style.background = '');
                    item.addEventListener('click', (e) => setFrameSkip(val, e));
                    fsSubMenu.appendChild(item);
                });
            }

            const fsContainer = document.getElementById('frameSkipOptionsContainer');
            if (fsContainer) {
                fsContainer.innerHTML = '';
                vals.forEach(val => {
                    const item = document.createElement('button');
                    item.type = 'button';
                    item.className = 'fs-opt w-full text-left px-3 py-1.5 text-[13px] hover:bg-gray-50 text-gray-700 transition-colors flex items-center justify-center';
                    item.dataset.val = val.toString();
                    item.innerText = getLabel(val);
                    item.addEventListener('click', (e) => setFrameSkip(val, e));
                    fsContainer.appendChild(item);
                });
            }

            const pillDisplay = document.getElementById('currentFrameSkipDisplay');
            if (pillDisplay && this.workspace.videoCtrl) {
                pillDisplay.innerText = getLabel(this.workspace.videoCtrl.frameSkipValue);
                this._updateActiveOption('fs-opt', this.workspace.videoCtrl.frameSkipValue.toString());
            }
        }

        setThisFrame() { /* Stub */ }
        saveThisFrame() { /* Stub */ }
        setStartToCurrent() { /* Stub */ }
        setEndToCurrent() { /* Stub */ }
        addNewRange() { /* Stub */ }
        saveAnnotation(e) { /* Stub */ }
        addCustomFrameSkip(e) { /* Stub */ }

        toggleSearchClasses() {
            const title = document.getElementById('classesHeaderTitle');
            const searchWrapper = document.getElementById('classesSearchWrapper');
            const input = document.getElementById('classesSearchInput');

            if (!title || !searchWrapper || !input) return;

            if (searchWrapper.classList.contains('hidden')) {
                title.classList.add('hidden');
                searchWrapper.classList.remove('hidden');
                input.focus();
            } else {
                title.classList.remove('hidden');
                searchWrapper.classList.add('hidden');
                input.value = '';
                this.filterClasses(''); // Reset filter
            }
        }

        toggleSearchLabels() {
            const title = document.getElementById('labelsHeaderTitleGroup');
            const searchWrapper = document.getElementById('labelsSearchWrapper');
            const input = document.getElementById('labelsSearchInput');

            if (!title || !searchWrapper || !input) return;

            if (searchWrapper.classList.contains('hidden')) {
                title.classList.add('hidden');
                searchWrapper.classList.remove('hidden');
                input.focus();
            } else {
                title.classList.remove('hidden');
                searchWrapper.classList.add('hidden');
                input.value = '';
                this.filterLabels(''); // Reset filter
            }
        }

        filterClasses(query) {
            const listContainer = document.getElementById('classListContainer');
            if (!listContainer) return;

            const items = listContainer.querySelectorAll('.class-item');
            const searchTerm = query.toLowerCase().trim();

            items.forEach(item => {
                const name = item.getAttribute('data-class') ? item.getAttribute('data-class').toLowerCase() : '';
                if (name.includes(searchTerm)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        filterLabels(query) {
            try {
                const listContainer = document.getElementById('sidebarMenuPortal');
                if (!listContainer) return;

                const frameCards = listContainer.querySelectorAll('.frame-card');
                if (!frameCards || frameCards.length === 0) return;

                const searchTerm = (query || '').toString().toLowerCase().trim();

                frameCards.forEach(card => {
                    const frameNumEl = card.querySelector('.frame-num');
                    const frameNumText = frameNumEl && frameNumEl.textContent ? frameNumEl.textContent.toLowerCase() : '';
                    const cardText = card.textContent ? card.textContent.toLowerCase() : '';

                    if (frameNumText.includes(searchTerm) || cardText.includes(searchTerm)) {
                        card.style.setProperty('display', 'block', 'important');
                    } else {
                        card.style.setProperty('display', 'none', 'important');
                    }
                });
            } catch (e) {
                console.error("Error in filterLabels:", e);
            }
        }
    }

    class SimpleTimeline {
        constructor(videoCtrl) {
            this.videoCtrl = videoCtrl;
            this.track = document.getElementById('progressTrack');
            this.fill = document.getElementById('progressFill');
            this.knob = document.getElementById('progressKnob');
            this.hoverPill = document.getElementById('hoverPill');
            this.isScrubbing = false;
            this.bindEvents();
        }

        bindEvents() {
            if (!this.track) return;

            const scrub = (e) => {
                const rect = this.track.getBoundingClientRect();
                const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                this.videoCtrl.currentTime = pct * this.videoCtrl.duration;
                this.update();
            };

            this.track.addEventListener('mousedown', (e) => { this.isScrubbing = true; scrub(e); });
            window.addEventListener('mousemove', (e) => { if (this.isScrubbing) scrub(e); });
            window.addEventListener('mouseup', () => { this.isScrubbing = false; });

            // Hover pill — show timestamp
            this.track.addEventListener('mousemove', (e) => {
                if (!this.hoverPill || this.videoCtrl.duration === 0) return;
                const rect = this.track.getBoundingClientRect();
                const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                const sec = pct * this.videoCtrl.duration;

                let displayVal = '';
                if (window.Workspace) {
                    displayVal = window.Workspace.formatTimeDisplay(sec, window.Workspace.timestampFormat);
                } else {
                    const mm = String(Math.floor(sec / 60)).padStart(2, '0');
                    const ss = String(Math.floor(sec % 60)).padStart(2, '0');
                    displayVal = `${mm}:${ss}`;
                }

                this.hoverPill.innerText = displayVal;
                this.hoverPill.style.left = `${pct * 100}%`;
                this.hoverPill.classList.remove('hidden');
            });
            this.track.addEventListener('mouseleave', () => {
                this.hoverPill?.classList.add('hidden');
            });
        }

        update() {
            if (!this.track || this.videoCtrl.duration === 0) return;
            const pct = (this.videoCtrl.currentTime / this.videoCtrl.duration) * 100;
            if (this.fill) this.fill.style.width = `${pct}%`;
            if (this.knob) this.knob.style.left = `${pct}%`;
        }
    }

    // Per-object keyboard shortcuts for the "Objects" checklist and the
    // "Frame" labels panel, assigned in QWERTY reading order. 26 letters
    // exactly covers WORKSPACE_CONFIG.CLASSES (26 entries); the frame
    // Row 0-3 Occupied/Empty radios use a separate digit-key set (1-8) so
    // the two panels — both visible in the sidebar at once — never clash.
    const OBJECT_HOTKEY_SEQUENCE = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P',
        'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
        'Z', 'X', 'C', 'V', 'B', 'N', 'M'];
    // Row0-Occupied, Row0-Empty, Row1-Occupied, Row1-Empty, ... Row3-Empty
    const ROW_OCCUPANCY_HOTKEYS = ['1', '2', '3', '4', '5', '6', '7', '8'];

    class WorkspaceManager {
        constructor() {
            this.videoCtrl = null;
            this.transform = null;
            this.timeline = null;
            this.ui = null;
            this.timestampFormat = WORKSPACE_CONFIG.DEFAULT_TIMESTAMP_FORMAT || 'Frames';
            this.activeLabelTab = 'Frame';
        }

        init() {
            const videoEl = document.getElementById('mainVideo');
            const wrapperEl = document.getElementById('videoTransformWrapper');

            this.videoCtrl = new VideoController(videoEl);
            this.transform = new ViewportTransform(wrapperEl, videoEl);
            this.timeline = new SimpleTimeline(this.videoCtrl);
            this.ui = new UIManager(this);

            // Set initial speed to 1x
            this.videoCtrl.playbackRate = WORKSPACE_CONFIG.DEFAULT_SPEED;

            this.renderClasses();

            this.bindEvents();
            this.bindShortcuts();
            this._bindLabelHotkeys();

            window.app = this.ui;

            videoEl.addEventListener('loadedmetadata', () => this.updateWorkspaceUI());
        }

        renderClasses() {
            const container = document.getElementById('classListContainer');
            if (!container) return;

            container.innerHTML = '';
            if (WORKSPACE_CONFIG.CLASSES) {
                WORKSPACE_CONFIG.CLASSES.forEach((cls, idx) => {
                    const item = document.createElement('label');
                    item.className = 'class-item group flex items-center justify-between pl-6 pr-3 py-1.5 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors w-full';
                    item.setAttribute('data-class', cls.name);
                    const hotkey = OBJECT_HOTKEY_SEQUENCE[idx] || '';
                    if (hotkey) item.setAttribute('data-hotkey', hotkey);

                    const isSelected = window.annotationState && window.annotationState.objects_in_roi && window.annotationState.objects_in_roi.includes(cls.name);
                    const content = `
                    <div class="flex items-center gap-3 w-full">
                        <input type="checkbox" class="w-[14px] h-[14px] rounded-[3px] border border-gray-300 text-[#5f45ff] focus:outline-none focus:ring-0 cursor-pointer object-checkbox shadow-sm checked:border-transparent" value="${cls.name}" ${isSelected ? 'checked' : ''} onchange="window.toggleObject('${cls.name}')" onkeydown="if(event.key === 'Enter') event.preventDefault();">
                        <span class="text-[13px] font-[450] text-[#4b5563] group-hover:text-gray-900 select-none flex-1">${cls.name}</span>
                        ${hotkey ? `<span class="kbd-key">${hotkey}</span>` : ''}
                    </div>
                `;
                    item.innerHTML = content;

                    container.appendChild(item);
                });
            }
        }

        /**
         * Keyboard shortcuts for the two always-visible sidebar panels:
         *  - "Objects" checklist (classListContainer) — letter keys from
         *    OBJECT_HOTKEY_SEQUENCE toggle the matching object on/off.
         *  - "Frame" labels panel (instructionContainer, only when the
         *    "Frame" tab is active) — digit keys from ROW_OCCUPANCY_HOTKEYS
         *    set a row's Occupied/Empty radio.
         * A dedicated listener (rather than folding this into bindShortcuts)
         * is needed because the Objects panel's search input auto-focuses
         * and would otherwise swallow these keystrokes; matching against the
         * item's CURRENT visibility means an active search filter still
         * takes precedence — a hotkey whose target got filtered out won't fire.
         */
        _bindLabelHotkeys() {
            document.addEventListener('keydown', (e) => {
                if (e.ctrlKey || e.altKey || e.metaKey) return;
                const active = document.activeElement;
                // Allow the classes search input to keep working (see comment
                // above); still block on any OTHER unrelated text input so we
                // don't hijack typing elsewhere in the page (e.g. frame number).
                if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') &&
                    active.id !== 'classesSearchInput') return;

                const key = e.key.toUpperCase();

                // Objects checklist
                const classContainer = document.getElementById('classListContainer');
                if (classContainer) {
                    const item = Array.from(classContainer.querySelectorAll('.class-item[data-hotkey]'))
                        .find(el => el.dataset.hotkey === key && el.style.display !== 'none');
                    if (item) {
                        e.preventDefault();
                        item.querySelector('.object-checkbox')?.click();
                        return;
                    }
                }

                // Frame Row Occupied/Empty labels (only rendered on the "Frame" tab)
                if (this.activeLabelTab === 'Frame') {
                    const instrContainer = document.getElementById('instructionContainer');
                    if (instrContainer) {
                        const label = Array.from(instrContainer.querySelectorAll('label[data-hotkey]'))
                            .find(el => el.dataset.hotkey === key);
                        if (label) {
                            e.preventDefault();
                            label.querySelector('input[type="radio"]')?.click();
                        }
                    }
                }
            });
        }

        bindEvents() {
            const video = this.videoCtrl.video;

            video.addEventListener('timeupdate', () => this.updateWorkspaceUI());
            video.addEventListener('play', () => this.updatePlayState());
            video.addEventListener('pause', () => this.updatePlayState());

            const container = document.getElementById('videoTransformWrapper');
            if (container) {
                const isInsideVideo = (e) => {
                    if (!video || !video.videoWidth || !video.videoHeight) return true;
                    const rect = video.getBoundingClientRect();
                    const videoRatio = video.videoWidth / video.videoHeight;
                    const elementRatio = rect.width / rect.height;
                    let actualWidth = rect.width;
                    let actualHeight = rect.height;
                    if (videoRatio > elementRatio) {
                        actualHeight = rect.width / videoRatio;
                    } else {
                        actualWidth = rect.height * videoRatio;
                    }
                    const actualLeft = rect.left + (rect.width - actualWidth) / 2;
                    const actualTop = rect.top + (rect.height - actualHeight) / 2;
                    return e.clientX >= actualLeft && e.clientX <= actualLeft + actualWidth &&
                        e.clientY >= actualTop && e.clientY <= actualTop + actualHeight;
                };

                container.parentElement.addEventListener('wheel', (e) => {
                    if (!isInsideVideo(e)) return;
                    e.preventDefault();
                    const step = e.deltaY < 0 ? WORKSPACE_CONFIG.ZOOM_STEP : -WORKSPACE_CONFIG.ZOOM_STEP;
                    this.transform.zoom(step, e.clientX, e.clientY);
                }, { passive: false });

                container.parentElement.addEventListener('mousedown', (e) => {
                    if (!isInsideVideo(e)) return;
                    if (e.button === 1 || e.shiftKey) {
                        this.transform.startPan(e.clientX, e.clientY);
                        container.parentElement.style.cursor = 'grabbing';
                    }
                });
                container.parentElement.addEventListener('mousemove', (e) => this.transform.pan(e.clientX, e.clientY));
                window.addEventListener('mouseup', () => {
                    this.transform.endPan();
                    if (container.parentElement) container.parentElement.style.cursor = 'default';
                });
            }

            // Close menus on outside click
            window.addEventListener('click', () => { if (this.ui) this.ui.closeAllMenus(); });
        }

        updatePlayState() {
            const icon = document.getElementById('playIconSvg');
            if (!icon) return;
            icon.innerHTML = this.videoCtrl.video.paused
                ? '<polygon points="6 3 20 12 6 21 6 3"></polygon>'
                : '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>';
        }

        formatTimeDisplay(totalSeconds, format) {
            if (format === 'Frames') {
                return Math.round(totalSeconds * WORKSPACE_CONFIG.FPS);
            }

            const hrs = Math.floor(totalSeconds / 3600);
            const mins = Math.floor((totalSeconds % 3600) / 60);
            const secs = Math.floor(totalSeconds % 60);
            const frames = Math.round((totalSeconds % 1) * WORKSPACE_CONFIG.FPS);

            if (format === 'HH:MM:SS') {
                return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            }
            if (format === 'MM:SS') {
                return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            }
            if (format === 'SS.FF') {
                return `${Math.floor(totalSeconds).toString().padStart(2, '0')}.${frames.toString().padStart(2, '0')}`;
            }
            return Math.round(totalSeconds * WORKSPACE_CONFIG.FPS);
        }

        updateWorkspaceUI() {
            if (this._uiUpdatePending) return;
            this._uiUpdatePending = true;
            requestAnimationFrame(() => {
                this._uiUpdatePending = false;
                if (!this.videoCtrl) return;

                const currentTime = this.videoCtrl.currentTime;
                const duration = this.videoCtrl.duration;

                const cfDisplay = this.formatTimeDisplay(currentTime, this.timestampFormat);
                const tfDisplay = this.formatTimeDisplay(duration, this.timestampFormat);

                const inp = document.getElementById('currentFrameInput');
                if (inp && document.activeElement !== inp) inp.value = cfDisplay;

                const tot = document.getElementById('totalFramesText');
                if (tot) tot.textContent = tfDisplay;

                this.timeline.update();
                if (this.activeLabelTab === 'Frame') {
                    this.renderLabels();
                }
                this.updateFrameDisplayFooter();
            });
        }

        updateFrameDisplayFooter() {
            const footer = document.getElementById('frameDisplayFooter');
            if (!footer) return;

            if (this.activeLabelTab === 'Frame') {
                const isFrames = this.timestampFormat === 'Frames';
                const prefixEl = document.getElementById('footerPrefix');
                const curEl = document.getElementById('currentFrameNumDisplay');
                const totEl = document.getElementById('totalFramesNumDisplay');

                if (prefixEl) {
                    prefixEl.textContent = isFrames ? 'Frame' : 'Time';
                }

                if (isFrames) {
                    const currentFrame = Math.round(this.videoCtrl.currentTime * WORKSPACE_CONFIG.FPS) || 0;
                    const totalFrames = Math.round(this.videoCtrl.duration * WORKSPACE_CONFIG.FPS) || 0;
                    if (curEl) curEl.textContent = currentFrame;
                    if (totEl) totEl.textContent = totalFrames;
                } else {
                    const cfDisplay = this.formatTimeDisplay(this.videoCtrl.currentTime, this.timestampFormat);
                    const tfDisplay = this.formatTimeDisplay(this.videoCtrl.duration, this.timestampFormat);
                    if (curEl) curEl.textContent = cfDisplay;
                    if (totEl) totEl.textContent = tfDisplay;
                }

                footer.classList.remove('hidden');
            } else {
                footer.classList.add('hidden');
            }
        }

        renderLabels() {
            const container = document.getElementById('instructionContainer');
            if (!container) return;

            if (this.activeLabelTab === 'Frame') {
                const currentFrame = Math.round(this.videoCtrl.currentTime * WORKSPACE_CONFIG.FPS) || 0;
                const occ = window.annotationState.frameOccupancy?.[currentFrame];

                let html = `
                <div class="flex flex-col items-center px-3 w-full h-full pb-6">
                    <div class="flex flex-col w-full max-w-[320px]">
                `;
                for (let r = 0; r < 4; r++) {
                    let rowTitle = `row_0${r}`;
                    let rowSub = "";
                    if (r === 0) rowSub = "Far from bumper";
                    else if (r === 3) rowSub = "Closest to bumper";

                    const isOcc = occ && occ[`row_${r}`] === true;
                    const isEmp = occ && occ[`row_${r}`] === false;
                    const occHotkey = ROW_OCCUPANCY_HOTKEYS[r * 2];
                    const empHotkey = ROW_OCCUPANCY_HOTKEYS[r * 2 + 1];

                    html += `
                        <div class="flex items-center justify-between py-4 px-2 transition-all duration-200 rounded-lg hover:bg-gray-50">
                            <div class="flex flex-col">
                                <span class="text-[13px] text-gray-800">${rowTitle}</span>
                                ${rowSub ? `<span class="text-[11px] text-gray-500 mt-0.5">${rowSub}</span>` : ''}
                            </div>
                            <div class="flex items-center gap-5">
                                <label class="flex items-center gap-2 cursor-pointer group/label w-[100px]" data-hotkey="${occHotkey}">
                                    <input type="radio" data-name="row_${r}_${currentFrame}" value="true" onchange="window.setOccupancy(${currentFrame}, ${r}, true)" ${isOcc ? 'checked' : ''} class="w-[15px] h-[15px] accent-[#5f45ff] cursor-pointer">
                                    <span class="text-[13px] text-gray-600 group-hover/label:text-gray-900 transition-colors">Occupied</span>
                                    <span class="kbd-key">${occHotkey}</span>
                                </label>
                                <label class="flex items-center gap-2 cursor-pointer group/label w-[90px]" data-hotkey="${empHotkey}">
                                    <input type="radio" data-name="row_${r}_${currentFrame}" value="false" onchange="window.setOccupancy(${currentFrame}, ${r}, false)" ${isEmp ? 'checked' : ''} class="w-[15px] h-[15px] accent-[#5f45ff] cursor-pointer">
                                    <span class="text-[13px] text-gray-600 group-hover/label:text-gray-900 transition-colors">Empty</span>
                                    <span class="kbd-key">${empHotkey}</span>
                                </label>
                            </div>
                        </div>
                    `;
                }
                html += `
                    </div>
                </div>`;
                container.innerHTML = html;
            } else {
                // All Mode
                let html = `<div class="flex flex-col gap-2 p-3">`;
                const frames = Object.keys(window.annotationState.frameOccupancy || {}).map(Number).sort((a, b) => a - b);
                if (frames.length === 0) {
                    html += `
                    <div class="flex flex-col items-center justify-center pt-10 pb-6">
                        <svg width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg">
                            <title>Simple Empty</title>
                            <g transform="translate(0 1)" fill="none" fill-rule="evenodd">
                                <ellipse fill="#f5f5f5" cx="32" cy="33" rx="32" ry="7"></ellipse>
                                <g fill-rule="nonzero" stroke="#d9d9d9">
                                    <path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path>
                                    <path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" fill="#fafafa"></path>
                                </g>
                            </g>
                        </svg>
                        <div class="mt-4 text-[#bfbfbf] text-[14px]">No annotations yet</div>
                    </div>
                `;
                } else {
                    for (let r = 0; r < 4; r++) {
                        let rowKey = `row_${r}`;
                        let rowFrames = frames.filter(f => window.annotationState.frameOccupancy[f][rowKey] !== undefined && window.annotationState.frameOccupancy[f][rowKey] !== null);
                        
                        let ranges = [];
                        if (rowFrames.length > 0) {
                            let start = rowFrames[0];
                            let prev = rowFrames[0];
                            let val = window.annotationState.frameOccupancy[start][rowKey];

                            for (let i = 1; i < rowFrames.length; i++) {
                                let curr = rowFrames[i];
                                let currVal = window.annotationState.frameOccupancy[curr][rowKey];
                                if (currVal !== val || curr !== prev + 1) {
                                    ranges.push({ start: start, end: prev, value: val });
                                    start = curr;
                                    val = currVal;
                                }
                                prev = curr;
                            }
                            ranges.push({ start: start, end: prev, value: val });
                        }
                        
                        let rowName = `row_0${r}`;
                        
                        html += `
                        <div class="border border-gray-100 rounded-lg bg-white shadow-[0_1px_3px_rgba(0,0,0,0.02)] overflow-hidden">
                            <div onclick="document.getElementById('rowContent_${r}').classList.toggle('hidden'); document.getElementById('rowIcon_${r}').classList.toggle('-rotate-90');" class="flex items-center justify-between px-3 py-2 pl-2 hover:bg-gray-50 cursor-pointer select-none border-b border-transparent group">
                                <div class="flex items-center gap-2">
                                    <div id="rowIcon_${r}" class="text-gray-400 flex items-center justify-center transform transition-transform duration-200"><svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg></div>
                                    <div class="text-gray-400 flex items-center justify-center"><svg viewBox="64 64 896 896" focusable="false" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M640.6 429.8h257.1c7.9 0 14.3-6.4 14.3-14.3V158.3c0-7.9-6.4-14.3-14.3-14.3H640.6c-7.9 0-14.3 6.4-14.3 14.3v92.9H490.6c-3.9 0-7.1 3.2-7.1 7.1v221.5h-85.7v-96.5c0-7.9-6.4-14.3-14.3-14.3H126.3c-7.9 0-14.3 6.4-14.3 14.3v257.2c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3V544h85.7v221.5c0 3.9 3.2 7.1 7.1 7.1h135.7v92.9c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3v-257c0-7.9-6.4-14.3-14.3-14.3h-257c-7.9 0-14.3 6.4-14.3 14.3v100h-78.6v-393h78.6v100c0 7.9 6.4 14.3 14.3 14.3zm53.5-217.9h150V362h-150V211.9zM329.9 587h-150V437h150v150zm364.2 75.1h150v150.1h-150V662.1z"></path></svg></div>
                                    <span class="text-[14px] font-[400] text-gray-700">${rowName}</span>
                                </div>
                                <div class="w-5 h-5 flex items-center justify-center border border-[#e7e4e4] rounded-full text-[11px] text-gray-500 bg-[#fafafa]">
                                    ${ranges.length}
                                </div>
                            </div>
                            <div id="rowContent_${r}" class="flex flex-col transition-all duration-200">
                                <div class="px-2 py-1.5 border-t border-gray-100 flex flex-col gap-0.5">
                                    ${ranges.length === 0 ? `<div class="text-[12px] text-gray-400 italic pl-8 py-1">No data</div>` : ranges.map(rng => `
                                        <div class="flex items-center justify-between text-[12px] hover:bg-gray-50 px-2 py-1.5 rounded-md pl-8 group/item">
                                            <div class="flex flex-col gap-1">
                                                <div class="flex items-center gap-2">
                                                    <span class="text-[13px] text-gray-400">frame</span>
                                                    <span class="bg-[#f0f5ff] text-[#5f45ff] px-2 py-0.5 rounded-md text-[12px] font-[500] inline-flex items-center gap-1">
                                                        ${rng.start === rng.end 
                                                            ? `<span class="cursor-pointer hover:underline" title="Click to seek to frame ${rng.start}" onclick="event.stopPropagation(); window.seekToFrame(${rng.start})">${rng.start}</span>` 
                                                            : `<span class="cursor-pointer hover:underline" title="Click to seek to frame ${rng.start}" onclick="event.stopPropagation(); window.seekToFrame(${rng.start})">${rng.start}</span><span class="text-gray-400 font-normal">&nbsp;-&nbsp;</span><span class="cursor-pointer hover:underline" title="Click to seek to frame ${rng.end}" onclick="event.stopPropagation(); window.seekToFrame(${rng.end})">${rng.end}</span>`
                                                        }
                                                    </span>
                                                </div>
                                            </div>
                                            <span class="${rng.value ? 'text-[#5f45ff] font-medium' : 'text-gray-500'}">${rng.value ? 'occupied' : 'empty'}</span>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        </div>`;
                    }
                }
                html += `</div>`;
                container.innerHTML = html;
            }
            this.updateFrameDisplayFooter();
        }

        stepSpeed(direction) {
            const speeds = WORKSPACE_CONFIG.DEFAULT_SPEEDS;
            const cur = this.videoCtrl.playbackRate;
            let idx = speeds.indexOf(cur);
            if (idx === -1) idx = speeds.findIndex(s => s >= cur);
            if (direction === 'up' && idx < speeds.length - 1) {
                this.videoCtrl.playbackRate = speeds[idx + 1];
                document.getElementById('currentSpeedBtn').innerText = speeds[idx + 1] + 'x';
                if (this.ui) this.ui._updateActiveOption('speed-opt', speeds[idx + 1].toString());
            } else if (direction === 'down' && idx > 0) {
                this.videoCtrl.playbackRate = speeds[idx - 1];
                document.getElementById('currentSpeedBtn').innerText = speeds[idx - 1] + 'x';
                if (this.ui) this.ui._updateActiveOption('speed-opt', speeds[idx - 1].toString());
            }
        }

        bindShortcuts() {
            window.addEventListener('keydown', (e) => {
                const key = e.key.toUpperCase();
                const active = document.activeElement;
                if (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') return;
                if (e.altKey && key === 'T') {
                    e.preventDefault();
                    const formats = WORKSPACE_CONFIG.TIMESTAMP_FORMATS || ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'];
                    let idx = formats.indexOf(this.timestampFormat);
                    idx = (idx + 1) % formats.length;
                    this.timestampFormat = formats[idx];
                    this.updateWorkspaceUI();
                    if (this.ui) {
                        this.ui._updateActiveOption('ts-opt', this.timestampFormat);
                        this.ui.renderFrameSkipOptions();
                    }
                    return;
                }

                // Ctrl+Left / Ctrl+Right jump to the first/last frame. This must be
                // checked before the plain PREV_FRAME/NEXT_FRAME case below, since
                // both share the same underlying key (ARROWLEFT/ARROWRIGHT) —
                // matching on key alone (ignoring the Ctrl modifier) would mean
                // Ctrl+Arrow silently falls through to a single-frame step, same
                // as a bare arrow key.
                if (e.ctrlKey && key === WORKSPACE_CONFIG.KEY_MAP.PREV_FRAME) {
                    e.preventDefault();
                    window.jumpToFirstFrame();
                    return;
                }
                if (e.ctrlKey && key === WORKSPACE_CONFIG.KEY_MAP.NEXT_FRAME) {
                    e.preventDefault();
                    window.jumpToLastFrame();
                    return;
                }

                // Alt+0/1/2/3 apply the filter-channel presets shown in the
                // filter menu's "Filters" submenu (None/Red/Green/Blue).
                if (e.altKey && ['0', '1', '2', '3'].includes(key)) {
                    e.preventDefault();
                    const presetMap = { '0': 'none', '1': 'red', '2': 'green', '3': 'blue' };
                    this.ui?._applyFilterPreset(presetMap[key]);
                    return;
                }

                switch (key) {
                    case WORKSPACE_CONFIG.KEY_MAP.PLAY_PAUSE: e.preventDefault(); this.videoCtrl.togglePlay(); break;
                    case WORKSPACE_CONFIG.KEY_MAP.PREV_FRAME: e.preventDefault(); this.videoCtrl.stepFrames(-1); break;
                    case WORKSPACE_CONFIG.KEY_MAP.NEXT_FRAME: e.preventDefault(); this.videoCtrl.stepFrames(1); break;
                    case 'ARROWUP': e.preventDefault(); this.stepSpeed('up'); break;
                    case 'ARROWDOWN': e.preventDefault(); this.stepSpeed('down'); break;
                }
            });
        }
    }

    // Bootstrap
    const initApp = () => {
        if (!window.annotationState) {
            try {
                if (window.FMN && window.FMN.existingAnnotation && window.FMN.existingAnnotation.data && window.FMN.existingAnnotation.data.annotation_data) {
                    let fmnData = window.FMN.existingAnnotation.data.annotation_data;
                    console.log("FMN Init data found:", fmnData);
                    if (typeof fmnData === 'string') {
                        window.annotationState = JSON.parse(fmnData);
                    } else {
                        window.annotationState = fmnData;
                    }
                } else if (window.sageMakerData && window.sageMakerData.prev_annotations && window.sageMakerData.prev_annotations !== '[]' && window.sageMakerData.prev_annotations !== '""') {
                    let taskInput = JSON.parse(window.sageMakerData.prev_annotations);
                    if (typeof taskInput === 'string') {
                        taskInput = JSON.parse(taskInput);
                    }
                    console.log("Clone task input:", taskInput);
                    
                    let unwrappedInput = taskInput;
                    // Sagemaker often returns an array of previous annotations for cloned tasks
                    if (Array.isArray(taskInput) && taskInput.length > 0) {
                        unwrappedInput = taskInput[0];
                    }

                    if (unwrappedInput && unwrappedInput.annotation_data) {
                        console.log("Received annotation_data:", unwrappedInput.annotation_data);
                        console.log("Parsed annotation:", JSON.parse(unwrappedInput.annotation_data));
                        window.annotationState = JSON.parse(unwrappedInput.annotation_data);
                    } else if (unwrappedInput) {
                        window.annotationState = unwrappedInput;
                    }
                } else if (window.initialAnnotations) {
                    window.annotationState = window.initialAnnotations;
                } else {
                    window.annotationState = { objects_in_roi: [], frameOccupancy: {} };
                }
            } catch (e) {
                console.error("Failed to parse previous annotations:", e);
                window.annotationState = { objects_in_roi: [], frameOccupancy: {} };
            }
        }
        if (!window.annotationState) window.annotationState = { objects_in_roi: [], frameOccupancy: {} };
        if (!window.annotationState.objects_in_roi) window.annotationState.objects_in_roi = [];
        if (!window.annotationState.frameOccupancy) window.annotationState.frameOccupancy = {};

        if (!window.Workspace) {
            window.Workspace = new WorkspaceManager();
            window.Workspace.init();
        }

        // Reveal app
        document.body.classList.remove('opacity-0');
        if (window.syncAnnotationData) window.syncAnnotationData();

        // Prevent Enter key from triggering automatic form submission
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' && event.target.tagName !== 'TEXTAREA') {
                event.preventDefault();
                if (event.target.tagName === 'INPUT') {
                    event.target.blur();
                }
            }
        });
    };
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApp);
    } else {
        initApp();
    }

    // Extra global functions referenced in HTML
    window.copyVideoName = function () {
        const text = document.getElementById('videoNameDisplay')?.innerText;
        if (text) navigator.clipboard.writeText(text);
    };
    window.closeAnnotationPanel = function () {
        document.getElementById('annotationOverlay')?.classList.add('hidden');
    };

    window.toggleObject = function (objName) {
        if (!window.annotationState) return;
        const idx = window.annotationState.objects_in_roi.indexOf(objName);
        if (idx > -1) {
            window.annotationState.objects_in_roi.splice(idx, 1);
        } else {
            window.annotationState.objects_in_roi.push(objName);
        }
        if (window.syncAnnotationData) window.syncAnnotationData();
    };

    window.showWarning = function (msg) {
        const toast = document.getElementById('globalWarningToast');
        const msgEl = document.getElementById('globalWarningMsg');
        if (!toast || !msgEl) {
            alert(msg);
            return;
        }
        msgEl.innerText = msg;
        toast.classList.remove('hidden');
        setTimeout(() => {
            toast.classList.remove('opacity-0');
            toast.classList.add('opacity-100');
        }, 10);

        // Auto hide after 3.5s
        setTimeout(() => {
            toast.classList.remove('opacity-100');
            toast.classList.add('opacity-0');
            setTimeout(() => toast.classList.add('hidden'), 300);
        }, 3500);
    };

    window.loadPreviousAnnotations = function (data) {
        // Stub - data loading is now handled during initialization in initApp
    };

    // --- New Global Functions for Frame Occupancy and JSON Export ---

    window.setOccupancy = function (frameNum, row, isOccupied) {
        if (!window.annotationState) return;
        if (!window.annotationState.frameOccupancy[frameNum]) {
            window.annotationState.frameOccupancy[frameNum] = { row_0: null, row_1: null, row_2: null, row_3: null };
        }
        window.annotationState.frameOccupancy[frameNum][`row_${row}`] = isOccupied;
        if (window.syncAnnotationData) window.syncAnnotationData();
        if (window.Workspace) window.Workspace.renderLabels();
    };

    window.seekToFrame = function (frameNum) {
        if (!window.Workspace) return;
        const time = frameNum / WORKSPACE_CONFIG.FPS;
        window.Workspace.videoCtrl.video.currentTime = time;
    };

    window.jumpToFirstFrame = function () {
        window.seekToFrame(0);
    };

    window.jumpToLastFrame = function () {
        if (window.Workspace && window.Workspace.videoCtrl) {
            const totalFrames = Math.round(window.Workspace.videoCtrl.duration * WORKSPACE_CONFIG.FPS);
            if (totalFrames > 0) {
                window.seekToFrame(totalFrames);
            }
        }
    };

    window.switchTab = function (clickedTab) {
        if (!window.Workspace) return;
        const parent = clickedTab.parentElement;
        const tabs = parent.querySelectorAll('.tab-item');
        let tabName = clickedTab.innerText.trim();

        tabs.forEach(tab => {
            if (tab === clickedTab) {
                tab.className = "tab-item active px-3 h-full flex items-center justify-center cursor-pointer rounded transition-all duration-200 bg-white shadow-[0_1px_2px_rgba(0,0,0,0.05)] text-gray-800 font-medium";
            } else {
                tab.className = "tab-item px-3 h-full flex items-center justify-center cursor-pointer rounded transition-all duration-200 text-gray-500 hover:text-gray-700";
            }
        });

        window.Workspace.activeLabelTab = tabName;
        window.Workspace.renderLabels();

        const interpolateWrapper = document.getElementById('interpolateTriggerWrapper');
        if (interpolateWrapper) {
            if (tabName === 'Frame') {
                interpolateWrapper.classList.remove('hidden');
            } else {
                interpolateWrapper.classList.add('hidden');
            }
        }


    };

    window._buildJSONPayload = function () {
        if (!window.annotationState) return "{}";
        return JSON.stringify(window.annotationState, null, 2);
    };

    window.syncAnnotationData = function () {
        const jsonString = window._buildJSONPayload();
        const input = document.getElementById('annotationDataInput');
        if (input) {
            input.value = jsonString;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }
    };

    window.exportJSON = function () {
        const jsonString = window._buildJSONPayload();

        // Derive filename from the video name (strip extension, add .json)
        const rawVideoName =
            window.sageMakerData?.videoName ||
            document.getElementById('videoNameDisplay')?.innerText ||
            'annotated_data';
        const baseName = rawVideoName.replace(/\.[^/.]+$/, ''); // remove extension
        const fileName = baseName + '.json';

        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    window.importJSON = function (event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const importedData = JSON.parse(e.target.result);
                if (importedData && typeof importedData === 'object') {
                    // Update the state
                    window.annotationState = {
                        objects_in_roi: importedData.objects_in_roi || [],
                        frameOccupancy: importedData.frameOccupancy || {}
                    };
                    
                    if (window.syncAnnotationData) window.syncAnnotationData();
                    if (window.Workspace) {
                        window.Workspace.renderClasses();
                        window.Workspace.renderLabels();
                    }
                    window.showWarning("JSON Imported successfully!");
                }
            } catch (err) {
                console.error("Failed to parse JSON", err);
                window.showValidationErrorModal("Failed to import JSON: Invalid format.");
            }
        };
        reader.readAsText(file);
        
        // Reset input so the same file can be selected again
        event.target.value = '';
    };

    window.showValidationErrorModal = function (msg) {
        const modal = document.getElementById('validationErrorModal');
        const msgEl = document.getElementById('validationErrorMessage');
        if (modal && msgEl) {
            msgEl.textContent = msg;
            modal.classList.remove('hidden');
        }
    };

    window.submitAnnotation = function () {
        if (!window.Workspace) return;

        // Close submit modal immediately
        const submitModal = document.getElementById('submitModal');
        if (submitModal) submitModal.classList.add('hidden');

        // VALIDATION
        const totalFrames = Math.round(window.Workspace.videoCtrl.duration * WORKSPACE_CONFIG.FPS) || 0;

        // Check if ALL frames are labeled
        let hasOccupied = false;
        const annotatedFrames = Object.keys(window.annotationState.frameOccupancy || {})
            .map(Number)
            .filter(f => f >= 1 && f <= totalFrames);

        for (const frame of annotatedFrames) {
            const occ = window.annotationState.frameOccupancy[frame];
            if (occ && (occ.row_0 || occ.row_1 || occ.row_2 || occ.row_3)) {
                hasOccupied = true;
                break;
            }
        }

        const missingCount = Math.max(0, totalFrames - annotatedFrames.length);

        if (missingCount > 0 && !WORKSPACE_CONFIG.ALLOW_MISSING) {
            window.showValidationErrorModal(`Cannot submit: You must label EVERY frame. Missing ${missingCount} frame(s).`);
            return;
        }

        const hasObjects = window.annotationState.objects_in_roi.length > 0;
        const hasNone = window.annotationState.objects_in_roi.includes('None');

        if (!hasObjects) {
            window.showValidationErrorModal("Cannot submit: You must select at least one object in the ROI, or select 'None'.");
            return;
        }

        if (hasOccupied && hasNone && window.annotationState.objects_in_roi.length === 1) {
            window.showValidationErrorModal("Warning: You marked rows as occupied, but selected 'None'. Please fix this contradiction.");
            return;
        }

        if (!hasOccupied && !hasNone && !WORKSPACE_CONFIG.ALLOW_MISSING) {
            window.showValidationErrorModal("Warning: You selected objects, but marked all rows as empty. Please fix this contradiction.");
            return;
        }

        const jsonString = window._buildJSONPayload();
        
        const submittedOutput = {
            annotation_data: jsonString
        };
        console.log("Submitted annotation_data:", submittedOutput.annotation_data);

        const input = document.getElementById('annotationDataInput');
        if (input) {
            input.value = jsonString;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }

        // Prevent AWS SageMaker crowd-form from auto-serializing UI inputs
        // by removing their 'name' attributes right before submission.
        document.querySelectorAll('input').forEach(el => {
            if (el.id !== 'annotationDataInput') {
                el.removeAttribute('name');
            }
        });

        const form = document.querySelector('crowd-form');
        if (form) form.submit();
    };

    window.toggleInterpolatePopover = function (e) {
        if (e) e.stopPropagation();
        const popover = document.getElementById('interpolatePopover');
        if (!popover) return;
        const isVisible = !popover.classList.contains('hidden');

        if (window.app) window.app.closeAllMenus();

        if (!isVisible) {
            popover.classList.remove('hidden');

            // Position it dynamically based on the trigger button
            if (e && e.currentTarget) {
                const rect = e.currentTarget.getBoundingClientRect();
                // Position above the button, aligned to the right edge
                popover.style.bottom = `${window.innerHeight - rect.top + 8}px`; // 8px spacing
                popover.style.right = `${window.innerWidth - rect.right - 10}px`; // offset for arrow alignment
            }

            const fromInput = document.getElementById('interpolateFrom');
            const toInput = document.getElementById('interpolateTo');
            const formContent = document.getElementById('interpolateFormContent');
            if (formContent) {
                formContent.classList.remove('opacity-40', 'pointer-events-none');
            }

            if (window.Workspace && fromInput) {
                fromInput.value = window.Workspace.formatTimeDisplay(window.Workspace.videoCtrl.currentTime, window.Workspace.timestampFormat);
            }

            if (toInput) {
                toInput.value = '';
                setTimeout(() => toInput.focus(), 50);
            }

            // Reset errors
            const errTooltip = document.getElementById('interpolateErrorTooltip');
            if (errTooltip) errTooltip.classList.add('hidden');
            if (toInput) toInput.classList.remove('border-red-400', 'focus:border-red-400', 'focus:ring-red-400');
            if (fromInput) {
                fromInput.classList.remove('border-red-400');
                fromInput.classList.add('border-gray-200');
            }
        }
    };

    window.handleInterpolateInput = function (input) {
        if (!window.Workspace) return;
        const format = window.Workspace.timestampFormat;

        // Hide error tooltip when user starts typing again
        const errTooltip = document.getElementById('interpolateErrorTooltip');
        if (errTooltip && !errTooltip.classList.contains('hidden')) {
            errTooltip.classList.add('hidden');
            input.classList.remove('border-red-400', 'focus:border-red-400', 'focus:ring-red-400');
            const fromInput = document.getElementById('interpolateFrom');
            if (fromInput) {
                fromInput.classList.remove('border-red-400');
                fromInput.classList.add('border-gray-200');
            }
        }

        // Remove all non-digits
        let val = input.value.replace(/[^\d]/g, '');

        if (format === 'Frames') {
            input.value = val;
        } else if (format === 'MM:SS') {
            if (val.length > 4) val = val.substring(0, 4);
            if (val.length > 2) {
                input.value = val.substring(0, 2) + ':' + val.substring(2);
            } else {
                input.value = val;
            }
        } else if (format === 'HH:MM:SS') {
            if (val.length > 6) val = val.substring(0, 6);
            if (val.length > 4) {
                input.value = val.substring(0, 2) + ':' + val.substring(2, 4) + ':' + val.substring(4);
            } else if (val.length > 2) {
                input.value = val.substring(0, 2) + ':' + val.substring(2);
            } else {
                input.value = val;
            }
        } else if (format === 'SS.FF') {
            if (val.length > 4) val = val.substring(0, 4);
            if (val.length > 2) {
                input.value = val.substring(0, 2) + '.' + val.substring(2);
            } else {
                input.value = val;
            }
        }
    };

    window.jumpToInputTime = function (valStr) {
        if (!window.Workspace) return;
        let frame = window.parseInterpolateInput(valStr);
        if (frame !== null && !isNaN(frame)) {
            window.seekToFrame(frame);
        }
    };

    window.parseInterpolateInput = function (valStr) {
        if (!window.Workspace) return null;
        valStr = valStr.trim();
        if (!valStr) return null;
        const fps = WORKSPACE_CONFIG.FPS;

        // If Frames format
        if (window.Workspace.timestampFormat === 'Frames') {
            return parseInt(valStr, 10);
        }

        // Check if it's just a number without format characters
        if (/^\d+$/.test(valStr)) {
            return parseInt(valStr, 10); // fall back to frame number if they just type a number and blur, or handle with handleInterpolateInput
        }

        // HH:MM:SS
        let match = valStr.match(/^(\d+):(\d+):(\d+)$/);
        if (match) {
            let s = parseInt(match[1], 10) * 3600 + parseInt(match[2], 10) * 60 + parseInt(match[3], 10);
            return Math.round(s * fps);
        }

        // MM:SS
        match = valStr.match(/^(\d+):(\d+)$/);
        if (match) {
            let s = parseInt(match[1], 10) * 60 + parseInt(match[2], 10);
            return Math.round(s * fps);
        }

        // SS.FF or SS:FF
        match = valStr.match(/^(\d+)[\.\:](\d+)$/);
        if (match) {
            let s = parseInt(match[1], 10);
            let f = parseInt(match[2], 10);
            return Math.round(s * fps) + f;
        }

        return null;
    };

    window.startInterpolation = function () {
        if (!window.Workspace) return;

        const popover = document.getElementById('interpolatePopover');
        const toInput = document.getElementById('interpolateTo');
        const toStr = toInput.value;

        const fromFrame = Math.round(window.Workspace.videoCtrl.currentTime * WORKSPACE_CONFIG.FPS) || 0;
        let toFrame = window.parseInterpolateInput(toStr);

        if (toFrame === null || isNaN(toFrame)) {
            const errTooltip = document.getElementById('interpolateErrorTooltip');
            const errMsg = document.getElementById('interpolateErrorMsg');
            if (errTooltip && errMsg) {
                toInput.parentElement.appendChild(errTooltip);
                errMsg.innerText = "Invalid format for 'To' field.";
                errTooltip.classList.remove('hidden');
                toInput.classList.add('border-red-400', 'focus:border-red-400', 'focus:ring-red-400');
            }
            return;
        }

        // Prevent interpolation if the "From" frame has not been annotated at all
        const fromOccupancy = window.annotationState.frameOccupancy[fromFrame];
        const isFromEmpty = !fromOccupancy || (fromOccupancy.row_0 === null && fromOccupancy.row_1 === null && fromOccupancy.row_2 === null && fromOccupancy.row_3 === null);
        if (isFromEmpty) {
            const fromInput = document.getElementById('interpolateFrom');
            const errTooltip = document.getElementById('interpolateErrorTooltip');
            const errMsg = document.getElementById('interpolateErrorMsg');
            if (errTooltip && errMsg && fromInput) {
                fromInput.parentElement.appendChild(errTooltip);
                errMsg.innerText = "Current frame is completely unannotated. Please annotate at least one row before interpolating.";
                errTooltip.classList.remove('hidden');
                fromInput.classList.remove('border-gray-200');
                fromInput.classList.add('border-red-400');
            }
            return;
        }

        const totalFrames = Math.round(window.Workspace.videoCtrl.duration * WORKSPACE_CONFIG.FPS);
        if (totalFrames > 0) {
            toFrame = Math.max(0, Math.min(totalFrames, toFrame));
        }

        if (fromFrame === toFrame) {
            if (popover) popover.classList.add('hidden');
            return;
        }

        const executeInterpolation = () => {
            const start = Math.min(fromFrame, toFrame);
            const end = Math.max(fromFrame, toFrame);

            // Check for existing annotations in the range (excluding 'fromFrame' itself)
            let conflict = false;
            const existingFrames = Object.keys(window.annotationState.frameOccupancy || {})
                .map(Number)
                .filter(f => f >= start && f <= end && f !== fromFrame);

            for (const f of existingFrames) {
                const occ = window.annotationState.frameOccupancy[f];
                if (occ && (occ.row_0 !== null || occ.row_1 !== null || occ.row_2 !== null || occ.row_3 !== null)) {
                    conflict = true;
                    break;
                }
            }

            const sourceOcc = window.annotationState.frameOccupancy[fromFrame];

            const applyInterpolation = () => {
                for (let i = start; i <= end; i++) {
                    if (i !== fromFrame) {
                        window.annotationState.frameOccupancy[i] = {
                            row_0: sourceOcc ? sourceOcc.row_0 : null,
                            row_1: sourceOcc ? sourceOcc.row_1 : null,
                            row_2: sourceOcc ? sourceOcc.row_2 : null,
                            row_3: sourceOcc ? sourceOcc.row_3 : null
                        };
                    }
                }
                if (window.syncAnnotationData) window.syncAnnotationData();
                window.Workspace.renderLabels();
                if (popover) popover.classList.add('hidden');
                window.seekToFrame(toFrame);
                window.showSuccessToast("Interpolation Successful", `Labels successfully interpolated from frame ${start} to ${end}.`);
            };

            if (conflict) {
                window.showWarning("Interpolation applied (some existing labels were overwritten).");
                applyInterpolation();
            } else {
                applyInterpolation();
            }
        };

        if (fromFrame > toFrame) {
            const confirmPopover = document.getElementById('backwardConfirmPopover');
            const formContent = document.getElementById('interpolateFormContent');
            if (confirmPopover) {
                confirmPopover.classList.remove('hidden');
                if (formContent) formContent.classList.add('opacity-40', 'pointer-events-none');
                window._confirmBackwardInterpolationCallback = executeInterpolation;
            } else {
                executeInterpolation();
            }
            return;
        }

        executeInterpolation();
    };

    window.cancelBackwardInterpolation = function (e) {
        if (e) e.stopPropagation();
        const confirmPopover = document.getElementById('backwardConfirmPopover');
        const formContent = document.getElementById('interpolateFormContent');
        if (confirmPopover) confirmPopover.classList.add('hidden');
        if (formContent) formContent.classList.remove('opacity-40', 'pointer-events-none');
        window._confirmBackwardInterpolationCallback = null;
    };

    window.confirmBackwardInterpolation = function (e) {
        if (e) e.stopPropagation();
        const confirmPopover = document.getElementById('backwardConfirmPopover');
        const formContent = document.getElementById('interpolateFormContent');
        if (confirmPopover) confirmPopover.classList.add('hidden');
        if (formContent) formContent.classList.remove('opacity-40', 'pointer-events-none');
        if (window._confirmBackwardInterpolationCallback) {
            window._confirmBackwardInterpolationCallback();
            window._confirmBackwardInterpolationCallback = null;
        }
    };

    window.showSuccessToast = function (title, desc) {
        const toast = document.getElementById('successNotificationToast');
        const card = document.getElementById('successNotificationCard');
        const titleEl = document.getElementById('successToastTitle');
        const descEl = document.getElementById('successToastDesc');

        if (toast && card) {
            if (titleEl && title) titleEl.innerText = title;
            if (descEl && desc) descEl.innerText = desc;

            toast.classList.remove('hidden');
            toast.classList.add('flex');

            requestAnimationFrame(() => {
                card.classList.remove('-translate-x-full', 'opacity-0');
                card.classList.add('translate-x-0', 'opacity-100');
            });

            if (window._successToastTimeout) clearTimeout(window._successToastTimeout);
            window._successToastTimeout = setTimeout(() => {
                window.closeSuccessToast();
            }, 3000);
        }
    };

    window.closeSuccessToast = function () {
        const toast = document.getElementById('successNotificationToast');
        const card = document.getElementById('successNotificationCard');

        if (toast && card) {
            card.classList.remove('translate-x-0', 'opacity-100');
            card.classList.add('-translate-x-full', 'opacity-0');

            setTimeout(() => {
                toast.classList.add('hidden');
                toast.classList.remove('flex');
            }, 300);
        }
    };

    // Support FMN (Field Mountain Network) external restorer
    window.addEventListener('fmn-annotation-restored', () => {
        console.log("FMN Restore event triggered!");
        if (window.FMN && window.FMN.existingAnnotation && window.FMN.existingAnnotation.data) {
            let restoredData = window.FMN.existingAnnotation.data.annotation_data;
            if (typeof restoredData === 'string') {
                try {
                    window.annotationState = JSON.parse(restoredData);
                } catch(e) {
                    console.error("FMN Restore parse error:", e);
                }
            } else if (restoredData) {
                window.annotationState = restoredData;
            }
            if (window.Workspace) {
                window.Workspace.updateWorkspaceUI();
                window.Workspace.renderLabels();
            }
            console.log("FMN Restore state loaded:", window.annotationState);
        }
    });

})();