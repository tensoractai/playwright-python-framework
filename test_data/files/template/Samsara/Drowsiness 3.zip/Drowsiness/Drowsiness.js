/**
 * VIDEO ANNOTATION WORKSPACE ENGINE
 * Architecture Pattern: OOP (Skeletal Structural Template)
 */

var WORKSPACE_CONFIG = {
    FPS: 30,
    DEFAULT_TIMESTAMP_FORMAT: 'MM:SS', // Default to Frames (FPS)
    TIMESTAMP_FORMATS: ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'],
    DEFAULT_PPS: 160,
    MIN_PPS: 40,
    MAX_PPS: 800,
    ZOOM_STEP: 0.1,
    MIN_ZOOM: 0.5,
    MAX_ZOOM: 8.0,
    DEFAULT_SPEEDS: [0.25, 0.5, 1.0, 1.5, 2.0, 4.0],
    DEFAULT_FRAME_SKIPS: [1, 2, 5, 10, 30, 60],
    DEFAULT_SPEED: 1.0,
    KEY_MAP: {
        PLAY_PAUSE: ' ',
        PREV_FRAME: 'ARROWLEFT',
        NEXT_FRAME: 'ARROWRIGHT',
        SPEED_UP: 'ARROWUP',
        SPEED_DOWN: 'ARROWDOWN',
        MARK_START: 'C',
        MARK_END: 'V',
        SAVE: 'S'
    }
};

var VideoController = class {
    constructor(videoElement) {
        if (!videoElement) throw new Error("Video element is required.");
        this.video = videoElement;
        this.frameSkipValue = 1;
    }

    get currentTime() { return this.video.currentTime; }
    set currentTime(secs) { this.video.currentTime = Math.max(0, Math.min(secs, this.duration)); }

    get duration() { return this.video.duration || 0; }
    get playbackRate() { return this.video.playbackRate; }
    set playbackRate(rate) { this.video.playbackRate = rate; }

    get muted() { return this.video.muted; }
    set muted(state) { this.video.muted = state; }

    getCurrentFrame() {
        return Math.round(this.currentTime * WORKSPACE_CONFIG.FPS);
    }

    getTotalFrames() {
        return Math.floor(this.duration * WORKSPACE_CONFIG.FPS);
    }

    seekToFrame(frameNumber) {
        this.currentTime = frameNumber / WORKSPACE_CONFIG.FPS;
        if (window.app && window.app.workspace) {
            window.app.workspace.updateWorkspaceUI();
        }
    }

    stepFrames(direction = 1) {
        const targetFrame = this.getCurrentFrame() + (direction * this.frameSkipValue);
        this.seekToFrame(Math.max(0, Math.min(this.getTotalFrames(), targetFrame)));
    }

    togglePlay() {
        if (this.video.paused) {
            this.video.play().catch(e => console.error("Playback failed", e));
        } else {
            this.video.pause();
        }
        setTimeout(() => window.app?.workspace?.updatePlayState(), 50);
    }
}

var ViewportTransform = class {
    constructor(wrapperElement, videoElement) {
        this.wrapper = wrapperElement;
        this.video = videoElement;
        this.scale = 1.0;
        this.rotation = 0;       // normalized 0-359
        this.displayRotation = 0; // cumulative for smooth transitions
        this.translateX = 0;
        this.translateY = 0;
        this.isPanning = false;
        this.startX = 0;
        this.startY = 0;
    }

    zoom(delta, clientX = null, clientY = null) {
        const oldScale = this.scale;
        this.scale = Math.max(WORKSPACE_CONFIG.MIN_ZOOM, Math.min(WORKSPACE_CONFIG.MAX_ZOOM, this.scale + delta));

        if (clientX !== null && clientY !== null && this.wrapper) {
            const rect = this.wrapper.parentElement.getBoundingClientRect();
            const mouseX = clientX - rect.left - rect.width / 2;
            const mouseY = clientY - rect.top - rect.height / 2;
            const ratio = this.scale / oldScale;
            this.translateX = mouseX - (mouseX - this.translateX) * ratio;
            this.translateY = mouseY - (mouseY - this.translateY) * ratio;
        } else if (this.scale === 1.0) {
            this.translateX = 0;
            this.translateY = 0;
        }
        this.apply();
    }

    setZoom(scale) {
        this.scale = Math.max(WORKSPACE_CONFIG.MIN_ZOOM, Math.min(WORKSPACE_CONFIG.MAX_ZOOM, scale));
        this.apply();
    }

    /**
     * Set rotation — additive adds to current, otherwise sets absolute.
     * After rotating, syncs the slider + input UI.
     */
    rotate(degrees, additive = false) {
        if (additive) {
            this.displayRotation = (this.displayRotation + degrees) % 360;
        } else {
            this.displayRotation = degrees % 360;
        }
        // Keep normalized 0-359
        this.rotation = ((this.displayRotation % 360) + 360) % 360;
        this.apply();
        this._syncRotateUI();
    }

    /** Sync the slider and input to current rotation value */
    _syncRotateUI() {
        const val = Math.round(this.rotation);
        const slider = document.getElementById('customRotateSlider');
        const input = document.getElementById('customRotateInput');
        if (slider) {
            slider.value = val;
            _updateSliderFill(slider);
        }
        if (input) input.value = val;

        // Also update highlight for quick rotate options if exact match
        document.querySelectorAll('.rotate-opt').forEach(opt => {
            const deg = parseInt(opt.dataset.deg, 10);
            if (deg === val) opt.classList.add('active-opt');
            else opt.classList.remove('active-opt');
        });
    }

    startPan(clientX, clientY) {
        this.isPanning = true;
        this.startX = clientX - this.translateX;
        this.startY = clientY - this.translateY;
    }

    pan(clientX, clientY) {
        if (!this.isPanning) return;
        this.translateX = clientX - this.startX;
        this.translateY = clientY - this.startY;
        this.apply();
    }

    endPan() { this.isPanning = false; }

    reset() {
        this.scale = 1.0;
        this.rotation = 0;
        this.displayRotation = 0;
        this.translateX = 0;
        this.translateY = 0;
        this.apply();
        this._syncRotateUI();
    }

    apply() {
        if (!this.wrapper) return;
        this.wrapper.style.transform =
            `translate(${this.translateX}px, ${this.translateY}px) scale(${this.scale}) rotate(${this.displayRotation}deg)`;
    }
}

/* -------------------------------------------------------
   Utility: update the linear-gradient fill of a range slider
   so the filled portion is purple and the rest is gray.
   ------------------------------------------------------- */
function _updateSliderFill(slider) {
    const min = parseFloat(slider.min) || 0;
    const max = parseFloat(slider.max) || 359;
    const val = parseFloat(slider.value) || 0;
    const pct = ((val - min) / (max - min)) * 100;
    slider.style.background =
        `linear-gradient(to right, #5f45ff ${pct}%, #e5e7eb ${pct}%)`;
}

var UIManager = class {
    constructor(workspace) {
        this.workspace = workspace;
        this.activeMenuId = null;
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.bindExtraToggles();

        // Menu buttons
        this._bindMenuBtn('rotateDropdownBtn', 'rotateMenu');
        this._bindMenuBtn('rotateActionBtn', 'customRotateMenu');
        this._bindMenuBtn('currentSpeedBtn', 'speedMenu');

        // Rotate quick options (45°, 90°, 180°) — absolute rotation for highlight matching
        document.querySelectorAll('.rotate-opt').forEach(opt => {
            opt.addEventListener('click', (e) => {
                e.stopPropagation();
                const deg = parseInt(opt.dataset.deg, 10);
                if (!isNaN(deg)) this.workspace.transform.rotate(deg, false);
                this.closeAllMenus();
            });
        });

        // Zoom tools
        document.getElementById('zoomIn')?.addEventListener('click', () =>
            this.workspace.transform.zoom(WORKSPACE_CONFIG.ZOOM_STEP));
        document.getElementById('zoomOut')?.addEventListener('click', () =>
            this.workspace.transform.zoom(-WORKSPACE_CONFIG.ZOOM_STEP));
        document.getElementById('zoomFit')?.addEventListener('click', () =>
            this.workspace.transform.reset());

        // Custom Rotation Slider
        const rotateSlider = document.getElementById('customRotateSlider');
        const rotateInput = document.getElementById('customRotateInput');
        if (rotateSlider && rotateInput) {
            rotateSlider.addEventListener('input', (e) => {
                const v = parseInt(e.target.value, 10);
                rotateInput.value = v;
                _updateSliderFill(rotateSlider);
                this.workspace.transform.rotate(v, false);
            });
            rotateInput.addEventListener('input', (e) => {
                let v = parseInt(e.target.value, 10);
                if (isNaN(v)) v = 0;
                v = Math.max(0, Math.min(359, v));
                rotateSlider.value = v;
                _updateSliderFill(rotateSlider);
                this.workspace.transform.rotate(v, false);
            });
            // Initialize fill on load
            _updateSliderFill(rotateSlider);
        }

        // Rotate Reset Button (triangle icon inside customRotateMenu)
        const resetBtn = document.getElementById('customRotateResetBtn');
        if (resetBtn) {
            resetBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.workspace.transform.reset(); // resets rotation, zoom, translation
            });
        }

        // Rotate Increment / Decrement arrow buttons
        const incBtn = document.getElementById('rotateIncrementBtn');
        const decBtn = document.getElementById('rotateDecrementBtn');
        if (incBtn) {
            incBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const input = document.getElementById('customRotateInput');
                let v = parseInt(input?.value || '0', 10);
                v = ((v + 1) + 360) % 360;
                if (input) input.value = v;
                const slider = document.getElementById('customRotateSlider');
                if (slider) { slider.value = v; _updateSliderFill(slider); }
                this.workspace.transform.rotate(v, false);
            });
        }
        if (decBtn) {
            decBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const input = document.getElementById('customRotateInput');
                let v = parseInt(input?.value || '0', 10);
                v = ((v - 1) + 360) % 360;
                if (input) input.value = v;
                const slider = document.getElementById('customRotateSlider');
                if (slider) { slider.value = v; _updateSliderFill(slider); }
                this.workspace.transform.rotate(v, false);
            });
        }

        // Speed Menu
        const speedMenu = document.getElementById('speedMenu');
        if (speedMenu) {
            speedMenu.innerHTML = '';
            WORKSPACE_CONFIG.DEFAULT_SPEEDS.forEach(speed => {
                const opt = document.createElement('div');
                opt.className = 'px-3 py-1.5 text-[13px] hover:bg-gray-50 cursor-pointer rounded speed-opt text-center';
                opt.innerText = speed + 'x';
                opt.dataset.speed = speed;
                opt.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.workspace.videoCtrl.playbackRate = speed;
                    const btn = document.getElementById('currentSpeedBtn');
                    if (btn) btn.innerText = speed + 'x';
                    this._updateActiveOption('speed-opt', speed.toString());
                    this.closeAllMenus();
                });
                speedMenu.appendChild(opt);
            });
            this._updateActiveOption('speed-opt', WORKSPACE_CONFIG.DEFAULT_SPEED.toString());
        }

        // Play Controls
        document.getElementById('btnPlayPause')?.addEventListener('click', () =>
            this.workspace.videoCtrl.togglePlay());
        document.getElementById('btnStart')?.addEventListener('click', () =>
            this.workspace.videoCtrl.stepFrames(-1));
        document.getElementById('btnNext')?.addEventListener('click', () =>
            this.workspace.videoCtrl.stepFrames(1));

        this._bindCurrentFrameInput();

        // Settings sub-menus
        this._bindSettingsSubMenus();
    }

    _updateActiveOption(className, value) {
        document.querySelectorAll('.' + className).forEach(el => {
            // Using dataset attribute matching what we assigned
            if (el.dataset.val === value || el.dataset.speed === value) {
                el.classList.add('active-opt');
            } else {
                el.classList.remove('active-opt');
            }
        });
    }

    /**
     * Menu button binding — stops propagation, closes other menus first.
     */
    _bindMenuBtn(btnId, menuId) {
        const btn = document.getElementById(btnId);
        const menu = document.getElementById(menuId);
        if (!btn || !menu) return;

        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = !menu.classList.contains('hidden');
            this.closeAllMenus();
            if (!isOpen) {
                menu.classList.remove('hidden');
                this.activeMenuId = menuId;
            }
        });

        // Prevent clicks inside menu from bubbling to document
        menu.addEventListener('click', (e) => e.stopPropagation());
    }

    _bindCurrentFrameInput() {
        const inp = document.getElementById('currentFrameInput');
        if (!inp) return;
        
        inp.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, ''); // keep only digits
            const format = this.workspace.timestampFormat;
            let formatted = val;

            if (format === 'HH:MM:SS') {
                if (val.length > 4) {
                    formatted = val.slice(0, 2) + ':' + val.slice(2, 4) + ':' + val.slice(4, 6);
                } else if (val.length > 2) {
                    formatted = val.slice(0, 2) + ':' + val.slice(2);
                }
            } else if (format === 'MM:SS') {
                if (val.length > 2) {
                    formatted = val.slice(0, 2) + ':' + val.slice(2, 4);
                }
            } else if (format === 'SS.FF') {
                if (val.length > 2) {
                    formatted = val.slice(0, 2) + '.' + val.slice(2, 4);
                }
            }
            // For 'Frames', it just stays as numbers
            e.target.value = formatted;
        });

        inp.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const val = e.target.value;
                const format = this.workspace.timestampFormat;
                let totalSeconds = 0;

                if (format === 'Frames') {
                    const frames = parseInt(val, 10);
                    if (!isNaN(frames)) {
                        totalSeconds = frames / WORKSPACE_CONFIG.FPS;
                    }
                } else if (format === 'HH:MM:SS') {
                    const parts = val.split(':');
                    if (parts.length >= 1) {
                        const h = parseInt(parts[0] || 0, 10);
                        const m = parseInt(parts[1] || 0, 10);
                        const s = parseInt(parts[2] || 0, 10);
                        totalSeconds = h * 3600 + m * 60 + s;
                    }
                } else if (format === 'MM:SS') {
                    const parts = val.split(':');
                    if (parts.length >= 1) {
                        const m = parseInt(parts[0] || 0, 10);
                        const s = parseInt(parts[1] || 0, 10);
                        totalSeconds = m * 60 + s;
                    }
                } else if (format === 'SS.FF') {
                    const parts = val.split('.');
                    if (parts.length >= 1) {
                        const s = parseInt(parts[0] || 0, 10);
                        const f = parseInt(parts[1] || 0, 10);
                        totalSeconds = s + (f / WORKSPACE_CONFIG.FPS);
                    }
                }

                if (totalSeconds >= 0) {
                    this.workspace.videoCtrl.seekToFrame(totalSeconds * WORKSPACE_CONFIG.FPS);
                }
                e.target.blur();
            }
        });
    }

    /**
     * Settings menu sub-menus:
     */
    _bindSettingsSubMenus() {
        // ---- Timestamp Format SubMenu ----
        const tsTrigger = document.getElementById('timestampFormatTrigger');
        const tsSubMenu = document.getElementById('timestampFormatSubMenu');

        if (tsTrigger && tsSubMenu) {
            const formats = WORKSPACE_CONFIG.TIMESTAMP_FORMATS || ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'];
            if (tsSubMenu && tsSubMenu.children.length === 0) {
                formats.forEach(fmt => {
                    const item = document.createElement('div');
                    item.className = 'ts-opt';
                    item.dataset.val = fmt;
                    item.style.cssText = 'padding:6px 12px;font-size:13px;cursor:pointer;border-radius:4px;color:#374151;white-space:nowrap;';
                    item.innerText = fmt;
                    item.addEventListener('mouseover', () => item.style.background = '#f9fafb');
                    item.addEventListener('mouseout', () => item.style.background = '');
                    item.addEventListener('click', (e) => {
                        e.stopPropagation();
                        this.workspace.timestampFormat = fmt;
                        document.getElementById('checkmark-timestamps')?.classList.remove('hidden');
                        this._updateActiveOption('ts-opt', fmt);
                        this.renderFrameSkipOptions();
                        this.workspace.updateWorkspaceUI(); // Force update display
                        this._hideSubMenus();
                        this.closeAllMenus();
                    });
                    tsSubMenu.appendChild(item);
                });
            }
            this._updateActiveOption('ts-opt', WORKSPACE_CONFIG.DEFAULT_TIMESTAMP_FORMAT || 'Frames');

            const showTS = () => {
                this._hideSubMenus();
                tsSubMenu.style.display = 'flex';
                tsSubMenu.style.flexDirection = 'column';
            };
            const hideTS = (e) => {
                if (!tsSubMenu.contains(e?.relatedTarget) && !tsTrigger.contains(e?.relatedTarget)) {
                    tsSubMenu.style.display = 'none';
                }
            };

            tsTrigger.addEventListener('mouseenter', showTS);
            tsTrigger.addEventListener('mouseleave', hideTS);
            tsSubMenu.addEventListener('mouseleave', hideTS);
            tsTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                tsSubMenu.style.display === 'flex' ? tsSubMenu.style.display = 'none' : showTS();
            });
        }

        // ---- Frame Skip SubMenu & Pill Options ----
        const fsTrigger = document.getElementById('frameSkipTrigger');
        const fsSubMenu = document.getElementById('frameSkipSubMenu');
        const fsContainer = document.getElementById('frameSkipOptionsContainer');

        if (fsTrigger && fsSubMenu) {
            this.renderFrameSkipOptions();

            const showFS = () => {
                this._hideSubMenus();
                fsSubMenu.style.display = 'flex';
                fsSubMenu.style.flexDirection = 'column';
            };
            const hideFS = (e) => {
                if (!fsSubMenu.contains(e?.relatedTarget) && !fsTrigger.contains(e?.relatedTarget)) {
                    fsSubMenu.style.display = 'none';
                }
            };

            fsTrigger.addEventListener('mouseenter', showFS);
            fsTrigger.addEventListener('mouseleave', hideFS);
            fsSubMenu.addEventListener('mouseleave', hideFS);
            fsTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                fsSubMenu.style.display === 'flex' ? fsSubMenu.style.display = 'none' : showFS();
            });
        }

        // ---- Show frame skip selector toggle ----
        const skipRow = document.getElementById('toggle-skipselector-row');
        if (skipRow) {
            skipRow.addEventListener('click', (e) => {
                e.stopPropagation();
                const pill = document.getElementById('frameSkipSelectorPill');
                const ck = document.getElementById('checkmark-skipselector');
                if (pill) {
                    const visible = !pill.classList.contains('hidden');
                    pill.classList.toggle('hidden', visible);
                    ck?.classList.toggle('hidden', visible);
                }
                this.closeAllMenus();
            });
        }

        // Prevent clicks inside settings menu from closing it
        document.getElementById('settingsMenu')?.addEventListener('click', e => e.stopPropagation());
    }

    _hideSubMenus() {
        const ts = document.getElementById('timestampFormatSubMenu');
        const fs = document.getElementById('frameSkipSubMenu');
        if (ts) ts.style.display = 'none';
        if (fs) fs.style.display = 'none';
    }

    closeAllMenus() {
        ['filterMenu', 'rotateMenu', 'customRotateMenu', 'speedMenu',
            'frameSkipSelectorMenu', 'moreNavMenu', 'settingsMenu'].forEach(id => {
                const m = document.getElementById(id);
                if (m) { m.classList.add('hidden'); m.style.display = ''; }
            });
        this._hideSubMenus();
        this.activeMenuId = null;
    }

    // Extra bindings
    bindExtraToggles() {
        const btnVolume = document.getElementById('btnVolume');
        if (btnVolume) {
            btnVolume.addEventListener('click', () => {
                const video = this.workspace.videoCtrl.video;
                video.muted = !video.muted;
                btnVolume.innerHTML = video.muted
                    ? `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M16 9a5 5 0 0 1 .95 2.293"></path><path d="M19.364 5.636a9 9 0 0 1 1.889 9.96"></path><path d="m2 2 20 20"></path><path d="m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11"></path><path d="M9.828 4.172A.686.686 0 0 1 11 4.657v.686"></path></svg>`
                    : `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"></path><path d="M16 9a5 5 0 0 1 0 6"></path><path d="M19.364 18.364a9 9 0 0 0 0-12.728"></path></svg>`;
            });
        }
        const btnSync = document.getElementById('btnSync');
        if (btnSync) {
            btnSync.addEventListener('click', (e) => {
                e.stopPropagation();
                btnSync.classList.toggle('text-brand-blue');
            });
        }
    }

    // Legacy
    bindToggle(btnId, menuId) { this._bindMenuBtn(btnId, menuId); }

    // Stub methods for HTML inline onclick handlers
    toggleFilterMenu() { document.getElementById('filterMenu')?.classList.toggle('hidden'); }
    toggleMoreNavMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('moreNavMenu');
        const btn = document.getElementById('moreNavBtn');
        if (!menu || !btn) return;
        const isVisible = !menu.classList.contains('hidden');
        this.closeAllMenus();
        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'flex';
            const rect = btn.getBoundingClientRect();
            menu.style.visibility = 'hidden';
            const mh = menu.offsetHeight;
            menu.style.visibility = 'visible';
            const offset = 10;
            if (window.innerHeight - rect.bottom > mh + offset + 20) {
                menu.style.top = (rect.bottom + offset) + 'px';
                menu.style.bottom = 'auto';
            } else {
                menu.style.top = 'auto';
                menu.style.bottom = (window.innerHeight - rect.top + offset) + 'px';
            }
            menu.style.left = rect.left + 'px';
        }
    }
    toggleFrameSkipSelectorMenu(e) {
        if (e) e.stopPropagation();
        document.getElementById('frameSkipSelectorMenu')?.classList.toggle('hidden');
    }
    toggleSettingsMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('settingsMenu');
        const btn = document.getElementById('settingsBtn');
        if (!menu || !btn) return;
        const isVisible = !menu.classList.contains('hidden');
        this.closeAllMenus();
        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.flexDirection = 'column';
            const rect = btn.getBoundingClientRect();
            menu.style.position = 'fixed';
            
            // Smart Positioning logic
            menu.style.visibility = 'hidden';
            menu.style.display = 'flex';
            const menuHeight = menu.offsetHeight;
            menu.style.visibility = 'visible';

            const offset = 10;
            const spaceBelow = window.innerHeight - rect.bottom;
            const rightFromWindow = window.innerWidth - rect.right;

            if (spaceBelow > menuHeight + offset + 20) {
                // Space below
                menu.style.top = `${rect.bottom + offset}px`;
                menu.style.bottom = 'auto';
            } else {
                // Place above
                menu.style.top = 'auto';
                menu.style.bottom = `${window.innerHeight - rect.top + offset}px`;
            }

            menu.style.right = `${rightFromWindow}px`;
            menu.style.left = 'auto';
            menu.style.zIndex = '999999';
        }
    }

    renderFrameSkipOptions() {
        if (!this.workspace) return;
        
        const fmt = this.workspace.timestampFormat;
        const fps = WORKSPACE_CONFIG.FPS || 30;
        
        let vals = [];
        if (fmt === 'Frames') {
            vals = [1, 2, 5, 8, 10, 15, 30];
        } else {
            vals = [
                fps * 1,   // 1s
                fps * 3,   // 3s
                fps * 10,  // 10s
                fps * 15,  // 15s
                fps * 30,  // 30s
                fps * 60,  // 1mins
                fps * 300  // 5mins
            ];
        }

        const getLabel = (val) => {
            if (fmt === 'Frames') return `${val}f`;
            const num = parseInt(val, 10);
            if (num >= fps * 60 && num % (fps * 60) === 0) return `${num / (fps * 60)}mins`;
            if (num >= fps && num % fps === 0) return `${num / fps}s`;
            return `${num}f`;
        };
        
        const setFrameSkip = (val, e) => {
            if (e) e.stopPropagation();
            if (this.workspace.videoCtrl) {
                this.workspace.videoCtrl.frameSkipValue = val;
            }
            this._updateActiveOption('fs-opt', val.toString());
            
            const pillDisplay = document.getElementById('currentFrameSkipDisplay');
            if (pillDisplay) {
                pillDisplay.innerText = getLabel(val);
            }
            
            if (this._hideSubMenus) this._hideSubMenus();
            if (this.closeAllMenus) this.closeAllMenus();
        };

        const fsSubMenu = document.getElementById('frameSkipSubMenu');
        if (fsSubMenu) {
            fsSubMenu.innerHTML = '';
            vals.forEach(val => {
                const item = document.createElement('div');
                item.className = 'fs-opt';
                item.dataset.val = val.toString();
                item.style.cssText = 'padding:6px 0;font-size:13px;cursor:pointer;border-radius:4px;color:#374151;text-align:center;';
                item.innerText = getLabel(val);
                item.addEventListener('mouseover', () => item.style.background = '#f9fafb');
                item.addEventListener('mouseout', () => item.style.background = '');
                item.addEventListener('click', (e) => setFrameSkip(val, e));
                fsSubMenu.appendChild(item);
            });
        }

        const fsContainer = document.getElementById('frameSkipOptionsContainer');
        if (fsContainer) {
            fsContainer.innerHTML = '';
            vals.forEach(val => {
                const item = document.createElement('button');
                item.type = 'button';
                item.className = 'fs-opt w-full text-left px-3 py-1.5 text-[13px] hover:bg-gray-50 text-gray-700 transition-colors flex items-center justify-center';
                item.dataset.val = val.toString();
                item.innerText = getLabel(val);
                item.addEventListener('click', (e) => setFrameSkip(val, e));
                fsContainer.appendChild(item);
            });
        }

        const pillDisplay = document.getElementById('currentFrameSkipDisplay');
        if (pillDisplay && this.workspace.videoCtrl) {
            pillDisplay.innerText = getLabel(this.workspace.videoCtrl.frameSkipValue);
            this._updateActiveOption('fs-opt', this.workspace.videoCtrl.frameSkipValue.toString());
        }
    }

    setThisFrame() { /* Stub */ }
    saveThisFrame() { /* Stub */ }
    setStartToCurrent() { /* Stub */ }
    setEndToCurrent() { /* Stub */ }
    addNewRange() { /* Stub */ }
    saveAnnotation(e) { /* Stub */ }
    addCustomFrameSkip(e) { /* Stub */ }
}

var SimpleTimeline = class {
    constructor(videoCtrl) {
        this.videoCtrl = videoCtrl;
        this.track = document.getElementById('progressTrack');
        this.fill = document.getElementById('progressFill');
        this.knob = document.getElementById('progressKnob');
        this.hoverPill = document.getElementById('hoverPill');
        this.isScrubbing = false;
        this.bindEvents();
    }

    bindEvents() {
        if (!this.track) return;

        const scrub = (e) => {
            const rect = this.track.getBoundingClientRect();
            const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            this.videoCtrl.currentTime = pct * this.videoCtrl.duration;
            this.update();
        };

        this.track.addEventListener('mousedown', (e) => { this.isScrubbing = true; scrub(e); });
        window.addEventListener('mousemove', (e) => { if (this.isScrubbing) scrub(e); });
        window.addEventListener('mouseup', () => { this.isScrubbing = false; });

        // Hover pill — show timestamp
        this.track.addEventListener('mousemove', (e) => {
            if (!this.hoverPill || this.videoCtrl.duration === 0) return;
            const rect = this.track.getBoundingClientRect();
            const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            const sec = pct * this.videoCtrl.duration;

            let displayVal = '';
            if (window.Workspace) {
                displayVal = window.Workspace.formatTimeDisplay(sec, window.Workspace.timestampFormat);
            } else {
                const mm = String(Math.floor(sec / 60)).padStart(2, '0');
                const ss = String(Math.floor(sec % 60)).padStart(2, '0');
                displayVal = `${mm}:${ss}`;
            }

            this.hoverPill.innerText = displayVal;
            this.hoverPill.style.left = `${pct * 100}%`;
            this.hoverPill.classList.remove('hidden');
        });
        this.track.addEventListener('mouseleave', () => {
            this.hoverPill?.classList.add('hidden');
        });
    }

    update() {
        if (!this.track || this.videoCtrl.duration === 0) return;
        const pct = (this.videoCtrl.currentTime / this.videoCtrl.duration) * 100;
        if (this.fill) this.fill.style.width = `${pct}%`;
        if (this.knob) this.knob.style.left = `${pct}%`;
    }
}

var WorkspaceManager = class {
    constructor() {
        this.videoCtrl = null;
        this.transform = null;
        this.timeline = null;
        this.ui = null;
        this.timestampFormat = WORKSPACE_CONFIG.DEFAULT_TIMESTAMP_FORMAT || 'Frames';
    }

    init() {
        const videoEl = document.getElementById('mainVideo');
        const wrapperEl = document.getElementById('videoTransformWrapper');

        this.videoCtrl = new VideoController(videoEl);
        this.transform = new ViewportTransform(wrapperEl, videoEl);
        this.timeline = new SimpleTimeline(this.videoCtrl);
        this.ui = new UIManager(this);

        // Set initial speed to 1x
        this.videoCtrl.playbackRate = WORKSPACE_CONFIG.DEFAULT_SPEED;

        this.bindEvents();
        this.bindShortcuts();

        window.app = this.ui;

        videoEl.addEventListener('loadedmetadata', () => this.updateWorkspaceUI());
    }

    bindEvents() {
        const video = this.videoCtrl.video;

        video.addEventListener('timeupdate', () => this.updateWorkspaceUI());
        video.addEventListener('play', () => this.updatePlayState());
        video.addEventListener('pause', () => this.updatePlayState());

        const container = document.getElementById('videoTransformWrapper');
        if (container) {
            const isInsideVideo = (e) => {
                if (!video || !video.videoWidth || !video.videoHeight) return true;
                const rect = video.getBoundingClientRect();
                const videoRatio = video.videoWidth / video.videoHeight;
                const elementRatio = rect.width / rect.height;
                let actualWidth = rect.width;
                let actualHeight = rect.height;
                if (videoRatio > elementRatio) {
                    actualHeight = rect.width / videoRatio;
                } else {
                    actualWidth = rect.height * videoRatio;
                }
                const actualLeft = rect.left + (rect.width - actualWidth) / 2;
                const actualTop = rect.top + (rect.height - actualHeight) / 2;
                return e.clientX >= actualLeft && e.clientX <= actualLeft + actualWidth &&
                    e.clientY >= actualTop && e.clientY <= actualTop + actualHeight;
            };

            container.parentElement.addEventListener('wheel', (e) => {
                if (!isInsideVideo(e)) return;
                e.preventDefault();
                const step = e.deltaY < 0 ? WORKSPACE_CONFIG.ZOOM_STEP : -WORKSPACE_CONFIG.ZOOM_STEP;
                this.transform.zoom(step, e.clientX, e.clientY);
            }, { passive: false });

            container.parentElement.addEventListener('mousedown', (e) => {
                if (!isInsideVideo(e)) return;
                if (e.button === 1 || e.shiftKey) {
                    this.transform.startPan(e.clientX, e.clientY);
                    container.parentElement.style.cursor = 'grabbing';
                }
            });
            container.parentElement.addEventListener('mousemove', (e) => this.transform.pan(e.clientX, e.clientY));
            window.addEventListener('mouseup', () => {
                this.transform.endPan();
                if (container.parentElement) container.parentElement.style.cursor = 'default';
            });
        }

        // Close menus on outside click
        window.addEventListener('click', () => { if (this.ui) this.ui.closeAllMenus(); });
    }

    updatePlayState() {
        const icon = document.getElementById('playIconSvg');
        if (!icon) return;
        icon.innerHTML = this.videoCtrl.video.paused
            ? '<polygon points="6 3 20 12 6 21 6 3"></polygon>'
            : '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>';
    }

    formatTimeDisplay(totalSeconds, format) {
        if (format === 'Frames') {
            return Math.round(totalSeconds * WORKSPACE_CONFIG.FPS);
        }

        const hrs = Math.floor(totalSeconds / 3600);
        const mins = Math.floor((totalSeconds % 3600) / 60);
        const secs = Math.floor(totalSeconds % 60);
        const frames = Math.round((totalSeconds % 1) * WORKSPACE_CONFIG.FPS);

        if (format === 'HH:MM:SS') {
            return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        if (format === 'MM:SS') {
            return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        if (format === 'SS.FF') {
            return `${Math.floor(totalSeconds).toString().padStart(2, '0')}.${frames.toString().padStart(2, '0')}`;
        }
        return Math.round(totalSeconds * WORKSPACE_CONFIG.FPS);
    }

    updateWorkspaceUI() {
        const currentTime = this.videoCtrl.currentTime;
        const duration = this.videoCtrl.duration;

        const cfDisplay = this.formatTimeDisplay(currentTime, this.timestampFormat);
        const tfDisplay = this.formatTimeDisplay(duration, this.timestampFormat);

        const inp = document.getElementById('currentFrameInput');
        if (inp && document.activeElement !== inp) inp.value = cfDisplay;

        const tot = document.getElementById('totalFramesText');
        if (tot) tot.textContent = tfDisplay;

        this.timeline.update();
    }

    stepSpeed(direction) {
        const speeds = WORKSPACE_CONFIG.DEFAULT_SPEEDS;
        const cur = this.videoCtrl.playbackRate;
        let idx = speeds.indexOf(cur);
        if (idx === -1) idx = speeds.findIndex(s => s >= cur);
        if (direction === 'up' && idx < speeds.length - 1) {
            this.videoCtrl.playbackRate = speeds[idx + 1];
            document.getElementById('currentSpeedBtn').innerText = speeds[idx + 1] + 'x';
            if (this.ui) this.ui._updateActiveOption('speed-opt', speeds[idx + 1].toString());
        } else if (direction === 'down' && idx > 0) {
            this.videoCtrl.playbackRate = speeds[idx - 1];
            document.getElementById('currentSpeedBtn').innerText = speeds[idx - 1] + 'x';
            if (this.ui) this.ui._updateActiveOption('speed-opt', speeds[idx - 1].toString());
        }
    }

    bindShortcuts() {
        window.addEventListener('keydown', (e) => {
            const key = e.key.toUpperCase();
            const active = document.activeElement;
            if (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') return;
            if (e.altKey && key === 'T') {
                e.preventDefault();
                const formats = WORKSPACE_CONFIG.TIMESTAMP_FORMATS || ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'];
                let idx = formats.indexOf(this.timestampFormat);
                idx = (idx + 1) % formats.length;
                this.timestampFormat = formats[idx];
                this.updateWorkspaceUI();
                if (this.ui) {
                    this.ui._updateActiveOption('ts-opt', this.timestampFormat);
                    this.ui.renderFrameSkipOptions();
                }
                return;
            }

            switch (key) {
                case WORKSPACE_CONFIG.KEY_MAP.PLAY_PAUSE: e.preventDefault(); this.videoCtrl.togglePlay(); break;
                case WORKSPACE_CONFIG.KEY_MAP.PREV_FRAME: e.preventDefault(); this.videoCtrl.stepFrames(-1); break;
                case WORKSPACE_CONFIG.KEY_MAP.NEXT_FRAME: e.preventDefault(); this.videoCtrl.stepFrames(1); break;
                case 'ARROWUP': e.preventDefault(); this.stepSpeed('up'); break;
                case 'ARROWDOWN': e.preventDefault(); this.stepSpeed('down'); break;
            }
        });
    }
}

var DROWSINESS_QUESTIONS = [
    {
        id: 'q1', title: 'Q1: Subjective Drowsiness Scale Level', prompt: 'Subjective drowsiness scale level', type: 'radio',
        options: ['No driver', 'Not drowsy', 'Drowsiness Level 1', 'Drowsiness Level 2', 'Drowsiness Level 3']
    },
    {
        id: 'q2', title: 'Q2: Other Observations – Other', prompt: 'Other observations - other', type: 'radio',
        options: ['Daytime (Color Video)', 'Nighttime (Grayscale Video)']
    },
    {
        id: 'q3', title: 'Q3: Other Observations – Driver Related', prompt: 'Other observations - driver related', type: 'checklist',
        options: ['No driver in the video', 'Driver’s eyes are partially or fully occluded from the camera view', 'Driver’s face is partially or fully occluded from the camera view', 'Wearing sunglasses or shade goggles', 'Wearing regular glasses or transparent goggles', 'Intense sunlight or glare on driver\'s face', 'Driver adjusting seats', 'Driver moving restlessly to adjust posture within the seat', 'Picking up something from the bottom of the cabin', 'Looking to the side for making left turns or changing lanes', 'Looking to the side or around for other reasons']
    },
    {
        id: 'q4', title: 'Q4: driver_action', prompt: 'driver action', type: 'checklist',
        options: ['The driver falls asleep in the video', 'The driver is engaged in a conversation (phone or passenger)', 'The driver is executing secondary driver tasks', 'The driver is singing', 'The driver is eating or drinking', 'The driver is smoking', 'None of the above', 'Cannot determine'],
        exclusive: ['None of the above', 'Cannot determine']
    },
    {
        id: 'q5', title: 'Q5: driver_yawning', prompt: 'driver yawning', type: 'radio',
        options: ['Yes', 'No', 'Cannot determine']
    },
    {
        id: 'q5_dur', title: 'Q5.1: How long was the yawning combined?', prompt: 'how long was the yawning combined', type: 'radio',
        options: ['0–2s', '2–5s', '5s+']
    },
    {
        id: 'q5_freq', title: 'Q5.2: How many times did the driver yawn in the video?', prompt: 'how many times did the driver yawn', type: 'radio',
        options: ['1', '2', '3+']
    },
    {
        id: 'q6', title: 'Q6: hand_action', prompt: 'hand action', type: 'checklist',
        options: ['Rubbing or scratching eyes', 'Driver resting head in hands', 'Rubbing face (not eyes)', 'None of the above', 'Cannot determine'],
        exclusive: ['None of the above', 'Cannot determine']
    },
    {
        id: 'q7', title: 'Q7: body_position', prompt: 'body position', type: 'checklist',
        options: ['Driver slouching', 'Driver sitting upright', 'Driver leaning forward', 'Driver leaning backward', 'None of the above', 'Cannot determine'],
        exclusive: ['None of the above', 'Cannot determine']
    },
    {
        id: 'q8', title: 'Q8: head_movement', prompt: 'head movement', type: 'checklist',
        options: ['Shaking head as an effort to be awake', 'Leaning head back', 'Driver head moving frequently', 'Driver head stationary throughout the video', 'Loss of neck muscle control or nodding/bobbing involuntarily', 'None of the above', 'Cannot determine'],
        exclusive: ['None of the above', 'Cannot determine']
    },
    {
        id: 'q9', title: 'Q9: eyes_movement', prompt: 'eyes movement', type: 'checklist',
        options: ['Driver not blinking throughout the video', 'Driver blinks slowly', 'Driver blinking rapidly', 'Eyes are closed for 2–5 seconds', 'Eyes are closed for more than 5 seconds', 'Squinting eyes', 'Eyes rolling back', 'Driver straining to keep eyes open', 'Blank stare or staring at a fixed position', 'None of the above', 'Cannot determine'],
        exclusive: ['None of the above', 'Cannot determine']
    }
];

var DrowsinessWorkflow = class {
    constructor() {
        this.container = document.getElementById('dw-questions-container');
        this.answers = {};
        this.filter = 'ALL'; // ALL, PENDING, COMPLETED
        if (this.container) {
            this._loadPrevAnnotations();
            this.init();
        }
        window.drowsinessUI = this;
    }

    /**
     * Load previous annotations from SageMaker prev_annotations into this.answers
     * so that selections survive a page submit/reload.
     *
     * Handles all SageMaker serialization quirks:
     *  - answers field may be a real JS array, a JSON-stringified array, or a plain string
     *  - The whole annotation blob may be double-stringified
     */
    _loadPrevAnnotations() {
        try {
            const raw = window.sageMakerData?.prev_annotations;
            if (!raw) return;
            let arr = typeof raw === 'string' ? JSON.parse(raw) : raw;
            if (!Array.isArray(arr)) arr = [arr];
            if (!arr.length) return;

            const firstResult = arr[0];
            let annotationData = null;

            // Strategy 1: firstResult.annotation is a JSON string (most common SageMaker path).
            // Our hidden input value is JSON.stringify({annotation:{Q1:…}}) — SageMaker stores
            // that raw string in the output manifest and feeds it back as prev_annotations[0].annotation.
            if (firstResult?.annotation && typeof firstResult.annotation === 'string') {
                try {
                    const parsed = JSON.parse(firstResult.annotation);
                    annotationData = parsed?.annotation || parsed;
                } catch (e) { /* not valid JSON, continue */ }
            }

            // Strategy 2: annotation is already a parsed object (some SageMaker configurations
            // auto-parse JSON values before returning them in prev_annotations).
            if (!annotationData && firstResult?.annotation && typeof firstResult.annotation === 'object') {
                annotationData = firstResult.annotation?.annotation || firstResult.annotation;
            }

            // Strategy 3: flat top-level keys like Q1, Q2 directly on firstResult.
            if (!annotationData && firstResult && typeof firstResult === 'object') {
                const hasQKey = Object.keys(firstResult).some(k => /^Q\d/i.test(k));
                if (hasQKey) annotationData = firstResult;
            }

            if (!annotationData) return;

            // Helper: normalise an answers value into a plain JS array of strings.
            // SageMaker can double-stringify arrays → '["Closed 2-5s","Not blinking all video"]'
            const toArray = (raw) => {
                if (Array.isArray(raw)) return raw;
                if (typeof raw === 'string') {
                    const trimmed = raw.trim();
                    // Could be a JSON array string: ["a","b"]
                    if (trimmed.startsWith('[')) {
                        try { return JSON.parse(trimmed); } catch (e) { /* fall through */ }
                    }
                    // Single value string
                    return trimmed !== '' ? [trimmed] : [];
                }
                return [];
            };

            Object.entries(annotationData).forEach(([key, val]) => {
                const qid = key.toLowerCase(); // Q6_FREQ → q6_freq
                const q = DROWSINESS_QUESTIONS.find(x => x.id === qid);
                if (!q) return;

                let rawAnswers;

                // Format A: our hidden-field JSON → { question, type, mandatory, answers: [...] }
                if (val && typeof val === 'object' && !Array.isArray(val) && 'answers' in val) {
                    rawAnswers = val.answers;
                }
                // Format B: SageMaker boolean-map from same-named checkbox/radio inputs.
                // crowd-form groups name="q2" inputs into { "opt1": true, "opt2": false, ... }
                // Extract all option-texts that are marked true.
                else if (val && typeof val === 'object' && !Array.isArray(val)) {
                    const trueKeys = Object.entries(val)
                        .filter(([, v]) => v === true || v === 'true' || v === 'on')
                        .map(([k]) => k);
                    rawAnswers = trueKeys.length > 0 ? trueKeys : [];
                }
                // Format C: scalar or array passed directly
                else {
                    rawAnswers = val;
                }

                const answers = toArray(rawAnswers);
                // Trust the saved answers directly — they were generated from the same
                // option list. Do NOT filter with q.options.includes() as that can
                // silently discard answers if option strings differ between versions.
                if (Array.isArray(answers) && answers.length > 0) {
                    this.answers[qid] = answers.slice();
                } else if (typeof answers === 'string' && answers !== '') {
                    this.answers[qid] = [answers];
                }
            });
        } catch (err) {
            console.warn('[DrowsinessWorkflow] Failed to load prev_annotations:', err);
        }
    }
    
    setFilter(filterType) {
        this.filter = filterType;
        this.preserveStateRender();
    }
    
    init() {
        this.bindEvents();
        this.renderAll();
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.dw-select-container')) {
                document.querySelectorAll('.dw-dropdown-menu.show').forEach(menu => {
                    menu.classList.remove('show');
                    const container = menu.closest('.dw-select-container');
                    if (container) container.classList.remove('is-open');
                });
            }
        });
    }

    renderAll() {
        let html = `
            <div class="sticky top-0 bg-white z-50 flex items-center justify-between mb-4 border-b border-[#e2e8f0] pb-3 px-1 pt-3 -mt-3">
                <div class="flex items-center gap-2">
                    <div class="flex items-center bg-[#f1f5f9] p-0.5 rounded-md border border-gray-200">
                        <div class="cursor-pointer px-3 py-1 rounded text-[12px] font-medium transition-all ${this.filter === 'ALL' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}" onclick="window.drowsinessUI.setFilter('ALL')">All</div>
                        <div class="cursor-pointer px-3 py-1 rounded text-[12px] font-medium transition-all ${this.filter === 'PENDING' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}" onclick="window.drowsinessUI.setFilter('PENDING')">Pending</div>
                        <div class="cursor-pointer px-3 py-1 rounded text-[12px] font-medium transition-all ${this.filter === 'COMPLETED' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}" onclick="window.drowsinessUI.setFilter('COMPLETED')">Completed</div>
                    </div>
                </div>
            </div>
        `;
        // FIX: Q5.1 and Q5.2 only show when Q5 answer is "Yes"
        const q5Answer = (this.answers['q5'] || [])[0];
        const showYawningSubQ = q5Answer === 'Yes';

        DROWSINESS_QUESTIONS.forEach((q, idx) => {
            if (!this.answers[q.id]) this.answers[q.id] = [];

            // Hide Q5.1 (q5_dur) and Q5.2 (q5_freq) unless Q5 = "Yes"
            let isHidden = false;
            if ((q.id === 'q5_freq' || q.id === 'q5_dur') && !showYawningSubQ) {
                isHidden = true; // render as hidden
            } else {
                const isAnswered = this.answers[q.id].length > 0;
                if (this.filter === 'PENDING' && isAnswered) isHidden = true;
                if (this.filter === 'COMPLETED' && !isAnswered) isHidden = true;
            }
            
            html += this.buildQuestionUI(q, idx + 1, isHidden);
        });
        // Optional: Add some bottom padding if needed, but no annotations section
        html += `<div class="pb-8"></div>`;
        
        this.container.innerHTML = html;
    }
    
    buildQuestionUI(q, index, isHidden = false) {
        const selected = this.answers[q.id] || [];
        
        let tagsHtml = '';
        selected.forEach(val => {
            const isExclusive = q.exclusive && q.exclusive.includes(val);
            const tagClass = isExclusive ? '' : 'tag-blue';
            tagsHtml += `
                <div class="dw-tag ${tagClass}">
                    ${val.replace(/_/g, ' ')}
                    <span class="dw-tag-close flex items-center cursor-pointer" data-qid="${q.id}" data-val="${val.replace(/"/g, '&quot;')}">
                        <svg class="icon-outlined" fill-rule="evenodd" viewBox="64 64 896 896" focusable="false" data-icon="close-circle" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm0 76c-205.4 0-372 166.6-372 372s166.6 372 372 372 372-166.6 372-372-166.6-372-372-372zm128.01 198.83c.03 0 .05.01.09.06l45.02 45.01a.2.2 0 01.05.09.12.12 0 010 .07c0 .02-.01.04-.05.08L557.25 512l127.87 127.86a.27.27 0 01.05.06v.02a.12.12 0 010 .07c0 .03-.01.05-.05.09l-45.02 45.02a.2.2 0 01-.09.05.12.12 0 01-.07 0c-.02 0-.04-.01-.08-.05L512 557.25 384.14 685.12c-.04.04-.06.05-.08.05a.12.12 0 01-.07 0c-.03 0-.05-.01-.09-.05l-45.02-45.02a.2.2 0 01-.05-.09.12.12 0 010-.07c0-.02.01-.04.06-.08L466.75 512 338.88 384.14a.27.27 0 01-.05-.06l-.01-.02a.12.12 0 010-.07c0-.03.01-.05.05-.09l45.02-45.02a.2.2 0 01.09-.05.12.12 0 01.07 0c.02 0 .04.01.08.06L512 466.75l127.86-127.86c.04-.05.06-.06.08-.06a.12.12 0 01.07 0z"></path></svg>
                        <svg class="icon-filled" fill-rule="evenodd" viewBox="64 64 896 896" focusable="false" data-icon="close-circle" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm127.98 274.82h-.04l-.08.06L512 466.75 384.14 338.88c-.04-.05-.06-.06-.08-.06a.12.12 0 00-.07 0c-.03 0-.05.01-.09.05l-45.02 45.02a.2.2 0 00-.05.09.12.12 0 000 .07v.02a.27.27 0 00.06.06L466.75 512 338.88 639.86c-.05.04-.06.06-.06.08a.12.12 0 000 .07c0 .03.01.05.05.09l45.02 45.02a.2.2 0 00.09.05.12.12 0 00.07 0c.02 0 .04-.01.08-.05L512 557.25l127.86 127.87c.04.04.06.05.08.05a.12.12 0 00.07 0c.03 0 .05-.01.09-.05l45.02-45.02a.2.2 0 00.05-.09.12.12 0 000-.07v-.02a.27.27 0 00-.05-.06L557.25 512l127.87-127.86c.04-.04.05-.06.05-.08a.12.12 0 000-.07c0-.03-.01-.05-.05-.09l-45.02-45.02a.2.2 0 00-.09-.05.12.12 0 00-.07 0z"></path></svg>
                    </span>
                </div>
            `;
        });
        
        let optionsHtml = '';
        q.options.forEach(opt => {
            const isSelected = selected.includes(opt);
            // Use name="${q.id}" for radio buttons to auto-group them.
            // Use name="${opt}" for checkboxes so AWS SageMaker native clone/review jobs
            // can map the flat boolean output {"Blinks slowly": true} back to individual checkboxes natively.
            // The authoritative answer data flows through window.Drowsiness.answers
            // → annotationJsonField (hidden JSON field) on submit.
            optionsHtml += `
                <label class="dw-option ${isSelected ? 'selected' : ''}">
                    <input type="${q.type === 'radio' ? 'radio' : 'checkbox'}" name="${q.type === 'radio' ? q.id : q.id + '_' + opt.replace(/"/g, '&quot;')}" class="dw-checkbox" value="${opt.replace(/"/g, '&quot;')}" ${isSelected ? 'checked' : ''} data-qid="${q.id}">
                    ${opt.replace(/_/g, ' ')}
                </label>
            `;
        });
        
        return `
            <div class="dw-q-card" ${isHidden ? 'style="display: none;"' : ''}>
                <div class="dw-q-header">
                    <div class="dw-q-title">${q.title}</div>
                    <div class="dw-q-badge">${index}</div>
                </div>
                ${selected.length > 0 ? `
                <div class="dw-tags-area mb-2 flex flex-wrap gap-1.5" id="tags-${q.id}">
                    ${tagsHtml}
                </div>
                ` : ''}
                <div class="dw-select-container" data-qid="${q.id}">
                    <div class="flex flex-wrap gap-1.5 items-center w-full relative z-10">
                        <input type="text" name="_search_${q.id}" class="dw-search-input" placeholder="Search options..." data-qid="${q.id}" autocomplete="off" onkeydown="if(event.key === 'Enter') event.preventDefault();">
                    </div>
                    <div class="dw-icons z-20">
                        ${selected.length > 0 ? `<div class="dw-icon-btn clear-btn" data-qid="${q.id}"><svg fill-rule="evenodd" viewBox="64 64 896 896" focusable="false" data-icon="close-circle" width="14px" height="14px" fill="currentColor" aria-hidden="true"><path d="M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm127.98 274.82h-.04l-.08.06L512 466.75 384.14 338.88c-.04-.05-.06-.06-.08-.06a.12.12 0 00-.07 0c-.03 0-.05.01-.09.05l-45.02 45.02a.2.2 0 00-.05.09.12.12 0 000 .07v.02a.27.27 0 00.06.06L466.75 512 338.88 639.86c-.05.04-.06.06-.06.08a.12.12 0 000 .07c0 .03.01.05.05.09l45.02 45.02a.2.2 0 00.09.05.12.12 0 00.07 0c.02 0 .04-.01.08-.05L512 557.25l127.86 127.87c.04.04.06.05.08.05a.12.12 0 00.07 0c.03 0 .05-.01.09-.05l45.02-45.02a.2.2 0 00.05-.09.12.12 0 000-.07v-.02a.27.27 0 00-.05-.06L557.25 512l127.87-127.86c.04-.04.05-.06.05-.08a.12.12 0 000-.07c0-.03-.01-.05-.05-.09l-45.02-45.02a.2.2 0 00-.09-.05.12.12 0 00-.07 0z"></path></svg></div>` : ''}
                        <div class="dw-icon-btn toggle-btn"><span class="material-icons-outlined !text-[18px]">arrow_drop_down</span></div>
                    </div>
                    <div class="dw-dropdown-menu" id="dropdown-${q.id}">
                        ${optionsHtml}
                    </div>
                </div>
            </div>
        `;
    }
    
    bindEvents() {
        this.container.addEventListener('click', (e) => {
            // Tag close
            const tagClose = e.target.closest('.dw-tag-close');
            if (tagClose) {
                e.stopPropagation();
                const qId = tagClose.dataset.qid;
                const val = tagClose.dataset.val;
                this.answers[qId] = this.answers[qId].filter(v => v !== val);
                
                this.preserveStateRender();
                return;
            }
            
            // Clear btn
            const clearBtn = e.target.closest('.clear-btn');
            if (clearBtn) {
                e.stopPropagation();
                const qId = clearBtn.dataset.qid;
                this.answers[qId] = [];
                
                this.preserveStateRender();
                return;
            }
            
            // Container click (toggle dropdown)
            const selContainer = e.target.closest('.dw-select-container');
            const optionLabel = e.target.closest('.dw-option');
            if (selContainer && !optionLabel) {
                const qId = selContainer.dataset.qid;
                const menu = document.getElementById(`dropdown-${qId}`);
                
                // close others
                document.querySelectorAll('.dw-dropdown-menu.show').forEach(m => {
                    if (m !== menu) {
                        m.classList.remove('show');
                        m.closest('.dw-select-container').classList.remove('is-open');
                    }
                });
                
                menu.classList.toggle('show');
                selContainer.classList.toggle('is-open');
                
                if (menu.classList.contains('show')) {
                    const input = selContainer.querySelector('.dw-search-input');
                    if (input) input.focus();
                }
            }
        });
        
        this.container.addEventListener('input', (e) => {
            if (e.target.classList.contains('dw-search-input')) {
                const qId = e.target.dataset.qid;
                const menu = document.getElementById(`dropdown-${qId}`);
                const term = e.target.value.toLowerCase();
                
                if (!menu.classList.contains('show')) {
                    menu.classList.add('show');
                    menu.closest('.dw-select-container').classList.add('is-open');
                }
                
                menu.querySelectorAll('.dw-option').forEach(opt => {
                    const text = opt.textContent.toLowerCase();
                    opt.style.display = text.includes(term) ? 'flex' : 'none';
                });
            }
        });
        
        this.container.addEventListener('change', (e) => {
            if (e.target.classList.contains('dw-checkbox')) {
                const input = e.target;
                const qId = input.dataset.qid;
                const val = input.value;
                const q = DROWSINESS_QUESTIONS.find(x => x.id === qId);
                
                if (q.type === 'radio') {
                    this.answers[qId] = [val];
                    
                    if (qId === 'q5' && val !== 'Yes') {
                        this.answers['q5_freq'] = [];
                        this.answers['q5_dur'] = [];
                    }

                    // Will close automatically since preserveStateRender checks if radio, wait, it doesn't. 
                    // Let's close the radio dropdown manually here.
                    const menu = document.getElementById(`dropdown-${qId}`);
                    if (menu) {
                        menu.classList.remove('show');
                        menu.closest('.dw-select-container').classList.remove('is-open');
                    }
                } else {
                    if (input.checked) {
                        if (q.exclusive && q.exclusive.includes(val)) {
                            this.answers[qId] = [val];
                        } else {
                            if (q.exclusive) {
                                this.answers[qId] = this.answers[qId].filter(v => !q.exclusive.includes(v));
                            }
                            if (!this.answers[qId].includes(val)) {
                                this.answers[qId].push(val);
                            }
                        }
                    } else {
                        this.answers[qId] = this.answers[qId].filter(v => v !== val);
                    }
                }
                
                this.preserveStateRender();
            }
        });
    }

    preserveStateRender() {
        // Capture state before render
        const openMenus = Array.from(document.querySelectorAll('.dw-dropdown-menu.show')).map(m => m.id);
        const focusQid = document.activeElement && document.activeElement.classList.contains('dw-search-input') ? document.activeElement.dataset.qid : null;
        const searchVal = focusQid ? document.activeElement.value : '';

        // FIX: capture scroll positions of open dropdown menus before re-render
        const scrollPositions = {};
        openMenus.forEach(menuId => {
            const m = document.getElementById(menuId);
            if (m) scrollPositions[menuId] = m.scrollTop;
        });
        
        this.renderAll();
        
        // Restore open menus
        openMenus.forEach(menuId => {
            const m = document.getElementById(menuId);
            if (m) {
                m.classList.add('show');
                m.closest('.dw-select-container').classList.add('is-open');
                // FIX: restore scroll position to prevent jump-to-top on multi-select
                if (scrollPositions[menuId] !== undefined) {
                    m.scrollTop = scrollPositions[menuId];
                }
            }
        });
        
        // Restore focus and search filter
        if (focusQid) {
            const focusInput = document.querySelector(`.dw-search-input[data-qid="${focusQid}"]`);
            if (focusInput) {
                focusInput.focus();
                focusInput.value = searchVal;
                // Dispatch input event to re-filter list
                focusInput.dispatchEvent(new Event('input', { bubbles: true }));
            }
        }
        
        // Eagerly update the hidden JSON field every time state changes.
        // This ensures external tools (like fmn-frontend's "Save and exit" button)
        // always capture the latest full JSON, even if they bypass the form submit event.
        const hiddenField = document.getElementById('annotationJsonField');
        if (hiddenField && window.buildAnnotationData) {
            hiddenField.value = JSON.stringify(window.buildAnnotationData());
        }
    }
}

// Bootstrap
var initApp = () => {
    if (!window.Workspace) {
        window.Workspace = new WorkspaceManager();
        window.Workspace.init();
    }
    if (!window.Drowsiness) {
        window.Drowsiness = new DrowsinessWorkflow();
    }

    // Safety net: always write full annotation JSON to the hidden field
    // before crowd-form submits, regardless of how submission is triggered.
    const crowdForm = document.querySelector('crowd-form');
    if (crowdForm) {
        crowdForm.addEventListener('submit', () => {
            const data = window.buildAnnotationData ? window.buildAnnotationData() : null;
            if (!data) return;
            const hiddenField = document.getElementById('annotationJsonField');
            if (hiddenField) hiddenField.value = JSON.stringify(data);
        });
    }
};
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

// Extra global functions referenced in HTML
window.copyVideoName = function () {
    const text = document.getElementById('videoNameDisplay')?.innerText;
    if (text) navigator.clipboard.writeText(text);
};
window.closeAnnotationPanel = function () {
    document.getElementById('annotationOverlay')?.classList.add('hidden');
};

/**
 * Serialize all Drowsiness answers into the annotation JSON structure.
 * Returns { annotation: { Q1: {...}, Q2: {...}, ... } }
 *
 * For multi_checkbox questions the answers field is ALWAYS a JS Array so that
 * JSON.stringify produces ["a","b","c"] — never a bare string.  SageMaker stores
 * and returns that string faithfully so _loadPrevAnnotations can restore all
 * selections on the next visit.
 */
window.buildAnnotationData = function() {
    if (!window.Drowsiness) return { annotation: {} };

    const annotation = {};

    DROWSINESS_QUESTIONS.forEach(q => {
        // Skip dependent questions if parent condition is not met
        if ((q.id === 'q5_freq' || q.id === 'q5_dur') && (!window.Drowsiness.answers['q5'] || window.Drowsiness.answers['q5'][0] !== 'Yes')) {
            return;
        }

        const key = q.id.toUpperCase(); // q6_freq -> Q6_FREQ
        const isRadio = q.type === 'radio';

        const ans = window.Drowsiness.answers[q.id] || [];

        // Radio: single string. Checklist: always a real Array (even 1 item)
        // so JSON round-trip through SageMaker preserves all selected values.
        const finalAnswer = isRadio
            ? (ans.length > 0 ? ans[0] : '')
            : ans.slice(); // defensive copy keeps it as Array

        const questionTitle = q.title.replace(/^Q\d+[a-zA-Z]*:\s*/, '');

        annotation[key] = {
            question: questionTitle,
            type: isRadio ? 'radio' : 'multi_checkbox',
            mandatory: true,
            answers: finalAnswer
        };
    });

    return { annotation };
};

/**
 * Called by the modal Submit button.
 * Writes the full annotation JSON to the hidden form field so SageMaker
 * captures ALL multi-select values (not just the last checkbox per name),
 * then triggers the crowd-form submission.
 */
window.submitAnnotation = function() {
    document.getElementById('submitModal').classList.add('hidden');

    // Serialize every answer (including multi-select arrays) into one JSON field
    const data = window.buildAnnotationData();
    const hiddenField = document.getElementById('annotationJsonField');
    if (hiddenField) {
        hiddenField.value = JSON.stringify(data);
    }

    // Submit the SageMaker crowd-form
    const crowdForm = document.querySelector('crowd-form');
    if (crowdForm) {
        crowdForm.submit();
    }
};

window.exportJSON = function() {
    const data = window.buildAnnotationData();

    // Derive filename from the video name (strip extension, add .json)
    const rawVideoName =
        window.sageMakerData?.videoName ||
        document.getElementById('videoNameDisplay')?.innerText ||
        'annotated_data';
    const baseName = rawVideoName.replace(/\.[^/.]+$/, ''); // remove extension
    const fileName = baseName + '.json';

    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
};

window.importJSON = function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            if (data.annotation) {
                // Update sageMakerData
                if (!window.sageMakerData) {
                    window.sageMakerData = {};
                }
                window.sageMakerData.prev_annotations = JSON.stringify(data.annotation);
                // Reload annotations
                if (window.Drowsiness && window.Drowsiness._loadPrevAnnotations) {
                    window.Drowsiness._loadPrevAnnotations();
                    window.Drowsiness.preserveStateRender();
                } else if (window.Drowsiness) {
                    // Force a re-init if _loadPrevAnnotations is not easily accessible
                    window.Drowsiness.init();
                }
            } else {
                alert("Invalid JSON format. Expected 'annotation' key.");
            }
        } catch (error) {
            console.error("Error parsing JSON:", error);
            alert("Error parsing JSON file.");
        }
        // Reset the input so the same file can be selected again
        event.target.value = '';
    };
    reader.readAsText(file);
};

window.jumpToFirstFrame = function() {
    if (window.app && window.app.workspace && window.app.workspace.videoCtrl) {
        window.app.workspace.videoCtrl.seekToFrame(0);
    }
};

window.jumpToLastFrame = function() {
    if (window.app && window.app.workspace && window.app.workspace.videoCtrl) {
        const totalFrames = window.app.workspace.videoCtrl.getTotalFrames();
        if (totalFrames > 0) {
            window.app.workspace.videoCtrl.seekToFrame(totalFrames);
        }
    }
};
