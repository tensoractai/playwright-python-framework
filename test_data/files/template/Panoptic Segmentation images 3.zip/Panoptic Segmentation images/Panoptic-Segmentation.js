/**
 * VIDEO ANNOTATION WORKSPACE ENGINE
 * Architecture Pattern: OOP (Skeletal Structural Template)
 */

// Per-class "quick action" icons (AI-assisted labeling / auto-segmentation)
// shown next to each class's hotkey badge in the Classes list — fully
// implemented (see renderClassList()'s classRowQuickActions), but hidden
// pending a product decision on whether/when to ship them. Flip this to
// `true` to show them again; no other code changes needed either way.
const SHOW_CLASS_ROW_QUICK_ACTIONS = false;

// Letters reserved for tool shortcuts (handleCanvasKeyDown: D = toggle
// freehand polygon, F = brush, G = polygon, H = eraser) — excluded from
// bindShortcuts()'s A-Z class-selection hotkeys so pressing one always
// switches tools, never re-triggers class selection (which would reset
// the tool back to its create-mode default) even though getShortcut()
// may still hand one of these letters out as some class's displayed badge.
const TOOL_SHORTCUT_LETTERS = ['D', 'F', 'G', 'H'];

const WORKSPACE_CONFIG = {
    CLASSES: {
        Objects: [
            { name: 'Person', color: '#499ED1' },
            { name: 'Bicycle', color: '#7872D9' },
            { name: 'Motorcycle', color: '#5B5D5A' },
            { name: 'Car', color: '#3D86A2' },
            { name: 'Truck', color: '#EF2EC9' },
            { name: 'Bus', color: '#F56D54' },
            { name: 'Train', color: '#ABDA04' },
            { name: 'Traffic Light', color: '#EEEED2' },
            { name: 'Stop Sign', color: '#927050' },
            { name: 'Speed Limit Sign', color: '#368D3C' },
            { name: 'Turn Sign', color: '#D40678' },
            { name: 'Traffic Sign Other', color: '#7C16A1' },
            { name: 'Banner/Billboard', color: '#47ADF8' },
            { name: 'Parking Meter', color: '#C1DF34' },
            { name: 'Fire Hydrant', color: '#25BC09' },
            { name: 'Animal', color: '#FC7BD2' },
            { name: 'Garbage Bin/Dumpster', color: '#5F3949' },
            { name: 'Person in Ego Vehicle', color: '#CA8827' }
        ],
        Regions: [
            { name: 'Ego Vehicle Partial Mask', color: '#DD9ED8' },
            { name: 'Ego Vehicle Cargo', color: '#B31BB6' },
            { name: 'Pole/Lamp', color: '#834F23' },
            { name: 'Divider/Fence/Guardrail', color: '#12EF6E' },
            { name: 'Traffic Cone', color: '#1350D1' },
            { name: 'Drivable Area', color: '#733A25' },
            { name: 'Sidewalk', color: '#5B2CEB' },
            { name: 'Bridge', color: '#155DFE' },
            { name: 'Tunnel', color: '#3442B6' },
            { name: 'Building Wall', color: '#1B36E9' },
            { name: 'Vegetation', color: '#0C2349' },
            { name: 'Terrain', color: '#4D8E88' },
            { name: 'Sky', color: '#25BD8B' }
        ]
    },
    FPS: 30,
    DEFAULT_PPS: 160,
    MIN_PPS: 40,
    MAX_PPS: 800,
    ZOOM_STEP: 0.1,
    MIN_ZOOM: 0.5,
    MAX_ZOOM: 50.0,
    // Wheel-notch / zoom-button step, as a PERCENTAGE of the CURRENT scale
    // rather than a fixed absolute amount — see the wheel and zoomIn/zoomOut
    // handlers in WorkspaceManager.bindEvents()/UIManager's toolbar binding.
    // A flat absolute step (the old ZOOM_STEP-derived behavior) shrinks to an
    // imperceptible fraction of the current zoom once zoomed in far enough —
    // a step that reads as a solid ~10% jump at 1x scale is under 1% at 10x
    // scale — which is what made a single wheel notch feel like it needed
    // two or three tries to register once zoomed in a while. A percentage
    // keeps every notch feeling the same regardless of zoom level.
    ZOOM_WHEEL_PERCENT: 0.08,

    // --- Editor defaults (Settings drawer) — the value each control boots
    // with before the user ever touches it. Every one of these mirrors a
    // live UIManager property of the same shape (see the constructor and
    // setLabelDisplaySetting()/setInvertWheelZoom()) that the drawer's own
    // inputs read/write at runtime; changing these only moves the STARTING
    // point, never a hard limit. ---
    DEFAULT_INVERT_WHEEL_ZOOM: false,
    DEFAULT_LABEL_COLOR_MODE: 'class',           // 'class' | 'object'
    DEFAULT_OBJECT_LABEL_FONT_SIZE: 14,          // px, 6-48 per the slider
    DEFAULT_OBJECT_FILL_OPACITY: 0.2,            // 0..1 (20%)
    DEFAULT_SELECTED_OBJECT_FILL_OPACITY: 0.4,   // 0..1 (40%)

    // --- Classes / Labels side-panel defaults ---
    // Classes panel (left): folder-per-group vs one flat list — see
    // toggleClassGrouping(). Labels panel (right): nested Category > Class >
    // Instance vs flat-by-class — see toggleLabelGrouping(). Independent of
    // each other and of CLASSES' own shape below.
    CLASSES_GROUPED_BY_DEFAULT: true,
    LABELS_GROUPED_BY_DEFAULT: false,
    // Group names (must match a key in CLASSES above) collapsed on first
    // load, before the user has ever clicked a group header this session —
    // e.g. ['Regions'] to start with Regions collapsed and Objects expanded.
    // Only a starting point: sessionStorage's own collapsedGroups (see
    // toggleGroup()) remembers whatever the user actually clicks to from
    // then on, same as everything else in this block.
    DEFAULT_COLLAPSED_CLASS_GROUPS: [],
    DEFAULT_SPEEDS: [0.25, 0.5, 1.0, 1.5, 2.0, 4.0],
    DEFAULT_FRAME_SKIPS: [1, 2, 5, 10, 30, 60],
    DEFAULT_SPEED: 1.0,
    KEY_MAP: {
        PLAY_PAUSE: ' ',
        PREV_FRAME: 'ARROWLEFT',
        NEXT_FRAME: 'ARROWRIGHT',
        SPEED_UP: 'ARROWUP',
        SPEED_DOWN: 'ARROWDOWN',
        MARK_START: 'C',
        MARK_END: 'V',
        SAVE: 'S'
    }
};

// Flattened, group-tagged view of WORKSPACE_CONFIG.CLASSES — every class
// across every group, as one array of { name, color, group }. Generic to
// however many groups CLASSES declares (or however few — a single group is
// effectively a flat, ungrouped class list; see toggleClassGrouping() for
// the separate per-session grouped/flat VIEW toggle, which is independent of
// how many groups the data itself actually has). Used anywhere the app
// needs "every class" regardless of grouping — shortcut assignment, class
// lookup by name, COCO category export/import — so adding, removing, or
// renaming a CLASSES group never requires touching those call sites.
function getAllClasses() {
    return Object.entries(WORKSPACE_CONFIG.CLASSES).flatMap(
        ([group, classes]) => classes.map(c => ({ ...c, group }))
    );
}

class VideoController {
    constructor(videoElement) {
        if (!videoElement) throw new Error("Video element is required.");
        this.video = videoElement;
        this.frameSkipValue = 1;
    }

    get currentTime() { return this.video.currentTime; }
    set currentTime(secs) { this.video.currentTime = Math.max(0, Math.min(secs, this.duration)); }

    get duration() { return this.video.duration || 0; }
    get playbackRate() { return this.video.playbackRate; }
    set playbackRate(rate) { this.video.playbackRate = rate; }

    get muted() { return this.video.muted; }
    set muted(state) { this.video.muted = state; }

    getCurrentFrame() {
        return Math.round(this.currentTime * WORKSPACE_CONFIG.FPS);
    }

    getTotalFrames() {
        return Math.floor(this.duration * WORKSPACE_CONFIG.FPS);
    }

    seekToFrame(frameNumber) {
        this.currentTime = frameNumber / WORKSPACE_CONFIG.FPS;
    }

    stepFrames(direction = 1) {
        const targetFrame = this.getCurrentFrame() + (direction * this.frameSkipValue);
        this.seekToFrame(Math.max(0, Math.min(this.getTotalFrames(), targetFrame)));
    }

    togglePlay() {
        if (this.video.paused) {
            this.video.play().catch(e => console.error("Playback failed", e));
        } else {
            this.video.pause();
        }
        setTimeout(() => window.app?.workspace?.updatePlayState(), 50);
    }
}

class ViewportTransform {
    constructor(wrapperElement, videoElement) {
        this.wrapper = wrapperElement;
        this.video = videoElement;
        this.scale = 0.9;
        this.rotation = 0;       // normalized 0-359
        this.displayRotation = 0; // cumulative for smooth transitions
        this.translateX = 0;
        this.translateY = 0;
        this.isPanning = false;
        this.startX = 0;
        this.startY = 0;
        // channel: 'none' | 'red' | 'green' | 'blue' — see setChannelFilter().
        this.filters = { brightness: 100, contrast: 100, saturation: 100, channel: 'none' };
        this.isPixelated = false;
        // The image's own native pixel size (set once known, from
        // WorkspaceManager's load/complete hook) and the per-image zoom
        // tuning derived from it in fitToContainer() — a fixed 0.5..15.0
        // zoom range made sense when `scale` was relative to a
        // container-fit size, but once `scale` is a direct
        // native-px-to-screen-px ratio, a tiny thumbnail and a
        // multi-thousand-pixel photo need very different absolute ranges/
        // step sizes to feel the same to scroll-zoom.
        this.naturalWidth = 0;
        this.naturalHeight = 0;
        this.minZoom = WORKSPACE_CONFIG.MIN_ZOOM;
        this.zoomStep = WORKSPACE_CONFIG.ZOOM_STEP;
        // True immediately after load or an explicit Zoom-to-Fit click,
        // cleared the instant the user manually zooms or pans — lets a
        // resize keep auto-refitting the view while the user hasn't
        // deviated from the default, without ever touching stored
        // annotation coordinates (see fitToContainer()).
        this.isAtDefaultFit = true;
        this.apply();
    }

    // Scales the (natural-pixel-sized) wrapper down/up so the whole image
    // fits inside its container, and derives a per-image zoom floor/step
    // from that fit size. Called once the image's natural dimensions are
    // known, and again whenever "Zoom to Fit" is clicked or (while
    // isAtDefaultFit is true) the container resizes.
    fitToContainer() {
        if (!this.wrapper || !this.wrapper.parentElement || !this.naturalWidth || !this.naturalHeight) {
            return null;
        }
        const rect = this.wrapper.parentElement.getBoundingClientRect();
        if (!rect.width || !rect.height) return null;

        const fitScale = Math.min(1.0, rect.width / this.naturalWidth, rect.height / this.naturalHeight);
        this.minZoom = fitScale * 0.25;
        this.zoomStep = fitScale * 0.15;
        this.scale = fitScale;
        this.translateX = 0;
        this.translateY = 0;
        this.isAtDefaultFit = true;
        this.apply();
        return fitScale;
    }

    zoom(delta, clientX = null, clientY = null) {
        const oldScale = this.scale;
        this.scale = Math.max(this.minZoom, Math.min(WORKSPACE_CONFIG.MAX_ZOOM, this.scale + delta));
        this.isAtDefaultFit = false;

        if (clientX !== null && clientY !== null && this.wrapper) {
            const rect = this.wrapper.parentElement.getBoundingClientRect();
            const mouseX = clientX - rect.left - rect.width / 2;
            const mouseY = clientY - rect.top - rect.height / 2;
            const ratio = this.scale / oldScale;
            this.translateX = mouseX - (mouseX - this.translateX) * ratio;
            this.translateY = mouseY - (mouseY - this.translateY) * ratio;
        } else if (this.scale === 1.0) {
            this.translateX = 0;
            this.translateY = 0;
        }
        this.apply();
    }

    setZoom(scale) {
        this.scale = Math.max(this.minZoom, Math.min(WORKSPACE_CONFIG.MAX_ZOOM, scale));
        this.isAtDefaultFit = false;
        this.apply();
    }

    setFilters(brightness, contrast, saturation) {
        // Keeps the existing channel filter (if any) — brightness/contrast/
        // gamma and the Filters submenu's grayscale channel are independent
        // knobs, so adjusting one shouldn't silently clear the other.
        this.filters.brightness = brightness;
        this.filters.contrast = contrast;
        this.filters.saturation = saturation;
        this.applyFilters();
    }

    // 'none' | 'red' | 'green' | 'blue' — see the matching #grayscaleChannel-*
    // SVG filters' HTML comment for why this needs an SVG feColorMatrix
    // rather than a plain CSS filter function.
    setChannelFilter(channel) {
        this.filters.channel = channel;
        this.applyFilters();
    }

    applyFilters() {
        if (!this.video) return;
        const { brightness, contrast, saturation, channel } = this.filters;
        let filterStr = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
        if (channel && channel !== 'none') {
            filterStr += ` url(#grayscaleChannel-${channel})`;
        }
        this.video.style.filter = filterStr;
    }

    setPixelated(enabled) {
        this.isPixelated = enabled;
        if (!this.video) return;
        if (enabled) {
            this.video.style.setProperty('image-rendering', 'pixelated', 'important');
        } else {
            this.video.style.removeProperty('image-rendering');
        }
    }

    /**
     * Set rotation — additive adds to current, otherwise sets absolute.
     * After rotating, syncs the slider + input UI.
     */
    rotate(degrees, additive = false) {
        if (additive) {
            this.displayRotation = (this.displayRotation + degrees) % 360;
        } else {
            this.displayRotation = degrees % 360;
        }
        // Keep normalized 0-359
        this.rotation = ((this.displayRotation % 360) + 360) % 360;
        this.apply();
        this._syncRotateUI();
    }

    /** Sync the slider and input to current rotation value */
    _syncRotateUI() {
        const val = Math.round(this.rotation);
        const slider = document.getElementById('customRotateSlider');
        const input = document.getElementById('customRotateInput');
        if (slider) {
            slider.value = val;
            _updateSliderFill(slider);
        }
        if (input) input.value = val;
        
        // Also update highlight for quick rotate options if exact match
        document.querySelectorAll('.rotate-opt').forEach(opt => {
            const deg = parseInt(opt.dataset.deg, 10);
            if (deg === val) opt.classList.add('active-opt');
            else opt.classList.remove('active-opt');
        });
    }

    startPan(clientX, clientY) {
        this.cancelPendingTransition();
        this.isPanning = true;
        this.startX = clientX - this.translateX;
        this.startY = clientY - this.translateY;
    }

    pan(clientX, clientY) {
        if (!this.isPanning) return;
        this.translateX = clientX - this.startX;
        this.translateY = clientY - this.startY;
        this.isAtDefaultFit = false;
        this.apply();
    }

    endPan() { this.isPanning = false; }

    reset() {
        this.rotation = 0;
        this.displayRotation = 0;
        // fitToContainer() sets scale/translateX/translateY/isAtDefaultFit
        // itself; if natural dimensions aren't known yet (image still
        // loading), fall back to the old static default rather than
        // leaving scale untouched.
        if (!this.fitToContainer()) {
            this.scale = 0.9;
            this.translateX = 0;
            this.translateY = 0;
            this.isAtDefaultFit = true;
            this.apply();
        }
        this._syncRotateUI();
    }

    // Wraps a single discrete transform change (a button click, not a
    // continuous wheel/drag gesture) in a short CSS transition so it snaps
    // smoothly instead of jumping. Continuous interactions must NEVER go
    // through this: a fresh wheel-zoom or pan mousemove arrives well inside
    // the transition's own duration, so the browser keeps retargeting an
    // in-flight animation towards a new endpoint every few ms — the visible
    // result is exactly the laggy "buffering" stutter this was meant to fix,
    // not smoothness. Kept as instant-by-default (no base CSS transition on
    // the wrapper) and only opted into here, per discrete action.
    animateOnce(fn) {
        if (this.wrapper) this.wrapper.classList.add('viewport-transition');
        fn();
        clearTimeout(this._transitionClearTimer);
        this._transitionClearTimer = setTimeout(() => {
            if (this.wrapper) this.wrapper.classList.remove('viewport-transition');
        }, 200);
    }

    // A continuous gesture (wheel-zoom, drag-pan) starting while a discrete
    // button click's transition (see animateOnce() above) is still pending
    // removal would otherwise get captured by that same CSS transition
    // instead of snapping instantly — the browser keeps retargeting the
    // in-flight animation towards each new wheel notch's endpoint, so the
    // first notch or two visibly lag before catching up, reading as "one
    // scroll did nothing, needed a second." Called at the START of every
    // continuous-gesture entry point (never from zoom()/rotate() themselves,
    // which animateOnce()'s button handlers rely on keeping the class for).
    cancelPendingTransition() {
        clearTimeout(this._transitionClearTimer);
        if (this.wrapper) this.wrapper.classList.remove('viewport-transition');
    }

    apply() {
        if (!this.wrapper) return;
        this.wrapper.style.transform =
            `translate(${this.translateX}px, ${this.translateY}px) scale(${this.scale}) rotate(${this.displayRotation}deg)`;

        // Re-render annotations so that text labels scale inversely and stay
        // constant physical size. apply() can fire many times per second
        // during a scroll-wheel zoom burst or a drag-pan — rebuilding the
        // entire SVG tree (every shape, hover outline, and tag) on EACH of
        // those calls is what caused the visible stutter/flicker. Coalesce
        // into at most one rebuild per animation frame instead.
        //
        // NOTE: the bootstrap code at the bottom of this file sets
        // `window.Workspace` (capital W) — `window.workspace` here was
        // always undefined, so this whole re-render-on-zoom path has been a
        // silent no-op. Left unnoticed because most call sites that touch
        // annotations already call renderAllAnnotations() directly anyway;
        // the one case it actually mattered for — tags/hover-outlines
        // re-scaling after a PURE zoom with no other action — quietly never
        // worked. Fixed now since it directly backs the scale-compensation
        // this file relies on for tags (addTextAndHover) and the live
        // drawing preview (renderCurrentPolygon) to stay a constant screen
        // size.
        if (window.Workspace && window.Workspace.ui) {
            // Cheap style-only write — safe to run synchronously on every
            // apply() (unlike the full annotation rebuild below) so the
            // brush cursor ring's size never lags a frame behind the zoom.
            window.Workspace.ui.refreshBrushCursorSize();

            if (this._renderRAF) cancelAnimationFrame(this._renderRAF);
            this._renderRAF = requestAnimationFrame(() => {
                this._renderRAF = null;
                window.Workspace.ui.renderAllAnnotations();
            });
        }
    }
}

/* -------------------------------------------------------
   Utility: update the linear-gradient fill of a range slider
   so the filled portion is purple and the rest is gray.
   ------------------------------------------------------- */
function _updateSliderFill(slider) {
    const min = parseFloat(slider.min) || 0;
    const max = parseFloat(slider.max) || 359;
    const val = parseFloat(slider.value) || 0;
    const pct = ((val - min) / (max - min)) * 100;
    slider.style.background =
        `linear-gradient(to right, #5f45ff ${pct}%, #e5e7eb ${pct}%)`;
}

class UIManager {
    constructor(workspace) {
        this.workspace = workspace;
        this.activeMenuId = null;
        this.annotations = [];
        this.selectedAnnotationId = null;
        // Drag-marquee multi-select — a separate set alongside
        // selectedAnnotationId (which stays the single "edit mode" shape).
        // See handleCanvasMouseDown/Move/Up for the drag box itself and
        // deleteMultiSelected() for the batch-delete keyboard shortcut.
        this.multiSelectedIds = new Set();
        this._marqueeStart = null;
        this._marqueeMoved = false;
        this._marqueeRectValue = null;
        // Dragging the whole multi-selection together — see
        // moveGroupBy()/finalizeGroupMove().
        this._groupMoving = false;
        this._groupMoveStartX = 0;
        this._groupMoveStartY = 0;
        this.instanceCounters = {};
        this.freehandPolygonMode = false;
        this.isClassGrouped = WORKSPACE_CONFIG.CLASSES_GROUPED_BY_DEFAULT;
        this.isLabelGrouped = WORKSPACE_CONFIG.LABELS_GROUPED_BY_DEFAULT;

        // --- Settings drawer > Label display (see setLabelDisplaySetting(),
        // called from the drawer's own slider script in the .html file) ---
        this.objectFillOpacity = WORKSPACE_CONFIG.DEFAULT_OBJECT_FILL_OPACITY;
        this.selectedObjectFillOpacity = WORKSPACE_CONFIG.DEFAULT_SELECTED_OBJECT_FILL_OPACITY;
        this.objectLabelFontSize = WORKSPACE_CONFIG.DEFAULT_OBJECT_LABEL_FONT_SIZE;
        // "By class" (every instance of a class shares its class color) or
        // "By object" (every instance gets its own unique color instead) —
        // see getEffectiveColor()/renderAnnotationStencil(). Persisted like
        // collapsedGroups below, so it survives a reopen of the editor.
        this.labelColorMode = sessionStorage.getItem('labelColorMode') || WORKSPACE_CONFIG.DEFAULT_LABEL_COLOR_MODE;
        // Running counter behind each new annotation's own objectColor —
        // golden-angle hue stepping (see finishPolygon()) so consecutive
        // objects land far apart on the color wheel instead of drifting
        // through neighboring hues.
        this._objectColorCounter = 0;
        // --- Settings drawer > General ---
        this.invertWheelZoom = WORKSPACE_CONFIG.DEFAULT_INVERT_WHEEL_ZOOM; // Invert mouse wheel zoom direction toggle

        // --- Pixel/raster brush state (see stampBrush/renderBrushLayer) ---
        this.currentMaskCanvas = null;   // in-progress raster for a brand-new brush annotation
        this.lastPaintPos = null;
        this._editingMaskAnnoId = null;  // set while painting directly into an existing selected annotation
        this._liveMoveOffsetX = 0;
        this._liveMoveOffsetY = 0;
        this.hoveredBrushAnnoId = null;
        // Polygon hover reuses the exact same raster hover-rim mechanism as
        // brush (see drawHoverRim()/renderBrushLayer()) instead of an SVG
        // stroke — an SVG stroke anti-aliases into a soft/blurry line under
        // this app's CSS-transform zoom, while the rim is drawn onto
        // #brushMaskCanvas with imageSmoothingEnabled off, staying crisp at
        // any zoom exactly like the brush's own hover rim.
        this.hoveredPolygonAnnoId = null;
        this._brushStampCache = null;
        this._rimScratch = null;

        this.initHistory();
        this.setupEventListeners();
    }

    // Same open-inbox illustration + message old-ref's InstructionListRenderer
    // uses for "No classifications or objects" — reused here for both the
    // Classes and Labels panels' own empty states (a genuinely empty list,
    // or a search with zero matches). `id`/`hidden` are optional: pass them
    // when the caller needs to toggle this element later (a search-empty
    // state that starts hidden and gets shown once a filter matches
    // nothing); omit them for a one-shot replacement of a list's contents
    // (the baseline "there's nothing here at all" case).
    _emptyStateHTML(message, id, hidden) {
        return `
            <div ${id ? `id="${id}"` : ''} class="${hidden ? 'hidden ' : ''}flex flex-col items-center justify-center pt-10">
                <svg width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg">
                    <title>Simple Empty</title>
                    <g transform="translate(0 1)" fill="none" fill-rule="evenodd">
                        <ellipse fill="#f5f5f5" cx="32" cy="33" rx="32" ry="7"></ellipse>
                        <g fill-rule="nonzero" stroke="#d9d9d9">
                            <path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path>
                            <path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" fill="#fafafa"></path>
                        </g>
                    </g>
                </svg>
                <div class="mt-4 text-[#bfbfbf] text-[14px]">${message}</div>
            </div>`;
    }

    // Lightweight, non-blocking notification — replaces alert(), which
    // stops the whole page (and every other tab if the browser blocks
    // subsequent alerts) just to say "pick a class first."
    showToast(message, duration = 2500) {
        let toast = document.getElementById('appToast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'appToast';
            toast.style.position = 'fixed';
            toast.style.bottom = '28px';
            toast.style.left = '50%';
            toast.style.background = '#1f1f1f';
            toast.style.color = '#fff';
            toast.style.padding = '10px 18px';
            toast.style.borderRadius = '8px';
            toast.style.fontSize = '13px';
            toast.style.fontFamily = 'Inter, system-ui, sans-serif';
            toast.style.boxShadow = '0 10px 25px rgba(0,0,0,0.25)';
            toast.style.zIndex = '99999';
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
            toast.style.pointerEvents = 'none';
            document.body.appendChild(toast);
        }
        toast.style.transform = 'translateX(-50%) translateY(10px)';
        toast.textContent = message;

        clearTimeout(this._toastHideTimer);
        requestAnimationFrame(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(-50%) translateY(0)';
        });
        this._toastHideTimer = setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(-50%) translateY(10px)';
        }, duration);
    }

    setupEventListeners() {
        this.bindExtraToggles();
        this.bindCrosshairEvents();
        this.bindCanvasEvents();

        // Menu buttons
        this._setupFilterMenu();
        this._bindMenuBtn('rotateDropdownBtn', 'rotateMenu');
        this._bindMenuBtn('rotateActionBtn', 'customRotateMenu');
        this._bindMenuBtn('currentSpeedBtn', 'speedMenu');

        // Rotate quick options (45°, 90°, 180°) — absolute rotation for highlight matching
        document.querySelectorAll('.rotate-opt').forEach(opt => {
            opt.addEventListener('click', (e) => {
                e.stopPropagation();
                const deg = parseInt(opt.dataset.deg, 10);
                if (!isNaN(deg)) this.workspace.transform.animateOnce(() => this.workspace.transform.rotate(deg, false));
                this.closeAllMenus();
            });
        });

        // Zoom tools — single-click, discrete jumps, so a brief eased
        // transition (see animateOnce) reads as smooth rather than glitchy.
        // Step is a percentage of the CURRENT scale (matching the wheel
        // handler in WorkspaceManager.bindEvents()), not the fixed
        // this.transform.zoomStep — otherwise repeated clicks at a high
        // zoom level barely move the view at all.
        document.getElementById('zoomIn')?.addEventListener('click', () =>
            this.workspace.transform.animateOnce(() => this.workspace.transform.zoom(this.workspace.transform.scale * WORKSPACE_CONFIG.ZOOM_WHEEL_PERCENT)));
        document.getElementById('zoomOut')?.addEventListener('click', () =>
            this.workspace.transform.animateOnce(() => this.workspace.transform.zoom(-this.workspace.transform.scale * WORKSPACE_CONFIG.ZOOM_WHEEL_PERCENT)));
        document.getElementById('zoomFit')?.addEventListener('click', () =>
            this.workspace.transform.animateOnce(() => this.workspace.transform.reset()));

        // Custom Rotation Slider
        const rotateSlider = document.getElementById('customRotateSlider');
        const rotateInput  = document.getElementById('customRotateInput');
        if (rotateSlider && rotateInput) {
            rotateSlider.addEventListener('input', (e) => {
                const v = parseInt(e.target.value, 10);
                rotateInput.value = v;
                _updateSliderFill(rotateSlider);
                this.workspace.transform.rotate(v, false);
            });
            rotateInput.addEventListener('input', (e) => {
                let v = parseInt(e.target.value, 10);
                if (isNaN(v)) v = 0;
                v = Math.max(0, Math.min(359, v));
                rotateSlider.value = v;
                _updateSliderFill(rotateSlider);
                this.workspace.transform.rotate(v, false);
            });
            // Initialize fill on load
            _updateSliderFill(rotateSlider);
        }

        // Rotate Reset Button (triangle icon inside customRotateMenu)
        const resetBtn = document.getElementById('customRotateResetBtn');
        if (resetBtn) {
            resetBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.workspace.transform.reset(); // resets rotation, zoom, translation
            });
        }

        // Rotate Increment / Decrement arrow buttons
        const incBtn = document.getElementById('rotateIncrementBtn');
        const decBtn = document.getElementById('rotateDecrementBtn');
        if (incBtn) {
            incBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const input = document.getElementById('customRotateInput');
                let v = parseInt(input?.value || '0', 10);
                v = ((v + 1) + 360) % 360;
                if (input) input.value = v;
                const slider = document.getElementById('customRotateSlider');
                if (slider) { slider.value = v; _updateSliderFill(slider); }
                this.workspace.transform.rotate(v, false);
            });
        }
        if (decBtn) {
            decBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const input = document.getElementById('customRotateInput');
                let v = parseInt(input?.value || '0', 10);
                v = ((v - 1) + 360) % 360;
                if (input) input.value = v;
                const slider = document.getElementById('customRotateSlider');
                if (slider) { slider.value = v; _updateSliderFill(slider); }
                this.workspace.transform.rotate(v, false);
            });
        }

        // Speed Menu
        const speedMenu = document.getElementById('speedMenu');
        if (speedMenu) {
            speedMenu.innerHTML = '';
            WORKSPACE_CONFIG.DEFAULT_SPEEDS.forEach(speed => {
                const opt = document.createElement('div');
                opt.className = 'px-3 py-1.5 text-[13px] hover:bg-gray-50 cursor-pointer rounded speed-opt text-center';
                opt.innerText = speed + 'x';
                opt.dataset.speed = speed;
                opt.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.workspace.videoCtrl.playbackRate = speed;
                    const btn = document.getElementById('currentSpeedBtn');
                    if (btn) btn.innerText = speed + 'x';
                    this._updateActiveOption('speed-opt', speed.toString());
                    this.closeAllMenus();
                });
                speedMenu.appendChild(opt);
            });
            this._updateActiveOption('speed-opt', WORKSPACE_CONFIG.DEFAULT_SPEED.toString());
        }

        // Play Controls
        document.getElementById('btnPlayPause')?.addEventListener('click', () =>
            this.workspace.videoCtrl.togglePlay());
        document.getElementById('btnStart')?.addEventListener('click', () =>
            this.workspace.videoCtrl.stepFrames(-1));
        document.getElementById('btnNext')?.addEventListener('click', () =>
            this.workspace.videoCtrl.stepFrames(1));

        // Settings sub-menus
        this._bindSettingsSubMenus();
    }

    _setupFilterMenu() {
        this._bindMenuBtn('filterBtn', 'filterMenu');

        const sliders = {
            brightRange: document.getElementById('brightRange'),
            contrastRange: document.getElementById('contrastRange'),
            gammaRange: document.getElementById('gammaRange'),
        };

        const applySliders = () => {
            const b = sliders.brightRange ? parseInt(sliders.brightRange.value, 10) : 100;
            const c = sliders.contrastRange ? parseInt(sliders.contrastRange.value, 10) : 100;
            const s = sliders.gammaRange ? parseInt(sliders.gammaRange.value, 10) : 100;
            this.workspace.transform.setFilters(b, c, s);
            Object.values(sliders).forEach(el => el && _updateSliderFill(el));
        };

        Object.values(sliders).forEach(el => {
            if (!el) return;
            el.addEventListener('input', applySliders);
            _updateSliderFill(el);
        });

        const pixelToggle = document.getElementById('pixelatedToggle');
        if (pixelToggle) {
            pixelToggle.addEventListener('change', (e) => {
                this.workspace.transform.setPixelated(e.target.checked);
            });
        }

        const subTrigger = document.getElementById('filterSubTrigger');
        const subMenu = document.getElementById('filterSubMenu');
        const filterMenuEl = document.getElementById('filterMenu');
        
        if (subTrigger && subMenu) {
            const showSub = () => { subMenu.classList.remove('hidden'); subMenu.classList.add('flex', 'flex-col'); };
            const hideSub = (e) => {
                if (!subMenu.contains(e?.relatedTarget) && !subTrigger.contains(e?.relatedTarget)) {
                    subMenu.classList.add('hidden');
                    subMenu.classList.remove('flex', 'flex-col');
                }
            };
            subTrigger.addEventListener('mouseenter', showSub);
            subTrigger.addEventListener('mouseleave', hideSub);
            subMenu.addEventListener('mouseleave', hideSub);
            subTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                const isHidden = subMenu.classList.contains('hidden');
                if (isHidden) showSub();
                else {
                    subMenu.classList.add('hidden');
                    subMenu.classList.remove('flex', 'flex-col');
                }
            });
            filterMenuEl?.querySelector('.p-4')?.addEventListener('mouseenter', () => { 
                subMenu.classList.add('hidden');
                subMenu.classList.remove('flex', 'flex-col'); 
            });
        }
        document.querySelectorAll('.filter-opt').forEach(opt => {
            opt.addEventListener('click', (e) => {
                e.stopPropagation();
                this._applyFilterPreset(opt.dataset.filter);
                // Stays open after picking an option — closing it here (as
                // this used to) meant trying a second grayscale channel
                // required reopening both the filter menu and its Filters
                // submenu from scratch instead of just clicking the next
                // option. The checkmark still moves to whichever option is
                // now active (see _applyFilterPreset()), so it's clear
                // which one is picked without the menu needing to close.
            });
        });
    }

    // filterType is 'none' | 'red' | 'green' | 'blue' (see the .filter-opt
    // data-filter attributes). Each grayscale option isolates that one
    // channel into gray via an SVG feColorMatrix (setChannelFilter()) —
    // plain saturate(0%) can't distinguish between them, which is why
    // picking Red/Green/Blue used to all look identical.
    _applyFilterPreset(filterType) {
        document.querySelectorAll('.filter-opt').forEach(opt => {
            const check = opt.querySelector('.check-mark');
            if (check) check.classList.toggle('hidden', opt.dataset.filter !== filterType);
        });
        const gammaRange = document.getElementById('gammaRange');
        const s = gammaRange ? parseInt(gammaRange.value, 10) : 100;
        this.workspace.transform.setFilters(
            parseInt(document.getElementById('brightRange')?.value || 100, 10),
            parseInt(document.getElementById('contrastRange')?.value || 100, 10),
            s
        );
        this.workspace.transform.setChannelFilter(filterType);
    }

    _updateActiveOption(className, value) {
        document.querySelectorAll('.' + className).forEach(el => {
            // Using dataset attribute matching what we assigned
            if (el.dataset.val === value || el.dataset.speed === value) {
                el.classList.add('active-opt');
            } else {
                el.classList.remove('active-opt');
            }
        });
    }

    /**
     * Menu button binding — stops propagation, closes other menus first.
     */
    _bindMenuBtn(btnId, menuId) {
        const btn  = document.getElementById(btnId);
        const menu = document.getElementById(menuId);
        if (!btn || !menu) return;

        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = !menu.classList.contains('hidden');
            this.closeAllMenus();
            if (!isOpen) {
                menu.classList.remove('hidden');
                this.activeMenuId = menuId;
            }
        });

        // Prevent clicks inside menu from bubbling to document
        menu.addEventListener('click', (e) => e.stopPropagation());
    }

    /**
     * Settings menu sub-menus:
     */
    _bindSettingsSubMenus() {
        // ---- Timestamp Format SubMenu ----
        const tsTrigger = document.getElementById('timestampFormatTrigger');
        const tsSubMenu = document.getElementById('timestampFormatSubMenu');

        if (tsTrigger && tsSubMenu) {
            const formats = ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'];
            if (tsSubMenu.children.length === 0) {
                formats.forEach(fmt => {
                    const item = document.createElement('div');
                    item.className = 'ts-opt';
                    item.dataset.val = fmt;
                    item.style.cssText = 'padding:6px 12px;font-size:13px;cursor:pointer;border-radius:4px;color:#374151;white-space:nowrap;';
                    item.innerText = fmt;
                    item.addEventListener('mouseover', () => item.style.background = '#f9fafb');
                    item.addEventListener('mouseout',  () => item.style.background = '');
                    item.addEventListener('mousedown', (e) => {
                        e.stopPropagation();
                        this.workspace.timestampFormat = fmt;
                        document.getElementById('checkmark-timestamps')?.classList.remove('hidden');
                        this._updateActiveOption('ts-opt', fmt);
                        this.workspace.updateWorkspaceUI(); // Force update display
                        this._hideSubMenus();
                        this.closeAllMenus();
                    });
                    tsSubMenu.appendChild(item);
                });
            }
            this._updateActiveOption('ts-opt', 'Frames');

            const showTS = () => {
                this._hideSubMenus();
                tsSubMenu.style.display = 'flex';
                tsSubMenu.style.flexDirection = 'column';
            };
            const hideTS = (e) => {
                if (!tsSubMenu.contains(e?.relatedTarget) && !tsTrigger.contains(e?.relatedTarget)) {
                    tsSubMenu.style.display = 'none';
                }
            };

            tsTrigger.addEventListener('mouseenter', showTS);
            tsTrigger.addEventListener('mouseleave', hideTS);
            tsSubMenu.addEventListener('mouseleave', hideTS);
            tsTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                tsSubMenu.style.display === 'flex' ? tsSubMenu.style.display = 'none' : showTS();
            });
        }

        // ---- Frame Skip SubMenu & Pill Options ----
        const fsTrigger = document.getElementById('frameSkipTrigger');
        const fsSubMenu = document.getElementById('frameSkipSubMenu');
        const fsContainer = document.getElementById('frameSkipOptionsContainer');

        if (fsTrigger && fsSubMenu) {
            const vals = [1, 2, 5, 10, 30, 60];
            
            // Function to sync frame skip value across UI
            const setFrameSkip = (val, e) => {
                if (e) e.stopPropagation();
                if (this.workspace.videoCtrl) {
                    this.workspace.videoCtrl.frameSkipValue = val;
                }
                const pillDisplay = document.getElementById('currentFrameSkipDisplay');
                if (pillDisplay) pillDisplay.innerText = val;
                this._updateActiveOption('fs-opt', val.toString());
                this._hideSubMenus();
                this.closeAllMenus();
            };

            // 1. Populate Settings Menu
            if (fsSubMenu.children.length === 0) {
                vals.forEach(val => {
                    const item = document.createElement('div');
                    item.className = 'fs-opt';
                    item.dataset.val = val.toString();
                    item.style.cssText = 'padding:6px 0;font-size:13px;cursor:pointer;border-radius:4px;color:#374151;text-align:center;';
                    item.innerText = val;
                    item.addEventListener('mouseover', () => item.style.background = '#f9fafb');
                    item.addEventListener('mouseout',  () => item.style.background = '');
                    item.addEventListener('mousedown', (e) => setFrameSkip(val, e));
                    fsSubMenu.appendChild(item);
                });
            }

            // 2. Populate Pill Dropdown Options (if empty)
            if (fsContainer && fsContainer.children.length === 0) {
                vals.forEach(val => {
                    const item = document.createElement('button');
                    item.type = 'button';
                    // We use the same fs-opt class to keep highlighting synchronized
                    item.className = 'fs-opt w-full text-left px-3 py-1.5 text-[13px] hover:bg-gray-50 text-gray-700 transition-colors flex items-center justify-center';
                    item.dataset.val = val.toString();
                    item.innerText = val;
                    item.addEventListener('click', (e) => setFrameSkip(val, e));
                    fsContainer.appendChild(item);
                });
            }
            
            this._updateActiveOption('fs-opt', '1');

            const showFS = () => {
                this._hideSubMenus();
                fsSubMenu.style.display = 'flex';
                fsSubMenu.style.flexDirection = 'column';
            };
            const hideFS = (e) => {
                if (!fsSubMenu.contains(e?.relatedTarget) && !fsTrigger.contains(e?.relatedTarget)) {
                    fsSubMenu.style.display = 'none';
                }
            };

            fsTrigger.addEventListener('mouseenter', showFS);
            fsTrigger.addEventListener('mouseleave', hideFS);
            fsSubMenu.addEventListener('mouseleave', hideFS);
            fsTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                fsSubMenu.style.display === 'flex' ? fsSubMenu.style.display = 'none' : showFS();
            });
        }

        // ---- Show frame skip selector toggle ----
        const skipRow = document.getElementById('toggle-skipselector-row');
        if (skipRow) {
            skipRow.addEventListener('click', (e) => {
                e.stopPropagation();
                const pill = document.getElementById('frameSkipSelectorPill');
                const ck   = document.getElementById('checkmark-skipselector');
                if (pill) {
                    const visible = !pill.classList.contains('hidden');
                    pill.classList.toggle('hidden', visible);
                    ck?.classList.toggle('hidden', visible);
                }
                this.closeAllMenus();
            });
        }

        // Prevent clicks inside settings menu from closing it
        document.getElementById('settingsMenu')?.addEventListener('click', e => e.stopPropagation());
    }

    _hideSubMenus() {
        const ts = document.getElementById('timestampFormatSubMenu');
        const fs = document.getElementById('frameSkipSubMenu');
        if (ts) ts.style.display = 'none';
        if (fs) fs.style.display = 'none';
    }

    closeAllMenus() {
        ['filterMenu','rotateMenu','customRotateMenu','speedMenu',
         'frameSkipSelectorMenu','moreNavMenu','settingsMenu'].forEach(id => {
            const m = document.getElementById(id);
            if (m) { m.classList.add('hidden'); m.style.display = ''; }
        });
        this._hideSubMenus();
        this.activeMenuId = null;
    }

    // Extra bindings
    bindExtraToggles() {
        const btnVolume = document.getElementById('btnVolume');
        if (btnVolume) {
            btnVolume.addEventListener('click', () => {
                const video = this.workspace.videoCtrl.video;
                video.muted = !video.muted;
                btnVolume.innerHTML = video.muted
                    ? `<svg stroke="currentColor" fill="currentColor" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M16 9a5 5 0 0 1 .95 2.293"></path><path d="M19.364 5.636a9 9 0 0 1 1.889 9.96"></path><path d="m2 2 20 20"></path><path d="m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11"></path><path d="M9.828 4.172A.686.686 0 0 1 11 4.657v.686"></path></svg>`
                    : `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="translate-y-px transform" height="16" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"></path><path d="M16 9a5 5 0 0 1 0 6"></path><path d="M19.364 18.364a9 9 0 0 0 0-12.728"></path></svg>`;
            });
        }
        const btnSync = document.getElementById('btnSync');
        if (btnSync) {
            btnSync.addEventListener('click', (e) => {
                e.stopPropagation();
                btnSync.classList.toggle('text-brand-blue');
            });
        }
    }

    // Legacy
    bindToggle(btnId, menuId) { this._bindMenuBtn(btnId, menuId); }

    // Stub methods for HTML inline onclick handlers
    toggleFilterMenu() { document.getElementById('filterMenu')?.classList.toggle('hidden'); }
    toggleMoreNavMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('moreNavMenu');
        const btn  = document.getElementById('moreNavBtn');
        if (!menu || !btn) return;
        const isVisible = !menu.classList.contains('hidden');
        this.closeAllMenus();
        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display = 'flex';
            const rect = btn.getBoundingClientRect();
            menu.style.visibility = 'hidden';
            const mh = menu.offsetHeight;
            menu.style.visibility = 'visible';
            const offset = 10;
            if (window.innerHeight - rect.bottom > mh + offset + 20) {
                menu.style.top    = (rect.bottom + offset) + 'px';
                menu.style.bottom = 'auto';
            } else {
                menu.style.top    = 'auto';
                menu.style.bottom = (window.innerHeight - rect.top + offset) + 'px';
            }
            menu.style.left = rect.left + 'px';
        }
    }
    toggleFrameSkipSelectorMenu(e) {
        if (e) e.stopPropagation();
        document.getElementById('frameSkipSelectorMenu')?.classList.toggle('hidden');
    }
    toggleSettingsMenu(e) {
        if (e) e.stopPropagation();
        const menu = document.getElementById('settingsMenu');
        const btn  = document.getElementById('settingsBtn');
        if (!menu || !btn) return;
        const isVisible = !menu.classList.contains('hidden');
        this.closeAllMenus();
        if (!isVisible) {
            menu.classList.remove('hidden');
            menu.style.display       = 'flex';
            menu.style.flexDirection = 'column';
            const rect = btn.getBoundingClientRect();
            menu.style.position = 'fixed';
            menu.style.bottom   = (window.innerHeight - rect.top + 10) + 'px';
            menu.style.right    = '10px';
            menu.style.top      = 'auto';
            menu.style.left     = 'auto';
            menu.style.zIndex   = '999999';
        }
    }
    setThisFrame()       { /* Stub */ }
    saveThisFrame()      { /* Stub */ }
    setStartToCurrent()  { /* Stub */ }
    setEndToCurrent()    { /* Stub */ }
    addNewRange()        { /* Stub */ }
    saveAnnotation(e)    { /* Stub */ }
    addCustomFrameSkip(e){ /* Stub */ }

    toggleClassGrouping() {
        this.isClassGrouped = !this.isClassGrouped;
        const btn = document.getElementById('btnGroupClasses');
        if (btn) {
            if (this.isClassGrouped) {
                btn.className = "premium-icon-btn w-6 h-6 bg-[#f4ebff] text-[#7f56d9]";
            } else {
                btn.className = "premium-icon-btn w-6 h-6 text-gray-500 hover:text-gray-700";
            }
        }
        this.renderClassList();
    }

    toggleLabelGrouping() {
        this.isLabelGrouped = !this.isLabelGrouped;
        const btn = document.getElementById('btnGroupLabels');
        if (btn) {
            if (this.isLabelGrouped) {
                btn.className = "label-premium-icon-btn flex items-center justify-center bg-[#f4ebff] text-[#7f56d9]";
            } else {
                btn.className = "label-premium-icon-btn flex items-center justify-center text-gray-500 hover:text-gray-700";
            }
        }
        this.updateLabelsPanel();
    }

    toggleTagAll() {
        const anyUntagged = this.annotations.some(a => !a.tagged);
        this.annotations.forEach(a => a.tagged = anyUntagged);
        this.updateLabelsPanel();
        this.renderAllAnnotations();
    }

    toggleLockAll() {}

    renderClassList() {
        const container = document.getElementById('classListContainer');
        if (!container) return;

        let i = 1;
        const getShortcut = (index) => {
            if (index <= 9) return index.toString();
            if (index === 10) return '0';
            return String.fromCharCode(97 + index - 11).toUpperCase();
        };

        const MINUS_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;
        const PLUS_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor" style="transform: rotate(-90deg);"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;
        
        const FOLDER_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M640.6 429.8h257.1c7.9 0 14.3-6.4 14.3-14.3V158.3c0-7.9-6.4-14.3-14.3-14.3H640.6c-7.9 0-14.3 6.4-14.3 14.3v92.9H490.6c-3.9 0-7.1 3.2-7.1 7.1v221.5h-85.7v-96.5c0-7.9-6.4-14.3-14.3-14.3H126.3c-7.9 0-14.3 6.4-14.3 14.3v257.2c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3V544h85.7v221.5c0 3.9 3.2 7.1 7.1 7.1h135.7v92.9c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3v-257c0-7.9-6.4-14.3-14.3-14.3h-257c-7.9 0-14.3 6.4-14.3 14.3v100h-78.6v-393h78.6v100c0 7.9 6.4 14.3 14.3 14.3zm53.5-217.9h150V362h-150V211.9zM329.9 587h-150V437h150v150zm364.2 75.1h150v150.1h-150V662.1z"></path></svg>`;
        const ITEM_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="appstore-add" width="1em" height="1em" fill="currentColor" aria-hidden="true" style="transform: rotate(270deg);"><path d="M464 144H160c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H212V212h200v200zm452-268H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H612V212h200v200zm52 132H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V560c0-8.8-7.2-16-16-16zm-52 268H612V612h200v200zM424 712H296V584c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v128H104c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h128v128c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V776h128c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8z"></path></svg>`;
        // Two not-yet-implemented per-class quick actions (AI-assisted
        // labeling / auto-segmentation) — placeholders only for now, hence
        // the "Coming soon" tooltip and toast instead of a real onclick
        // action. Grouped with the hotkey badge in one right-hand flex
        // container (not spread across the row via justify-between) so
        // they sit close together the way the reference mockup shows.
        const CLASS_ROW_SPARKLES_SVG = `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path d="M16 18a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2zm0 -12a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2zm-7 12a6 6 0 0 1 6 -6a6 6 0 0 1 -6 -6a6 6 0 0 1 -6 6a6 6 0 0 1 6 6z"></path></svg>`;
        const CLASS_ROW_AUTOSEG_SVG = `<svg stroke="currentColor" fill="currentColor" stroke-width="0" version="1.1" viewBox="0 0 16 16" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path d="M4 3l-2-2h-1v1l2 2zM5 0h1v2h-1zM9 5h2v1h-2zM10 2v-1h-1l-2 2 1 1zM0 5h2v1h-2zM5 9h1v2h-1zM1 9v1h1l2-2-1-1zM15.781 13.781l-9.939-9.939c-0.292-0.292-0.769-0.292-1.061 0l-0.939 0.939c-0.292 0.292-0.292 0.769 0 1.061l9.939 9.939c0.292 0.292 0.769 0.292 1.061 0l0.939-0.939c0.292-0.292 0.292-0.769 0-1.061zM7.5 8.5l-3-3 1-1 3 3-1 1z"></path></svg>`;
        // See SHOW_CLASS_ROW_QUICK_ACTIONS at the top of the file — flip
        // that one flag to bring these back; everything below already
        // works, it's just skipped while the flag is false.
        const classRowQuickActions = !SHOW_CLASS_ROW_QUICK_ACTIONS ? '' : `
            <div class="flex items-center gap-2 text-gray-400">
                <span class="cursor-pointer hover:text-gray-600" data-tooltip="Coming soon" data-tooltip-pos="top"
                    onclick="event.stopPropagation(); window.app.showToast('Coming soon');">${CLASS_ROW_SPARKLES_SVG}</span>
                <span class="cursor-pointer hover:text-gray-600" data-tooltip="Coming soon" data-tooltip-pos="top"
                    onclick="event.stopPropagation(); window.app.showToast('Coming soon');">${CLASS_ROW_AUTOSEG_SVG}</span>
            </div>`;

        let html = '';
        
        if (this.isClassGrouped) {
            for (const [groupName, classes] of Object.entries(WORKSPACE_CONFIG.CLASSES)) {
                // Trim plural 's' if needed for display like user requested "Object" instead of "Objects"
                const displayGroup = groupName === 'Objects' ? 'Object' : (groupName === 'Regions' ? 'Region' : groupName);
                
                html += `
                <div class="class-category-group mb-1 mx-2" data-group-name="${groupName}">
                    <div onclick="window.app.toggleGroup(this)" class="flex items-center justify-between gap-2 px-3 py-2 pl-2 hover:bg-gray-50 cursor-pointer select-none">
                        <div class="flex items-center gap-2">
                            <div class="group-icon-container text-gray-20 flex items-center justify-center">${MINUS_SVG}</div>
                            <div class="text-gray-20 flex items-center justify-center">${FOLDER_SVG}</div>
                            <span class="text-[14px] font-[400] text-gray-20">${displayGroup}</span>
                        </div>
                        <div class="w-5 h-5 flex items-center justify-center border border-[#e7e4e4] rounded-full text-[11px] text-gray-20 bg-[#fafafa]">
                            ${classes.length}
                        </div>
                    </div>
                    <div class="class-category-content space-y-0.5 mb-1">`;
                
                classes.forEach(cls => {
                    html += `
                        <div class="class-group" data-classname="${cls.name}" onclick="window.app.showToolbar(this, '${cls.name}')">
                            <div class="flex justify-between items-center p-1 pl-8 rounded-md cursor-pointer hover:bg-gray-100 transition-colors">
                                <div class="flex items-center gap-2 text-[14px] text-gray-800 font-sans">
                                    <div class="flex items-center justify-center text-[15px]" style="color: ${cls.color}">
                                        ${ITEM_SVG}
                                    </div>
                                    ${cls.name}
                                    <span class="instance-count-badge ml-1 text-gray-400 text-[12px]"></span>
                                </div>
                                <div class="flex items-center gap-2">
                                    ${classRowQuickActions}
                                    <div class="kbd-key text-[11px] scale-90">${getShortcut(i++)}</div>
                                </div>
                            </div>
                        </div>`;
                });
                html += `
                    </div>
                </div>`;
            }
        } else {
            // Flat list for classes
            html += `<div class="class-category-content space-y-0.5 mb-1 mt-2">`;
            const allClasses = [];
            for (const classes of Object.values(WORKSPACE_CONFIG.CLASSES)) {
                allClasses.push(...classes);
            }
            allClasses.forEach(cls => {
                html += `
                    <div class="class-group" data-classname="${cls.name}" onclick="window.app.showToolbar(this, '${cls.name}')">
                        <div class="flex justify-between items-center p-1 pl-4 rounded-md cursor-pointer hover:bg-gray-100 transition-colors mx-2">
                            <div class="flex items-center gap-2 text-[14px] text-gray-800 font-sans">
                                <div class="flex items-center justify-center text-[15px]" style="color: ${cls.color}">
                                    ${ITEM_SVG}
                                </div>
                                ${cls.name}
                                <span class="instance-count-badge ml-1 text-gray-400 text-[12px]"></span>
                            </div>
                            <div class="flex items-center gap-2">
                                ${classRowQuickActions}
                                <div class="kbd-key text-[11px] scale-90">${getShortcut(i++)}</div>
                            </div>
                        </div>
                    </div>`;
            });
            html += `</div>`;
        }
        
        container.innerHTML = html;
        // Search-empty state — starts hidden; filterClasses() shows it
        // when a search matches nothing. Appended once per full re-render
        // rather than living statically in the .html file, since this
        // container's innerHTML gets fully replaced above every time.
        container.insertAdjacentHTML('beforeend', this._emptyStateHTML('No classes found', 'classesSearchEmptyState', true));

        if (this.isClassGrouped) {
            // Restore collapse state
            document.querySelectorAll('.class-category-group').forEach(groupEl => {
                const groupName = groupEl.dataset.groupName;
                if (this.isGroupCollapsed(groupName)) {
                    const content = groupEl.querySelector('.class-category-content');
                    const icon = groupEl.querySelector('.group-icon-container');
                    if (content) content.classList.add('hidden');
                    if (icon) icon.innerHTML = PLUS_SVG;
                }
            });
        }
    }

    // Whether `groupName`'s folder should currently render collapsed —
    // sessionStorage's own per-session choice (see toggleGroup()) always
    // wins once the user has actually clicked that group's header; before
    // that, falls back to WORKSPACE_CONFIG.DEFAULT_COLLAPSED_CLASS_GROUPS so
    // a group can start collapsed on first load without that choice being
    // indistinguishable from "never touched".
    isGroupCollapsed(groupName) {
        const collapsed = JSON.parse(sessionStorage.getItem('collapsedGroups') || '{}');
        if (Object.prototype.hasOwnProperty.call(collapsed, groupName)) return collapsed[groupName];
        return (WORKSPACE_CONFIG.DEFAULT_COLLAPSED_CLASS_GROUPS || []).includes(groupName);
    }

    toggleGroup(headerEl) {
        const groupEl = headerEl.closest('.class-category-group');
        const content = groupEl.querySelector('.class-category-content');
        const icon = groupEl.querySelector('.group-icon-container');
        const isHidden = content.classList.contains('hidden');
        
        const MINUS_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;
        const PLUS_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor" style="transform: rotate(-90deg);"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;
        
        if (isHidden) {
            content.classList.remove('hidden');
            icon.innerHTML = MINUS_SVG;
        } else {
            content.classList.add('hidden');
            icon.innerHTML = PLUS_SVG;
        }
        
        const groupName = groupEl.dataset.groupName;
        const collapsed = JSON.parse(sessionStorage.getItem('collapsedGroups') || '{}');
        collapsed[groupName] = !isHidden;
        sessionStorage.setItem('collapsedGroups', JSON.stringify(collapsed));
    }

    showToolbar(element, className, isEditMode = false) {
        if (this._hasPendingDrawing()) {
            this.showToast('Please finish or discard the current drawing before changing the class.');
            return;
        }

        // Picking a class (create mode) or selecting an existing object
        // (edit mode) — from the class list, the Labels panel, or clicking
        // a shape directly — are both routed through here, so this is the
        // one place that reliably catches "moved on to something else":
        // release any leftover drag-marquee multi-selection rather than
        // leaving it highlighted with nothing acting on it.
        this.clearMultiSelection();

        this.activeLabel = className;
        const allClasses = getAllClasses();
        const classObj = allClasses.find(c => c.name === className);
        this.activeColor = classObj ? classObj.color : '#4a90e2';

        // Editing an existing annotation: reflect ITS panoptic mode in the
        // toolbar (rather than whatever was last picked for a new shape).
        if (isEditMode && this.selectedAnnotationId) {
            const anno = this.annotations.find(a => a.id === this.selectedAnnotationId);
            this.panopticMode = (anno && anno.panopticMode) || 'none';
        }
        this.syncPanopticModeUI();

        if (this.selectedAnnotationId && !isEditMode) {
            this.selectedAnnotationId = null;
            this.renderAllAnnotations();
            if (typeof this.updateLabelsPanel === 'function') {
                this.updateLabelsPanel();
            }
        }

        if (!isEditMode) {
            // Highlight active class only in create mode
            document.querySelectorAll('.class-group .rounded-md').forEach(el => {
                el.classList.remove('bg-gray-200');
                el.classList.add('hover:bg-gray-100');
            });
            const container = element.querySelector('.rounded-md');
            if (container) {
                container.classList.remove('hover:bg-gray-100');
                container.classList.add('bg-gray-200');
            }
        } else {
            // In edit mode, we can unhighlight everything so it's less noisy
            document.querySelectorAll('.class-group .rounded-md').forEach(el => {
                el.classList.remove('bg-gray-200');
                el.classList.add('hover:bg-gray-100');
            });
        }
        
        // Show toolbar and reset position
        const toolbar = document.getElementById('annotatorToolbar');
        if (toolbar) {
            toolbar.classList.remove('hidden');
            toolbar.style.top = '16px';
            toolbar.style.left = '16px';
            toolbar.style.right = 'auto'; // Reset any right positioning
        }
        
        // Default to brush if no tool is selected or if switching to create mode from edit mode
        if (!isEditMode && (!this.activeTool || this.activeTool === 'move' || this.activeTool === 'eraser')) {
            this.selectTool('brush');
        } else if (!this.activeTool) {
            this.selectTool('brush');
        }
    }

    selectTool(toolName) {
        if (this.activeTool !== toolName) {
            if (this._hasPendingDrawing()) {
                const bothAreDrawingTools = (toolName === 'brush' || toolName === 'polygon') &&
                    (this.activeTool === 'brush' || this.activeTool === 'polygon');

                if (bothAreDrawingTools) {
                    // Switching between brush and polygon mid-instance means
                    // "keep composing the SAME pending shape with a
                    // different tool," not "I'm done" — fold any open
                    // polygon loop into the pending mask and leave
                    // everything else pending (activeLabel, the mask
                    // itself). Only an explicit Enter — see the 'Enter' key
                    // handler, which calls finishPolygon() — commits it.
                    if (this.currentPoints && this.currentPoints.length > 0) {
                        this.mergeCurrentPolygonIntoMask();
                    }
                } else {
                    // Switching to move/eraser (or away from drawing
                    // entirely) still finalizes immediately — those tools
                    // act on already-committed annotations, not on an
                    // in-progress shape. finishPolygon() clears
                    // activeLabel/activeColor as part of its normal
                    // "user explicitly finished, go idle" cleanup; restore
                    // them right after so switching back to a drawing tool
                    // for the same class doesn't require re-picking it from
                    // the sidebar.
                    const keepLabel = this.activeLabel;
                    const keepColor = this.activeColor;
                    this.finishPolygon();
                    if (keepLabel) {
                        this.activeLabel = keepLabel;
                        this.activeColor = keepColor;
                        const classRow = document.querySelector(`.class-group[data-classname="${keepLabel}"] .rounded-md`);
                        if (classRow) {
                            classRow.classList.remove('hover:bg-gray-100');
                            classRow.classList.add('bg-gray-200');
                        }
                    }
                }
            }
        }

        const brushCursor = document.getElementById('brushCursor');
        if (brushCursor) brushCursor.classList.add('hidden');
        
        const videoWrapper = document.getElementById('videoTransformWrapper');
        if (videoWrapper) videoWrapper.style.cursor = 'default';
        
        this.activeTool = toolName;
        
        const btnBrush = document.getElementById('btnBrushTool');
        const btnPolygon = document.getElementById('btnPolygonTool');
        const btnEraser = document.getElementById('btnEraserTool');
        const btnMove = document.getElementById('btnMoveTool');
        const crosshair = document.getElementById('polygonCrosshair');

        const buttons = [btnBrush, btnPolygon, btnEraser, btnMove];
        
        // Reset classes for all buttons
        buttons.forEach(btn => {
            if (!btn) return;
            btn.classList.remove('bg-[#f4f7f4]', 'text-[#7eb93c]', 'bg-[#f4ebff]', 'text-[#5f45ff]');
            btn.classList.add('hover:bg-gray-100', 'text-[#434d58]');
        });

        // Set active tool classes
        let activeBtn = null;
        if (toolName === 'brush') activeBtn = btnBrush;
        else if (toolName === 'polygon') activeBtn = btnPolygon;
        else if (toolName === 'eraser') activeBtn = btnEraser;
        else if (toolName === 'move') activeBtn = btnMove;

        if (activeBtn) {
            activeBtn.classList.remove('hover:bg-gray-100', 'text-[#434d58]');
            activeBtn.classList.add('bg-[#f4f7f4]', 'text-[#7eb93c]');
        }
        
        // Hide/Show tool properties based on tool
        const shapeSection = document.getElementById('toolbarShapeSection');
        const sizeSec = document.getElementById('toolbarSizeSection');
        const panopticSec = document.getElementById('toolbarPanopticSection');
        
        const toolbar = document.getElementById('annotatorToolbar');
        
        if (toolName === 'brush' || toolName === 'eraser') {
            // The size slider's purple fill is only ever painted by
            // updateSize() — on the very first time this section becomes
            // visible (this.brushSize still unset, or just never synced
            // since page load) the slider sat at the plain unstyled browser
            // default until the user dragged it once. Sync it the instant
            // the section is shown instead.
            this.updateSize(this.brushSize || 50);
        }

        if (toolName === 'brush') {
            if (shapeSection) shapeSection.classList.remove('hidden');
            if (sizeSec) sizeSec.classList.remove('hidden');
            if (panopticSec) panopticSec.classList.remove('hidden');
            if (toolbar) toolbar.style.width = '230px';
        } else if (toolName === 'polygon') {
            if (shapeSection) shapeSection.classList.add('hidden');
            if (sizeSec) sizeSec.classList.add('hidden');
            if (panopticSec) panopticSec.classList.remove('hidden');
            if (toolbar) toolbar.style.width = '230px';
        } else if (toolName === 'eraser') {
            if (shapeSection) shapeSection.classList.remove('hidden');
            if (sizeSec) sizeSec.classList.remove('hidden');
            if (panopticSec) panopticSec.classList.add('hidden');
            if (toolbar) toolbar.style.width = '230px';
        } else if (toolName === 'move') {
            if (shapeSection) shapeSection.classList.add('hidden');
            if (sizeSec) sizeSec.classList.add('hidden');
            if (panopticSec) panopticSec.classList.add('hidden');
            if (toolbar) toolbar.style.width = 'max-content';
        }
        
        if (crosshair) {
            if (toolName === 'polygon') {
                crosshair.classList.remove('hidden');
                crosshair.style.opacity = '1';
            } else {
                crosshair.classList.add('hidden');
            }
        }
        if (videoWrapper) {
            let cursorStyle = 'default';
            if (toolName === 'move') {
                cursorStyle = 'grab';
            } else if (toolName === 'eraser' || toolName === 'brush') {
                cursorStyle = 'none'; // custom cursor
            } else if (toolName === 'polygon') {
                cursorStyle = 'default';
            }
            document.getElementById('toolbarFreehandSection')?.classList.toggle('hidden', toolName !== 'polygon');
            
            videoWrapper.style.cursor = cursorStyle;
            
            // Explicitly set on child layers to prevent browser from overriding inherited cursors
            const canvas = document.getElementById('annotationCanvas');
            const img = document.getElementById('mainVideo');
            if (canvas) canvas.style.cursor = cursorStyle;
            if (img) img.style.cursor = cursorStyle;

            // Belt-and-suspenders: existing shapes set their own inline
            // `cursor: pointer` for click-to-select, which otherwise wins
            // the instant the pointer is over one of them. The CSS
            // !important rule for .tool-brush/.tool-eraser is what actually
            // forces `none` to win everywhere underneath.
            videoWrapper.classList.toggle('tool-brush', toolName === 'brush');
            videoWrapper.classList.toggle('tool-eraser', toolName === 'eraser');
        }
    }


    // --- Undo / Redo history ---------------------------------------------
    // Painting/erasing mutate raster canvases directly in place — and, under
    // panoptic "Overwrite", they mutate OTHER annotations' pixel data too
    // (see eraseSegmentFromOthers) — so there's no clean before/after diff
    // to record. The only reliable undo unit here is a full clone of
    // `this.annotations` (canvases included) taken right before a discrete
    // user action and swapped back in wholesale on undo/redo, the same
    // approach raster tools use for brush history.
    initHistory() {
        this.undoStack = [];
        this.redoStack = [];
        this._historyPending = null;
        this._historyDirty = false;
        this._maxHistory = 50;
        this.updateUndoRedoButtons();
    }

    cloneAnnotationsSnapshot() {
        return {
            annotations: this.annotations.map(anno => {
                const clone = { ...anno, _bbox: null };
                if (anno.maskCanvas) {
                    const c = document.createElement('canvas');
                    c.width = anno.maskCanvas.width;
                    c.height = anno.maskCanvas.height;
                    c.getContext('2d').drawImage(anno.maskCanvas, 0, 0);
                    clone.maskCanvas = c;
                }
                if (anno.points) clone.points = anno.points.map(p => ({ ...p }));
                if (anno.eraserStrokes) {
                    clone.eraserStrokes = anno.eraserStrokes.map(s => ({ ...s, points: (s.points || []).map(p => ({ ...p })) }));
                }
                return clone;
            }),
            instanceCounters: { ...this.instanceCounters },
            // Pending (not-yet-committed) shape state — a brush stroke
            // painted before Enter only ever touches this.currentMaskCanvas,
            // never this.annotations, so without capturing it here, undo/
            // redo would have nothing to actually revert between strokes of
            // the SAME in-progress shape (see markDirty() calls in
            // handleCanvasMouseDown's brush branch).
            currentPoints: this.currentPoints ? this.currentPoints.map(p => ({ ...p })) : null,
            currentMaskCanvas: (() => {
                if (!this.currentMaskCanvas) return null;
                const c = document.createElement('canvas');
                c.width = this.currentMaskCanvas.width;
                c.height = this.currentMaskCanvas.height;
                c.getContext('2d').drawImage(this.currentMaskCanvas, 0, 0);
                return c;
            })(),
            editingMaskAnnoId: this._editingMaskAnnoId || null
        };
    }

    pushSnapshot(snapshot) {
        this.undoStack.push(snapshot);
        if (this.undoStack.length > this._maxHistory) this.undoStack.shift();
        this.redoStack = [];
        this.updateUndoRedoButtons();
    }

    // For discrete, non-drag actions (create a shape, delete a shape) —
    // snapshot immediately before the mutation.
    snapshotBeforeAction() {
        this.pushSnapshot(this.cloneAnnotationsSnapshot());
    }

    // For drag-based gestures (paint/erase/move) — call once at the
    // gesture's start; markDirty() whenever the gesture actually changes
    // something; endGesture() once at the gesture's end. A gesture that
    // never actually mutated anything (e.g. an eraser click over empty
    // space) is discarded rather than cluttering the undo stack with a
    // no-op step.
    beginGesture() {
        this._historyPending = this.cloneAnnotationsSnapshot();
        this._historyDirty = false;
    }

    markDirty() {
        this._historyDirty = true;
    }

    endGesture() {
        if (this._historyPending && this._historyDirty) {
            this.pushSnapshot(this._historyPending);
        }
        this._historyPending = null;
        this._historyDirty = false;
    }

    _restoreAnnotationsSnapshot(snapshot) {
        this.annotations = snapshot.annotations;
        this.instanceCounters = { ...snapshot.instanceCounters };

        // Restore whatever pending (not-yet-committed) shape existed at
        // snapshot time, if any — see the matching fields added in
        // cloneAnnotationsSnapshot(). A snapshot taken before Enter was ever
        // pressed has these as null/empty, so this still correctly clears
        // everything for the "no pending shape" case, same as before.
        this.selectedAnnotationId = null;
        this.currentPoints = snapshot.currentPoints ? snapshot.currentPoints.map(p => ({ ...p })) : [];
        this.currentMaskCanvas = snapshot.currentMaskCanvas || null;
        this._editingMaskAnnoId = snapshot.editingMaskAnnoId || null;
        this.lastPaintPos = null;
        this.isDrawing = false;
        this.isErasing = false;
        this.isMoving = false;
        this._liveMoveOffsetX = 0;
        this._liveMoveOffsetY = 0;
        this.hoveredBrushAnnoId = null;
        this.hoveredPolygonAnnoId = null;

        // A pending shape being restored means we're still mid-composition
        // — keep the toolbar up rather than hiding it, since finishing that
        // shape (Enter) is still the expected next step, same as it was
        // before the undo.
        const hasPending = !!(this.currentMaskCanvas || (this.currentPoints && this.currentPoints.length));
        if (!hasPending) {
            const toolbar = document.getElementById('annotatorToolbar');
            if (toolbar) toolbar.classList.add('hidden');

            // Nothing left pending to keep composing — fully back out of
            // the active tool too, not just hide the toolbar div. Without
            // this, this.activeTool stays whatever it was (typically
            // 'brush', from having a class selected), so the very next
            // mousemove still takes the brush-tool branch and keeps
            // positioning the round #brushCursor ring under the pointer —
            // it never reverts to a plain default cursor even though the
            // toolbar/class selection just visually cleared. selectTool(null)
            // is what actually hides #brushCursor and resets the wrapper's
            // cursor style (see its own body).
            this.activeLabel = null;
            this.activeColor = null;
            this.selectTool(null);
            document.querySelectorAll('.class-group .rounded-md').forEach(el => {
                el.classList.remove('bg-gray-200');
                el.classList.add('hover:bg-gray-100');
            });
        }

        const currentPolyGroup = document.getElementById('currentPolygon');
        if (currentPolyGroup) currentPolyGroup.innerHTML = '';

        this.renderAllAnnotations();
        this.renderCurrentPolygon();
        this.renderBrushLayer();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
        if (typeof this.updateClassCounts === 'function') this.updateClassCounts();
    }

    undo() {
        if (!this.undoStack.length) return;
        this.redoStack.push(this.cloneAnnotationsSnapshot());
        const prev = this.undoStack.pop();
        this._restoreAnnotationsSnapshot(prev);
        this.updateUndoRedoButtons();
    }

    redo() {
        if (!this.redoStack.length) return;
        this.undoStack.push(this.cloneAnnotationsSnapshot());
        const next = this.redoStack.pop();
        this._restoreAnnotationsSnapshot(next);
        this.updateUndoRedoButtons();
    }

    updateUndoRedoButtons() {
        const undoBtn = document.getElementById('undoBtn');
        const redoBtn = document.getElementById('redoBtn');
        const canUndo = !!(this.undoStack && this.undoStack.length);
        const canRedo = !!(this.redoStack && this.redoStack.length);
        if (undoBtn) {
            undoBtn.classList.toggle('opacity-40', !canUndo);
            undoBtn.classList.toggle('pointer-events-none', !canUndo);
        }
        if (redoBtn) {
            redoBtn.classList.toggle('opacity-40', !canRedo);
            redoBtn.classList.toggle('pointer-events-none', !canRedo);
        }
    }

    bindCanvasEvents() {
        const wrapper = document.getElementById('videoTransformWrapper');
        if (!wrapper) return;
        
        wrapper.addEventListener('mousedown', (e) => {
            if (e.button === 0 && !e.shiftKey) {
                this.handleCanvasMouseDown(e);
            }
        });

        // Right-click while placing a new polygon's vertices backs out the
        // most recently placed one instead of opening the browser's own
        // context menu — a way to undo a misplaced point without
        // discarding the whole shape (Escape) or finishing it early.
        wrapper.addEventListener('contextmenu', (e) => {
            if (this.activeTool === 'polygon' && this.currentPoints && this.currentPoints.length > 0) {
                e.preventDefault();
                this.undoLastPolygonPoint();
                return;
            }
            // Right-click anywhere inside the multi-selection's own group
            // bbox opens the "combine into..." menu — same hit-region
            // handleCanvasMouseDown checks to start a group MOVE drag, so a
            // right-click lands on this menu everywhere a left-click-drag
            // would instead move the group.
            if (this.multiSelectedIds.size > 1) {
                const { x, y } = this.getCanvasCoords(e);
                const box = this.getGroupBoundsRect();
                if (box && x >= box.x && x <= box.x + box.w && y >= box.y && y <= box.y + box.h) {
                    e.preventDefault();
                    this.openMultiSelectContextMenu(e);
                }
            }
        });

        // Bound to `window`, not `wrapper` — a move/group-move/marquee/erase
        // drag must keep tracking the cursor even once it leaves the
        // wrapper's own (image-sized) box, e.g. while dragging a brush mask
        // out past the image edge to crop/delete it (see moveAnnotation/
        // finalizeMove). `wrapper`-scoped mousemove stops firing the instant
        // the pointer exits that box, which froze drags at the boundary —
        // matches the `mouseup` listener just below, which was already on
        // `window` for the same reason.
        window.addEventListener('mousemove', (e) => {
            this.handleCanvasMouseMove(e);
        });

        window.addEventListener('mouseup', (e) => {
            if (e.button === 0) {
                this.handleCanvasMouseUp(e);
            }
        });

        window.addEventListener('keydown', (e) => {
            this.handleCanvasKeyDown(e);
        });
    }

    isInsideImage(x, y) {
        const bounds = this.getImageBounds();
        if (!bounds) return true;
        return x >= bounds.rx && x <= bounds.rx + bounds.rw &&
               y >= bounds.ry && y <= bounds.ry + bounds.rh;
    }

    // isInsideImage() alone is purely native-image-space math with no idea
    // where the visible viewport actually is — #videoTransformWrapper's own
    // untransformed box is native-image-pixel sized, and at any real zoom
    // level beyond 1x that box geometrically extends far past what's
    // actually visible (clipped by this panel's own overflow:hidden), often
    // right underneath the sidebar or top toolbar. So a cursor physically
    // over the Classes/Labels panel or the toolbar can still land inside
    // isInsideImage()'s native-space bounds and get treated as "hovering the
    // image" — showing/following the brush-size cursor circle out there.
    // This adds the other half: is the pointer even within the panel that
    // actually clips what's visible, in real screen space, regardless of
    // zoom. Only meaningful for a live mouse EVENT (handleCanvasMouseMove/
    // Up) — isInsideImage() on its own is still correct and used as-is for
    // pure geometry checks against annotation data (no event exists there).
    isPointerOverImagePanel(e) {
        const wrapper = document.getElementById('videoTransformWrapper');
        const panel = wrapper && wrapper.parentElement;
        if (!panel) return true;
        const rect = panel.getBoundingClientRect();
        return e.clientX >= rect.left && e.clientX <= rect.right &&
               e.clientY >= rect.top && e.clientY <= rect.bottom;
    }

    // #annotatorToolbar is an absolutely-positioned overlay that lives
    // INSIDE #videoTransformWrapper's own on-screen rect (it's anchored
    // top-4/left-4 within the same panel) — so isPointerOverImagePanel()'s
    // purely geometric check still reports true while the cursor is
    // sitting on the toolbar itself. Without this, the round brush-size
    // cursor (z-index 99999 — see bindEvents()) renders directly on top of
    // the toolbar's own buttons whenever the mouse crosses over it, which
    // both looks wrong (a giant circle over the Size/Panoptic-mode panel)
    // and blocks their normal hover state, since the fixed-position ring
    // sits above them in the exact spot the mouse actually is.
    isPointerOverFloatingUI(e) {
        return !!(e.target && e.target.closest && e.target.closest('#annotatorToolbar'));
    }

    clampToImage(x, y) {
        const bounds = this.getImageBounds();
        if (!bounds) return { x, y };

        const minX = bounds.rx;
        const maxX = bounds.rx + bounds.rw;
        const minY = bounds.ry;
        const maxY = bounds.ry + bounds.rh;

        return {
            x: Math.max(minX, Math.min(x, maxX)),
            y: Math.max(minY, Math.min(y, maxY))
        };
    }

    // The image's rect within #videoTransformWrapper is now ALWAYS the full
    // wrapper: the wrapper itself is sized to the image's native pixel
    // dimensions (see WorkspaceManager.init()'s sizeWrapperToImage and
    // ViewportTransform.naturalWidth/naturalHeight), not to 100% of its
    // container. There is no letterboxing left to compute, and nothing here
    // depends on container size anymore. This used to independently
    // recompute an object-fit:contain rect from the container's current
    // size on every call — that recomputation and the browser's own
    // separate internal object-fit rendering of the <img> were two
    // independent calculations of "where is the image" that could disagree
    // by a fraction of a pixel (worst at corners/high zoom), and every
    // container resize required re-mapping every stored annotation point
    // onto the newly-recomputed rect. Neither problem can exist anymore:
    // the image and this overlay share the exact same size by construction,
    // always, so annotation points never need to move because of a resize.
    getImageBounds() {
        const media = document.getElementById('mainVideo');
        const box = document.getElementById('imageBoundsBox');
        const transform = this.workspace && this.workspace.transform;
        const nw = (transform && transform.naturalWidth) || (media && media.naturalWidth) || 1000;
        const nh = (transform && transform.naturalHeight) || (media && media.naturalHeight) || 1000;

        if (box) {
            box.style.left = '0px';
            box.style.top = '0px';
            box.style.width = nw + 'px';
            box.style.height = nh + 'px';
        }

        const canvas = document.getElementById('annotationCanvas');
        if (canvas) {
            canvas.style.left = '0px';
            canvas.style.top = '0px';
            canvas.style.width = nw + 'px';
            canvas.style.height = nh + 'px';
        }

        const brushCanvas = document.getElementById('brushMaskCanvas');
        if (brushCanvas) {
            brushCanvas.style.left = '0px';
            brushCanvas.style.top = '0px';
            brushCanvas.style.width = nw + 'px';
            brushCanvas.style.height = nh + 'px';
            // .width/.height (the backing-store size, unlike the CSS size
            // above) clears the canvas as soon as they're assigned — only
            // touch them when the natural image size actually changes, never
            // on every render, or every painted stroke would vanish.
            if (brushCanvas.width !== nw) brushCanvas.width = nw;
            if (brushCanvas.height !== nh) brushCanvas.height = nh;
        }

        // See the HTML comment on #dragOverflowCanvas — 3x size, centered on
        // the image, so its own (0,0) is native (-nw,-nh).
        const dragCanvas = document.getElementById('dragOverflowCanvas');
        if (dragCanvas) {
            dragCanvas.style.left = (-nw) + 'px';
            dragCanvas.style.top = (-nh) + 'px';
            dragCanvas.style.width = (nw * 3) + 'px';
            dragCanvas.style.height = (nh * 3) + 'px';
            if (dragCanvas.width !== nw * 3) dragCanvas.width = nw * 3;
            if (dragCanvas.height !== nh * 3) dragCanvas.height = nh * 3;
        }

        const clipRect = document.getElementById('imageAreaClipRect');
        if (clipRect) {
            clipRect.setAttribute('x', 0);
            clipRect.setAttribute('y', 0);
            clipRect.setAttribute('width', nw);
            clipRect.setAttribute('height', nh);
        }

        return { rx: 0, ry: 0, rw: nw, rh: nh };
    }

    getCanvasCoords(e) {
        const canvas = document.getElementById('annotationCanvas');
        if (!canvas) return { x: 0, y: 0 };
        const rect = canvas.getBoundingClientRect();
        let scale = 1;
        if (this.workspace && this.workspace.transform) {
            scale = this.workspace.transform.scale || 1;
        }
        return {
            x: (e.clientX - rect.left) / scale,
            y: (e.clientY - rect.top) / scale,
            scale
        };
    }

    _hasPendingDrawing() {
        return this.isDrawing || !!this.currentMaskCanvas || (this.currentPoints && this.currentPoints.length > 0);
    }

    // Shows/hides the toolbar's green "Finish" (checkmark) button — the
    // click equivalent of pressing Enter (see finishActiveDrawing()), for
    // annotators who can't or don't want to rely on the keyboard to commit
    // a shape. Hooked into renderBrushLayer() rather than every individual
    // mousedown/mousemove/mouseup, since that already runs after every
    // point/stroke change that could flip _hasPendingDrawing()'s answer.
    syncFinishButtonVisibility() {
        const btn = document.getElementById('btnFinishAnnotation');
        if (!btn) return;
        // Create-mode only — a brand-new shape being built up
        // (_hasPendingDrawing()) with no annotation selected. Edit-mode
        // touch-ups (brush/eraser on an already-selected annotation) commit
        // themselves the instant the mouse is released — see
        // commitCurrentStroke() — so there's no persistent "pending" state
        // for Finish to represent there; showing it only for the instant a
        // dab is actively being dragged just flickered on and off with
        // every stroke, which is why edit mode is excluded outright rather
        // than shown-but-debounced.
        const shouldShow = !this.selectedAnnotationId && this._hasPendingDrawing();
        const wasHidden = btn.classList.contains('hidden');
        btn.classList.toggle('hidden', !shouldShow);
        // Reset to the resting (outline) icon whenever the button transitions
        // from hidden to shown — otherwise a session that ends mid-hover
        // (button hidden while the mouse was still over it, so mouseleave
        // never fired) would leave the filled icon's inline style stuck
        // "on" for the next drawing session, before the mouse ever hovers
        // it again.
        if (shouldShow && wasHidden) {
            const outline = btn.querySelector('.finish-icon-outline');
            const filled = btn.querySelector('.finish-icon-filled');
            if (outline) outline.style.display = 'block';
            if (filled) filled.style.display = 'none';
        }
    }

    // Recomputes the #brushCursor ring's on-screen size from the current
    // `brushSize` is a SCREEN-pixel size (matching Encord/v2's convention:
    // the cursor is a constant on-screen size the user dials in, not a
    // fixed amount of image detail) — so the cursor is just brushSize
    // itself, invariant to zoom. What varies with zoom is how much actual
    // IMAGE gets covered by that constant-looking brush; see
    // getNativeBrushSize() for the conversion used at actual paint time.
    // Still called from mousemove AND ViewportTransform.apply() so a
    // brushSize change made mid-zoom-gesture (or vice versa) is never
    // reflected a frame late.
    refreshBrushCursorSize() {
        const brushCursor = document.getElementById('brushCursor');
        if (!brushCursor) return;
        if (this.activeTool !== 'brush' && this.activeTool !== 'eraser') return;
        if (this.isDrawing || this.isErasing) return; // matches the "don't resize mid-stroke" behavior below
        const size = this.brushSize || 50;
        brushCursor.style.width = `${size}px`;
        brushCursor.style.height = `${size}px`;
        brushCursor.dataset.cachedSize = String(size);
    }

    // Converts the screen-constant brushSize into the actual number of
    // image-native pixels a stamp should cover at the CURRENT zoom — the
    // same relationship v2 used (`Math.round(brushSize / currentZoom)`):
    // zoomed in, a fixed-looking on-screen brush covers fewer native
    // pixels; zoomed out, it covers more. This is what actually gets
    // painted; refreshBrushCursorSize() is only ever the on-screen ring.
    getNativeBrushSize() {
        const scale = this.workspace && this.workspace.transform ? (this.workspace.transform.scale || 1) : 1;
        return Math.max(1, (this.brushSize || 50) / scale);
    }

    // --- Pixel/raster brush engine -----------------------------------
    // Each brush annotation owns a full-image-size offscreen <canvas>
    // (anno.maskCanvas) holding its painted alpha mask, painted in the
    // annotation's own class color with hard (non-anti-aliased) edges —
    // a real pixel mask, not an SVG stroke approximation. All of them are
    // composited onto the single visible #brushMaskCanvas by
    // renderBrushLayer() every time anything changes.

    createFullSizeCanvas() {
        const bounds = this.getImageBounds();
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(bounds.rw));
        c.height = Math.max(1, Math.round(bounds.rh));
        return c;
    }

    // A brush "stamp" is a small canvas containing exactly one dab of the
    // brush, rasterized pixel-by-pixel (not via ctx.arc()) so its edge is
    // hard-stepped rather than anti-aliased — this is what gives painted
    // strokes their blocky "pixel mask" look instead of a smooth circle.
    getBrushStamp(size, shape, color) {
        if (!this._brushStampCache) this._brushStampCache = new Map();
        const key = `${size}-${shape}-${color}`;
        let stamp = this._brushStampCache.get(key);
        if (stamp) return stamp;

        const sz = Math.max(1, Math.round(size));
        stamp = document.createElement('canvas');
        stamp.width = sz;
        stamp.height = sz;
        const ctx = stamp.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.fillStyle = color;
        if (shape === 'square') {
            ctx.fillRect(0, 0, sz, sz);
        } else {
            // Test each pixel's CENTER against the circle, not an offset
            // rounded back to an integer coordinate — the previous version
            // computed positions as Math.round(r + dx) which, for small odd
            // sizes (most visibly size=1), rounded to a coordinate exactly
            // at or past the canvas edge and got silently clipped away,
            // leaving the stamp fully blank. A 1px brush painted nothing.
            // Comparing pixel centers is the standard, off-by-one-safe way
            // to rasterize a circle onto a fixed pixel grid.
            const r = sz / 2;
            for (let py = 0; py < sz; py++) {
                for (let px = 0; px < sz; px++) {
                    const cx = px + 0.5 - r;
                    const cy = py + 0.5 - r;
                    if (cx * cx + cy * cy <= r * r) {
                        ctx.fillRect(px, py, 1, 1);
                    }
                }
            }
        }
        this._brushStampCache.set(key, stamp);
        return stamp;
    }

    // Stamps one dab of the brush centered at (x, y) onto `canvas`.
    // `erase` switches to destination-out compositing so it punches a
    // hole instead of painting (the stamp's own color doesn't matter then
    // — only its alpha coverage does).
    stampBrush(canvas, x, y, size, shape, color, erase) {
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
        const stamp = this.getBrushStamp(size, shape, erase ? '#000000' : color);
        const off = stamp.width / 2;
        ctx.drawImage(stamp, Math.round(x - off), Math.round(y - off));
        ctx.globalCompositeOperation = 'source-over';
    }

    // Stamps along the segment from `from` to `to` at sub-brush-width
    // intervals so a fast drag doesn't leave gaps between dabs.
    paintSegment(canvas, from, to, size, shape, color, erase) {
        const dist = Math.hypot(to.x - from.x, to.y - from.y);
        const step = Math.max(size * 0.35, 1);
        const steps = Math.max(1, Math.ceil(dist / step));
        for (let i = 1; i <= steps; i++) {
            const t = i / steps;
            this.stampBrush(canvas, from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t, size, shape, color, erase);
        }
    }

    // Topmost brush annotation whose mask has a painted (alpha > 0) pixel
    // at image-space (x, y) — the raster equivalent of the old per-shape
    // SVG click/hover targets.
    hitTestBrushAt(x, y) {
        for (let i = this.annotations.length - 1; i >= 0; i--) {
            const anno = this.annotations[i];
            if (anno.type !== 'brush' || !anno.visible || !anno.maskCanvas) continue;
            const lx = Math.round(x - (anno.offsetX || 0));
            const ly = Math.round(y - (anno.offsetY || 0));
            if (lx < 0 || ly < 0 || lx >= anno.maskCanvas.width || ly >= anno.maskCanvas.height) continue;
            const ctx = anno.maskCanvas.getContext('2d', { willReadFrequently: true });
            const alpha = ctx.getImageData(lx, ly, 1, 1).data[3];
            if (alpha > 0) return anno;
        }
        return null;
    }

    // Selects `anno` for editing — the same steps regardless of entry
    // point (a direct pixel hit-test click on a brush mask, a polygon's
    // own SVG click handler, or clicking a DIFFERENT shape while already
    // in Move mode with something else selected): switch
    // selectedAnnotationId to it, drop any stale multi-selection,
    // re-render, and open its toolbar defaulted to Move — clicking the
    // shape itself on canvas means "grab/reposition it."
    selectAnnotationForEdit(anno) {
        this.selectedAnnotationId = anno.id;
        if (this.multiSelectedIds.size > 0) this.multiSelectedIds.clear();
        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
        this.selectTool('move');
        const classGroup = document.querySelector(`.class-group[data-classname="${anno.class}"]`);
        if (classGroup) this.showToolbar(classGroup, anno.class, true);
    }

    isMaskEmpty(canvas) {
        if (!canvas || !canvas.width || !canvas.height) return true;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
        for (let i = 3; i < data.length; i += 4) {
            if (data[i] > 0) return false;
        }
        return true;
    }

    // Tight bounding box of the painted (alpha > 0) pixels, found via a
    // 4-direction edge scan. `topX` is the x of the first painted pixel
    // found on the top-most row — used to anchor the class-name tag the
    // same way the old code anchored it to the highest drawn point.
    computeMaskBBox(canvas) {
        if (!canvas || !canvas.width || !canvas.height) return null;
        const w = canvas.width, h = canvas.height;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        const data = ctx.getImageData(0, 0, w, h).data;
        const alphaAt = (x, y) => data[(y * w + x) * 4 + 3];

        let top = -1, topX = 0;
        outer1:
        for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
                if (alphaAt(x, y) > 0) { top = y; topX = x; break outer1; }
            }
        }
        if (top === -1) return null;

        let bottom = h - 1;
        outer2:
        for (let y = h - 1; y >= 0; y--) {
            for (let x = 0; x < w; x++) {
                if (alphaAt(x, y) > 0) { bottom = y; break outer2; }
            }
        }
        let left = 0;
        outer3:
        for (let x = 0; x < w; x++) {
            for (let y = 0; y < h; y++) {
                if (alphaAt(x, y) > 0) { left = x; break outer3; }
            }
        }
        let right = w - 1;
        outer4:
        for (let x = w - 1; x >= 0; x--) {
            for (let y = 0; y < h; y++) {
                if (alphaAt(x, y) > 0) { right = x; break outer4; }
            }
        }
        return { x: left, y: top, w: right - left + 1, h: bottom - top + 1, topX };
    }

    getAnnoBBox(anno) {
        if (!anno._bbox) {
            anno._bbox = this.computeMaskBBox(anno.maskCanvas) || { x: 0, y: 0, w: 0, h: 0, topX: 0 };
        }
        return anno._bbox;
    }

    _invalidateBBox(anno) {
        anno._bbox = null;
    }

    // Highlight rim hugging the INSIDE of a mask's silhouette (Encord-style
    // inset border, not a halo puffing outward past the actual boundary):
    // erode the mask 1px inward (intersect 4 one-pixel-shifted copies —
    // keeps only pixels opaque in the original AND all 4 neighbors), then
    // subtract that eroded core from the original shape, leaving a thin
    // 1-native-pixel band along the inner edge. Previously this dilated the
    // mask 2px OUTWARD in 8 directions and punched the original out, which
    // put the rim outside the boundary and, being 2px thick, read as a
    // thick, rounded-off blocky halo.
    //
    // This is deliberately a WHOLE, hard-edged native pixel — not a
    // fraction of one kept constant in screen space. An earlier version of
    // this tried the screen-constant route (dividing the offset by zoom,
    // with smoothing on) to avoid the rim looking "thick" at high zoom, but
    // that's not how a reference tool like Encord actually renders it:
    // their own hover rim stays crisp, solid, and exactly 1 real image
    // pixel wide at every zoom level — it just reads as a bigger block on
    // screen at high zoom because the image's OWN pixels are doing exactly
    // the same thing (see the reference screenshots). Softening/shrinking
    // the rim below that made it read as pale and disconnected from the
    // shape's actual pixel grid instead. imageSmoothingEnabled stays off
    // here to match, same as the shape's own fill.
    drawHoverRim(ctx, maskCanvas, ox, oy) {
        if (!this._rimScratch) this._rimScratch = document.createElement('canvas');
        if (!this._erodeScratch) this._erodeScratch = document.createElement('canvas');
        const rim = this._rimScratch;
        const erode = this._erodeScratch;
        if (rim.width !== maskCanvas.width || rim.height !== maskCanvas.height) {
            rim.width = erode.width = maskCanvas.width;
            rim.height = erode.height = maskCanvas.height;
        }

        const ectx = erode.getContext('2d');
        ectx.imageSmoothingEnabled = false;
        ectx.clearRect(0, 0, erode.width, erode.height);
        ectx.globalCompositeOperation = 'source-over';
        ectx.drawImage(maskCanvas, 0, 0);
        const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
        dirs.forEach(([dx, dy]) => {
            ectx.globalCompositeOperation = 'destination-in';
            ectx.drawImage(maskCanvas, dx, dy);
        });

        const rctx = rim.getContext('2d');
        rctx.imageSmoothingEnabled = false;
        rctx.clearRect(0, 0, rim.width, rim.height);
        rctx.globalCompositeOperation = 'source-over';
        rctx.drawImage(maskCanvas, 0, 0);
        rctx.globalCompositeOperation = 'destination-out';
        rctx.drawImage(erode, 0, 0);
        rctx.globalCompositeOperation = 'source-atop';
        rctx.fillStyle = '#1d4ed8';
        rctx.fillRect(0, 0, rim.width, rim.height);

        ctx.globalAlpha = 1;
        ctx.drawImage(rim, ox, oy);
    }

    // Rasterizes `anno`'s own silhouette (before any panoptic punching) into
    // a fresh full-image-size canvas, in the annotation's own class color.
    // Brush: just its maskCanvas at the given live offset. Polygon: fills
    // its point path and punches its own eraserStrokes out the same way the
    // (now invisible-fill) SVG copy would — see the polygon branch of
    // renderAllAnnotations(). Used both as an annotation's own "final"
    // appearance when nothing punches it, and as the cutting stencil fed
    // into OTHER annotations' destination-out compositing below.
    renderAnnotationStencil(anno, liveOx, liveOy) {
        const bounds = this.getImageBounds();
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(bounds.rw));
        c.height = Math.max(1, Math.round(bounds.rh));
        const ctx = c.getContext('2d');
        ctx.imageSmoothingEnabled = false;

        if (anno.type === 'brush' && anno.maskCanvas) {
            ctx.drawImage(anno.maskCanvas, liveOx || 0, liveOy || 0);
        } else if (anno.type === 'polygon' && anno.points && anno.points.length >= 3) {
            ctx.fillStyle = anno.color || '#4a90e2';
            ctx.beginPath();
            anno.points.forEach((p, i) => { if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); });
            ctx.closePath();
            ctx.fill();

            if (anno.eraserStrokes && anno.eraserStrokes.length > 0) {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.strokeStyle = '#000';
                anno.eraserStrokes.forEach(stroke => {
                    if (!stroke.points || stroke.points.length === 0) return;
                    ctx.lineJoin = stroke.shape === 'square' ? 'miter' : 'round';
                    ctx.lineCap = stroke.shape === 'square' ? 'square' : 'round';
                    ctx.lineWidth = stroke.size || 50;
                    ctx.beginPath();
                    stroke.points.forEach((p, i) => { if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); });
                    ctx.stroke();
                });
                ctx.globalCompositeOperation = 'source-over';
            }

            // ctx.fill()/stroke() always anti-alias their edges — unlike
            // drawImage, there is no imageSmoothingEnabled equivalent for
            // path rendering. Left alone, every polygon's silhouette
            // carries a soft alpha gradient along its boundary, which is
            // the actual root cause of the blurry border: drawHoverRim()
            // erodes/rims whatever alpha values are already in this
            // canvas, so a soft input silhouette produces a soft rim no
            // matter how the rim itself is drawn. Snap alpha to fully
            // opaque/transparent here so a polygon's raster is exactly as
            // hard-edged as the brush's own manually-rasterized stamps
            // (see getBrushStamp) — scoped to this shape's own bounding
            // box (plus eraser-stroke width) rather than the whole image,
            // since getImageData/putImageData over a full HD canvas on
            // every render would add up.
            this._thresholdPolygonEdges(ctx, c.width, c.height, anno);
        }

        // Settings drawer > Label display > Label color mode — "By object"
        // retints the whole silhouette to this annotation's own unique
        // color, replacing whatever color is already baked in (a brush's
        // maskCanvas has its class color baked into its actual pixels at
        // paint time; a polygon's fill above used it directly). source-in
        // keeps this stencil's existing alpha/shape exactly as-is and just
        // swaps the RGB wherever that alpha is already nonzero — a no-op
        // fillRect-sized cost in "By class" mode (effectiveColor ===
        // anno.color), skipped entirely below.
        //
        // Safe for COCO export too, which also flows through this same
        // stencil (see the comment above this method) — export only reads
        // the alpha channel via RLE-encoding, never the RGB, so retinting
        // for display has no effect on exported data.
        const effectiveColor = this.getEffectiveColor(anno);
        if (effectiveColor !== (anno.color || '#4a90e2')) {
            ctx.globalCompositeOperation = 'source-in';
            ctx.fillStyle = effectiveColor;
            ctx.fillRect(0, 0, c.width, c.height);
            ctx.globalCompositeOperation = 'source-over';
        }
        return c;
    }

    _thresholdPolygonEdges(ctx, canvasW, canvasH, anno) {
        const xs = anno.points.map(p => p.x), ys = anno.points.map(p => p.y);
        let maxStrokeSize = 0;
        if (anno.eraserStrokes) {
            anno.eraserStrokes.forEach(s => { maxStrokeSize = Math.max(maxStrokeSize, s.size || 50); });
        }
        const pad = Math.ceil(maxStrokeSize / 2) + 2;
        const bx = Math.max(0, Math.floor(Math.min(...xs) - pad));
        const by = Math.max(0, Math.floor(Math.min(...ys) - pad));
        const bx2 = Math.min(canvasW, Math.ceil(Math.max(...xs) + pad));
        const by2 = Math.min(canvasH, Math.ceil(Math.max(...ys) + pad));
        const bw = bx2 - bx, bh = by2 - by;
        if (bw <= 0 || bh <= 0) return;

        const imgData = ctx.getImageData(bx, by, bw, bh);
        const data = imgData.data;
        for (let i = 3; i < data.length; i += 4) {
            data[i] = data[i] >= 128 ? 255 : 0;
        }
        ctx.putImageData(imgData, bx, by);
    }

    // --- Permanent panoptic paint-time effects (brush) ------------------
    // Per the actual product spec: Exclude/Overwrite are baked into real
    // pixel data the instant a stroke is drawn — "the existing pixels of
    // Object A remain completely unchanged" / "overlapping pixels are
    // removed from Object A" are one-time facts about what got painted,
    // not an ongoing live relationship. Doing this as a render-time-only
    // effect (recomputed from current z-order/position every frame) was
    // the earlier design here, and it's what caused the reported bug:
    // moving either shape afterward changed what got cut, since the cut
    // was never actually stored anywhere — only ever inferred live. Baking
    // it into each shape's own maskCanvas/eraserStrokes at paint time means
    // the cut is real data that moves (or doesn't) exactly like any other
    // pixel the user painted, matching Encord's behavior.

    // Exclude: the stroke being painted must never end up occupying a pixel
    // any OTHER existing visible annotation already owns. Called once per
    // paint tick (mousedown dab / mousemove segment), after the normal
    // paint, so `canvas` briefly contains the "naive" stamp before this
    // subtracts every other annotation's current silhouette from it.
    //
    // Runs unconditionally now (not just when panopticMode === 'exclude')
    // because a punch can be required either from the stroke's OWN side
    // (panopticMode) or from the OTHER shape's side — the Labels panel's
    // per-row overlap toggle: an existing label set to "Cannot be drawn
    // over" must reject every new stroke regardless of that stroke's own
    // panoptic mode. These are two independent, unrelated settings —
    // panopticMode describes what THIS shape does while it's being
    // painted; overlapMode describes what OTHER shapes may do to THIS one.
    applyExcludeAgainstOthers(canvas, selfId, selfPanopticMode) {
        const ctx = canvas.getContext('2d');
        this.annotations.forEach(other => {
            if (other.id === selfId || !other.visible) return;
            // "Must overlap" is never excluded away from — a new stroke is
            // already confined to stay INSIDE a must-overlap shape's own
            // boundary in the first place (see getMustOverlapBoundaryMask(),
            // applied before this), so nothing here should also carve a
            // hole back out of that same region.
            if (other.overlapMode === 'mustOverlap') return;
            const mustExclude = selfPanopticMode === 'exclude' || other.overlapMode === 'noOverlap';
            if (!mustExclude) return;
            const stencil = this.renderAnnotationStencil(other, other.offsetX || 0, other.offsetY || 0);
            ctx.globalCompositeOperation = 'destination-out';
            ctx.drawImage(stencil, 0, 0);
            ctx.globalCompositeOperation = 'source-over';
        });
    }

    // Overwrite: the stroke being painted takes absolute ownership of the
    // pixels it covers — permanently erase that exact segment from every
    // OTHER visible, unlocked annotation's own data (brush: destination-out
    // on its maskCanvas; polygon: appended as a real eraserStrokes segment,
    // the same mechanism the eraser tool already uses) — UNLESS that other
    // annotation's own Labels panel overlap toggle says otherwise: "No
    // overlap" (cannot be drawn over) is a hard wall Overwrite can't punch
    // through, and "Must overlap" is exempt too — it's never modified by
    // anything drawn over it at all (see getMustOverlapBoundaryMask()),
    // Overwrite included.
    eraseSegmentFromOthers(selfId, from, to, size, shape) {
        this.annotations.forEach(other => {
            if (other.id === selfId || !other.visible || other.locked ||
                other.overlapMode === 'mustOverlap' || other.overlapMode === 'noOverlap') return;
            this.markDirty();
            if (other.type === 'brush' && other.maskCanvas) {
                const ox = other.offsetX || 0, oy = other.offsetY || 0;
                this.paintSegment(
                    other.maskCanvas,
                    { x: from.x - ox, y: from.y - oy },
                    { x: to.x - ox, y: to.y - oy },
                    size, shape, null, true
                );
                this._invalidateBBox(other);
            } else if (other.type === 'polygon') {
                // One short stroke segment per paint tick — renderAnnotationStencil
                // draws every entry in eraserStrokes regardless of how many
                // there are, so fragmenting into several small strokes over
                // the course of a drag is harmless.
                if (!other.eraserStrokes) other.eraserStrokes = [];
                other.eraserStrokes.push({ size, shape, points: [from, to] });
            }
        });
    }

    // Converts `anno` from a vector polygon into an equivalent raster mask
    // IN PLACE (fills its path, punches its own eraserStrokes into that
    // fill) — a no-op if it's already raster. Used by eraseSilhouetteFromOthers()
    // to erase an arbitrary piece out of an annotation's own data: a
    // polygon's vector points can't represent an arbitrary notch the way a
    // raster mask's pixels can, so it has to become one first.
    _ensureRasterMask(anno) {
        if (anno.type !== 'polygon' || !anno.points || anno.points.length < 3) return;
        const converted = this.createFullSizeCanvas();
        const cctx = converted.getContext('2d');
        cctx.fillStyle = anno.color || '#4a90e2';
        cctx.beginPath();
        anno.points.forEach((p, idx) => {
            if (idx === 0) cctx.moveTo(p.x, p.y); else cctx.lineTo(p.x, p.y);
        });
        cctx.closePath();
        cctx.fill();
        if (anno.eraserStrokes && anno.eraserStrokes.length > 0) {
            cctx.globalCompositeOperation = 'destination-out';
            cctx.strokeStyle = '#000';
            anno.eraserStrokes.forEach(stroke => {
                if (!stroke.points || stroke.points.length === 0) return;
                cctx.lineJoin = stroke.shape === 'square' ? 'miter' : 'round';
                cctx.lineCap = stroke.shape === 'square' ? 'square' : 'round';
                cctx.lineWidth = stroke.size || 50;
                cctx.beginPath();
                stroke.points.forEach((p, idx) => {
                    if (idx === 0) cctx.moveTo(p.x, p.y); else cctx.lineTo(p.x, p.y);
                });
                cctx.stroke();
            });
            cctx.globalCompositeOperation = 'source-over';
        }
        anno.type = 'brush';
        anno.maskCanvas = converted;
        anno.points = null;
        anno.eraserStrokes = null;
    }

    // Overwrite's OTHER half — erases an arbitrary shape's own silhouette
    // (a full-image-size alpha mask, e.g. straight from
    // renderAnnotationStencil()) out of every OTHER visible, unlocked
    // annotation, same "takes ownership of these exact pixels" effect
    // eraseSegmentFromOthers() already gives a brush stroke mid-paint,
    // generalized here so a freshly-finished POLYGON's silhouette can erase
    // from a target too — see finishPolygon()'s bake step for why a plain
    // stroke-shaped dab can't stand in for an arbitrary polygon outline.
    eraseSilhouetteFromOthers(selfId, sourceCanvas) {
        this.annotations.forEach(other => {
            if (other.id === selfId || !other.visible || other.locked ||
                other.overlapMode === 'mustOverlap' || other.overlapMode === 'noOverlap') return;
            this._ensureRasterMask(other);
            if (!other.maskCanvas) return;
            this.markDirty();
            const ctx = other.maskCanvas.getContext('2d');
            ctx.globalCompositeOperation = 'destination-out';
            ctx.drawImage(sourceCanvas, -(other.offsetX || 0), -(other.offsetY || 0));
            ctx.globalCompositeOperation = 'source-over';
            this._invalidateBBox(other);
        });
    }

    // "Must overlap" — the one Labels-panel overlap toggle that acts as a
    // DRAWING BOUNDARY: while at least one annotation is marked "must
    // overlap", ANY new or edited shape (any class) is confined to stay
    // INSIDE that shape's own silhouette; you cannot paint outside it at
    // all. The must-overlap shape itself is never modified by this — no
    // erase, no transfer. Confirmed directly against Encord's own
    // reference behavior: a prior version of this also erased the touched
    // patch out of the must-overlap shape, which both fragmented it into
    // stray disconnected slivers on an elongated silhouette and doesn't
    // match the real product — the must-overlap shape stays fully intact,
    // and wherever the (boundary-clipped) new shape overlaps it, that's
    // just two annotations' own fills naturally showing through each other,
    // same as any other two overlapping shapes. Union of every OTHER
    // visible, unlocked "must overlap" shape's silhouette — null when none
    // exist, so normal unrestricted drawing (the vast majority of the
    // time) never pays for this at all.
    getMustOverlapBoundaryMask(selfId) {
        const targets = this.annotations.filter(a =>
            a.id !== selfId && a.visible && !a.locked && a.overlapMode === 'mustOverlap');
        if (!targets.length) return null;
        const mask = this.createFullSizeCanvas();
        const ctx = mask.getContext('2d');
        targets.forEach(other => {
            ctx.drawImage(this.renderAnnotationStencil(other, other.offsetX || 0, other.offsetY || 0), 0, 0);
        });
        return mask;
    }

    // A cheap bounding-box pre-filter for which "must overlap" shapes are
    // even worth a real per-pixel check below — a single brush dab's own
    // small rect while painting, or a finished polygon's full bbox. Only
    // ever used for the Overwrite-specific ownership transfer below — the
    // drawing boundary itself (getMustOverlapBoundaryMask()) already keeps
    // every OTHER mode confined without needing this.
    findMustOverlapTargets(rect, selfId) {
        if (!rect) return [];
        return this.annotations.filter(other => {
            if (other.id === selfId || !other.visible || other.locked || other.overlapMode !== 'mustOverlap') return false;
            const b = this.getAnnoBoundsRect(other);
            return !!b && b.x < rect.x + rect.w && b.x + b.w > rect.x &&
                   b.y < rect.y + rect.h && b.y + b.h > rect.y;
        });
    }

    // Overwrite-specific ownership transfer for a "must overlap" target —
    // confirmed directly against product behavior: Overwrite's whole point
    // is "this stroke takes ownership of the pixels it covers," and that
    // applies to a must-overlap shape too, unlike every other Panoptic
    // mode (None just leaves it fully intact; Exclude is blocked outright
    // — see getMustOverlapExcludeBlockMessage()). Only called from the
    // panopticMode === 'overwrite' branches, alongside eraseSegmentFromOthers'
    // own general erase (which still exempts "must overlap" targets — this
    // is the one deliberate, precise exception to that, scoped to exactly
    // the touched intersection rather than eraseSegmentFromOthers' cruder
    // whole-dab shape). Erases wherever `touchedMask` (this paint tick's
    // own dab/segment/polygon silhouette, full-image-size, absolute native
    // coordinates) overlaps each `targets` shape's silhouette OUT of their
    // own mask — everything OUTSIDE this tick's touched area is left
    // alone, so the must-overlap shape keeps existing as its own label
    // with whatever's left, gaining a permanent notch only where Overwrite
    // actually painted over it.
    absorbMustOverlapTargets(targets, touchedMask) {
        if (!targets || targets.length === 0) return;
        targets.forEach(other => {
            this._ensureRasterMask(other);
            if (!other.maskCanvas) return;
            const stencil = this.renderAnnotationStencil(other, other.offsetX || 0, other.offsetY || 0);
            const overlap = this.createFullSizeCanvas();
            const octx = overlap.getContext('2d');
            octx.drawImage(stencil, 0, 0);
            // Keep only where THIS TICK's own touched area also has alpha —
            // the actual "inside the shape's own draw, not wherever you
            // drag" intersection, rather than the whole silhouette.
            octx.globalCompositeOperation = 'destination-in';
            octx.drawImage(touchedMask, 0, 0);
            octx.globalCompositeOperation = 'source-over';

            const ctx = other.maskCanvas.getContext('2d');
            ctx.globalCompositeOperation = 'destination-out';
            ctx.drawImage(overlap, -(other.offsetX || 0), -(other.offsetY || 0));
            ctx.globalCompositeOperation = 'source-over';
            this._invalidateBBox(other);
        });
        this.markDirty();
    }

    // See handleCanvasMouseDown's call sites for why Exclude specifically
    // (not None/Overwrite) is incompatible with an active "must overlap"
    // boundary. `mode` is the EFFECTIVE panoptic mode this specific stroke
    // will actually use — this.panopticMode (the toolbar's global setting)
    // for a brand-new shape, but an existing selected shape's own stored
    // mode when editing/extending it instead (brush only; polygon has no
    // such per-shape override) — passed in explicitly rather than read
    // internally, since callers resolve that differently. Returns a
    // ready-to-show warning naming every currently must-overlap shape, or
    // null when drawing may proceed normally.
    getMustOverlapExcludeBlockMessage(mode, selfId) {
        if ((mode || 'none') !== 'exclude') return null;
        const targets = this.annotations.filter(a =>
            a.id !== selfId && a.visible && !a.locked && a.overlapMode === 'mustOverlap');
        if (!targets.length) return null;
        const names = targets.map(a => `${a.class} (${this.getDisplayInstanceNumber(a)})`).join(', ');
        return `Drawing was blocked because ${names} has Must overlap enabled. New strokes can only be drawn on top of that bitmask.`;
    }

    // Returns [{anno, canvas}] — every visible annotation's FINAL raster
    // (after panoptic exclude/overwrite clipping), in z-order. Shared by
    // renderBrushLayer() (for display) and generateCOCOFormat() (for
    // export), so exported pixels always match exactly what's on screen.
    //
    // Brush is deliberately never punched here — its exclude/overwrite
    // effect is baked permanently into its own maskCanvas pixel data at
    // paint time (see applyExcludeAgainstOthers/eraseSegmentFromOthers),
    // exactly like Encord: the cut is a fact of what was drawn, not a live
    // relationship that silently changes if either shape is moved later.
    // Punching it again here transiently on top of that would double-cut,
    // and worse, would recompute the wrong cut the instant either shape
    // moved — which was the actual bug that design replaced. Polygon
    // creation doesn't bake anything into its own vector points, so it
    // keeps this live/reactive punching against whatever the other shape
    // currently looks like.
    computeFinalAnnotationCanvases() {
        const visible = this.annotations.filter(a => a.visible && (
            (a.type === 'brush' && a.maskCanvas) || (a.type === 'polygon' && a.points && a.points.length >= 3)
        ));

        const stencils = visible.map(anno => {
            const isMovingThis = anno.type === 'brush' && this.isMoving && this.selectedAnnotationId === anno.id;
            // Same idea as isMovingThis, for a brush shape currently being
            // dragged as part of a group move (see moveGroupBy()) — its
            // offset lives on the annotation itself (_liveGroupOffsetX/Y)
            // rather than a single shared field, since several brush
            // shapes can be group-moving at once.
            const isGroupMovingThis = anno.type === 'brush' && this._groupMoving && this.multiSelectedIds.has(anno.id);
            const ox = isMovingThis ? (this._liveMoveOffsetX || 0) : (isGroupMovingThis ? (anno._liveGroupOffsetX || 0) : (anno.offsetX || 0));
            const oy = isMovingThis ? (this._liveMoveOffsetY || 0) : (isGroupMovingThis ? (anno._liveGroupOffsetY || 0) : (anno.offsetY || 0));
            return { anno, canvas: this.renderAnnotationStencil(anno, ox, oy) };
        });

        stencils.forEach(({ anno, canvas: finalCanvas }, i) => {
            if (anno.type !== 'polygon') return;
            const fctx = finalCanvas.getContext('2d');
            stencils.forEach(({ anno: other, canvas: otherCanvas }, j) => {
                if (other === anno) return;
                const excludedByEarlierShape = anno.panopticMode === 'exclude' && j < i;
                // Only a later POLYGON's overwrite still punches live — a
                // later brush's overwrite already permanently erased this
                // polygon's own eraserStrokes at paint time.
                const overwrittenByLaterShape = other.type === 'polygon' && other.panopticMode === 'overwrite' && j > i;
                if (excludedByEarlierShape || overwrittenByLaterShape) {
                    fctx.globalCompositeOperation = 'destination-out';
                    fctx.drawImage(otherCanvas, 0, 0);
                    fctx.globalCompositeOperation = 'source-over';
                }
            });
        });

        return stencils;
    }

    // Composites every visible brush + polygon annotation's final raster
    // (see computeFinalAnnotationCanvases()) onto the single visible
    // #brushMaskCanvas. Redrawn from scratch each call — annotation counts
    // are small, so a handful of full-size drawImage composites per shape
    // stays cheap even though the punching pass above is O(n²).
    renderBrushLayer() {
        const canvas = document.getElementById('brushMaskCanvas');
        if (!canvas || !canvas.width || !canvas.height) return;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const stencils = this.computeFinalAnnotationCanvases();
        stencils.forEach(({ anno, canvas: finalCanvas }) => {
            // handleCanvasMouseMove only updates hoveredBrushAnnoId while
            // NOT drawing (this.isDrawing gates it), so whatever it was set
            // to right before a paint stroke started — almost always the
            // very shape you're about to edit — stays frozen for the whole
            // stroke. Painting fires renderBrushLayer() after every stamp,
            // so without this guard the hover rim keeps re-erosion-tracing
            // a mask that's changing shape stamp-by-stamp mid-stroke,
            // which reads as a flickering, dashed-looking glitch instead of
            // a stable outline. There's no useful "hover highlight" to show
            // on the exact shape you're actively painting onto anyway.
            const isHoveredBrush = anno.type === 'brush' && this.hoveredBrushAnnoId === anno.id
                && this._editingMaskAnnoId !== anno.id;
            // Same rim, same raster path, for a hovered polygon — see the
            // comment on this.hoveredPolygonAnnoId in the constructor for
            // why this replaced the old SVG stroke-based hover outline.
            const isHoveredPolygon = anno.type === 'polygon' && this.hoveredPolygonAnnoId === anno.id
                && this._editingMaskAnnoId !== anno.id;
            // Settings drawer > Label display > "Selected object fill
            // opacity" covers both hovering a shape AND having it selected
            // (edit mode) — "Object fill opacity" is everything else.
            const isSelectedOrHovered = this.selectedAnnotationId === anno.id || isHoveredBrush || isHoveredPolygon;

            ctx.globalAlpha = isSelectedOrHovered ? this.selectedObjectFillOpacity : this.objectFillOpacity;
            ctx.drawImage(finalCanvas, 0, 0);
            ctx.globalAlpha = 1;

            // Rim painted AFTER (on top of) the semi-transparent fill, not
            // before — drawHoverRim's rim hugs the INSIDE of the
            // silhouette, so drawing it first would just get washed out
            // the instant the fill above re-covers that same inner band.
            // Drag-marquee multi-select is shown as a single group bbox
            // instead of a per-shape rim — see updateGroupSelectionBBox().
            if (isHoveredBrush || isHoveredPolygon) this.drawHoverRim(ctx, finalCanvas, 0, 0);
        });
        ctx.globalAlpha = 1;

        // Brand-new brush annotation still being drawn (not yet pushed into
        // this.annotations — see finishPolygon()); not part of the panoptic
        // set yet since it isn't a real annotation, shown as a plain overlay.
        if (this.currentMaskCanvas && !this._editingMaskAnnoId) {
            ctx.globalAlpha = this.objectFillOpacity;
            ctx.drawImage(this.currentMaskCanvas, 0, 0);
            ctx.globalAlpha = 1;
        }

        this.syncFinishButtonVisibility();
    }

    handleCanvasMouseDown(e) {
        const { x, y } = this.getCanvasCoords(e);

        if (this.multiSelectedIds.size > 0) {
            const box = this.getGroupBoundsRect();
            const insideGroupBox = box && x >= box.x && x <= box.x + box.w && y >= box.y && y <= box.y + box.h;
            if (insideGroupBox) {
                // Clicking anywhere inside the group's bbox grabs and moves
                // the whole selection together — see moveGroupBy()/
                // finalizeGroupMove(). Same drag convention as the
                // single-shape move tool below.
                this.beginGesture();
                this._groupMoving = true;
                this._groupMoveStartX = x;
                this._groupMoveStartY = y;
                const wrapper = document.getElementById('videoTransformWrapper');
                if (wrapper) {
                    wrapper.style.cursor = 'grabbing';
                    // The inline style alone isn't enough — see the CSS
                    // comment on .group-moving for why (a selected shape's
                    // own cursor style wins the instant the pointer is
                    // over it, which is exactly where a group-move drag
                    // starts).
                    wrapper.classList.add('group-moving');
                }
                const boundsBox = document.getElementById('imageBoundsBox');
                if (boundsBox) boundsBox.style.overflow = 'visible';
                return;
            }
            // Clicked outside the group's bbox: the user has moved on from
            // this selection — release it and fall through to whatever
            // this click normally does (select a different shape, start a
            // fresh marquee, etc.)
            this.multiSelectedIds.clear();
            this.renderAllAnnotations();
        }

        if (this.activeTool === 'move' && this.selectedAnnotationId) {
            // Only actually start a move-drag if this click landed ON the
            // CURRENTLY selected shape — not just "move tool active with
            // something selected" regardless of where the click actually
            // was. Without this check, clicking a DIFFERENT shape while in
            // Move mode still unconditionally armed a drag of the OLD
            // selection from wherever the click happened to land — a
            // clean click-no-drag then finalizes that (no-op) move, and
            // finalizeMove() rebuilds every annotation's SVG group from
            // scratch (renderAllAnnotations()) in the process. That rebuild
            // happens BETWEEN this mousedown and the browser's own
            // synthetic 'click' event for the same gesture — which fires
            // on whatever DOM element ORIGINALLY received the mousedown.
            // Since that original element just got destroyed and replaced
            // by a freshly rebuilt one, the browser silently drops the
            // click entirely, so the OTHER shape's own onclick (see
            // addTextAndHover()) never runs and never gets selected — this
            // is what actually made it feel "stuck" on the old selection.
            const clickedGroup = e.target && e.target.closest ? e.target.closest('[id^="anno-group-"]') : null;
            const clickedAnnoId = clickedGroup ? clickedGroup.id.slice('anno-group-'.length) : null;
            const selfHit = this.hitTestBrushAt(x, y);
            const clickedSelf = clickedAnnoId === this.selectedAnnotationId ||
                (selfHit && selfHit.id === this.selectedAnnotationId);
            if (clickedSelf) {
                this.beginGesture();
                this.isMoving = true;
                this.moveStartX = x;
                this.moveStartY = y;
                const movingAnno = this.annotations.find(a => a.id === this.selectedAnnotationId);
                if (movingAnno && movingAnno.type === 'brush') {
                    this._liveMoveOffsetX = movingAnno.offsetX || 0;
                    this._liveMoveOffsetY = movingAnno.offsetY || 0;
                }
                // Keep a clear "actively moving" cursor for the whole drag,
                // even once it crosses outside #imageBoundsBox — only
                // hovering (not dragging) should ever fall back to the
                // default arrow there.
                const wrapper = document.getElementById('videoTransformWrapper');
                if (wrapper) wrapper.style.cursor = 'grabbing';
                // Let the shape render fully, even past the image edges,
                // for the duration of the drag (matches Encord).
                // #imageBoundsBox's overflow:hidden is what actually
                // enforces the boundary now, so it must be temporarily
                // relaxed here — otherwise it clips the shape
                // unconditionally regardless of the isMoving-based
                // clip-path skip in renderAllAnnotations. finalizeMove()
                // restores it (and permanently crops whatever ends up
                // outside) the moment the drag ends.
                const boundsBox = document.getElementById('imageBoundsBox');
                if (boundsBox) boundsBox.style.overflow = 'visible';
                return;
            }
            // Clicked a DIFFERENT shape — switch selection to it directly,
            // right here on mousedown, rather than relying on THAT shape's
            // own SVG 'click' handler firing later for the SAME gesture:
            // that's the exact same fragile mousedown-then-click timing
            // this whole branch exists to avoid (see the comment above) —
            // a re-render triggered by anything else in between (a hover
            // update, another shape's own state change) can just as
            // easily destroy the original DOM target before the browser's
            // synthesized click event reaches it, silently dropping the
            // select. clickedAnnoId covers a polygon (real DOM element);
            // selfHit covers a brush (pixel hit-test, no DOM element of
            // its own to match against e.target).
            const otherAnno = (clickedAnnoId && this.annotations.find(a => a.id === clickedAnnoId)) || selfHit;
            if (otherAnno && otherAnno.visible && !otherAnno.locked) {
                this.selectAnnotationForEdit(otherAnno);
                return;
            }
            // Otherwise, clicked empty space — fall through to the
            // marquee-drag start below.
        }

        if (this.activeTool === 'eraser' && this.selectedAnnotationId) {
            this.beginGesture();
            this.isErasing = true;
            this.lastEraseX = x;
            this.lastEraseY = y;
            this.eraseAt(x, y);
            return;
        }

        if (!this.activeLabel) {
            const hit = this.hitTestBrushAt(x, y);
            if (hit && hit.visible && !hit.locked) {
                // Clicking the shape ITSELF on canvas defaults to move (you
                // clicked it to grab/reposition it); clicking its row in the
                // Labels panel instead defaults to brush (see that row's
                // onclick) — different entry points imply different intent.
                this.selectAnnotationForEdit(hit);
                return;
            }
            if (e.target && e.target.closest && e.target.closest('[id^="anno-group-"]')) {
                return;
            }
            // Empty canvas, no drawing tool active: start a drag-marquee
            // box instead of immediately complaining — see
            // handleCanvasMouseMove/handleCanvasMouseUp for where the box
            // is grown and finished. A negligible drag (a plain click)
            // still falls back to the "pick a class" toast there.
            this._marqueeStart = { x, y };
            this._marqueeMoved = false;
            return;
        }
        if (this.activeTool !== 'polygon' && this.activeTool !== 'brush') return;

        const clamped = this.clampToImage(x, y);
        
        // If not already drawing and clicked fully outside, ignore it to prevent accidental starts outside
        if (!this.isDrawing && !this.isInsideImage(x, y)) return;
        
        if (this.activeTool === 'polygon') {
            // Checked on EVERY vertex click, not just the first — this.panopticMode
            // is a single global field read fresh each time, so switching to
            // Exclude mid-instance (after already placing earlier points
            // under a different mode) must still get caught right here,
            // not just at the very first vertex. See the matching check in
            // the brush branch below for why Exclude is blocked outright.
            const polyBlockMsg = this.getMustOverlapExcludeBlockMessage(this.panopticMode, this.selectedAnnotationId);
            if (polyBlockMsg) {
                this.showToast(polyBlockMsg);
                return;
            }
            if (this.currentPoints && this.currentPoints.length > 2) {
                const first = this.currentPoints[0];
                const dist = Math.hypot(first.x - clamped.x, first.y - clamped.y);
                // A fixed 10 native-pixel radius here reads as a
                // constant-SIZE hit-zone in native-pixel terms, but the
                // whole point is "close enough to the start point on
                // screen" — at high zoom, 10 native px is a huge area on
                // screen (easy to land inside it by accident while placing
                // an unrelated later vertex, e.g. a zigzag shape with
                // several vertices near each other); at low zoom it's tiny
                // (barely reachable at all). Scaling by the current zoom
                // keeps this a constant ~10 SCREEN pixels regardless of
                // zoom level, matching every other zoom-invariant distance
                // in this file (see the stroke-width comments elsewhere).
                const scale = this.workspace && this.workspace.transform ? this.workspace.transform.scale : 1;
                if (dist < 10 / scale) {
                    if (this.currentMaskCanvas) {
                        // A brush mask is already pending — this polygon is
                        // being added to that SAME instance, not drawn
                        // standalone. Fold it in and keep composing; don't
                        // finalize the whole annotation just because this
                        // one polygon loop closed (only Enter does that).
                        this.mergeCurrentPolygonIntoMask();
                    } else {
                        this.finishPolygon();
                    }
                    return;
                }
            }
            if (!this.currentPoints) this.currentPoints = [];
            this.currentPoints.push({x: clamped.x, y: clamped.y});
            this.isDrawing = true;
            this.renderCurrentPolygon(clamped.x, clamped.y);
        } else if (this.activeTool === 'brush') {
            // Peek at the EFFECTIVE panoptic mode this stroke will actually
            // use — this.panopticMode (the toolbar's global setting) for a
            // brand-new shape, or the specific existing shape's own stored
            // mode when editing/extending it (mirrors the real resolution
            // just below) — checked on EVERY mousedown, not just a fresh
            // instance's first dab, so switching to Exclude mid-instance
            // (after already painting earlier strokes under a different
            // mode into the SAME pending shape) still gets caught. Done
            // BEFORE beginGesture()/isDrawing so a blocked click never
            // leaves a half-started gesture behind.
            let peekMode = this.panopticMode || 'none';
            if (this.selectedAnnotationId) {
                const selAnno = this.annotations.find(a => a.id === this.selectedAnnotationId);
                if (selAnno && selAnno.class === this.activeLabel && (selAnno.type === 'brush' || selAnno.type === 'polygon')) {
                    peekMode = selAnno.panopticMode || 'none';
                }
            }
            const brushBlockMsg = this.getMustOverlapExcludeBlockMessage(peekMode, this.selectedAnnotationId);
            if (brushBlockMsg) {
                this.showToast(brushBlockMsg);
                return;
            }

            this.beginGesture();
            this.isDrawing = true;

            let targetCanvas = null, targetColor = this.activeColor, ox = 0, oy = 0;
            let panopticMode = this.panopticMode || 'none';
            if (this.selectedAnnotationId) {
                const anno = this.annotations.find(a => a.id === this.selectedAnnotationId);
                if (anno && anno.class === this.activeLabel && (anno.type === 'brush' || anno.type === 'polygon')) {
                    if (anno.type === 'polygon') {
                        // Polygon is just another way of painting a bitmask —
                        // brushing onto a selected polygon in edit mode should
                        // keep editing THIS annotation, not silently start a
                        // separate new one. Convert its vector points into a
                        // real raster mask on first touch (same fill pattern
                        // renderAnnotationStencil() uses for a committed
                        // polygon; mergeCurrentPolygonIntoMask() does the
                        // equivalent for a still-open one), then fall through
                        // to the normal brush-onto-existing-mask path below.
                        const converted = this.createFullSizeCanvas();
                        if (anno.points && anno.points.length >= 3) {
                            const cctx = converted.getContext('2d');
                            cctx.fillStyle = anno.color || this.activeColor;
                            cctx.beginPath();
                            anno.points.forEach((p, i) => {
                                if (i === 0) cctx.moveTo(p.x, p.y); else cctx.lineTo(p.x, p.y);
                            });
                            cctx.closePath();
                            cctx.fill();
                        }
                        anno.type = 'brush';
                        anno.maskCanvas = converted;
                        anno.points = null;
                        this._invalidateBBox(anno);
                    }
                    if (!anno.maskCanvas) anno.maskCanvas = this.createFullSizeCanvas();
                    this._editingMaskAnnoId = anno.id;
                    targetCanvas = anno.maskCanvas;
                    targetColor = anno.color || this.activeColor;
                    ox = anno.offsetX || 0;
                    oy = anno.offsetY || 0;
                    panopticMode = anno.panopticMode || 'none';
                }
            }
            if (!targetCanvas) {
                this._editingMaskAnnoId = null;
                if (!this.currentMaskCanvas) this.currentMaskCanvas = this.createFullSizeCanvas();
                targetCanvas = this.currentMaskCanvas;
            }

            this.lastPaintPos = { x: clamped.x, y: clamped.y };
            const size = this.getNativeBrushSize(), shape = this.brushShape || 'circle';

            // "Must overlap" drawing boundary — while at least one shape is
            // marked must-overlap, this stroke can only exist inside its
            // silhouette (union of every such shape, if more than one).
            // Only THIS TICK's fresh dab is clipped against the boundary as
            // it stands RIGHT NOW, then merged into targetCanvas permanently
            // — re-clipping the WHOLE accumulated canvas against the
            // boundary on every tick (the earlier approach) fought with
            // Overwrite's own erase-from-Car below: eroding Car on tick N
            // shrinks the boundary, which would then retroactively re-clip
            // tick N's own just-painted pixels on tick N+1, wiping out
            // exactly the patch Overwrite just transferred (Car erased AND
            // the new shape left empty there — nothing drawn at all, only
            // ever ADDING already-boundary-valid pixels avoids that
            // feedback loop entirely, since nothing already on
            // targetCanvas ever needs re-checking against a later, smaller
            // boundary.
            const boundaryMask = this.getMustOverlapBoundaryMask(this._editingMaskAnnoId);
            let dabMask = null;
            if (boundaryMask) {
                dabMask = this.createFullSizeCanvas();
                this.stampBrush(dabMask, clamped.x, clamped.y, size, shape, '#000', false);
                const dctx = dabMask.getContext('2d');
                dctx.globalCompositeOperation = 'destination-in';
                dctx.drawImage(boundaryMask, 0, 0);
                dctx.globalCompositeOperation = 'source-in';
                dctx.fillStyle = targetColor || '#4a90e2';
                dctx.fillRect(0, 0, dabMask.width, dabMask.height);
                dctx.globalCompositeOperation = 'source-over';
                targetCanvas.getContext('2d').drawImage(dabMask, -ox, -oy);
            } else {
                this.stampBrush(targetCanvas, clamped.x - ox, clamped.y - oy, size, shape, targetColor, false);
            }
            // Marks history dirty regardless of whether this stroke is
            // editing an existing committed annotation OR still building up
            // a brand-new pending one (this.currentMaskCanvas) — the latter
            // used to be skipped here, which is why undo/redo previously
            // did nothing until the whole shape was finished with Enter:
            // cloneAnnotationsSnapshot() now captures the pending mask too,
            // so there's something real for endGesture() to actually push.
            this.markDirty();

            // Bake the panoptic effect in immediately, as part of the paint
            // itself — see applyExcludeAgainstOthers/eraseSegmentFromOthers.
            // Always runs (not just when panopticMode === 'exclude') since
            // an existing shape's own "Cannot be drawn over" overlap toggle
            // must reject this stroke too — see applyExcludeAgainstOthers's
            // own comment.
            this.applyExcludeAgainstOthers(targetCanvas, this._editingMaskAnnoId, panopticMode);
            if (panopticMode === 'overwrite') {
                this.eraseSegmentFromOthers(this._editingMaskAnnoId, { x: clamped.x, y: clamped.y }, { x: clamped.x, y: clamped.y }, size, shape);

                // Overwrite's must-overlap-specific half — see
                // absorbMustOverlapTargets()'s own comment. Reuses dabMask
                // (already exactly "this dab, clipped to the boundary") as
                // the touched area instead of rebuilding it.
                if (dabMask) {
                    const dabRect = { x: clamped.x - size / 2, y: clamped.y - size / 2, w: size, h: size };
                    const mustOverlapHit = this.findMustOverlapTargets(dabRect, this._editingMaskAnnoId);
                    if (mustOverlapHit.length) this.absorbMustOverlapTargets(mustOverlapHit, dabMask);
                }
            }

            this.renderBrushLayer();
        }
    }

    handleCanvasMouseMove(e) {
        const { x, y } = this.getCanvasCoords(e);
        // See isPointerOverImagePanel()'s own comment — required alongside
        // isInsideImage() now that this handler is on `window` (so a drag
        // can keep tracking the cursor past the image edge — see
        // bindCanvasEvents()), not just while inside #videoTransformWrapper.
        const inImage = this.isInsideImage(x, y) && this.isPointerOverImagePanel(e)
            && !this.isPointerOverFloatingUI(e);

        if (this._groupMoving) {
            // Same missed-mouseup safety net as the single-shape isMoving
            // branch below.
            if (e.buttons === 0) {
                this.finalizeGroupMove();
                return;
            }
            const dx = x - this._groupMoveStartX;
            const dy = y - this._groupMoveStartY;
            this.moveGroupBy(dx, dy);
            this._groupMoveStartX = x;
            this._groupMoveStartY = y;
            return;
        }

        if (this._marqueeStart) {
            const dx = x - this._marqueeStart.x, dy = y - this._marqueeStart.y;
            if (!this._marqueeMoved && Math.hypot(dx, dy) > 3) this._marqueeMoved = true;
            if (this._marqueeMoved) this.updateMarqueeRect(this._marqueeStart.x, this._marqueeStart.y, x, y);
            return;
        }

        // Idle hover highlight for brush annotations — the raster
        // equivalent of the old per-shape SVG mouseenter/mouseleave.
        if (!this.isDrawing && !this.isErasing && !this.isMoving) {
            const hit = inImage ? this.hitTestBrushAt(x, y) : null;
            const hitId = hit ? hit.id : null;
            if (hitId !== this.hoveredBrushAnnoId) {
                this.hoveredBrushAnnoId = hitId;
                this.renderBrushLayer();
            }
        }

        if (this.isMoving && this.selectedAnnotationId) {
            // Safety net: if the mouse button was released somewhere the page
            // never saw the mouseup (e.g. over DevTools, a native browser
            // panel, or outside the window entirely), isMoving can get stuck
            // "true" forever, leaving the shape permanently un-clipped. The
            // next time a mousemove reaches us with the button no longer
            // held, treat that as the missed release.
            if (e.buttons === 0) {
                this.finalizeMove();
                return;
            }
            const dx = x - this.moveStartX;
            const dy = y - this.moveStartY;
            this.moveAnnotation(this.selectedAnnotationId, dx, dy);
            this.moveStartX = x;
            this.moveStartY = y;
            return;
        }

        if (this.isErasing && this.selectedAnnotationId) {
            const clamped = this.clampToImage(x, y);
            this.eraseAt(clamped.x, clamped.y);
            this.lastEraseX = clamped.x;
            this.lastEraseY = clamped.y;
        }

        const wrapper = document.getElementById('videoTransformWrapper');
        if (wrapper) {
            const brushCursor = document.getElementById('brushCursor');
            const crosshair = document.getElementById('polygonCrosshair');
            const canvas = document.getElementById('annotationCanvas');
            const img = document.getElementById('mainVideo');

            // The brush-size circle cursor is only shown while the actual
            // cursor tip sits inside #imageBoundsBox — not merely whenever
            // the oversized circle happens to graze the edge. Previously
            // this tolerated the cursor being up to a full brush-radius
            // outside (so a 50px brush could show while ~80%+ of the circle
            // was already off the image), which looked wrong. `inImage`
            // alone is the strict, correct check.
            let intersectsImage = inImage;
            // Outside #imageBoundsBox always means a default, visible cursor —
            // this applies even while a brush stroke or eraser is actively in
            // progress. The custom brush-size circle is likewise always
            // hidden out there; only clampToImage-constrained points are ever
            // actually painted, so showing a brush circle beyond the edge
            // would be misleading regardless of drawing state.
            //
            // NOTE: selectTool() sets an explicit inline cursor on
            // #mainVideo (not just the wrapper) to defeat cursor
            // inheritance, so it must be updated here too. #mainVideo's own
            // box now exactly matches #videoTransformWrapper (both sized to
            // the image's native pixel dimensions, no letterboxed margin
            // inside either) — so `!intersectsImage` in practice only ever
            // fires once the cursor has left the wrapper entirely, where
            // neither element receives the pointer anyway. This branch is
            // effectively inert now rather than removed, kept only so a
            // deliberately smaller/cropped #mainVideo (or a future
            // letterboxing use case) wouldn't silently regress.
            if (!intersectsImage && !this.isMoving) {
                wrapper.style.cursor = 'default';
                if (canvas) canvas.style.cursor = 'default';
                if (img) img.style.cursor = 'default';
                // Drop the CSS !important force-none rule while outside the
                // image — otherwise it would keep overriding this back to
                // 'none' even though we explicitly want 'default' here.
                wrapper.classList.remove('tool-brush', 'tool-eraser');
                if (brushCursor) {
                    brushCursor.style.display = 'none';
                    brushCursor.classList.add('hidden');
                }
                if (crosshair && this.activeTool === 'polygon') {
                    crosshair.classList.add('hidden');
                }
            } else if (intersectsImage) {
                if (this.activeTool === 'brush' || this.activeTool === 'eraser') {
                    wrapper.style.cursor = 'none';
                    if (canvas) canvas.style.cursor = 'none';
                    if (img) img.style.cursor = 'none';
                    // Re-apply now that we're back inside the image — this
                    // is what actually defeats any shape's own inline
                    // `cursor: pointer` when hovering it while brushing.
                    wrapper.classList.toggle('tool-brush', this.activeTool === 'brush');
                    wrapper.classList.toggle('tool-eraser', this.activeTool === 'eraser');
                } else if (this.activeTool === 'move') {
                    // selectTool() sets the initial 'grab', but every
                    // mousemove used to stomp it back to 'default' the
                    // instant the cursor moved at all — this is what kept
                    // the move cursor looking inert. 'grabbing' while an
                    // actual drag is in progress, 'grab' otherwise.
                    const moveCursor = this.isMoving ? 'grabbing' : 'grab';
                    wrapper.style.cursor = moveCursor;
                    if (canvas) canvas.style.cursor = moveCursor;
                    if (img) img.style.cursor = moveCursor;
                    wrapper.classList.remove('tool-brush', 'tool-eraser');
                } else {
                    wrapper.style.cursor = 'default';
                    if (canvas) canvas.style.cursor = 'default';
                    if (img) img.style.cursor = 'default';
                    wrapper.classList.remove('tool-brush', 'tool-eraser');
                }
                if (crosshair && this.activeTool === 'polygon') {
                    crosshair.classList.remove('hidden');
                }
                if (this.activeTool === 'brush' || this.activeTool === 'eraser') {
                    if (this.activeTool === 'brush' && this.isDrawing) {
                        // Don't update cursor size while actively drawing stroke
                    } else if (this.activeTool === 'eraser' && this.isErasing) {
                        // Don't update cursor size while erasing
                    } else if (brushCursor && (this.activeLabel || this.activeTool === 'eraser')) {
                        // Encord's eraser cursor is a neutral white/gray ring,
                        // not tinted — matching that instead of the red we
                        // had, which read as a "delete/danger" color rather
                        // than a plain eraser indicator.
                        const cursorColor = this.activeTool === 'eraser' ? 'rgba(255,255,255,0.9)' : (this.activeColor || 'white');
                        if (brushCursor.dataset.cachedColor !== cursorColor) {
                            brushCursor.style.borderColor = cursorColor;
                            brushCursor.dataset.cachedColor = cursorColor;
                        }

                        this.refreshBrushCursorSize();

                        const isSquare = this.brushShape === 'square';
                        brushCursor.style.borderRadius = isSquare ? '0' : '50%';
                    }

                    if (brushCursor) {
                        if (intersectsImage || this.isDrawing) {
                            brushCursor.style.display = 'block';
                            brushCursor.classList.remove('hidden');
                            brushCursor.style.left = e.clientX + 'px';
                            brushCursor.style.top = e.clientY + 'px';
                            brushCursor.style.transform = `translate(-50%, -50%)`;
                        } else {
                            brushCursor.style.display = 'none';
                            brushCursor.classList.add('hidden');
                            if (canvas) canvas.style.cursor = 'default';
                        }
                    }
                }        
            }
            
            if (this.activeTool === 'brush' && this.isDrawing) {
                if (e.buttons === 0) {
                    this.commitCurrentStroke();
                    return;
                }
                const clamped = this.clampToImage(x, y);
                let targetCanvas = null, targetColor = this.activeColor, ox = 0, oy = 0;
                let panopticMode = this.panopticMode || 'none';
                if (this._editingMaskAnnoId) {
                    const anno = this.annotations.find(a => a.id === this._editingMaskAnnoId);
                    if (anno && anno.maskCanvas) {
                        targetCanvas = anno.maskCanvas;
                        targetColor = anno.color || this.activeColor;
                        ox = anno.offsetX || 0;
                        oy = anno.offsetY || 0;
                        panopticMode = anno.panopticMode || 'none';
                    }
                } else if (this.currentMaskCanvas) {
                    targetCanvas = this.currentMaskCanvas;
                }
                if (targetCanvas && this.lastPaintPos) {
                    const size = this.getNativeBrushSize(), shape = this.brushShape || 'circle';

                    // Same "must overlap" drawing-boundary handling as
                    // mousedown — only THIS TICK's fresh swept segment is
                    // clipped against the CURRENT boundary, then merged in
                    // permanently, so a later tick's Overwrite erosion of
                    // the must-overlap shape never retroactively re-clips
                    // an earlier tick's already-painted pixels (see the
                    // mousedown branch's own comment for the exact feedback
                    // loop this avoids).
                    const boundaryMask = this.getMustOverlapBoundaryMask(this._editingMaskAnnoId);
                    let segMask = null;
                    if (boundaryMask) {
                        segMask = this.createFullSizeCanvas();
                        this.paintSegment(segMask, this.lastPaintPos, clamped, size, shape, '#000', false);
                        const sctx = segMask.getContext('2d');
                        sctx.globalCompositeOperation = 'destination-in';
                        sctx.drawImage(boundaryMask, 0, 0);
                        sctx.globalCompositeOperation = 'source-in';
                        sctx.fillStyle = targetColor || '#4a90e2';
                        sctx.fillRect(0, 0, segMask.width, segMask.height);
                        sctx.globalCompositeOperation = 'source-over';
                        targetCanvas.getContext('2d').drawImage(segMask, -ox, -oy);
                    } else {
                        const from = { x: this.lastPaintPos.x - ox, y: this.lastPaintPos.y - oy };
                        const to = { x: clamped.x - ox, y: clamped.y - oy };
                        this.paintSegment(targetCanvas, from, to, size, shape, targetColor, false);
                    }
                    // See the matching comment in handleCanvasMouseDown's
                    // brush branch — unconditional now, not just when editing
                    // an existing annotation.
                    this.markDirty();

                    // Same permanent bake as mousedown — see
                    // applyExcludeAgainstOthers/eraseSegmentFromOthers.
                    this.applyExcludeAgainstOthers(targetCanvas, this._editingMaskAnnoId, panopticMode);
                    if (panopticMode === 'overwrite') {
                        this.eraseSegmentFromOthers(this._editingMaskAnnoId, { x: this.lastPaintPos.x, y: this.lastPaintPos.y }, { x: clamped.x, y: clamped.y }, size, shape);

                        // Same must-overlap-specific transfer as mousedown,
                        // over the whole swept segment (not just the
                        // endpoint) so a fast drag can't skip past it.
                        // Reuses segMask (already exactly "this segment,
                        // clipped to the boundary") instead of rebuilding it.
                        if (segMask) {
                            const segRect = {
                                x: Math.min(this.lastPaintPos.x, clamped.x) - size / 2,
                                y: Math.min(this.lastPaintPos.y, clamped.y) - size / 2,
                                w: Math.abs(clamped.x - this.lastPaintPos.x) + size,
                                h: Math.abs(clamped.y - this.lastPaintPos.y) + size
                            };
                            const mustOverlapHit = this.findMustOverlapTargets(segRect, this._editingMaskAnnoId);
                            if (mustOverlapHit.length) this.absorbMustOverlapTargets(mustOverlapHit, segMask);
                        }
                    }

                    this.renderBrushLayer();
                }
                this.lastPaintPos = { x: clamped.x, y: clamped.y };
            } else if (this.activeTool === 'polygon' && this.isDrawing) {
                const clamped = this.clampToImage(x, y);
                if (this.freehandPolygonMode && e.buttons === 1) {
                    const lastPt = this.currentPoints[this.currentPoints.length - 1];
                    const dist = Math.hypot(clamped.x - lastPt.x, clamped.y - lastPt.y);
                    if (dist > 5) {
                        this.currentPoints.push({x: clamped.x, y: clamped.y});
                    }
                }
                this.renderCurrentPolygon(clamped.x, clamped.y);
            }
        }
    }

    // Ends an active move drag: resets the cursor, then permanently bakes in
    // a flat boundary cut for whatever part of the shape ended up outside
    // the image (see cropAnnotationOutlineToImageBounds) — this is a real
    // data change, not a transient render-time clip, so the cut survives
    // being dragged somewhere else afterward. If nothing is left at all, the
    // annotation is discarded.
    finalizeMove() {
        this.isMoving = false;

        const wrapper = document.getElementById('videoTransformWrapper');
        if (wrapper) wrapper.style.cursor = 'default';

        // Restore real clipping first and unconditionally (before any early
        // return below), so it can never get stuck in the drag's temporary
        // "visible" state. Same for the drag-overflow indicator — it must
        // never survive past the drag it was shown for.
        const boundsBox = document.getElementById('imageBoundsBox');
        if (boundsBox) boundsBox.style.overflow = 'hidden';
        this.hideDragOverflowIndicator();

        this.endGesture();

        if (!this.selectedAnnotationId) return;
        const anno = this.annotations.find(a => a.id === this.selectedAnnotationId);
        if (!anno) return;

        if (anno.type === 'brush' && anno.maskCanvas) {
            const dx = Math.round(this._liveMoveOffsetX || 0);
            const dy = Math.round(this._liveMoveOffsetY || 0);
            this._liveMoveOffsetX = 0;
            this._liveMoveOffsetY = 0;

            // Bake the drag offset into the raster itself so the canvas
            // stays anchored at (0,0) — anything dragged past the image
            // edge is naturally clipped by drawImage against the
            // fixed-size canvas, no separate crop/outline math needed.
            const baked = this.createFullSizeCanvas();
            baked.getContext('2d').drawImage(anno.maskCanvas, dx, dy);
            anno.maskCanvas = baked;
            anno.offsetX = 0;
            anno.offsetY = 0;
            this._invalidateBBox(anno);

            if (this.isMaskEmpty(anno.maskCanvas)) {
                this.deleteAnnotationById(this.selectedAnnotationId);
                return;
            }
        } else if (anno.type === 'polygon' && anno.points) {
            this.cropAnnotationOutlineToImageBounds(anno);
            if (!(anno.points && anno.points.length >= 3)) {
                this.deleteAnnotationById(this.selectedAnnotationId);
                return;
            }
        }

        this.renderAllAnnotations();
    }

    handleCanvasMouseUp(e) {
        if (this._groupMoving) {
            this.finalizeGroupMove();
            return;
        }

        if (this._marqueeStart) {
            const wasRealDrag = this._marqueeMoved;
            this._marqueeStart = null;
            this._marqueeMoved = false;
            // finishMarqueeSelect() reads this._marqueeRectValue — must run
            // BEFORE clearMarqueeVisual() nulls it back out.
            if (wasRealDrag) {
                const selectedCount = this.finishMarqueeSelect();
                if (!selectedCount) this.showToast('No objects inside the selection box.');
            } else {
                this.showToast('Please select a class from the list on the right before drawing!');
            }
            this.clearMarqueeVisual();
            return;
        }

        if (this.isMoving) {
            this.finalizeMove();
        }
        if (this.isErasing) {
            this.isErasing = false;
            this.endGesture();
            this.lastEraseX = undefined;
            this.lastEraseY = undefined;

            const anno = this.selectedAnnotationId && this.annotations.find(a => a.id === this.selectedAnnotationId);
            if (anno && anno.type === 'brush' && anno.maskCanvas && this.isMaskEmpty(anno.maskCanvas)) {
                this.deleteAnnotationById(anno.id);
            }
        }
        
        if (this.activeTool === 'brush' && this.isDrawing) {
            this.commitCurrentStroke();
        }
        
        // Ensure cursor is restored if mouse is released outside the image
        if ((this.activeTool === 'brush' || this.activeTool === 'eraser') && e) {
            const { x, y } = this.getCanvasCoords(e);

            if (!this.isInsideImage(x, y) || !this.isPointerOverImagePanel(e) || this.isPointerOverFloatingUI(e)) {
                const wrapper = document.getElementById('videoTransformWrapper');
                const brushCursor = document.getElementById('brushCursor');
                if (wrapper) {
                    wrapper.style.cursor = 'default';
                    wrapper.classList.remove('tool-brush', 'tool-eraser');
                }
                if (brushCursor) {
                    brushCursor.style.display = 'none';
                    brushCursor.classList.add('hidden');
                }
            }
        }
    }

    // Drag-marquee multi-select — draws/grows the selection box itself as
    // an SVG rect in image space (same coordinate system as annotation
    // points, so no separate scale math is needed here).
    updateMarqueeRect(x1, y1, x2, y2) {
        const rect = { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1), h: Math.abs(y2 - y1) };
        this._marqueeRectValue = rect;
        let el = document.getElementById('marqueeSelectRect');
        if (!el) {
            const svg = document.getElementById('annotationCanvas');
            if (!svg) return;
            el = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            el.id = 'marqueeSelectRect';
            el.setAttribute('fill', 'rgba(255, 255, 255, 0.08)');
            el.setAttribute('stroke', '#ffffff');
            el.setAttribute('stroke-width', '1');
            el.setAttribute('stroke-dasharray', '4 3');
            el.style.pointerEvents = 'none';
            svg.appendChild(el);
        }
        el.setAttribute('x', rect.x);
        el.setAttribute('y', rect.y);
        el.setAttribute('width', rect.w);
        el.setAttribute('height', rect.h);
    }

    clearMarqueeVisual() {
        this._marqueeRectValue = null;
        const el = document.getElementById('marqueeSelectRect');
        if (el) el.remove();
    }

    // Unified image-space bounding box for either annotation type — brush
    // masks store their tight bbox relative to the mask canvas (offset by
    // offsetX/offsetY, same as addTextAndHover's tag anchor); polygons have
    // no offset concept, so their points are already absolute. While a
    // group-move drag is live, brush shapes also carry a transient
    // _liveGroupOffsetX/Y (see moveGroupBy()) that isn't baked into
    // offsetX/Y until finalizeGroupMove() — folded in here so the group
    // bbox tracks the drag in real time. Polygons need no such branch:
    // moveGroupBy() mutates their points directly and immediately.
    getAnnoBoundsRect(anno) {
        if (anno.type === 'brush' && anno.maskCanvas) {
            const bbox = this.getAnnoBBox(anno);
            if (!bbox || bbox.w <= 0 || bbox.h <= 0) return null;
            const liveOx = this._groupMoving ? (anno._liveGroupOffsetX || 0) : 0;
            const liveOy = this._groupMoving ? (anno._liveGroupOffsetY || 0) : 0;
            return { x: bbox.x + (anno.offsetX || 0) + liveOx, y: bbox.y + (anno.offsetY || 0) + liveOy, w: bbox.w, h: bbox.h };
        }
        if (anno.type === 'polygon' && anno.points && anno.points.length > 0) {
            const xs = anno.points.map(p => p.x), ys = anno.points.map(p => p.y);
            const minX = Math.min(...xs), maxX = Math.max(...xs);
            const minY = Math.min(...ys), maxY = Math.max(...ys);
            return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
        }
        return null;
    }

    // Union bounding box of the whole drag-marquee multi-selection, in
    // image space — the single rectangle drawn by updateGroupSelectionBBox()
    // and the hit-region handleCanvasMouseDown checks to start a group move.
    getGroupBoundsRect() {
        if (this.multiSelectedIds.size === 0) return null;
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        this.multiSelectedIds.forEach(id => {
            const anno = this.annotations.find(a => a.id === id);
            if (!anno) return;
            const b = this.getAnnoBoundsRect(anno);
            if (!b) return;
            minX = Math.min(minX, b.x);
            minY = Math.min(minY, b.y);
            maxX = Math.max(maxX, b.x + b.w);
            maxY = Math.max(maxY, b.y + b.h);
        });
        if (!isFinite(minX)) return null;
        return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
    }

    // Single solid rectangle around the whole multi-selection (replacing a
    // per-shape highlight) — matches the product reference: "which things
    // are selected" is shown as one group bbox, not N separate outlines.
    // Called from renderAllAnnotations() so it always tracks reality
    // without needing a call at every single mutation site.
    updateGroupSelectionBBox() {
        const svg = document.getElementById('annotationCanvas');
        let el = document.getElementById('groupSelectBBox');
        const box = this.getGroupBoundsRect();
        if (!box) {
            if (el) el.remove();
            return;
        }
        if (!el) {
            if (!svg) return;
            el = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            el.id = 'groupSelectBBox';
            el.setAttribute('fill', 'none');
            el.setAttribute('stroke', '#1d4ed8');
            el.style.pointerEvents = 'none';
            svg.appendChild(el);
        }
        const scale = this.workspace && this.workspace.transform ? this.workspace.transform.scale : 1;
        const pad = 6 / scale;
        el.setAttribute('stroke-width', (1.5 / scale).toString());
        el.setAttribute('x', box.x - pad);
        el.setAttribute('y', box.y - pad);
        el.setAttribute('width', box.w + pad * 2);
        el.setAttribute('height', box.h + pad * 2);
    }

    // An annotation is selected as soon as the drag box touches ANY part
    // of its bounding box — not just when the box fully encloses it. Full
    // containment was tried first, but an irregular/elongated shape (a
    // road marking, a cable, anything not roughly box-shaped) routinely
    // has its bbox corners sit outside any reasonably-sized drag box even
    // when the box clearly covers the shape itself, so requiring full
    // bbox containment silently dropped exactly the shapes a user was
    // visibly dragging over. A standard AABB-intersection test instead —
    // same "does the box touch this" rule most rubber-band selection UIs
    // (Figma, Photoshop, etc.) use.
    finishMarqueeSelect() {
        const box = this._marqueeRectValue;
        if (!box || box.w < 2 || box.h < 2) return 0;
        const covered = this.annotations.filter(a => {
            if (!a.visible || a.locked) return false;
            const b = this.getAnnoBoundsRect(a);
            if (!b) return false;
            return b.x < box.x + box.w && b.x + b.w > box.x && b.y < box.y + box.h && b.y + b.h > box.y;
        });
        if (covered.length === 0) return 0;

        this.multiSelectedIds = new Set(covered.map(a => a.id));
        // Multi-select and the single edit-mode selection are mutually
        // exclusive — dragging a box supersedes whatever was individually
        // selected/being edited before.
        this.selectedAnnotationId = null;
        const toolbar = document.getElementById('annotatorToolbar');
        if (toolbar) toolbar.classList.add('hidden');
        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
        return covered.length;
    }

    // Releases the drag-marquee multi-selection without deleting anything —
    // called whenever the user moves on to a different action (picking a
    // class, selecting a single object, Escape) per the product ask that a
    // stale multi-selection shouldn't silently linger once you've clearly
    // moved on from it.
    clearMultiSelection() {
        if (this.multiSelectedIds.size === 0) return;
        this.multiSelectedIds.clear();
        this.renderAllAnnotations();
    }

    // Drags the whole multi-selection together, called once per mousemove
    // tick with the incremental delta since the last tick — same
    // incremental-delta convention as the single-shape moveAnnotation().
    // Polygons are moved by direct point mutation (same as
    // moveAnnotation()'s own polygon branch — already "live", no baking
    // needed); brush shapes accumulate a transient per-annotation live
    // offset (mirroring _liveMoveOffsetX/Y for a single shape, but keyed
    // per-id since several brush shapes can be moving at once) that
    // finalizeGroupMove() bakes into their raster at drag end.
    moveGroupBy(dx, dy) {
        this.multiSelectedIds.forEach(id => {
            const anno = this.annotations.find(a => a.id === id);
            if (!anno || !anno.visible || anno.locked) return;
            this.markDirty();
            if (anno.type === 'brush') {
                anno._liveGroupOffsetX = (anno._liveGroupOffsetX || 0) + dx;
                anno._liveGroupOffsetY = (anno._liveGroupOffsetY || 0) + dy;
            } else if (anno.type === 'polygon' && anno.points) {
                anno.points.forEach(p => { p.x += dx; p.y += dy; });
                if (anno.eraserStrokes) {
                    anno.eraserStrokes.forEach(stroke => {
                        if (!stroke.points) return;
                        stroke.points.forEach(p => { p.x += dx; p.y += dy; });
                    });
                }
            }
        });
        this.renderAllAnnotations();
    }

    // Bakes every brush shape's live group offset into its raster (same
    // reasoning as finalizeMove()) and crops every polygon back to the
    // image bounds; drops any shape a move left empty/degenerate.
    finalizeGroupMove() {
        this._groupMoving = false;
        const wrapper = document.getElementById('videoTransformWrapper');
        if (wrapper) {
            wrapper.style.cursor = 'default';
            wrapper.classList.remove('group-moving');
        }
        const boundsBox = document.getElementById('imageBoundsBox');
        if (boundsBox) boundsBox.style.overflow = 'hidden';
        this.endGesture();

        const toDrop = [];
        this.multiSelectedIds.forEach(id => {
            const anno = this.annotations.find(a => a.id === id);
            if (!anno) return;
            if (anno.type === 'brush' && anno.maskCanvas) {
                const dx = Math.round(anno._liveGroupOffsetX || 0);
                const dy = Math.round(anno._liveGroupOffsetY || 0);
                anno._liveGroupOffsetX = 0;
                anno._liveGroupOffsetY = 0;
                const baked = this.createFullSizeCanvas();
                baked.getContext('2d').drawImage(anno.maskCanvas, dx, dy);
                anno.maskCanvas = baked;
                anno.offsetX = 0;
                anno.offsetY = 0;
                this._invalidateBBox(anno);
                if (this.isMaskEmpty(anno.maskCanvas)) toDrop.push(id);
            } else if (anno.type === 'polygon' && anno.points) {
                this.cropAnnotationOutlineToImageBounds(anno);
                if (!(anno.points && anno.points.length >= 3)) toDrop.push(id);
            }
        });
        if (toDrop.length > 0) {
            const dropSet = new Set(toDrop);
            this.annotations = this.annotations.filter(a => !dropSet.has(a.id));
            toDrop.forEach(id => this.multiSelectedIds.delete(id));
        }

        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
    }

    // Batched delete for the drag-marquee multi-selection — one undo
    // snapshot for the whole group, same as a single deleteAnnotation()
    // call, rather than one snapshot per shape.
    deleteMultiSelected() {
        const ids = Array.from(this.multiSelectedIds);
        if (ids.length === 0) return;
        this.snapshotBeforeAction();
        const idSet = new Set(ids);
        this.annotations = this.annotations.filter(a => !idSet.has(a.id));
        this.multiSelectedIds.clear();
        if (idSet.has(this.selectedAnnotationId)) {
            this.selectedAnnotationId = null;
            const toolbar = document.getElementById('annotatorToolbar');
            if (toolbar) toolbar.classList.add('hidden');
            this.activeLabel = null;
            this.activeColor = null;
            this.selectTool(null);
        }
        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
    }

    // Right-click popover for the drag-marquee multi-selection — "N OBJECTS
    // SELECTED" header plus a "Combine bitmasks into ▸" row whose flyout
    // lists each currently-selected object; picking one merges every OTHER
    // selected object's silhouette into that one (see mergeSelectedInto()).
    // Built fresh each time (not a static element in the .html file) since
    // its content depends entirely on whatever's selected right now.
    openMultiSelectContextMenu(e) {
        document.getElementById('multiSelectContextMenu')?.remove();

        const ids = Array.from(this.multiSelectedIds);
        const items = ids
            .map(id => this.annotations.find(a => a.id === id))
            .filter(Boolean);
        if (items.length < 2) return;

        const chevronSvg = `<svg viewBox="64 64 896 896" focusable="false" width="10px" height="10px" fill="currentColor"><path d="M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z"></path></svg>`;
        const combineSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14px" height="14px"><rect x="3" y="3" width="8" height="8" rx="1"></rect><rect x="13" y="13" width="8" height="8" rx="1"></rect><path d="M11 7h6a2 2 0 0 1 2 2v4"></path></svg>`;
        const itemLabel = (anno) => `${anno.class} (${this.getDisplayInstanceNumber(anno)})`;

        const menu = document.createElement('div');
        menu.id = 'multiSelectContextMenu';
        menu.className = 'fixed bg-white border border-gray-200 shadow-xl rounded-xl py-1.5 w-[220px] z-[100000] font-sans';

        const header = document.createElement('div');
        header.className = 'px-3.5 pt-1.5 pb-2 text-[11px] font-semibold text-gray-400 tracking-wide uppercase';
        header.textContent = `${items.length} objects selected`;
        menu.appendChild(header);

        const divider = document.createElement('div');
        divider.className = 'menu-divider';
        menu.appendChild(divider);

        const combineRow = document.createElement('div');
        combineRow.className = 'menu-item relative justify-between';
        combineRow.innerHTML = `<div class="flex items-center gap-3">${combineSvg}<span>Combine bitmasks into</span></div>${chevronSvg}`;
        menu.appendChild(combineRow);

        const subMenu = document.createElement('div');
        subMenu.className = 'hidden absolute top-0 left-full ml-1 w-[190px] bg-white border border-gray-200 shadow-xl rounded-xl py-1.5';
        items.forEach(anno => {
            const swatchColor = this.getEffectiveColor(anno);
            const row = document.createElement('div');
            row.className = 'menu-item';
            row.innerHTML = `<span class="inline-block w-2.5 h-2.5 rounded-sm flex-shrink-0" style="background:${swatchColor}"></span><span>${itemLabel(anno)}</span>`;
            row.onclick = (ev) => {
                ev.stopPropagation();
                menu.remove();
                this.mergeSelectedInto(anno.id);
            };
            subMenu.appendChild(row);
        });
        combineRow.appendChild(subMenu);

        const showSub = () => subMenu.classList.remove('hidden');
        const hideSub = () => subMenu.classList.add('hidden');
        combineRow.addEventListener('mouseenter', showSub);
        combineRow.addEventListener('mouseleave', hideSub);

        document.body.appendChild(menu);
        const menuWidth = menu.offsetWidth, menuHeight = menu.offsetHeight;
        menu.style.left = `${Math.max(4, Math.min(window.innerWidth - menuWidth - 4, e.clientX))}px`;
        menu.style.top = `${Math.max(4, Math.min(window.innerHeight - menuHeight - 4, e.clientY))}px`;
        // Flip the flyout to the LEFT of the main menu instead of off the
        // right edge of the screen, same clamping idea as the menu itself.
        if (menu.offsetLeft + menuWidth + 190 + 4 > window.innerWidth) {
            subMenu.classList.remove('left-full', 'ml-1');
            subMenu.classList.add('right-full', 'mr-1');
        }

        const closeMenu = (ev) => {
            if (!menu.contains(ev.target)) {
                menu.remove();
                window.removeEventListener('mousedown', closeMenu);
            }
        };
        setTimeout(() => window.addEventListener('mousedown', closeMenu), 0);
    }

    // Merges every OTHER currently multi-selected object's silhouette into
    // `targetId`'s own raster mask, then discards those other objects —
    // "Combine bitmasks into <target>" from openMultiSelectContextMenu().
    // renderAnnotationStencil() already knows how to rasterize EITHER a
    // brush OR a polygon annotation (eraserStrokes/panoptic cuts baked in,
    // whichever type each source happens to be) — reused here as-is rather
    // than re-deriving a raster silhouette per source type, so a polygon
    // merged into a bitmask target converts for free as part of the same
    // union draw.
    mergeSelectedInto(targetId) {
        const ids = Array.from(this.multiSelectedIds);
        const target = this.annotations.find(a => a.id === targetId);
        if (!target || ids.length < 2) return;

        this.snapshotBeforeAction();

        if (!target.maskCanvas) target.maskCanvas = this.createFullSizeCanvas();
        const tctx = target.maskCanvas.getContext('2d');
        ids.forEach(id => {
            if (id === targetId) return;
            const source = this.annotations.find(a => a.id === id);
            if (!source) return;
            const stencil = this.renderAnnotationStencil(source, source.offsetX || 0, source.offsetY || 0);
            tctx.drawImage(stencil, 0, 0);
        });

        // Recolor the WHOLE merged silhouette (the target's own original
        // pixels included) to the target's class color — matches the
        // reference: after merging, the combined shape reads as one single
        // instance's color, not a patchwork of whatever colors the sources
        // were painted in. source-in keeps this canvas's own alpha exactly
        // as-is (the just-unioned silhouette) and only swaps the RGB
        // wherever that alpha is already nonzero.
        const recolored = this.createFullSizeCanvas();
        const rctx = recolored.getContext('2d');
        rctx.drawImage(target.maskCanvas, 0, 0);
        rctx.globalCompositeOperation = 'source-in';
        rctx.fillStyle = target.color || '#4a90e2';
        rctx.fillRect(0, 0, recolored.width, recolored.height);
        target.maskCanvas = recolored;
        target.type = 'brush';
        target.points = null;
        target.offsetX = 0;
        target.offsetY = 0;
        this._invalidateBBox(target);

        const idsToRemove = new Set(ids.filter(id => id !== targetId));
        this.annotations = this.annotations.filter(a => !idsToRemove.has(a.id));

        this.multiSelectedIds.clear();
        this.selectedAnnotationId = target.id;

        this.renderAllAnnotations();
        this.updateLabelsPanel();
        this.updateClassCounts();
    }

    commitCurrentStroke() {
        this.endGesture();
        this.isDrawing = false;
        this.lastPaintPos = null;

        // Painting into the canvas already IS the paint operation for the
        // raster brush — there's no separate point-array to fold in here.
        // Just tidy up state and, if editing an existing annotation, check
        // whether it was erased down to nothing.
        if (this._editingMaskAnnoId) {
            const anno = this.annotations.find(a => a.id === this._editingMaskAnnoId);
            this._editingMaskAnnoId = null;
            if (anno) {
                this._invalidateBBox(anno);
                if (this.isMaskEmpty(anno.maskCanvas)) {
                    this.deleteAnnotationById(anno.id);
                    return;
                }
            }
        }

        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();

        // We'll let them hit Enter to finalize a brand-new brush annotation,
        // or clicking Finish — this.currentMaskCanvas persists across
        // further strokes until then.
    }

    // `mode` is 'none' | 'exclude' | 'overwrite'. With an annotation
    // selected (editing), this changes THAT annotation's own panoptic
    // behavior; otherwise it's the mode new annotations get created with
    // (see finishPolygon()). Either way, the actual exclude/overwrite pixel
    // clipping is computed in renderBrushLayer()/renderAnnotationStencil()
    // every render — this just sets the flag and re-renders.
    setPanopticMode(mode) {
        this.panopticMode = mode;

        if (this.selectedAnnotationId) {
            const anno = this.annotations.find(a => a.id === this.selectedAnnotationId);
            if (anno) anno.panopticMode = mode;
        }

        this.syncPanopticModeUI();
        this.renderAllAnnotations();
    }

    syncPanopticModeUI() {
        const container = document.getElementById('panopticModeContainer');
        if (!container) return;
        const mode = this.panopticMode || 'none';
        container.querySelectorAll('button[data-mode]').forEach(btn => {
            const isActive = btn.dataset.mode === mode;
            btn.classList.toggle('bg-white', isActive);
            btn.classList.toggle('shadow-sm', isActive);
            btn.classList.toggle('font-medium', isActive);
            btn.classList.toggle('text-[#1a202c]', isActive);
            btn.classList.toggle('text-[#718096]', !isActive);
            btn.classList.toggle('hover:text-[#2d3748]', !isActive);
        });
    }

    toggleFreehand() {
        this.freehandPolygonMode = !this.freehandPolygonMode;
        const btn = document.getElementById('freehandToggleBtn');
        const dot = document.getElementById('freehandToggleDot');
        if (btn && dot) {
            if (this.freehandPolygonMode) {
                btn.classList.remove('bg-gray-200');
                btn.classList.add('bg-[#1d4ed8]');
                dot.classList.remove('translate-x-0');
                dot.classList.add('translate-x-3');
            } else {
                btn.classList.add('bg-gray-200');
                btn.classList.remove('bg-[#1d4ed8]');
                dot.classList.add('translate-x-0');
                dot.classList.remove('translate-x-3');
            }
        }
    }

    // Opens the drawer and lazily builds its section list
    // (renderSettingsSections(), defined in the page's own inline script)
    // the first time. Label display and General are wired to real
    // behavior (see setLabelDisplaySetting()/setInvertWheelZoom() below);
    // the remaining sections are still placeholder-only — see the HTML
    // comment on #settingsDrawer.
    openSettingsDrawer() {
        if (typeof renderSettingsSections === 'function') renderSettingsSections();
        const overlay = document.getElementById('settingsDrawerOverlay');
        const drawer = document.getElementById('settingsDrawer');
        if (overlay) overlay.classList.remove('hidden');
        if (drawer) drawer.style.transform = 'translateX(0)';
    }

    closeSettingsDrawer() {
        const overlay = document.getElementById('settingsDrawerOverlay');
        const drawer = document.getElementById('settingsDrawer');
        if (overlay) overlay.classList.add('hidden');
        if (drawer) drawer.style.transform = 'translateX(100%)';
    }

    // Called from the settings drawer's own slider script (in the .html
    // file) on every drag/click — `key` matches each slider's own
    // data-key (see LABEL_DISPLAY_SLIDERS), `value` is its raw slider
    // value (0-100 for the opacity sliders, 6-48px for font size).
    setLabelDisplaySetting(key, value) {
        if (key === 'fillOpacity') this.objectFillOpacity = value / 100;
        else if (key === 'selectedFillOpacity') this.selectedObjectFillOpacity = value / 100;
        else if (key === 'fontSize') this.objectLabelFontSize = value;
        else return;
        this.renderAllAnnotations();
    }

    // Called from the settings drawer's General section toggle.
    setInvertWheelZoom(enabled) {
        this.invertWheelZoom = enabled;
    }

    // Called from the settings drawer's Label display > Label color mode
    // toggle (By class / By object). Persisted so it survives closing and
    // reopening the editor, same as collapsedGroups elsewhere.
    setLabelColorMode(mode) {
        if (mode !== 'class' && mode !== 'object') return;
        this.labelColorMode = mode;
        sessionStorage.setItem('labelColorMode', mode);
        this.renderAllAnnotations();
    }

    // The color actually used to render `anno` — its class's shared color
    // in "class" mode, or its own permanently-assigned objectColor (see
    // finishPolygon()'s newAnnotation) in "object" mode. Rendering (and
    // export — see the comment on renderAnnotationStencil()) should always
    // go through this rather than reading anno.color directly, so the two
    // modes actually differ on screen.
    getEffectiveColor(anno) {
        if (this.labelColorMode === 'object' && anno.objectColor) return anno.objectColor;
        return anno.color || '#4a90e2';
    }

    // Golden-angle hue stepping (~137.5° per call) so consecutive objects
    // land far apart on the color wheel — plain evenly-divided steps drift
    // through neighboring hues instead once the count isn't known ahead of
    // time, which it isn't here (objects get created one at a time).
    nextObjectColor() {
        const hue = (this._objectColorCounter * 137.508) % 360;
        this._objectColorCounter++;
        return `hsl(${hue.toFixed(1)}, 70%, 50%)`;
    }

    handleCanvasKeyDown(e) {
        const active = document.activeElement;
        const inField = !!active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA');

        // Brush/eraser size — ] grows, [ shrinks (Photoshop's convention);
        // Shift for a bigger jump. Matches the shortcut hint on the Size
        // row's tooltip in the toolbar.
        if (!inField && (e.key === ']' || e.key === '[') && (this.activeTool === 'brush' || this.activeTool === 'eraser')) {
            e.preventDefault();
            const step = e.shiftKey ? 25 : 5;
            const current = this.brushSize || 50;
            this.updateSize(current + (e.key === ']' ? step : -step));
            return;
        }

        // Undo / Redo. Disabled mid-gesture (drawing/erasing/moving) so a
        // half-finished stroke never gets silently rewritten out from under
        // the user — Escape (below) is the existing way to bail out of that.
        if (!inField && (e.ctrlKey || e.metaKey) && !e.altKey && (e.key === 'z' || e.key === 'Z')) {
            e.preventDefault();
            if (this.isDrawing || this.isErasing || this.isMoving) return;
            if (e.shiftKey) this.redo(); else this.undo();
            return;
        }
        if (!inField && (e.ctrlKey || e.metaKey) && !e.altKey && (e.key === 'y' || e.key === 'Y')) {
            e.preventDefault();
            if (this.isDrawing || this.isErasing || this.isMoving) return;
            this.redo();
            return;
        }

        // Draw-mode tool shortcuts (F/H/G) — plain letters, so guarded by
        // !inField like the undo/redo shortcuts above, and skipped while a
        // modifier key is held so they don't fight any OS/browser shortcut
        // that happens to share the same letter.
        //
        // H (eraser) and G (polygon) are further gated to whichever mode
        // actually shows that tool's button — see the Move/Brush/Eraser vs.
        // Brush/Polygon split in renderAllAnnotations(). Without this, the
        // shortcut could switch activeTool to a tool whose toolbar button
        // is hidden (e.g. eraser while still in create mode), leaving the UI
        // showing no active tool selected while eraser silently behaves as
        // active. Brush (F) has no such restriction — its button is visible
        // in both modes.
        // !e.shiftKey here too — Shift+H is reserved globally for
        // "hide/unhide all labels" (see WorkspaceManager.bindShortcuts()),
        // not this eraser-tool shortcut; without this guard, Shift+H in
        // edit mode fired BOTH bound keydown listeners and silently
        // switched to the eraser tool in addition to toggling visibility.
        if (!inField && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey &&
            (e.key === 'f' || e.key === 'F' || e.key === 'h' || e.key === 'H' || e.key === 'g' || e.key === 'G')) {
            const isEditMode = !!this.selectedAnnotationId;
            if ((e.key === 'h' || e.key === 'H') && !isEditMode) return;
            if ((e.key === 'g' || e.key === 'G') && isEditMode) return;
            e.preventDefault();
            if (e.key === 'f' || e.key === 'F') this.selectTool('brush');
            else if (e.key === 'h' || e.key === 'H') this.selectTool('eraser');
            else this.selectTool('polygon');
            return;
        }

        if (e.key === 'd' || e.key === 'D') {
            if (this.activeTool === 'polygon') {
                this.toggleFreehand();
            }
        } else if (e.key === 'Enter' || e.key === 'Escape') {
            if (this._hasPendingDrawing()) {
                if (e.key === 'Enter') {
                    this.finishPolygon();
                } else {
                    this.currentPoints = [];
                    this.currentMaskCanvas = null;
                    this.lastPaintPos = null;
                    this._editingMaskAnnoId = null;
                    this.isDrawing = false;
                    this.renderCurrentPolygon();
                    this.renderBrushLayer();
                }
            }
            this._resetToolbarState();
        } else if ((e.key === 'Delete' || e.key === 'Backspace') && this.multiSelectedIds.size > 0) {
            this.deleteMultiSelected();
        } else if ((e.key === 'Delete' || e.key === 'Backspace') && this.selectedAnnotationId) {
            this.deleteAnnotation(this.selectedAnnotationId);
        }
    }

    // Deselects everything and returns the toolbar to its neutral,
    // no-tool-active state — the second half of what Enter/Escape both do
    // in handleCanvasKeyDown(), factored out so finishActiveDrawing() (the
    // toolbar's own Finish button) can reuse it instead of duplicating it.
    _resetToolbarState() {
        this.selectedAnnotationId = null;
        this.multiSelectedIds.clear();
        this.activeLabel = null;
        this.activeColor = null;
        this.selectTool(null);

        const toolbar = document.getElementById('annotatorToolbar');
        if (toolbar) toolbar.classList.add('hidden');

        document.querySelectorAll('.class-group .rounded-md').forEach(el => {
            el.classList.remove('bg-gray-200');
            el.classList.add('hover:bg-gray-100');
        });

        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') {
            this.updateLabelsPanel();
        }
    }

    // Click equivalent of pressing Enter (see handleCanvasKeyDown()) —
    // commits whatever's currently pending (a polygon's points, an
    // in-progress brush mask, or both) and resets the toolbar. Bound to the
    // toolbar's own green checkmark button (#btnFinishAnnotation, shown by
    // syncFinishButtonVisibility() only while _hasPendingDrawing() is true)
    // so annotators aren't required to use the keyboard to finish a shape.
    finishActiveDrawing() {
        if (this._hasPendingDrawing()) {
            this.finishPolygon();
        }
        this._resetToolbarState();
    }

    // Called from the wrapper's contextmenu handler (see bindCanvasEvents())
    // — removes the last vertex placed for the polygon currently being
    // drawn and redraws the in-progress preview. Resets isDrawing back to
    // false once popping empties currentPoints entirely, same as it was
    // before the first point went down; _hasPendingDrawing()'s other
    // checks (currentMaskCanvas) still correctly report a pending drawing
    // on their own if a brush mask is also in progress underneath.
    undoLastPolygonPoint() {
        if (!this.currentPoints || this.currentPoints.length === 0) return;
        this.currentPoints.pop();
        if (this.currentPoints.length === 0) this.isDrawing = false;
        this.renderCurrentPolygon();
    }

    renderCurrentPolygon(mx, my) {
        const g = document.getElementById('currentPolygon');
        if (!g) return;

        g.innerHTML = '';

        // Live brush preview is painted straight onto #brushMaskCanvas by
        // renderBrushLayer() (see the mousedown/mousemove handlers) — there's
        // no SVG geometry to build for it here.
        if (this.activeTool === 'brush') return;

        // Live drawing preview is always cut flush at the image edges/corners.
        this.getImageBounds();
        g.setAttribute('clip-path', 'url(#imageAreaClip)');

        if (!this.currentPoints || this.currentPoints.length === 0) {
            this._cachedPolyline = null;
            return;
        }

        const color = this.activeColor || '#4a90e2';
        // Annotation-space is native image pixels, not screen pixels — these
        // are UI-chrome constants (vertex dots, thin preview line) that must
        // stay a constant SCREEN size regardless of zoom or image resolution,
        // exactly like addTextAndHover() already does for tag labels.
        //
        // vector-effect: non-scaling-stroke does NOT help here — it only
        // cancels transforms applied INSIDE the SVG document (a nested <g
        // transform=...>, a viewBox), not the CSS transform:scale() this
        // app's zoom applies to #videoTransformWrapper, an ANCESTOR of this
        // whole SVG. A "non-scaling" 1.5px stroke still gets uniformly
        // magnified right along with everything else once that ancestor
        // transform composites — confirmed by pixel-measuring an actual
        // screenshot: at 5x zoom it rendered ~8 device px thick, not 1.5.
        //
        // Dividing by scale is what actually works — and, contrary to an
        // earlier version of this code, needs NO floor clamp: pixel-
        // measuring the ACTUAL rendered color at scale 1 vs 15 with an
        // unclamped width showed IDENTICAL blending (a sub-pixel SVG stroke
        // does not get progressively paler as it shrinks, unlike a CSS
        // border, which does have a real rounding floor — that assumption
        // was carried over from the crosshair fix without re-verifying it
        // for SVG). The floor this used to have (0.35) was the actual bug:
        // at scale > ~4 it clamped the WIDTH to grow linearly with zoom
        // instead of staying constant, which is exactly the "not fixed
        // when zoomed in" symptom. Target width bumped 1.5 -> 2: measured
        // 1.5 as a slightly pale blend even at scale 1 (not a zoom-related
        // issue, just genuinely thin); 2 renders as a fully-saturated,
        // solid line at every scale tested.
        const scale = this.workspace && this.workspace.transform ? this.workspace.transform.scale : 1;
        const lineWidth = 2 / scale;

        let pts = "";
        const len = this.currentPoints.length;
        for (let i = 0; i < len; i++) {
            pts += this.currentPoints[i].x + "," + this.currentPoints[i].y + " ";
        }
        if (mx !== undefined && my !== undefined) {
            pts += mx + "," + my;
        }

        // Live fill preview — closes the CURRENT (possibly still
        // open/unfinished) points including the live mouse position into a
        // translucent polygon, matching the same 0.3 opacity a committed
        // polygon annotation renders at (see renderBrushLayer()'s
        // `anno.type === 'polygon' ? 0.3 : ...`), so the shape reads with
        // its real color while you're still placing points instead of only
        // once Enter commits it. Needs at least 3 points to look like
        // anything; below that it'd just be a zero-area sliver.
        const trimmedPts = pts.trim();
        if (trimmedPts.split(' ').length >= 3) {
            const previewFill = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
            previewFill.setAttribute('points', trimmedPts);
            previewFill.setAttribute('fill', color);
            previewFill.setAttribute('fill-opacity', '0.3');
            previewFill.setAttribute('stroke', 'none');
            g.appendChild(previewFill);
        }

        const polyline = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
        polyline.setAttribute('points', trimmedPts);
        polyline.setAttribute('fill', 'none');
        polyline.setAttribute('stroke', color);
        polyline.setAttribute('stroke-width', lineWidth.toString());

        for (let i = 0; i < len; i++) {
            const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
            circle.setAttribute('cx', this.currentPoints[i].x);
            circle.setAttribute('cy', this.currentPoints[i].y);
            circle.setAttribute('r', (3 / scale).toString());
            circle.setAttribute('fill', color);
            g.appendChild(circle);
        }
        g.appendChild(polyline);
    }

    // Folds the current in-progress polygon loop (this.currentPoints) into
    // this.currentMaskCanvas — creating it if this is the first shape drawn
    // for this pending instance — using the same fillStyle + beginPath/
    // lineTo/closePath/fill pattern renderAnnotationStencil() uses for
    // already-committed polygon annotations. This is what lets brush and
    // polygon compose into ONE eventual annotation: switching tools
    // mid-instance (selectTool()) or closing a polygon loop while a mask is
    // already pending (handleCanvasMouseDown()) call this instead of
    // finishPolygon(), so the shape stays open — pending an explicit Enter
    // — rather than committing (and resetting activeLabel/activeTool)
    // immediately.
    mergeCurrentPolygonIntoMask() {
        if (!this.currentPoints || this.currentPoints.length < 3) {
            this.currentPoints = [];
            this.renderCurrentPolygon();
            return false;
        }
        if (!this.currentMaskCanvas) this.currentMaskCanvas = this.createFullSizeCanvas();
        const ctx = this.currentMaskCanvas.getContext('2d');
        ctx.fillStyle = this.activeColor || '#4a90e2';
        ctx.beginPath();
        this.currentPoints.forEach((p, i) => {
            if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
        });
        ctx.closePath();
        ctx.fill();

        this.currentPoints = [];
        this.isDrawing = true;
        this.renderCurrentPolygon();
        this.renderBrushLayer();
        return true;
    }

    finishPolygon() {
        // Fold any still-open polygon loop into the pending mask first —
        // Enter must finalize whatever's pending as ONE shape regardless of
        // which tool happens to be active right now (the user may have
        // started with brush and switched to polygon mid-instance, or vice
        // versa). A polygon with no pre-existing mask is left alone here —
        // it stays a genuine standalone vector shape, same as always.
        if (this.currentPoints && this.currentPoints.length > 0 && this.currentMaskCanvas) {
            this.mergeCurrentPolygonIntoMask();
        }

        // Whether this finalizes as a raster ('brush') or vector
        // ('polygon') annotation is decided by whether a mask actually
        // exists, NOT by whatever tool happens to be selected right now —
        // activeTool only reflects the last tool clicked, which after
        // composing with multiple tools mid-instance may not match what
        // was actually drawn.
        const isBrush = !!this.currentMaskCanvas;
        const hasPoints = this.currentPoints && this.currentPoints.length > 0;

        if (!hasPoints && !isBrush) {
            this.currentPoints = [];
            this.currentMaskCanvas = null;
            this.isDrawing = false;
            this.renderCurrentPolygon();
            this.renderBrushLayer();
            return;
        }

        if (!isBrush && hasPoints && this.currentPoints.length < 3) {
            this.currentPoints = [];
            this.isDrawing = false;
            this.renderCurrentPolygon();
            return;
        }

        // A brush stroke that ended up entirely clipped to nothing — most
        // likely drawn completely outside every currently-active "must
        // overlap" boundary (see getMustOverlapBoundaryMask()'s paint-time
        // clip in handleCanvasMouseDown/Move), though a fully-Excluded
        // stroke could theoretically land here too — would otherwise still
        // get pushed below as a real annotation with zero actual pixels: a
        // genuinely invisible "ghost" row sitting in the Labels panel.
        if (isBrush && this.isMaskEmpty(this.currentMaskCanvas)) {
            this.currentMaskCanvas = null;
            this.isDrawing = false;
            this.renderBrushLayer();
            if (this.annotations.some(a => a.visible && a.overlapMode === 'mustOverlap')) {
                this.showToast('Drawing is restricted to the boundary of the "must overlap" object.');
            }
            return;
        }

        this.snapshotBeforeAction();

        const count = this.instanceCounters[this.activeLabel] || 0;
        this.instanceCounters[this.activeLabel] = count + 1;

        const newAnnotation = {
            id: 'anno_' + Date.now(),
            class: this.activeLabel,
            instanceNumber: count + 1,
            color: this.activeColor,
            // Settings drawer > Label display > Label color mode > "By
            // object" — a permanent, unique-per-instance color assigned
            // once here (see nextObjectColor()/getEffectiveColor()),
            // independent of `color` above (the shared class color).
            objectColor: this.nextObjectColor(),
            type: isBrush ? 'brush' : 'polygon',
            visible: true,
            locked: false,
            panopticMode: this.panopticMode || 'none',
            // Bitmask overlap control (Labels panel toggle, brush rows only)
            // — separate from panopticMode above: panopticMode governs how
            // THIS shape behaves when it's the one being painted; overlapMode
            // governs how OTHER shapes are allowed to paint over THIS one.
            // See applyOverlapExclusions()/eraseSegmentFromOthers().
            overlapMode: 'none',
            points: !isBrush ? [...this.currentPoints] : null,
            maskCanvas: isBrush ? this.currentMaskCanvas : null,
            offsetX: 0,
            offsetY: 0
        };

        // Bake Exclude/Overwrite/others'-protection into a genuine vector
        // polygon exactly like brush already does at paint time — brush's
        // own mode is baked into its raster the instant each stroke is
        // drawn (see applyExcludeAgainstOthers/eraseSegmentFromOthers'
        // call sites in handleCanvasMouseDown/Move), but a plain polygon
        // never went through either of those, and computeFinalAnnotationCanvases()'s
        // own "live" polygon-only punching (kept for backward compat, see
        // its own comment) never checked other.overlapMode at all and only
        // ever punched a LATER polygon into an EARLIER one — never a brush
        // target either direction. Converting to raster here (same one-way
        // conversion handleCanvasMouseDown's brush-over-selected-polygon
        // path already uses) and reusing the exact same two brush helpers
        // makes a polygon's panoptic mode behave identically to brush's,
        // against BOTH brush and polygon siblings, baked once and done —
        // instead of leaving it to that separate live mechanism, which only
        // ever half-covered this. A plain, unaffected polygon (mode 'none',
        // nothing else protected) is left alone and still exports as real
        // vector points, matching v2.
        if (!isBrush) {
            const mode = newAnnotation.panopticMode;
            // The "must overlap" drawing boundary applies regardless of
            // Panoptic mode — see getMustOverlapBoundaryMask()'s own
            // comment.
            const boundaryMask = this.getMustOverlapBoundaryMask(null);
            const needsExclude = mode === 'exclude' ||
                this.annotations.some(a => a.visible && a.overlapMode === 'noOverlap');
            const needsOverwrite = mode === 'overwrite';
            if (boundaryMask || needsExclude || needsOverwrite) {
                const converted = this.createFullSizeCanvas();
                const cctx = converted.getContext('2d');
                cctx.fillStyle = newAnnotation.color || '#4a90e2';
                cctx.beginPath();
                newAnnotation.points.forEach((p, idx) => {
                    if (idx === 0) cctx.moveTo(p.x, p.y); else cctx.lineTo(p.x, p.y);
                });
                cctx.closePath();
                cctx.fill();
                newAnnotation.type = 'brush';
                newAnnotation.maskCanvas = converted;
                newAnnotation.points = null;

                // Clip to the "must overlap" boundary FIRST — same as
                // brush's own paint-time clip — so this polygon can only
                // exist inside whatever's currently marked must-overlap.
                if (boundaryMask) {
                    const bctx = newAnnotation.maskCanvas.getContext('2d');
                    bctx.globalCompositeOperation = 'destination-in';
                    bctx.drawImage(boundaryMask, 0, 0);
                    bctx.globalCompositeOperation = 'source-over';
                }

                if (needsExclude) this.applyExcludeAgainstOthers(newAnnotation.maskCanvas, null, mode);
                if (needsOverwrite) {
                    const sourceStencil = this.renderAnnotationStencil(newAnnotation, 0, 0);
                    this.eraseSilhouetteFromOthers(null, sourceStencil);

                    // Overwrite's must-overlap-specific half — see
                    // absorbMustOverlapTargets()'s own comment. The
                    // polygon's own (now boundary-clipped) silhouette IS
                    // the touched area here; it commits as one shape in a
                    // single shot, unlike brush's incremental dabs.
                    const mustOverlapHit = this.findMustOverlapTargets(this.getAnnoBoundsRect(newAnnotation), null);
                    if (mustOverlapHit.length) {
                        this.absorbMustOverlapTargets(mustOverlapHit, newAnnotation.maskCanvas);
                    }
                }

                // Drawn entirely outside every "must overlap" shape's own
                // boundary — nothing survived the clip. Distinct from a
                // shape emptied by the eraser tool (which silently drops
                // with no message elsewhere): this is a novel, non-obvious
                // restriction the user may not expect, so it's worth saying
                // out loud rather than just having their drawing vanish.
                if (boundaryMask && this.isMaskEmpty(newAnnotation.maskCanvas)) {
                    this.currentPoints = [];
                    this.currentMaskCanvas = null;
                    this.isDrawing = false;
                    this.renderCurrentPolygon();
                    this.renderBrushLayer();
                    this.showToast('Drawing is restricted to the boundary of the "must overlap" object.');
                    return;
                }
            }
        }

        this.annotations.push(newAnnotation);
        this.selectedAnnotationId = null;

        this.currentPoints = [];
        this.currentMaskCanvas = null;
        this.isDrawing = false;

        document.getElementById('currentPolygon').innerHTML = '';
        
        const toolbar = document.getElementById('annotatorToolbar');
        if (toolbar) {
            toolbar.classList.add('hidden');
        }
        
        const oldActiveLabel = this.activeLabel;
        this.activeLabel = null;
        this.activeColor = null;
        this.selectTool(null);
        
        document.querySelectorAll('.class-group .rounded-md').forEach(el => {
            el.classList.remove('bg-gray-200');
            el.classList.add('hover:bg-gray-100');
        });
        
        this.renderAllAnnotations();
        
        // Update Class Badge Count
        // (Delegated to updateClassCounts via updateLabelsPanel, but keep for compatibility if needed)
        this.updateClassCounts();
        
        if (typeof this.updateLabelsPanel === 'function') {
            this.updateLabelsPanel();
        }
    }

    closeToolbar() {
        if (this._hasPendingDrawing()) {
            this.currentPoints = [];
            this.currentMaskCanvas = null;
            this.lastPaintPos = null;
            this._editingMaskAnnoId = null;
            this.isDrawing = false;
            this.renderCurrentPolygon();
            this.renderBrushLayer();
        }
        
        this.selectedAnnotationId = null;
        this.multiSelectedIds.clear();
        this.activeLabel = null;
        this.activeColor = null;
        this.selectTool(null);

        const toolbar = document.getElementById('annotatorToolbar');
        if (toolbar) toolbar.classList.add('hidden');

        document.querySelectorAll('.class-group .rounded-md').forEach(el => {
            el.classList.remove('bg-gray-200');
            el.classList.add('hover:bg-gray-100');
        });

        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') {
            this.updateLabelsPanel();
        }
    }

    renderAllAnnotations() {
        const gLayer = document.getElementById('finishedPolygons');
        if (!gLayer) return;

        gLayer.innerHTML = '';

        const labelsLayer = document.getElementById('annotationLabels');
        if (labelsLayer) labelsLayer.innerHTML = '';

        // Keep the shared image-area clip in sync before anything references it.
        this.getImageBounds();

        const btnMove = document.getElementById('btnMoveTool');
        const btnEraser = document.getElementById('btnEraserTool');
        const btnBrush = document.getElementById('btnBrushTool');
        const btnPolygon = document.getElementById('btnPolygonTool');
        
        if (this.selectedAnnotationId) {
            // Edit mode: Move, Brush, Eraser
            if (btnMove) btnMove.classList.remove('hidden');
            if (btnBrush) btnBrush.classList.remove('hidden');
            if (btnEraser) btnEraser.classList.remove('hidden');
            if (btnPolygon) btnPolygon.classList.add('hidden');
        } else {
            // Create mode: Brush, Polygon
            if (btnMove) btnMove.classList.add('hidden');
            if (btnEraser) btnEraser.classList.add('hidden');
            if (btnBrush) btnBrush.classList.remove('hidden');
            if (btnPolygon) btnPolygon.classList.remove('hidden');
        }
        
        // Paints every visible brush annotation's pixel mask onto the
        // shared raster #brushMaskCanvas (see renderBrushLayer()) — the
        // SVG loop below now only ever handles polygon-type shapes.
        this.renderBrushLayer();

        this.annotations.forEach(anno => {
            if (!anno.visible) return;

            const isSelected = this.selectedAnnotationId === anno.id;

            if (this.isDrawing && isSelected) return; // Skip rendering here while drawing to avoid double opacity overlap

            // Label color mode — same effective color the raster fill uses
            // (see getEffectiveColor()), so the tag/label text matches
            // whatever's actually on screen in either mode.
            const color = this.getEffectiveColor(anno);

            if (anno.type === 'brush' && anno.maskCanvas) {
                // The painted shape itself lives on #brushMaskCanvas now —
                // this group only carries the floating class-name tag
                // (addTextAndHover). Click/hover-to-select for the shape
                // itself is handled via pixel hit-testing in
                // handleCanvasMouseDown/handleCanvasMouseMove instead.
                const annoGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
                annoGroup.id = `anno-group-${anno.id}`;
                const tagGroup = this.addTextAndHover(annoGroup, anno, color, isSelected);
                if (tagGroup && labelsLayer) labelsLayer.appendChild(tagGroup);
                gLayer.appendChild(annoGroup);
            } else if (anno.type === 'polygon' && anno.points && anno.points.length > 0) {
                const ptsStr = anno.points.map(p => `${p.x},${p.y}`).join(' ');
                const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
                polygon.setAttribute('points', ptsStr);
                polygon.setAttribute('fill', color);
                // Fill is invisible here on purpose — the actual colored
                // area is painted on #brushMaskCanvas (see
                // renderAnnotationStencil/renderBrushLayer) so panoptic
                // exclude/overwrite can visually clip it against other
                // annotations. This <polygon> now exists only to keep the
                // real geometry hit-testable/hoverable/erasable.
                polygon.setAttribute('fill-opacity', '0');
                polygon.setAttribute('stroke', color);
                polygon.setAttribute('stroke-width', '0');
                polygon.setAttribute('stroke-opacity', '0');
                
                const annoGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
                annoGroup.id = `anno-group-${anno.id}`;
                annoGroup.style.pointerEvents = 'all';
                annoGroup.style.cursor = 'pointer';

                const shapeGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
                shapeGroup.id = `anno-svg-${anno.id}`;

                const isActivelyMovingThis = this.isMoving && this.selectedAnnotationId === anno.id;
                if (!isActivelyMovingThis) {
                    shapeGroup.setAttribute('clip-path', 'url(#imageAreaClip)');
                }

                if (anno.eraserStrokes && anno.eraserStrokes.length > 0) {
                    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
                    const mask = document.createElementNS("http://www.w3.org/2000/svg", "mask");
                    mask.setAttribute('id', `mask-${anno.id}`);
                    
                    const bgRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
                    bgRect.setAttribute('width', '100%');
                    bgRect.setAttribute('height', '100%');
                    bgRect.setAttribute('fill', 'white');
                    mask.appendChild(bgRect);
                    
                    anno.eraserStrokes.forEach(stroke => {
                        if (!stroke.points || stroke.points.length === 0) return;
                        const ePtsStr = stroke.points.map(p => `${p.x},${p.y}`).join(' ');
                        const eLine = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
                        eLine.setAttribute('points', ePtsStr);
                        eLine.setAttribute('fill', 'none');
                        eLine.setAttribute('stroke', 'black');
                        eLine.setAttribute('stroke-width', stroke.size ? stroke.size.toString() : '50');
                        eLine.setAttribute('stroke-linejoin', stroke.shape === 'square' ? 'miter' : 'round');
                        eLine.setAttribute('stroke-linecap', stroke.shape === 'square' ? 'square' : 'round');
                        mask.appendChild(eLine);
                    });
                    
                    defs.appendChild(mask);
                    shapeGroup.appendChild(defs);
                    polygon.setAttribute('mask', `url(#mask-${anno.id})`);
                }
                
                shapeGroup.appendChild(polygon);
                annoGroup.appendChild(shapeGroup);
                const tagGroup = this.addTextAndHover(annoGroup, anno, color, isSelected);
                if (tagGroup && labelsLayer) labelsLayer.appendChild(tagGroup);
                gLayer.appendChild(annoGroup);
            }
        });

        this.updateGroupSelectionBBox();
    }

    addTextAndHover(annoGroup, anno, color, isSelected) {
        let highestY = Infinity, highestX = 0;
        let textX = 0, textY = 0;
        if (anno.type === 'brush' && anno.maskCanvas) {
            const bbox = this.getAnnoBBox(anno);
            if (bbox.w > 0 && bbox.h > 0) {
                highestY = bbox.y + (anno.offsetY || 0);
                highestX = bbox.topX + (anno.offsetX || 0);
            }
        } else if (anno.type === 'polygon' && anno.points && anno.points.length > 0) {
            anno.points.forEach(p => {
                if (p.y < highestY) {
                    highestY = p.y;
                    highestX = p.x;
                }
            });
        }
        
        const textContentStr = `${anno.class} ${this.getDisplayInstanceNumber(anno)}`;
        const scale = this.workspace && this.workspace.transform ? this.workspace.transform.scale : 1;
        // Settings drawer > Label display > "Object label font size" —
        // rectHeight keeps the same 1.5x ratio to font size the old
        // hardcoded 12/18 pair had, so the tag box still looks
        // proportionate at any font size the user picks.
        const fontSize = this.objectLabelFontSize / scale;
        const rectHeight = (this.objectLabelFontSize * 1.5) / scale;
        const rx = 4 / scale;
        const gap = 5 / scale;

        const textBg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        const textLabel = document.createElementNS("http://www.w3.org/2000/svg", "text");
        textLabel.id = `label-text-${anno.id}`;
        textLabel.setAttribute('fill', color);
        textLabel.setAttribute('font-size', `${fontSize}px`);
        textLabel.setAttribute('font-family', 'sans-serif');
        // Centered via anchor/baseline (positioned at the box's own center
        // point below), not by eyeballing an estimated text width against a
        // left-aligned x — that's what was making the label read off-center
        // inside the black box.
        textLabel.setAttribute('text-anchor', 'middle');
        textLabel.setAttribute('dominant-baseline', 'central');
        textLabel.textContent = textContentStr;
        textLabel.style.pointerEvents = 'none';

        // sans-serif isn't monospace, so a fixed per-character width
        // estimate (the old `textContentStr.length * charWidth`) routinely
        // over- or under-shoots the real rendered width, sizing the black
        // box wrong and leaving uneven left/right padding around the text.
        // Measure the actual glyph advance instead. getComputedTextLength()
        // is unreliable on a fully detached element in some browsers, so
        // attach to a live SVG first purely to measure — it gets moved into
        // tagGroup below regardless, same as before.
        const svgRoot = document.getElementById('annotationCanvas');
        if (svgRoot) svgRoot.appendChild(textLabel);
        let textLen = 0;
        try { textLen = textLabel.getComputedTextLength(); } catch (e) { /* fall through to estimate */ }
        if (!textLen || !isFinite(textLen) || textLen <= 0) {
            // ~7px average glyph width at the old fixed 12px font — scaled
            // to whatever font size is actually in effect now.
            textLen = textContentStr.length * ((7 * this.objectLabelFontSize / 12) / scale);
        }

        // #imageBoundsBox (the tag's own SVG ancestor) is exactly rw x rh at
        // rx,ry and clips with real overflow:hidden. Clamping only against 0
        // (viewport origin) let a tag near the right/bottom image edge keep
        // its rect past rx+rw / ry+rh, which that overflow:hidden then
        // silently sliced off — invisible/cut-off tag, not a stacking issue.
        // Clamping against the actual image rect on every side keeps the
        // whole tag inside the visible, clipped box.
        const bounds = this.getImageBounds();
        // textX/textY are the box's own top-left from here on (previously
        // textY represented the text's top with the box offset from it —
        // now the box is primary and the text just centers within it).
        textX = highestX - (textLen / 2) - (4 / scale);
        textX = Math.max(bounds.rx, Math.min(textX, bounds.rx + bounds.rw - textLen - (8 / scale)));

        textY = highestY - rectHeight - gap;
        textY = Math.max(bounds.ry, Math.min(textY, bounds.ry + bounds.rh - rectHeight)); // Clamp top/bottom

        textLabel.setAttribute('x', textX + (4 / scale) + textLen / 2);
        textLabel.setAttribute('y', textY + rectHeight / 2);

        textBg.setAttribute('x', textX);
        textBg.setAttribute('y', textY);
        textBg.setAttribute('width', textLen + (8 / scale));
        textBg.setAttribute('height', rectHeight.toString());
        textBg.setAttribute('fill', 'black');
        textBg.setAttribute('rx', rx.toString());
        textBg.style.pointerEvents = 'none';
        
        // Create tag group that will be rendered on top
        const tagGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
        tagGroup.id = `tag-group-${anno.id}`;
        if (!anno.tagged) {
            tagGroup.appendChild(textBg);
            tagGroup.appendChild(textLabel);
        } else if (textLabel.parentNode) {
            // Tag is hidden for this annotation — textLabel was only ever
            // attached to #annotationCanvas above to measure its real
            // width, and never gets moved into tagGroup in this branch, so
            // it has to be explicitly detached here or it'd sit as an
            // orphaned, invisible-but-present extra node in the live SVG.
            textLabel.parentNode.removeChild(textLabel);
        }

        annoGroup.onclick = (e) => {
            e.stopPropagation();
            // A click and a mousedown on the SAME shape fire as two
            // SEPARATE events (mousedown fires first, then this 'click'
            // handler fires after mouseup) — while a NEW polygon is being
            // placed, clicking on top of this existing shape already
            // correctly added a vertex via the wrapper's own mousedown
            // listener (handleCanvasMouseDown) by the time this runs.
            // Without this guard, this handler still went on to select
            // THIS existing shape and switch the toolbar to Move/edit
            // mode right afterward — silently yanking focus away from the
            // polygon still being drawn (which was never actually
            // finished — just abandoned mid-instance with its own
            // toolbar/cursor state left stuck) every time a new vertex
            // happened to land on top of another shape.
            if (this._hasPendingDrawing()) return;
            // Clicking the shape itself on canvas defaults to move — see
            // the matching comment on the hit-test-select branch in
            // handleCanvasMouseDown. selectAnnotationForEdit() is the same
            // select-and-switch-to-move-and-open-toolbar sequence used by
            // every other entry point that selects a shape by clicking it.
            this.selectAnnotationForEdit(anno);
        };

        annoGroup.onmouseenter = () => {
            const row = document.getElementById(`label-row-${anno.id}`);
            if (row) {
                row.classList.add('bg-gray-100');
                row.classList.remove('bg-white');
            }
            
            // Polygon hover draws a crisp raster rim on #brushMaskCanvas —
            // see this.hoveredPolygonAnnoId/renderBrushLayer() — instead of
            // an SVG stroke, which anti-aliased into a blurry line under
            // this app's CSS-transform zoom.
            if (anno.type === 'polygon' && !(this.selectedAnnotationId === anno.id && (this.activeTool === 'brush' || this.activeTool === 'eraser'))) {
                this.hoveredPolygonAnnoId = anno.id;
                this.renderBrushLayer();
            }
            // Brush hover is driven by pixel hit-testing in
            // handleCanvasMouseMove (hoveredBrushAnnoId) — this tag-only
            // group has no shape geometry of its own to hover over.
        };
        annoGroup.onmouseleave = () => {
            const row = document.getElementById(`label-row-${anno.id}`);
            if (row && this.selectedAnnotationId !== anno.id) {
                row.classList.remove('bg-gray-100');
                row.classList.add('bg-white');
            }
            if (anno.type === 'polygon' && this.hoveredPolygonAnnoId === anno.id) {
                this.hoveredPolygonAnnoId = null;
                this.renderBrushLayer();
            }
        };

        return tagGroup;
    }

    // The number shown to the user (canvas tag + Labels row) is always
    // sequential among CURRENTLY existing annotations of the same class
    // (1..N) — not anno.instanceNumber, which is the ever-increasing
    // historical counter instanceCounters hands out once at creation time
    // (or on a class change) and never reclaims. Deleting an earlier
    // instance closes the gap for whichever ones remain — e.g. deleting
    // "Bicycle 1" out of {1,2,3} renumbers the survivors to {1,2}, not left
    // showing {2,3}. anno.instanceNumber itself is left untouched — nothing
    // reads it for export (see generateCOCOFormat()), so there's no
    // persisted-identity reason to keep it stable, but no reason to touch
    // it either.
    getDisplayInstanceNumber(anno) {
        const sameClass = this.annotations.filter(a => a.class === anno.class);
        const idx = sameClass.indexOf(anno);
        return idx === -1 ? anno.instanceNumber : idx + 1;
    }

    updateClassCounts() {
        const counts = {};
        this.annotations.forEach(a => {
            counts[a.class] = (counts[a.class] || 0) + 1;
        });

        document.querySelectorAll('.class-group').forEach(cg => {
            const className = cg.dataset.classname;
            const badge = cg.querySelector('.instance-count-badge');
            if (badge) {
                const count = counts[className] || 0;
                badge.textContent = count > 0 ? `(${count})` : '';
            }
        });
    }

    updateLabelsPanel() {
        const container = document.getElementById('instructionContainer');
        if (!container) return;
        
        this.updateClassCounts();
        
        const ITEM_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="appstore-add" width="1em" height="1em" fill="currentColor" aria-hidden="true" style="transform: rotate(270deg);"><path d="M464 144H160c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H212V212h200v200zm452-268H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H612V212h200v200zm52 132H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V560c0-8.8-7.2-16-16-16zm-52 268H612V612h200v200zM424 712H296V584c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v128H104c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h128v128c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V776h128c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8z"></path></svg>`;
        const FOLDER_SVG = `<svg viewBox="64 64 896 896" focusable="false" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M640.6 429.8h257.1c7.9 0 14.3-6.4 14.3-14.3V158.3c0-7.9-6.4-14.3-14.3-14.3H640.6c-7.9 0-14.3 6.4-14.3 14.3v92.9H490.6c-3.9 0-7.1 3.2-7.1 7.1v221.5h-85.7v-96.5c0-7.9-6.4-14.3-14.3-14.3H126.3c-7.9 0-14.3 6.4-14.3 14.3v257.2c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3V544h85.7v221.5c0 3.9 3.2 7.1 7.1 7.1h135.7v92.9c0 7.9 6.4 14.3 14.3 14.3h257.1c7.9 0 14.3-6.4 14.3-14.3v-257c0-7.9-6.4-14.3-14.3-14.3h-257c-7.9 0-14.3 6.4-14.3 14.3v100h-78.6v-393h78.6v100c0 7.9 6.4 14.3 14.3 14.3zm53.5-217.9h150V362h-150V211.9zM329.9 587h-150V437h150v150zm364.2 75.1h150v150.1h-150V662.1z"></path></svg>`;

        container.innerHTML = '';

        // Nothing drawn at all yet — same empty state used for a
        // zero-result search below, shown outright here instead of
        // building (and immediately hiding) an empty grouping structure.
        // A brand-new shape isn't pushed into this.annotations until it's
        // explicitly finished (Enter / finishPolygon()) — commitCurrentStroke()
        // already calls updateLabelsPanel() after every stroke, though, so
        // without the pending-drawing check this flashed "No
        // classifications or objects" the moment someone started their
        // very first shape, while it was still clearly visible mid-draw
        // on the canvas.
        if (this.annotations.length === 0 && !this._hasPendingDrawing()) {
            container.innerHTML = this._emptyStateHTML('No classifications or objects');
            this.syncHiddenInputSilently();
            return;
        }

        // Helper to construct annotation rows
        const buildAnnoRow = (anno, color, padClass) => {
            const row = document.createElement('div');
            const isSelected = this.selectedAnnotationId === anno.id;
            row.className = `flex items-center justify-between py-1.5 pr-2 ${padClass} cursor-pointer group transition-colors ${isSelected ? 'bg-gray-100' : 'hover:bg-gray-50 bg-white'}`;
            row.id = `label-row-${anno.id}`;
            
            row.onmouseenter = () => {
                // Same crisp raster hover rim as the shape's own on-canvas
                // hover (see this.hoveredPolygonAnnoId/hoveredBrushAnnoId
                // and renderBrushLayer()) — no SVG stroke/filter here, both
                // of which anti-aliased into a blurry border under this
                // app's CSS-transform zoom.
                if (anno.type === 'polygon') {
                    this.hoveredPolygonAnnoId = anno.id;
                    this.renderBrushLayer();
                } else if (anno.type === 'brush') {
                    this.hoveredBrushAnnoId = anno.id;
                    this.renderBrushLayer();
                }
            };
            row.onmouseleave = () => {
                if (anno.type === 'polygon') {
                    if (this.hoveredPolygonAnnoId === anno.id) this.hoveredPolygonAnnoId = null;
                    this.renderBrushLayer();
                } else if (anno.type === 'brush') {
                    if (this.hoveredBrushAnnoId === anno.id) this.hoveredBrushAnnoId = null;
                    this.renderBrushLayer();
                }
            };
            
            row.onclick = () => {
                this.selectedAnnotationId = anno.id;
                this.renderAllAnnotations();
                this.updateLabelsPanel();
                if (window.app && typeof window.app.selectTool === 'function') {
                    // Selecting via the Labels panel row (rather than
                    // clicking the shape itself) defaults to brush — you're
                    // here to refine/inspect it by class, not to grab and
                    // reposition it.
                    window.app.selectTool('brush');
                }
                const classGroup = document.querySelector(`.class-group[data-classname="${anno.class}"]`);
                if (window.app && typeof window.app.showToolbar === 'function' && classGroup) {
                    window.app.showToolbar(classGroup, anno.class, true);
                }
            };
            
            const leftDiv = document.createElement('div');
            leftDiv.className = 'flex items-center gap-2';
            leftDiv.innerHTML = `
                <div class="flex items-center justify-center text-[15px]" style="color: ${color}">
                    <svg viewBox="64 64 896 896" focusable="false" data-icon="appstore-add" width="12px" height="12px" fill="currentColor" aria-hidden="true" style="transform: rotate(270deg);"><path d="M464 144H160c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H212V212h200v200zm452-268H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H612V212h200v200zm52 132H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V560c0-8.8-7.2-16-16-16zm-52 268H612V612h200v200zM424 712H296V584c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v128H104c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h128v128c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V776h128c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8z"></path></svg>
                </div>
                <span class="text-[13.5px] text-gray-700 font-sans">${anno.class} (${this.getDisplayInstanceNumber(anno)})</span>
            `;
            
            const rightDiv = document.createElement('div');
            rightDiv.className = `flex items-center gap-1.5`;

            const lockSvgClosed = `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path d="M368 192h-16v-80a96 96 0 1 0-192 0v80h-16a64.07 64.07 0 0 0-64 64v176a64.07 64.07 0 0 0 64 64h224a64.07 64.07 0 0 0 64-64V256a64.07 64.07 0 0 0-64-64zm-48 0H192v-80a64 64 0 1 1 128 0z"></path></svg>`;
            const lockSvgOpen = `<svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M336 112a80 80 0 0 0-160 0v96"></path><rect width="320" height="272" x="96" y="208" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" rx="48" ry="48"></rect></svg>`;
            
            const lockBtn = document.createElement('span');
            lockBtn.className = `text-[#434d58] hover:text-black flex items-center justify-center cursor-pointer ml-1 transition-opacity ${anno.locked ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`;
            lockBtn.innerHTML = anno.locked ? lockSvgClosed : lockSvgOpen;
            lockBtn.onclick = (e) => {
                e.stopPropagation();
                anno.locked = !anno.locked;
                this.updateLabelsPanel();
            };
            
            const visSvgOpen = `<svg viewBox="64 64 896 896" focusable="false" data-icon="eye" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 000 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z"></path></svg>`;
            const visSvgClosed = `<svg viewBox="64 64 896 896" focusable="false" data-icon="eye-invisible" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M942.2 486.2Q889.47 375.11 816.7 305l-50.88 50.88C807.31 395.53 843.45 447.4 874.7 512 791.5 684.2 673.4 766 512 766q-72.67 0-133.87-22.38L323 798.75Q408 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 000-51.5zm-63.57-320.64L836 122.88a8 8 0 00-11.32 0L715.31 232.2Q624.86 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 000 51.5q56.69 119.4 136.5 191.41L112.48 835a8 8 0 000 11.31L155.17 889a8 8 0 0011.31 0l712.15-712.12a8 8 0 000-11.32zM149.3 512C232.6 339.8 350.7 258 512 258c54.54 0 104.13 9.36 149.12 28.39l-70.3 70.3a176 176 0 00-238.13 238.13l-83.42 83.42C223.1 637.49 183.3 582.28 149.3 512zm246.7 0a112.11 112.11 0 01146.2-106.69L401.31 546.2A112 112 0 01396 512z"></path><path d="M508 624c-3.46 0-6.87-.16-10.25-.47l-52.82 52.82a176.09 176.09 0 00227.42-227.42l-52.82 52.82c.31 3.38.47 6.79.47 10.25a111.94 111.94 0 01-112 112z"></path></svg>`;
            
            const visBtn = document.createElement('span');
            visBtn.className = `text-[#434d58] hover:text-black flex items-center justify-center cursor-pointer ml-1 transition-opacity ${!anno.visible ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`;
            visBtn.innerHTML = anno.visible ? visSvgOpen : visSvgClosed;
            visBtn.onclick = (e) => {
                e.stopPropagation();
                anno.visible = !anno.visible;
                this.updateLabelsPanel();
                this.renderAllAnnotations();
            };

            const tagSvgOutline = `<svg viewBox="64 64 896 896" focusable="false" data-icon="tag" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M938 458.8l-29.6-312.6c-1.5-16.2-14.4-29-30.6-30.6L565.2 86h-.4c-3.2 0-5.7 1-7.6 2.9L88.9 557.2a9.96 9.96 0 000 14.1l363.8 363.8c1.9 1.9 4.4 2.9 7.1 2.9s5.2-1 7.1-2.9l468.3-468.3c2-2.1 3-5 2.8-8zM459.7 834.7L189.3 564.3 589 164.6 836 188l23.4 247-399.7 399.7zM680 256c-48.5 0-88 39.5-88 88s39.5 88 88 88 88-39.5 88-88-39.5-88-88-88zm0 120c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32z"></path></svg>`;
            const tagSvgFilled = `<svg viewBox="64 64 896 896" focusable="false" data-icon="tag" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M938 458.8l-29.6-312.6c-1.5-16.2-14.4-29-30.6-30.6L565.2 86h-.4c-3.2 0-5.7 1-7.6 2.9L88.9 557.2a9.96 9.96 0 000 14.1l363.8 363.8c1.9 1.9 4.4 2.9 7.1 2.9s5.2-1 7.1-2.9l468.3-468.3c2-2.1 3-5 2.8-8zM699 387c-35.3 0-64-28.7-64-64s28.7-64 64-64 64 28.7 64 64-28.7 64-64 64z"></path></svg>`;
            
            const tagBtn = document.createElement('span');
            tagBtn.className = `text-[#434d58] hover:text-[#5f45ff] flex items-center justify-center cursor-pointer ml-1 transition-opacity ${anno.tagged ? 'opacity-100 text-[#5f45ff]' : 'opacity-0 group-hover:opacity-100'}`;
            tagBtn.innerHTML = anno.tagged ? tagSvgFilled : tagSvgOutline;
            tagBtn.onmouseenter = () => { if (!anno.tagged) tagBtn.innerHTML = tagSvgFilled; };
            tagBtn.onmouseleave = () => { if (!anno.tagged) tagBtn.innerHTML = tagSvgOutline; };
            tagBtn.onclick = (e) => {
                e.stopPropagation();
                anno.tagged = !anno.tagged;
                this.updateLabelsPanel();
                this.renderAllAnnotations();
            };

            // Bitmask overlap control — a 3-state cycle over anno.overlapMode:
            // none ("can be drawn over", default) -> noOverlap ("cannot be
            // drawn over") -> mustOverlap ("must be drawn over") -> back to
            // none. Shown on BOTH brush and polygon rows — overlapMode
            // itself was always type-agnostic (getMustOverlapBoundaryMask/
            // applyExcludeAgainstOthers/absorbMustOverlapTargets all already
            // handle a polygon target correctly via renderAnnotationStencil/
            // _ensureRasterMask), it was only ever this UI toggle that
            // forgot to expose it for a polygon row, leaving no way to
            // actually set overlapMode on one even though the mechanics
            // were ready for it. Deliberately a DIFFERENT field from
            // anno.panopticMode (the toolbar's own None/Exclude/Overwrite
            // pills): panopticMode governs what THIS shape does while it's
            // the one being actively painted; overlapMode governs what
            // OTHER shapes are allowed to do to THIS one, enforced in
            // applyExcludeAgainstOthers()/eraseSegmentFromOthers()/
            // absorbMustOverlapTargets() regardless of whichever
            // panopticMode the other stroke has.
            const overlapIcons = {
                none: `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" aria-label="bitmask-no-effect" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path d="M3 21v-4a4 4 0 1 1 4 4h-4"></path><path d="M21 3a16 16 0 0 0 -12.8 10.2"></path><path d="M21 3a16 16 0 0 1 -10.2 12.8"></path><path d="M10.6 9a9 9 0 0 1 4.4 4.4"></path></svg>`,
                noOverlap: `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" aria-label="bitmask-exclude" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path d="M3 17a4 4 0 1 1 4 4h-4v-4z"></path><path d="M21 3a16 16 0 0 0 -9.309 4.704m-1.795 2.212a15.993 15.993 0 0 0 -1.696 3.284"></path><path d="M21 3a16 16 0 0 1 -4.697 9.302m-2.195 1.786a15.993 15.993 0 0 1 -3.308 1.712"></path><path d="M3 3l18 18"></path></svg>`,
                mustOverlap: `<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" aria-label="bitmask-include" height="13px" width="13px" xmlns="http://www.w3.org/2000/svg"><path d="M3 21v-4a4 4 0 1 1 4 4h-4"></path><path d="M21 3a16 16 0 0 0 -12.8 10.2"></path><path d="M21 3a16 16 0 0 1 -10.2 12.8"></path><path d="M10.6 9a9 9 0 0 1 4.4 4.4"></path></svg>`,
            };
            // title/desc/badge — rich tooltip content (see initGlobalTooltips'
            // data-tooltip-title/-desc/-badge/-badge-variant handling), same
            // three-state layout as Encord's own reference for this icon: a
            // bold state sentence, a constant instructional line underneath,
            // and a colored state pill on the header row.
            const overlapTooltips = {
                none: { title: 'Segmentation can be drawn over.', badge: 'No effect' },
                noOverlap: { title: 'Segmentation cannot be drawn over.', badge: 'No overlap' },
                mustOverlap: { title: 'Segmentation must be drawn over.', badge: 'Must overlap' },
            };
            const overlapTooltipDesc = 'Toggle if other segmentations can be drawn over this one.';
            const overlapColors = {
                none: 'text-[#434d58] hover:text-black opacity-0 group-hover:opacity-100',
                noOverlap: 'opacity-100 text-red-500',
                mustOverlap: 'opacity-100 text-green-600',
            };
            const overlapNextState = { none: 'noOverlap', noOverlap: 'mustOverlap', mustOverlap: 'none' };

            const overlapBtn = document.createElement('span');
            if (anno.type === 'brush' || anno.type === 'polygon') {
                const mode = anno.overlapMode || 'none';
                overlapBtn.className = `flex items-center justify-center cursor-pointer ml-1 transition-opacity ${overlapColors[mode]}`;
                overlapBtn.setAttribute('data-tooltip-title', overlapTooltips[mode].title);
                overlapBtn.setAttribute('data-tooltip-desc', overlapTooltipDesc);
                overlapBtn.setAttribute('data-tooltip-badge', overlapTooltips[mode].badge);
                overlapBtn.setAttribute('data-tooltip-badge-variant', mode);
                overlapBtn.setAttribute('data-tooltip-pos', 'top');
                overlapBtn.innerHTML = overlapIcons[mode];
                overlapBtn.onclick = (e) => {
                    e.stopPropagation();
                    anno.overlapMode = overlapNextState[mode];
                    this.updateLabelsPanel();
                    this.renderAllAnnotations();
                };
            }

            const moreSvg = `<svg viewBox="64 64 896 896" focusable="false" data-icon="more" width="13px" height="13px" fill="currentColor" aria-hidden="true"><path d="M456 231a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0z"></path></svg>`;
            const moreBtn = document.createElement('span');
            moreBtn.className = `text-[#434d58] hover:text-black flex items-center justify-center cursor-pointer ml-1 transition-opacity opacity-0 group-hover:opacity-100`;
            moreBtn.innerHTML = moreSvg;
            moreBtn.onclick = (e) => {
                e.stopPropagation();
                this.openAnnoOptionsMenu(anno, moreBtn);
            };

            rightDiv.appendChild(visBtn);
            rightDiv.appendChild(tagBtn);
            rightDiv.appendChild(lockBtn);
            if (anno.type === 'brush' || anno.type === 'polygon') rightDiv.appendChild(overlapBtn);
            rightDiv.appendChild(moreBtn);

            row.appendChild(leftDiv);
            row.appendChild(rightDiv);

            return row;
        };

        const createClassHeader = (className, color, count, padClass) => {
            const header = document.createElement('div');
            header.className = `flex items-center ${padClass} pr-4 py-1.5 cursor-pointer hover:bg-gray-50`;
            header.innerHTML = `
                <svg viewBox="64 64 896 896" class="w-3 h-3 text-gray-700 mr-2 transition-transform duration-200" fill="currentColor">
                    <path d="M840.4 300H183.6c-19.7 0-30.7 20.8-18.5 35l328.4 380.8c9.4 10.9 27.5 10.9 37 0L858.9 335c12.2-14.2 1.2-35-18.5-35z"></path>
                </svg>
                <div class="flex items-center justify-center text-[15px] mr-2" style="color: ${color}">
                    ${ITEM_SVG}
                </div>
                <span class="text-[14.5px] text-gray-700 font-sans">${className}</span>
                <span class="ml-3 mt-0.5 w-5 h-5 flex items-center justify-center border border-[#e7e4e4] rounded-full text-[11px] text-gray-20 bg-[#fafafa]">${count}</span>
            `;
            return header;
        };

        if (this.isLabelGrouped) {
            // Nested grouping: Category -> Class -> Instance — built from
            // whatever group names WORKSPACE_CONFIG.CLASSES actually
            // declares (any count, any names), not a hardcoded Objects/
            // Regions pair, so this still works if CLASSES is restructured
            // down to a single group (an effectively flat class list) or
            // renamed/re-grouped entirely.
            const groupNames = Object.keys(WORKSPACE_CONFIG.CLASSES);
            const categoryGroups = {};
            groupNames.forEach(groupName => { categoryGroups[groupName] = { classes: {} }; });
            const fallbackGroup = groupNames[0];

            const classToCategory = {};
            for (const [catName, classes] of Object.entries(WORKSPACE_CONFIG.CLASSES)) {
                classes.forEach(c => classToCategory[c.name] = catName);
            }

            // Group by category then class
            let hasAnyAnnotations = false;
            this.annotations.forEach(anno => {
                hasAnyAnnotations = true;
                const cat = classToCategory[anno.class] || fallbackGroup;
                if (categoryGroups[cat]) {
                    if (!categoryGroups[cat].classes[anno.class]) {
                        categoryGroups[cat].classes[anno.class] = { color: anno.color || '#D84C3E', items: [] };
                    }
                    categoryGroups[cat].classes[anno.class].items.push(anno);
                }
            });

            Object.keys(categoryGroups).forEach(catName => {
                const groupData = categoryGroups[catName];
                const classesInGroup = Object.keys(groupData.classes);
                if (classesInGroup.length === 0) return;
                
                let totalInstances = 0;
                classesInGroup.forEach(c => totalInstances += groupData.classes[c].items.length);
                
                const displayGroup = catName === 'Objects' ? 'Object' : (catName === 'Regions' ? 'Region' : catName);
                
                const catDiv = document.createElement('div');
                catDiv.className = 'w-full text-neutral-800';
                
                const catHeader = document.createElement('div');
                catHeader.className = 'flex items-center pl-4 pr-4 py-1.5 cursor-pointer hover:bg-gray-50';
                catHeader.innerHTML = `
                    <svg viewBox="64 64 896 896" class="w-3 h-3 text-gray-700 mr-2 transition-transform duration-200" fill="currentColor">
                        <path d="M840.4 300H183.6c-19.7 0-30.7 20.8-18.5 35l328.4 380.8c9.4 10.9 27.5 10.9 37 0L858.9 335c12.2-14.2 1.2-35-18.5-35z"></path>
                    </svg>
                    <div class="flex items-center justify-center text-[15px] mr-2 text-gray-700">
                        ${FOLDER_SVG}
                    </div>
                    <span class="text-[14.5px] text-gray-700 font-sans">${displayGroup}</span>
                    <span class="ml-3 mt-0.5 w-5 h-5 flex items-center justify-center border border-[#e7e4e4] rounded-full text-[11px] text-gray-20 bg-[#fafafa]">${classesInGroup.length}</span>
                `;
                catDiv.appendChild(catHeader);
                
                const catContent = document.createElement('div');
                catContent.className = 'flex flex-col transition-all';
                
                catHeader.onclick = () => {
                    const isHidden = catContent.classList.contains('hidden');
                    if (isHidden) {
                        catContent.classList.remove('hidden');
                        catHeader.querySelector('svg').style.transform = 'rotate(0deg)';
                    } else {
                        catContent.classList.add('hidden');
                        catHeader.querySelector('svg').style.transform = 'rotate(-90deg)';
                    }
                };
                
                // Now render Class folders inside Category
                classesInGroup.forEach(className => {
                    const clsData = groupData.classes[className];
                    
                    const clsDiv = document.createElement('div');
                    clsDiv.className = 'w-full text-neutral-800';
                    
                    const clsHeader = createClassHeader(className, clsData.color, clsData.items.length, 'pl-9');
                    clsDiv.appendChild(clsHeader);
                    
                    const clsContent = document.createElement('div');
                    clsContent.className = 'flex flex-col pb-1 transition-all';
                    
                    clsHeader.onclick = () => {
                        const isHidden = clsContent.classList.contains('hidden');
                        if (isHidden) {
                            clsContent.classList.remove('hidden');
                            clsHeader.querySelector('svg').style.transform = 'rotate(0deg)';
                        } else {
                            clsContent.classList.add('hidden');
                            clsHeader.querySelector('svg').style.transform = 'rotate(-90deg)';
                        }
                    };
                    
                    clsData.items.forEach(anno => {
                        clsContent.appendChild(buildAnnoRow(anno, this.getEffectiveColor(anno), 'pl-14')); // indented inside class
                    });
                    
                    clsDiv.appendChild(clsContent);
                    catContent.appendChild(clsDiv);
                });
                
                catDiv.appendChild(catContent);
                container.appendChild(catDiv);
            });
        } else {
            // Group by className (old behavior)
            const groups = {};
            this.annotations.forEach(anno => {
                if (!groups[anno.class]) {
                    groups[anno.class] = { color: anno.color || '#D84C3E', items: [] };
                }
                groups[anno.class].items.push(anno);
            });
            
            Object.keys(groups).forEach(className => {
                const groupData = groups[className];
                
                const groupDiv = document.createElement('div');
                groupDiv.className = 'w-full text-neutral-800';
                
                const header = createClassHeader(className, groupData.color, groupData.items.length, 'pl-4');
                groupDiv.appendChild(header);
                
                const itemsContainer = document.createElement('div');
                itemsContainer.className = 'flex flex-col pb-1 transition-all';
                
                header.onclick = () => {
                    const isHidden = itemsContainer.classList.contains('hidden');
                    if (isHidden) {
                        itemsContainer.classList.remove('hidden');
                        header.querySelector('svg').style.transform = 'rotate(0deg)';
                    } else {
                        itemsContainer.classList.add('hidden');
                        header.querySelector('svg').style.transform = 'rotate(-90deg)';
                    }
                };
                
                groupData.items.forEach(anno => {
                    itemsContainer.appendChild(buildAnnoRow(anno, this.getEffectiveColor(anno), 'pl-9'));
                });
                
                groupDiv.appendChild(itemsContainer);
                container.appendChild(groupDiv);
            });
        }

        // Search-empty state — starts hidden; filterLabels() shows it when
        // a search matches nothing. There IS at least one real annotation
        // at this point (see the early return above), so this only ever
        // needs to cover the search case, never the baseline-empty one.
        container.insertAdjacentHTML('beforeend', this._emptyStateHTML('No matching objects', 'labelsSearchEmptyState', true));

        // Keeps #annotations-output current after every mutation this
        // function already runs for (drawing, deleting, class changes,
        // panoptic/overlap mode edits, ...) — see syncHiddenInputSilently()'s
        // own comment for why this can't just live at explicit Submit time.
        this.syncHiddenInputSilently();
    }

    showAnnotationMenu(e, id, className) {
        let menu = document.getElementById('annotationDropdownMenu');
        if (!menu) {
            menu = document.createElement('div');
            menu.id = 'annotationDropdownMenu';
            menu.className = 'fixed bg-white border border-gray-100 shadow-2xl rounded-xl py-1 min-w-[130px] w-max z-[100000] pointer-events-auto';
            
            const delBtn = document.createElement('div');
            delBtn.className = 'flex items-center gap-2 px-3 py-1.5 text-[12px] font-medium text-red-500 hover:bg-[#f64d62] hover:text-white cursor-pointer mx-1 rounded-md transition-colors';
            delBtn.innerHTML = `<svg viewBox="64 64 896 896" focusable="false" width="14" height="14" fill="currentColor"><path d="M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72zm504 72H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z"></path></svg> <div>Delete</div>`;
            menu.appendChild(delBtn);
            document.body.appendChild(menu);
        }
        
        menu.classList.remove('hidden');
        menu.style.left = e.clientX + 'px';
        menu.style.top = e.clientY + 'px';
        
        menu.firstElementChild.onclick = (ev) => {
            ev.stopPropagation();
            menu.classList.add('hidden');
            this.showDeleteConfirmation(id, className);
        };
        
        const closeMenu = () => {
            menu.classList.add('hidden');
            window.removeEventListener('click', closeMenu);
        };
        setTimeout(() => window.addEventListener('click', closeMenu), 0);
    }
    
    showDeleteConfirmation(id, className) {
        this.pendingDeleteId = id;
        const modal = document.getElementById('deleteConfirmationModal');
        const nameSpan = document.getElementById('deleteTargetName');
        if (modal && nameSpan) {
            nameSpan.textContent = className;
            // .flex is what actually activates this modal's own baked-in
            // items-start/justify-center/pt-20 centering utilities (they're
            // no-ops without a flex/grid display) — same pairing
            // openChangeClassMenu() already uses correctly. Toggling only
            // .hidden left this (and every other confirmation modal that
            // copied this same pattern) rendering top-left instead of
            // centered with a top margin.
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    }

    hideDeleteConfirmation() {
        this.pendingDeleteId = null;
        const modal = document.getElementById('deleteConfirmationModal');
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    }
    
    deleteAnnotation(id = null) {
        const targetId = id || this.pendingDeleteId || this.selectedAnnotationId;
        if (!targetId) return;
        this.snapshotBeforeAction();
        this.annotations = this.annotations.filter(a => a.id !== targetId);
        if (this.selectedAnnotationId === targetId) {
            this.selectedAnnotationId = null;
            const toolbar = document.getElementById('annotatorToolbar');
            if (toolbar) toolbar.classList.add('hidden');

            // Deleting the annotation you were actively editing (e.g. via
            // the Delete key while in Brush/Eraser edit mode) must drop back
            // to idle: selectTool(null) hides the brush cursor and clears
            // the 'tool-brush'/'tool-eraser' forced-cursor classes. Without
            // this, activeTool/activeLabel stayed pointed at the
            // now-deleted annotation's class, so the custom cursor kept
            // following the mouse and any click after that either silently
            // started a new stroke of the deleted class or did nothing —
            // there was no way to click and select something else.
            this.activeLabel = null;
            this.activeColor = null;
            this.selectTool(null);
        }
        this.hideDeleteConfirmation();
        this.renderAllAnnotations();
        this.updateLabelsPanel();
    }

    // Sets every OTHER annotation invisible, leaving only `anno` shown —
    // the "Hide other objects" item in openAnnoOptionsMenu(). Deliberately
    // does not touch `anno.locked`/panopticMode/anything else, and does not
    // persist as some separate "isolated" mode — it's just a one-shot bulk
    // edit of anno.visible, exactly like toggling the eye icon on every
    // other row by hand.
    hideOtherAnnotations(anno) {
        this.snapshotBeforeAction();
        this.annotations.forEach(a => { if (a.id !== anno.id) a.visible = false; });
        anno.visible = true;
        this.renderAllAnnotations();
        this.updateLabelsPanel();
    }

    // Reassigns `anno` to a different class: a fresh instanceNumber drawn
    // from the TARGET class's own counter (the old class's counter is left
    // untouched, same as a deleted annotation's number is never reclaimed
    // elsewhere in this file — instanceCounters only ever increase).
    openChangeClassMenu(anno) {
        const modal = document.getElementById('changeClassModal');
        const listContainer = document.getElementById('changeClassListContainer');
        const targetLabel = document.getElementById('changeClassTargetLabel');
        const searchInput = document.getElementById('changeClassSearchInput');
        if (!modal || !listContainer || !targetLabel || !searchInput) return;

        const ITEM_SVG = `<svg viewBox="64 64 896 896" focusable="false" data-icon="appstore-add" width="12px" height="12px" fill="currentColor" aria-hidden="true" style="transform: rotate(270deg);"><path d="M464 144H160c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H212V212h200v200zm452-268H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V160c0-8.8-7.2-16-16-16zm-52 268H612V212h200v200zm52 132H560c-8.8 0-16 7.2-16 16v304c0 8.8 7.2 16 16 16h304c8.8 0 16-7.2 16-16V560c0-8.8-7.2-16-16-16zm-52 268H612V612h200v200zM424 712H296V584c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v128H104c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h128v128c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V776h128c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8z"></path></svg>`;
        const typeLabel = anno.type === 'brush' ? 'Bitmask' : 'Polygon';
        targetLabel.innerHTML = `Change class of 1 <span class="inline-flex items-center align-middle mx-0.5" style="color:${anno.color}">${ITEM_SVG}</span> ${typeLabel}`;

        // Same 1-9, 0, A-Z scheme renderClassList() assigns to the sidebar's
        // own class rows, so the badges shown here match the ones the user
        // already sees there.
        const getShortcut = (index) => {
            if (index <= 9) return index.toString();
            if (index === 10) return '0';
            return String.fromCharCode(97 + index - 11).toUpperCase();
        };
        const allClasses = getAllClasses();

        const renderList = (filter = '') => {
            listContainer.innerHTML = '';
            allClasses.forEach((c, idx) => {
                if (filter && !c.name.toLowerCase().includes(filter.toLowerCase())) return;
                const item = document.createElement('div');
                item.className = 'flex items-center justify-between gap-2 px-3 py-2 text-[13px] text-gray-700 hover:bg-gray-100 cursor-pointer rounded-lg transition-colors';
                item.innerHTML = `
                    <span class="flex items-center gap-2">
                        <span class="inline-flex items-center justify-center" style="color:${c.color}">${ITEM_SVG}</span>
                        <span>${c.name}</span>
                    </span>
                    <span class="kbd-key text-[11px] scale-90">${getShortcut(idx + 1)}</span>
                `;
                item.onclick = () => {
                    this.snapshotBeforeAction();
                    const count = this.instanceCounters[c.name] || 0;
                    this.instanceCounters[c.name] = count + 1;
                    anno.class = c.name;
                    anno.color = c.color;
                    anno.instanceNumber = count + 1;
                    // anno.color is metadata only — a brush mask's pixels
                    // are physically painted with whatever color was active
                    // at stroke time, so just reassigning the field leaves
                    // the shape rendering in its OLD color. Recolor the
                    // existing pixels in place: draw the current mask (for
                    // its alpha/shape only) into a fresh canvas, then
                    // 'source-in' a flat fill of the new color so only
                    // where the shape was opaque gets recolored, alpha
                    // untouched. Vector polygons don't need this — they
                    // read anno.color fresh at render time already.
                    if (anno.type === 'brush' && anno.maskCanvas) {
                        const recolored = this.createFullSizeCanvas();
                        const rctx = recolored.getContext('2d');
                        rctx.drawImage(anno.maskCanvas, 0, 0);
                        rctx.globalCompositeOperation = 'source-in';
                        rctx.fillStyle = c.color;
                        rctx.fillRect(0, 0, recolored.width, recolored.height);
                        anno.maskCanvas = recolored;
                    }
                    this.closeChangeClassModal();
                    this.renderAllAnnotations();
                    this.updateLabelsPanel();
                    this.updateClassCounts();
                };
                listContainer.appendChild(item);
            });
        };
        renderList();
        searchInput.value = '';
        searchInput.oninput = () => renderList(searchInput.value);

        // Own number/letter shortcuts (same 1-9,0,A-Z scheme as the badges
        // just rendered) — without this, the modal shows shortcut badges
        // that do nothing, and the SAME keys instead fall through to the
        // background sidebar's class-selection hotkeys (guarded off above
        // in bindShortcuts(), but that only stops the wrong thing from
        // happening — this is what makes the right thing happen).
        if (this._changeClassKeyHandler) {
            window.removeEventListener('keydown', this._changeClassKeyHandler);
        }
        this._changeClassKeyHandler = (e) => {
            if (document.activeElement === searchInput) return; // let typing work
            if (e.key === 'Escape') { this.closeChangeClassModal(); return; }
            const key = e.key.toUpperCase();
            if (key.length !== 1) return;
            let idx = -1;
            if (key >= '1' && key <= '9') idx = parseInt(key);
            else if (key === '0') idx = 10;
            else if (key >= 'A' && key <= 'Z') idx = key.charCodeAt(0) - 65 + 11;
            if (idx < 1) return;
            const cls = allClasses[idx - 1];
            if (!cls) return;
            const filter = searchInput.value.toLowerCase();
            if (filter && !cls.name.toLowerCase().includes(filter)) return; // not currently visible
            e.preventDefault();
            const item = Array.from(listContainer.children).find(el => el.textContent.includes(cls.name));
            if (item) item.click();
        };
        window.addEventListener('keydown', this._changeClassKeyHandler);

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    closeChangeClassModal() {
        const modal = document.getElementById('changeClassModal');
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
        if (this._changeClassKeyHandler) {
            window.removeEventListener('keydown', this._changeClassKeyHandler);
            this._changeClassKeyHandler = null;
        }
    }

    // The Labels row's "..." button — a pop-out menu reusing the existing
    // [id^="optionsMenu-"] card/triangle-pointer styling (Panoptic-
    // Segmentation.css) by matching its id prefix, with exactly the three
    // items requested: Hide other objects, Change class, Delete object.
    openAnnoOptionsMenu(anno, anchorEl) {
        document.querySelectorAll('[id^="optionsMenu-"]').forEach(m => m.remove());

        const menu = document.createElement('div');
        menu.id = `optionsMenu-${anno.id}`;

        const hideSvg = `<svg viewBox="64 64 896 896" focusable="false" data-icon="eye-invisible" width="14px" height="14px" fill="currentColor" aria-hidden="true"><path d="M942.2 486.2Q889.47 375.11 816.7 305l-50.88 50.88C807.31 395.53 843.45 447.4 874.7 512 791.5 684.2 673.4 766 512 766q-72.67 0-133.87-22.38L323 798.75Q408 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 000-51.5zm-63.57-320.64L836 122.88a8 8 0 00-11.32 0L715.31 232.2Q624.86 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 000 51.5q56.69 119.4 136.5 191.41L112.48 835a8 8 0 000 11.31L155.17 889a8 8 0 0011.31 0l712.15-712.12a8 8 0 000-11.32zM149.3 512C232.6 339.8 350.7 258 512 258c54.54 0 104.13 9.36 149.12 28.39l-70.3 70.3a176 176 0 00-238.13 238.13l-83.42 83.42C223.1 637.49 183.3 582.28 149.3 512zm246.7 0a112.11 112.11 0 01146.2-106.69L401.31 546.2A112 112 0 01396 512z"></path><path d="M508 624c-3.46 0-6.87-.16-10.25-.47l-52.82 52.82a176.09 176.09 0 00227.42-227.42l-52.82 52.82c.31 3.38.47 6.79.47 10.25a111.94 111.94 0 01-112 112z"></path></svg>`;
        const changeSvg = `<svg viewBox="64 64 896 896" focusable="false" data-icon="edit" width="14px" height="14px" fill="currentColor" aria-hidden="true"><path d="M257.7 752c2 0 4-.2 6-.5L431.9 722c2-.4 3.9-1.3 5.3-2.8l423.9-423.9a9.96 9.96 0 000-14.1L694.9 114.9c-1.9-1.9-4.4-2.9-7.1-2.9s-5.2 1-7.1 2.9L256.8 538.8c-1.5 1.5-2.4 3.3-2.8 5.3l-29.5 168.2a33.5 33.5 0 009.4 30.3c6.6 6.4 14.9 9.4 23.8 9.4zm67.4-174.4L687.8 215l73.3 73.3-362.7 362.6-88.9 15.7 15.6-89zM880 836H144c-17.7 0-32 14.3-32 32v36c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-36c0-17.7-14.3-32-32-32z"></path></svg>`;
        const deleteSvg = `<svg viewBox="64 64 896 896" focusable="false" data-icon="delete" width="14px" height="14px" fill="currentColor" aria-hidden="true"><path d="M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72zm504 72H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z"></path></svg>`;

        const makeItem = (svg, label, danger, onClick) => {
            const item = document.createElement('div');
            item.className = 'menu-item';
            if (danger) item.style.color = '#ef4444';
            item.innerHTML = `${svg}<div>${label}</div>`;
            item.onclick = (ev) => {
                ev.stopPropagation();
                menu.remove();
                onClick();
            };
            return item;
        };

        menu.appendChild(makeItem(hideSvg, 'Hide other objects', false, () => this.hideOtherAnnotations(anno)));
        menu.appendChild(makeItem(changeSvg, 'Change class', false, () => this.openChangeClassMenu(anno)));
        const divider = document.createElement('div');
        divider.className = 'menu-divider';
        menu.appendChild(divider);
        menu.appendChild(makeItem(deleteSvg, 'Delete object', true, () => this.deleteAnnotation(anno.id)));

        document.body.appendChild(menu);
        const rect = anchorEl.getBoundingClientRect();
        menu.style.left = Math.max(4, Math.min(window.innerWidth - 220, rect.right + 10)) + 'px';
        menu.style.top = Math.max(4, Math.min(window.innerHeight - 180, rect.top - 10)) + 'px';

        const closeMenu = (ev) => {
            if (!menu.contains(ev.target)) {
                menu.remove();
                window.removeEventListener('mousedown', closeMenu);
            }
        };
        setTimeout(() => window.addEventListener('mousedown', closeMenu), 0);
    }

    toggleLockAll() {
        const anyUnlocked = this.annotations.some(a => !a.locked);
        this.annotations.forEach(a => a.locked = anyUnlocked);
        this.updateLabelsPanel();
    }

    toggleHideAll() {
        const anyVisible = this.annotations.some(a => a.visible);
        this.annotations.forEach(a => a.visible = !anyVisible);
        this.renderAllAnnotations();
        this.updateLabelsPanel();
    }

    eraseAt(x, y) {
        if (!this.selectedAnnotationId) return;
        const anno = this.annotations.find(a => a.id === this.selectedAnnotationId);
        if (!anno || !anno.visible || anno.locked) return;
        this.markDirty();

        const lastX = this.lastEraseX !== undefined ? this.lastEraseX : x;
        const lastY = this.lastEraseY !== undefined ? this.lastEraseY : y;

        if (anno.type === 'brush') {
            if (anno.maskCanvas) {
                const ox = anno.offsetX || 0, oy = anno.offsetY || 0;
                this.paintSegment(
                    anno.maskCanvas,
                    { x: lastX - ox, y: lastY - oy },
                    { x: x - ox, y: y - oy },
                    this.getNativeBrushSize(), this.brushShape || 'circle', null, true
                );
                this._invalidateBBox(anno);
            }
            this.renderBrushLayer();
        } else if (anno.type === 'polygon') {
            this._pushEraserPoint(anno, x, y, lastX, lastY);
            this.renderAllAnnotations();
        }

        this.lastEraseX = x;
        this.lastEraseY = y;
    }

    // Appends to anno.eraserStrokes (used as an SVG mask over filled shapes:
    // polygon fills and brush croppedOutlines). A plain <polyline> renders
    // NOTHING with fewer than 2 points, so a single click (lastX/lastY ===
    // x/y, zero distance) must still seed a real 2-point segment — otherwise
    // clicking without dragging silently erases nothing.
    _pushEraserPoint(anno, x, y, lastX, lastY) {
        if (!anno.eraserStrokes) anno.eraserStrokes = [];

        let currentStroke = anno.eraserStrokes[anno.eraserStrokes.length - 1];
        const isNewStroke = !currentStroke || this.lastEraseX === undefined;
        if (isNewStroke) {
            currentStroke = { size: this.getNativeBrushSize(), shape: this.brushShape || 'circle', points: [] };
            anno.eraserStrokes.push(currentStroke);
            // Seed point so even a single click (no drag yet) forms a
            // renderable zero-length segment.
            currentStroke.points.push({ x: lastX, y: lastY });
        }

        const dist = Math.hypot(x - lastX, y - lastY);
        const steps = Math.max(1, Math.ceil(dist / 2));
        for (let j = 1; j <= steps; j++) {
            currentStroke.points.push({
                x: lastX + (x - lastX) * (j / steps),
                y: lastY + (y - lastY) * (j / steps)
            });
        }
    }

    // Shows, on #dragOverflowCanvas (see its HTML comment), the part of a
    // dragged brush shape that currently sits OUTSIDE the image's own
    // bounds — recolored solid warning-red to flag that finalizeMove() is
    // about to crop it away for real. The in-bounds part is already shown
    // correctly, in its own color, by the normal #brushMaskCanvas render;
    // this only ever draws the OUTSIDE part (punched out via
    // destination-out below), so the two never double up or fight.
    renderDragOverflowIndicator(anno) {
        const canvas = document.getElementById('dragOverflowCanvas');
        if (!canvas || !canvas.width || !canvas.height) return;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const nw = this.workspace.transform.naturalWidth;
        const nh = this.workspace.transform.naturalHeight;
        if (!nw || !nh) return;
        // This canvas's own (0,0) is native (-nw,-nh) (see getImageBounds()),
        // so the real image rect sits at (nw, nh) in its local coordinates.
        const dx = Math.round(this._liveMoveOffsetX || 0) + nw;
        const dy = Math.round(this._liveMoveOffsetY || 0) + nh;

        ctx.drawImage(anno.maskCanvas, dx, dy);
        ctx.globalCompositeOperation = 'source-atop';
        ctx.fillStyle = 'rgba(220,38,38,0.85)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.globalCompositeOperation = 'destination-out';
        // destination-out only removes as much destination alpha as the
        // SOURCE's own alpha carries (result = destAlpha * (1 - srcAlpha)),
        // so this fillStyle must be fully opaque — reusing the 0.85-alpha
        // red from the step above would only erase 85%, leaving a faint
        // red ghost of the "inside" part behind instead of nothing.
        ctx.fillStyle = '#000';
        ctx.fillRect(nw, nh, nw, nh);
        ctx.globalCompositeOperation = 'source-over';

        canvas.classList.remove('hidden');
    }

    hideDragOverflowIndicator() {
        const canvas = document.getElementById('dragOverflowCanvas');
        if (!canvas) return;
        canvas.classList.add('hidden');
        if (canvas.width && canvas.height) {
            canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
        }
    }

    moveAnnotation(id, dx, dy) {
        const anno = this.annotations.find(a => a.id === id);
        if (!anno || !anno.visible || anno.locked) return;
        this.markDirty();

        // Free movement: the whole shape moves together, unconstrained. It
        // can go outside the image while dragging; the shared image-area
        // clip-path (see renderAllAnnotations) hides whatever part sits
        // outside purely visually — the points themselves are never mutated,
        // so moving it back inside always restores the original shape.
        if (anno.type === 'brush') {
            // Live-drag offset only — no pixel data is touched (and nothing
            // can go outside the fixed-size canvas) until finalizeMove()
            // bakes it in.
            this._liveMoveOffsetX = (this._liveMoveOffsetX || 0) + dx;
            this._liveMoveOffsetY = (this._liveMoveOffsetY || 0) + dy;
            this.renderBrushLayer();
            this.renderDragOverflowIndicator(anno);
            return;
        } else if (anno.type === 'polygon' && anno.points) {
            anno.points.forEach(p => {
                p.x += dx;
                p.y += dy;
            });
            if (anno.eraserStrokes) {
                anno.eraserStrokes.forEach(stroke => {
                    if (!stroke.points) return;
                    stroke.points.forEach(p => {
                        p.x += dx;
                        p.y += dy;
                    });
                });
            }
        }

        this.renderAllAnnotations();
    }

    // --- Permanent boundary cropping (matches Encord: the cut is baked into
    // the shape's actual geometry, not just a transient render-time clip).
    // Brush annotations no longer need this: their maskCanvas is always
    // exactly image-sized, so drawImage() clips anything painted or moved
    // past the edge for free — see finalizeMove()/stampBrush(). Only
    // polygon-type point arrays still need explicit clipping. ---

    // Sutherland-Hodgman polygon clip against an axis-aligned rect. Unlike
    // clipping a bare centerline, this correctly handles a FILLED shape —
    // the result is always a clean, flat cut exactly along whichever edges
    // of `rect` the polygon crossed.
    _clipPolygonToRect(points, rect) {
        if (!points || points.length < 3) return [];
        const xmin = rect.rx, xmax = rect.rx + rect.rw;
        const ymin = rect.ry, ymax = rect.ry + rect.rh;

        const clipEdge = (poly, inside, intersect) => {
            const result = [];
            for (let i = 0; i < poly.length; i++) {
                const curr = poly[i];
                const prev = poly[(i - 1 + poly.length) % poly.length];
                const currIn = inside(curr);
                const prevIn = inside(prev);
                if (currIn) {
                    if (!prevIn) result.push(intersect(prev, curr));
                    result.push(curr);
                } else if (prevIn) {
                    result.push(intersect(prev, curr));
                }
            }
            return result;
        };

        let poly = points;
        poly = clipEdge(poly, p => p.x >= xmin, (a, b) => {
            const t = (xmin - a.x) / (b.x - a.x);
            return { x: xmin, y: a.y + t * (b.y - a.y) };
        });
        poly = clipEdge(poly, p => p.x <= xmax, (a, b) => {
            const t = (xmax - a.x) / (b.x - a.x);
            return { x: xmax, y: a.y + t * (b.y - a.y) };
        });
        poly = clipEdge(poly, p => p.y >= ymin, (a, b) => {
            const t = (ymin - a.y) / (b.y - a.y);
            return { x: a.x + t * (b.x - a.x), y: ymin };
        });
        poly = clipEdge(poly, p => p.y <= ymax, (a, b) => {
            const t = (ymax - a.y) / (b.y - a.y);
            return { x: a.x + t * (b.x - a.x), y: ymax };
        });
        return poly;
    }

    // Permanently bakes in a flat boundary cut for whatever part of a
    // polygon annotation now sits outside the image.
    cropAnnotationOutlineToImageBounds(anno) {
        const bounds = this.getImageBounds();

        if (anno.type === 'polygon' && anno.points) {
            const needsCrop = anno.points.some(p => !this.isInsideImage(p.x, p.y));
            if (needsCrop) {
                anno.points = this._clipPolygonToRect(anno.points, bounds);
            }
        }
    }

    deleteAnnotationById(id) {
        this.annotations = this.annotations.filter(a => a.id !== id);
        const wasEditingThis = this.selectedAnnotationId === id;
        if (wasEditingThis) {
            this.selectedAnnotationId = null;
            const toolbar = document.getElementById('annotatorToolbar');
            if (toolbar) toolbar.classList.add('hidden');
            // Same reasoning as deleteAnnotation(): this only ever fires at
            // a gesture's end (stroke commit / drag end), so it's safe to
            // drop straight back to idle here too — otherwise erasing or
            // moving a shape into nothingness left the brush/eraser cursor
            // stuck active with a stale class selected.
            this.activeLabel = null;
            this.activeColor = null;
            this.selectTool(null);
        }
        this.renderAllAnnotations();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
    }

    bindCrosshairEvents() {
        const wrapper = document.getElementById('videoTransformWrapper');
        const crossX = document.getElementById('polygonCrosshairX');
        const crossY = document.getElementById('polygonCrosshairY');
        const crosshair = document.getElementById('polygonCrosshair');

        if (!wrapper || !crossX || !crossY || !crosshair) return;

        // Fixed 1px, set once — #polygonCrosshair now lives OUTSIDE the
        // zoomed #videoTransformWrapper (see its HTML comment), so this is
        // never subject to the ancestor transform:scale() and never needs
        // recomputing per zoom level the way it used to.
        crossX.style.borderTopWidth = '1px';
        crossY.style.borderLeftWidth = '1px';

        wrapper.addEventListener('mousemove', (e) => {
            if (crosshair.classList.contains('hidden')) return;
            // Position in real SCREEN space, relative to the crosshair's
            // own (unscaled) parent panel — not native image-pixel space
            // divided by zoom, which was only correct back when this
            // element lived inside the scaled wrapper and relied on that
            // same transform to re-multiply it back to the right spot.
            const panelRect = crosshair.parentElement.getBoundingClientRect();
            const x = e.clientX - panelRect.left;
            const y = e.clientY - panelRect.top;
            crossX.style.top = y + 'px';
            crossY.style.left = x + 'px';
        });
        
        wrapper.addEventListener('mouseenter', () => {
            if (!crosshair.classList.contains('hidden')) crosshair.style.opacity = '1';
        });
        
        wrapper.addEventListener('mouseleave', () => {
            crosshair.style.opacity = '0';
            const brushCursor = document.getElementById('brushCursor');
            if (brushCursor) {
                brushCursor.style.display = 'none';
                brushCursor.classList.add('hidden');
            }
        });
    }

    updateSize(val) {
        let size = parseInt(val);
        if (isNaN(size)) size = 50;
        if (size < 1) size = 1;
        if (size > 500) size = 500;

        this.brushSize = size;

        const slider = document.getElementById('sizeRangeSlider');
        const textInput = document.getElementById('sizeTextInput');
        const tooltip = document.getElementById('sizeTooltip');

        if (slider) {
            slider.value = size;
            // Fill percentage relative to the slider's own min/max (1-500),
            // NOT the raw size value — that only ever coincidentally worked
            // while max happened to be exactly 100.
            const min = parseFloat(slider.min) || 1;
            const max = parseFloat(slider.max) || 500;
            const pct = ((size - min) / (max - min)) * 100;
            slider.style.background = 'linear-gradient(to right, #a855f7 ' + pct + '%, #e6e6e6 ' + pct + '%)';
        }
        if (textInput) {
            textInput.value = size;
        }
        if (tooltip) {
            tooltip.innerText = size + 'px';
        }
        
        // brushCursor size is a constant on-screen size (see
        // refreshBrushCursorSize()'s comment) — no zoom scale here.
        const brushCursor = document.getElementById('brushCursor');
        if (brushCursor) {
            brushCursor.style.width = `${size}px`;
            brushCursor.style.height = `${size}px`;
            brushCursor.dataset.cachedSize = String(size);
        }
    }

    bindToolbarEvents() {
        const toolbar = document.getElementById('annotatorToolbar');
        const header = document.getElementById('annotatorToolbarHeader');
        
        const shapeCircleBtn = document.getElementById('shapeCircleBtn');
        const shapeSquareBtn = document.getElementById('shapeSquareBtn');
        
        if (shapeCircleBtn && shapeSquareBtn) {
            const updateShapeUI = () => {
                const isSquare = this.brushShape === 'square';
                shapeCircleBtn.className = isSquare
                    ? "cursor-pointer w-5 h-5 flex items-center justify-center rounded-[3px] hover:bg-[#f8f9fa] transition-colors"
                    : "cursor-pointer w-5 h-5 flex items-center justify-center rounded-[3px] bg-[#f8f9fa] border border-[#e4e7eb] text-[#2c3e50]";
                shapeSquareBtn.className = isSquare
                    ? "cursor-pointer w-5 h-5 flex items-center justify-center rounded-[3px] bg-[#f8f9fa] border border-[#e4e7eb] text-[#2c3e50]"
                    : "cursor-pointer w-5 h-5 flex items-center justify-center rounded-[3px] hover:bg-[#f8f9fa] transition-colors";
                
                shapeCircleBtn.firstElementChild.className = isSquare
                    ? "w-2.5 h-2.5 rounded-full bg-[#64748b]"
                    : "w-2.5 h-2.5 rounded-full bg-[#1e293b]";
                shapeSquareBtn.firstElementChild.className = isSquare
                    ? "w-2.5 h-2.5 bg-[#1e293b]"
                    : "w-2.5 h-2.5 bg-[#64748b]";
            };

            shapeCircleBtn.addEventListener('click', () => {
                this.brushShape = 'circle';
                updateShapeUI();
            });
            shapeSquareBtn.addEventListener('click', () => {
                this.brushShape = 'square';
                updateShapeUI();
            });
            
            if (!this.brushShape) this.brushShape = 'circle';
            updateShapeUI();
        }

        if (!toolbar || !header) return;

        let isDragging = false;
        let startX, startY, initialX, initialY;

        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            const rect = toolbar.getBoundingClientRect();
            // Get position relative to the relative parent container
            const parentRect = toolbar.parentElement.getBoundingClientRect();
            initialX = rect.left - parentRect.left;
            initialY = rect.top - parentRect.top;
            
            // Fix absolute positioning so it doesn't jump
            toolbar.style.right = 'auto';
            toolbar.style.left = initialX + 'px';
            toolbar.style.top = initialY + 'px';
        });

        window.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            const newX = initialX + dx;
            const newY = initialY + dy;
            
            toolbar.style.left = newX + 'px';
            toolbar.style.top = newY + 'px';
        });

        window.addEventListener('mouseup', () => {
            isDragging = false;
        });
    }

    // Reveals #classesSearchWrapper (hiding the plain "Classes" title while
    // it's open, same as old-ref) and focuses the input; a second click
    // closes it again and clears whatever filter was applied. This was
    // referenced by the search icon's onclick already but never actually
    // defined anywhere, so clicking it just threw and the input never
    // appeared.
    toggleSearchClasses() {
        const title = document.getElementById('classesHeaderTitle');
        const searchWrapper = document.getElementById('classesSearchWrapper');
        const input = document.getElementById('classesSearchInput');
        if (!title || !searchWrapper || !input) return;
        if (searchWrapper.classList.contains('hidden')) {
            title.classList.add('hidden');
            searchWrapper.classList.remove('hidden');
            input.focus();
        } else {
            title.classList.remove('hidden');
            searchWrapper.classList.add('hidden');
            input.value = '';
            this.filterClasses('');
        }
    }

    filterClasses(query) {
        const searchTerm = query.toLowerCase().trim();
        const groups = document.querySelectorAll('.class-category-group');

        const MINUS_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;
        const PLUS_SVG = `<svg viewBox="0 0 1024 1024" width="11" height="11" fill="currentColor" style="transform: rotate(-90deg);"><path d="M899.1 303.4H124.9c-19.3 0-28.7 22.3-15.3 36.1l369.9 380.7c10.1 10.4 26.9 10.4 37 0l369.9-380.7c13.4-13.8 4-36.1-17.3-36.1z"></path></svg>`;

        const emptyState = document.getElementById('classesSearchEmptyState');
        const setEmptyState = (anyVisible) => {
            if (emptyState) emptyState.classList.toggle('hidden', searchTerm === '' || anyVisible);
        };

        // Flat (ungrouped — see toggleClassGrouping()) class list has no
        // .class-category-group wrapper to hide/show at all, so the loop
        // below would silently do nothing; filter each row directly instead.
        if (groups.length === 0) {
            let anyVisible = false;
            document.querySelectorAll('#classListContainer .class-group').forEach(item => {
                const name = item.textContent.toLowerCase();
                const match = searchTerm === '' || name.includes(searchTerm);
                item.style.display = match ? 'block' : 'none';
                if (match) anyVisible = true;
            });
            setEmptyState(anyVisible);
            return;
        }

        let anyGroupVisible = false;
        groups.forEach(groupEl => {
            const classItems = groupEl.querySelectorAll('.class-group');
            const content = groupEl.querySelector('.class-category-content');
            const iconContainer = groupEl.querySelector('.group-icon-container');
            let hasMatch = false;

            if (searchTerm === '') {
                classItems.forEach(item => item.style.display = 'block');
                groupEl.style.display = 'block';
                anyGroupVisible = true;

                const groupName = groupEl.dataset.groupName;
                if (this.isGroupCollapsed(groupName)) {
                    content.classList.add('hidden');
                    iconContainer.innerHTML = PLUS_SVG;
                } else {
                    content.classList.remove('hidden');
                    iconContainer.innerHTML = MINUS_SVG;
                }
                return;
            }

            classItems.forEach(item => {
                const name = item.textContent.toLowerCase();
                if (name.includes(searchTerm)) {
                    item.style.display = 'block';
                    hasMatch = true;
                } else {
                    item.style.display = 'none';
                }
            });

            if (hasMatch) {
                groupEl.style.display = 'block';
                content.classList.remove('hidden');
                iconContainer.innerHTML = MINUS_SVG;
                anyGroupVisible = true;
            } else {
                groupEl.style.display = 'none';
            }
        });
        setEmptyState(anyGroupVisible);
    }

    // Same open/close/focus pattern as toggleSearchClasses(), scoped to the
    // Labels panel instead. #labelsFilterBtn used to call toggleFilterBar()
    // (a frame start/end range filter) despite its own tooltip already
    // reading "Search objects" — that mismatch is what this replaces;
    // toggleFilterBar()/#labelsFilterBar are left as-is elsewhere in case
    // that frame-range filter is still reachable from another control.
    toggleSearchLabels() {
        const title = document.getElementById('labelsHeaderTitle');
        const searchWrapper = document.getElementById('labelsSearchWrapper');
        const input = document.getElementById('labelsSearchInput');
        if (!title || !searchWrapper || !input) return;
        if (searchWrapper.classList.contains('hidden')) {
            title.classList.add('hidden');
            searchWrapper.classList.remove('hidden');
            input.focus();
        } else {
            title.classList.remove('hidden');
            searchWrapper.classList.add('hidden');
            input.value = '';
            this.filterLabels('');
        }
    }

    // Filters the Labels list by each row's own text (its class name and
    // instance number, e.g. "Car (0)") — updateLabelsPanel() builds rows
    // under a couple of different nesting shapes depending on
    // isClassGrouped/isLabelGrouped (category > class folder > rows, a
    // flat class folder > rows, or grouped-by-object instead of by-class),
    // so this matches every row generically by its shared `label-row-*` id
    // prefix rather than depending on which nesting is currently active,
    // then hides whichever folder-like ancestor ends up with nothing
    // visible inside it.
    filterLabels(query) {
        const searchTerm = query.toLowerCase().trim();
        const rows = document.querySelectorAll('#instructionContainer [id^="label-row-"]');
        rows.forEach(row => {
            const match = searchTerm === '' || row.textContent.toLowerCase().includes(searchTerm);
            row.style.display = match ? '' : 'none';
        });
        document.querySelectorAll('#instructionContainer .w-full.text-neutral-800').forEach(folder => {
            const anyVisible = Array.from(folder.querySelectorAll('[id^="label-row-"]'))
                .some(r => r.style.display !== 'none');
            folder.style.display = (searchTerm === '' || anyVisible) ? '' : 'none';
        });

        const emptyState = document.getElementById('labelsSearchEmptyState');
        if (emptyState) {
            const anyRowVisible = Array.from(rows).some(r => r.style.display !== 'none');
            emptyState.classList.toggle('hidden', searchTerm === '' || anyRowVisible || rows.length === 0);
        }
    }

    // --- Export / Import / Submit (migrated from samsara-template-v2.html's
    // COCO export pipeline) ---------------------------------------------

    // Tight bbox [x, y, w, h] of a polygon's own vector points — used only
    // for the "plain vector polygon" export branch; masks get their bbox
    // from the pixel scan in _encodeCanvasToCocoRLE instead.
    _polygonBBox(points) {
        if (!points || points.length === 0) return null;
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        points.forEach(p => {
            if (p.x < minX) minX = p.x;
            if (p.x > maxX) maxX = p.x;
            if (p.y < minY) minY = p.y;
            if (p.y > maxY) maxY = p.y;
        });
        return [minX, minY, maxX - minX, maxY - minY];
    }

    // COCO RLE encode, ported directly from v2's generateCOCOFormatSync —
    // column-major run-length + LEB128-style 5-bit varint ASCII encoding,
    // matching what pycocotools' frString produces.
    _encodeCanvasToCocoRLE(canvas, w, h) {
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        const data = ctx.getImageData(0, 0, w, h).data;
        let minX = w, minY = h, maxX = -1, maxY = -1, area = 0;
        const counts = [];
        let currentBit = 0, run = 0;

        for (let x = 0; x < w; x++) {
            for (let y = 0; y < h; y++) {
                const bit = data[(y * w + x) * 4 + 3] > 128 ? 1 : 0;
                if (bit === 1) {
                    area++;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
                if (bit === currentBit) {
                    run++;
                } else {
                    counts.push(run);
                    run = 1;
                    currentBit = bit;
                }
            }
        }
        counts.push(run);

        let asciiRle = '';
        for (let i = 0; i < counts.length; i++) {
            let x = counts[i];
            if (i > 2) x -= counts[i - 2];
            let more = true;
            while (more) {
                let c = x & 0x1f;
                x >>= 5;
                const isNegative = (c & 0x10) !== 0;
                more = isNegative ? (x !== -1) : (x !== 0);
                if (more) c |= 0x20;
                c += 48;
                asciiRle += String.fromCharCode(c);
            }
        }

        const bbox = area > 0 ? [minX, minY, (maxX - minX + 1), (maxY - minY + 1)] : [0, 0, 0, 0];
        return { asciiRle, bbox, area };
    }

    // Inverse of _encodeCanvasToCocoRLE — decodes a COCO RLE counts string
    // back into a canvas painted in the given class color. Ported directly
    // from v2's decodeCocoRLE.
    decodeCocoRLEToCanvas(countsStr, rleHeight, rleWidth, colorHex) {
        let p = 0;
        const counts = [];
        while (p < countsStr.length) {
            let x = 0, k = 0, more = 1;
            while (more) {
                const c = countsStr.charCodeAt(p) - 48;
                x |= (c & 0x1f) << k;
                more = c & 0x20;
                p++;
                k += 5;
                if (!more && (c & 0x10)) x |= -1 << k;
            }
            counts.push(x);
        }
        for (let i = 3; i < counts.length; i++) counts[i] += counts[i - 2];

        const canvas = document.createElement('canvas');
        canvas.width = rleWidth;
        canvas.height = rleHeight;
        const ctx = canvas.getContext('2d');
        const imgData = ctx.createImageData(rleWidth, rleHeight);
        const data = imgData.data;

        const r = parseInt(colorHex.slice(1, 3), 16) || 0;
        const g = parseInt(colorHex.slice(3, 5), 16) || 0;
        const b = parseInt(colorHex.slice(5, 7), 16) || 0;

        let pixelPos = 0;
        for (let i = 0; i < counts.length; i++) {
            const run = counts[i];
            const isMask = (i % 2 === 1);
            if (isMask) {
                for (let j = 0; j < run; j++) {
                    const y = (pixelPos + j) % rleHeight;
                    const x = Math.floor((pixelPos + j) / rleHeight);
                    const idx = (y * rleWidth + x) * 4;
                    data[idx] = r; data[idx + 1] = g; data[idx + 2] = b; data[idx + 3] = 255;
                }
            }
            pixelPos += run;
        }
        ctx.putImageData(imgData, 0, 0);
        return canvas;
    }

    // Builds the same COCO-format payload v2 produced. Brush and any
    // polygon that's actually clipped (panoptic mode, or has eraserStrokes)
    // export as pixel-accurate RLE masks pulled from
    // computeFinalAnnotationCanvases() — the exact rasters on screen — so
    // export can never drift from what's visible. A plain, unclipped
    // polygon still exports as real vector points, matching v2.
    generateCOCOFormat() {
        const bounds = this.getImageBounds();
        const imgW = Math.round(bounds.rw) || 1;
        const imgH = Math.round(bounds.rh) || 1;

        const allClasses = getAllClasses();
        const categories = allClasses.map((c, idx) => ({ id: idx + 1, name: c.name, supercategory: c.group }));
        const categoryIdByName = new Map(categories.map(c => [c.name, c.id]));

        const finalCanvasById = new Map(
            this.computeFinalAnnotationCanvases().map(({ anno, canvas }) => [anno.id, canvas])
        );

        const cocoAnnotations = this.annotations.map((ann, idx) => {
            let catId = categoryIdByName.get(ann.class);
            if (!catId) {
                catId = categories.length + 1;
                categories.push({ id: catId, name: ann.class, supercategory: 'Objects' });
                categoryIdByName.set(ann.class, catId);
            }

            const attributes = {
                track_id: idx,
                track_uuid: ann.id,
                classifications: {},
                manual_annotation: true
            };

            const isPlainPolygon = ann.type === 'polygon'
                && (ann.panopticMode || 'none') === 'none'
                && (!ann.eraserStrokes || ann.eraserStrokes.length === 0);

            if (isPlainPolygon) {
                const flatPoints = [];
                (ann.points || []).forEach(p => flatPoints.push(p.x, p.y));
                const bbox = this._polygonBBox(ann.points) || [0, 0, 0, 0];
                return {
                    area: bbox[2] * bbox[3],
                    bbox,
                    category_id: catId,
                    image_id: 0,
                    iscrowd: 0,
                    segmentation: [flatPoints],
                    keypoints: null,
                    num_keypoints: null,
                    id: idx,
                    attributes
                };
            }

            const sourceCanvas = finalCanvasById.get(ann.id) || ann.maskCanvas;
            const { asciiRle, bbox, area } = sourceCanvas
                ? this._encodeCanvasToCocoRLE(sourceCanvas, imgW, imgH)
                : { asciiRle: '', bbox: [0, 0, 0, 0], area: 0 };

            return {
                area,
                bbox,
                category_id: catId,
                image_id: 0,
                iscrowd: 1,
                segmentation: { size: [imgH, imgW], counts: asciiRle },
                keypoints: null,
                num_keypoints: null,
                id: idx,
                attributes
            };
        });

        const fileName = (window.sageMakerData && window.sageMakerData.videoName) || 'image.jpg';

        return {
            info: {
                description: fileName,
                contributor: null,
                date_created: new Date().toISOString(),
                url: null,
                version: null,
                year: new Date().getFullYear()
            },
            categories,
            images: [{
                coco_url: (window.sageMakerData && window.sageMakerData.videoUrl) || '',
                id: 0,
                image_title: fileName,
                file_name: 'images/' + fileName,
                height: imgH,
                width: imgW
            }],
            annotations: cocoAnnotations
        };
    }

    // Ported directly from v2's formatCOCOJSON(): pycocotools' own COCO
    // writer always emits "area" and "bbox" as floats (e.g. 40.0), but
    // JS has no separate int/float number type — a whole-number JS number
    // stringifies as "40", never "40.0", no matter how it was computed.
    // Forcing the distinction means operating on the JSON TEXT itself,
    // after JSON.stringify, rather than the number values: appends ".0" to
    // any bare integer specifically inside an "area" field or a "bbox"
    // array, but only when it doesn't already have a decimal point — so an
    // already-fractional value is left exactly as-is instead of getting a
    // second ".0" appended.
    //
    // A brush/mask annotation's bbox is always built from integer pixel
    // loop indices (see _encodeCanvasToCocoRLE), so it never has a decimal
    // point to begin with. A plain VECTOR polygon's bbox, though, comes
    // straight from raw mouse coordinates (getCanvasCoords() divides by the
    // current zoom scale — a float division), so it's routinely something
    // like 45.2. The PREVIOUS version of this regex matched bare digit runs
    // one at a time rather than whole numbers, so it treated the "2" in
    // "45.2" as its own standalone integer (nothing after it but a comma)
    // and appended ".0" to THAT too — turning 45.2 into the syntactically
    // invalid 45.2.0, which is exactly the kind of number a brush/mask
    // export would never contain, and why only polygon exports ever
    // silently corrupted into unparseable JSON. Matching the WHOLE number
    // token (optional minus, digits, optional .digits) in one go, then
    // deciding once whether IT already has a decimal point, fixes this for
    // any number shape rather than just the brush-only integer case.
    formatCOCOJSON(jsonStr) {
        const appendFloatSuffix = (numStr) => (numStr.includes('.') ? numStr : numStr + '.0');
        let str = jsonStr.replace(/"area":\s*(-?\d+(?:\.\d+)?)/g, (m, num) => `"area": ${appendFloatSuffix(num)}`);
        str = str.replace(/"bbox":\s*\[([\s\S]*?)\]/g, (match, inner) => {
            const replacedInner = inner.replace(/-?\d+(?:\.\d+)?/g, appendFloatSuffix);
            return '"bbox": [' + replacedInner + ']';
        });
        return str;
    }

    // Downloads the current annotations as a COCO JSON file. Ported from
    // v2's exportJSON() — Blob + object URL, not a data: URI, since dense
    // RLE masks can easily exceed the practical size limit of a data: URI.
    exportAnnotations() {
        if (this.annotations.length === 0) {
            this.showToast('No annotations to export.');
            return;
        }
        try {
            const outputJSON = this.generateCOCOFormat();
            const jsonStr = this.formatCOCOJSON(JSON.stringify(outputJSON, null, 2));
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            const fileName = (window.sageMakerData && window.sageMakerData.videoName) || 'coco_segmentation.jpg';
            const nameWithoutExt = fileName.split('/').pop().replace(/\.[^/.]+$/, '') || 'coco_segmentation';
            a.download = `${nameWithoutExt}.coco.json`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch (err) {
            console.error('Export JSON failed:', err);
            this.showToast('Export failed — check the console for details.');
        }
    }

    // Unwraps whatever shape the platform actually handed back for a
    // previously-saved task — ported directly from samsara-template-v2.html's
    // unwrapPayload(), which is the confirmed-working reference for restoring
    // on this same FMN platform (unlike this template, it persists
    // correctly today). Handles: a JSON string that still needs parsing; an
    // extra {data: {...}} wrapper; annotations itself re-stringified inside
    // the object; annotations nested one level deeper than expected. Returns
    // a flat {annotations, categories, info, images} object, or the input
    // unchanged if none of those shapes matched.
    unwrapPayload(p) {
        if (!p) return null;
        if (typeof p === 'string') {
            try { p = JSON.parse(p); } catch (e) { return null; }
        }
        if (p.data && typeof p.data === 'object') p = p.data;
        if (p.annotations !== undefined) {
            if (typeof p.annotations === 'string') {
                try { return this.unwrapPayload(JSON.parse(p.annotations)); } catch (e) { return p; }
            }
            if (typeof p.annotations === 'object' && !Array.isArray(p.annotations)) {
                return this.unwrapPayload(p.annotations);
            }
            if (Array.isArray(p.annotations)) {
                return { annotations: p.annotations, categories: p.categories, info: p.info, images: p.images };
            }
        }
        return p;
    }

    // Reads whatever previously-saved annotation data is available RIGHT
    // NOW, in priority order:
    //   1. window.FMN.existingAnnotation — this template hosted through FMN.
    //   2. window.sageMakerData.prev_annotations — SageMaker Ground Truth's
    //      OWN native clone/relaunch-job restore field, set via this file's
    //      own Liquid templating (`{{ task.input['annotations'] | to_json
    //      | default: '[]' }}` — see the <script> near the top of the HTML).
    //      This is what makes the template work on PLAIN AWS SageMaker
    //      Ground Truth with no FMN wrapper involved at all — FMN is its
    //      own platform-specific integration, not an AWS mechanism, so
    //      relying on window.FMN alone would silently restore nothing for
    //      a task run outside FMN.
    //   3. #annotations-output's own value — the platform/Liquid may have
    //      pre-filled it server-side by some other route.
    // Stashes whatever's found for loadExistingAnnotations() to actually
    // process once the image's real dimensions are known. Deliberately
    // does NOT call processImportedAnnotations() itself: this runs at
    // WorkspaceManager construction time, before the image has loaded, and
    // importing a brush/mask annotation needs getImageBounds()'s real
    // width/height to correctly scale/place it. Called again from the
    // fmn-annotation-restored listener below in case window.FMN.existingAnnotation
    // wasn't populated yet at this first, very early synchronous check
    // (this template's own init runs earlier — at DOMContentLoaded — than
    // v2's, which only checks on the image's load event, by which point
    // FMN's own restore bridge has reliably already run).
    captureRestoreData() {
        if (this._restoredOnce) return;
        const outputInput = document.getElementById('annotations-output');
        const FMN = window.FMN || {};
        let existingData = null;

        if (FMN.existingAnnotation) {
            existingData = this.unwrapPayload(FMN.existingAnnotation);
        } else if (window.sageMakerData && window.sageMakerData.prev_annotations
            && window.sageMakerData.prev_annotations !== '[]' && window.sageMakerData.prev_annotations !== '""') {
            try {
                let taskInput = JSON.parse(window.sageMakerData.prev_annotations);
                // Liquid's `to_json` applied to a field that was ALREADY a
                // JSON string (our own submit writes a stringified COCO
                // payload into the "annotations" form field) double-encodes
                // it — the first parse above only unwraps the outer layer,
                // still leaving a string, not yet the real object.
                if (typeof taskInput === 'string') taskInput = JSON.parse(taskInput);
                // SageMaker clone/relaunch jobs sometimes wrap the previous
                // response in an array (one entry per prior worker) rather
                // than handing back the object directly.
                if (Array.isArray(taskInput) && taskInput.length > 0) taskInput = taskInput[0];
                existingData = this.unwrapPayload(taskInput);
            } catch (e) { /* not valid JSON — nothing to restore from this tier */ }
        } else if (outputInput && outputInput.value) {
            try { existingData = this.unwrapPayload(JSON.parse(outputInput.value)); } catch (e) { /* not JSON yet */ }
        }

        if (existingData && Array.isArray(existingData.annotations) && existingData.annotations.length > 0) {
            this._pendingRestoreData = existingData;
        }
    }

    // Actually applies whatever captureRestoreData() found, now that the
    // image is loaded and getImageBounds() has real dimensions to work
    // with. One-shot — _restoredOnce prevents a later capture/load pair
    // (from the fmn-annotation-restored listener) from re-importing on top
    // of annotations the annotator has since started drawing themselves.
    //
    // Also callable before the image has actually finished loading (the
    // fmn-annotation-restored event's timing relative to the image's own
    // load event isn't something this template controls) — getImageBounds()
    // falls back to a fake 1000x1000 default when the media element's real
    // naturalWidth/naturalHeight aren't known yet, so checking THOSE
    // directly (rather than getImageBounds()'s output) is what actually
    // tells real from placeholder. If it's too early, this just leaves
    // _pendingRestoreData in place — sizeWrapperToImage()'s own call, once
    // the image genuinely loads, will pick it up then.
    loadExistingAnnotations() {
        if (this._restoredOnce || !this._pendingRestoreData) return;
        const media = document.getElementById('mainVideo');
        if (!media || !media.naturalWidth || !media.naturalHeight) return;
        this._restoredOnce = true;
        const data = this._pendingRestoreData;
        this._pendingRestoreData = null;
        this.processImportedAnnotations(data);
    }

    // Keeps #annotations-output's value fresh with the CURRENT annotation
    // state at all times, not just at explicit Submit — ported from v2's
    // syncHiddenInputSilently(). Hooked into updateLabelsPanel() (called
    // after nearly every mutation — drawing, deleting, class changes, ...)
    // so a "Save and Exit" triggered by the platform's own UI (which never
    // calls this template's own submitAnnotations()) still has current
    // data to read, rather than whatever was last written at explicit
    // Submit time (or nothing at all, if Submit was never clicked this
    // session). Silent by design — no toast, no console noise on success —
    // since this fires constantly as a background sync, not a user action.
    syncHiddenInputSilently() {
        const outputInput = document.getElementById('annotations-output');
        if (!outputInput) return;
        try {
            const jsonStr = this.formatCOCOJSON(JSON.stringify(this.generateCOCOFormat()));
            outputInput.value = jsonStr;
            // Some host platforms (this one included, per the FMN bridge
            // that watches for unsaved-changes) detect edits by listening
            // for the input's own 'input' event rather than polling — a
            // plain .value assignment alone doesn't fire that.
            outputInput.dispatchEvent(new Event('input', { bubbles: true }));
        } catch (e) {
            console.error('Auto-save sync failed:', e);
        }
    }

    // Parses a COCO-format annotations JSON (same shape exportAnnotations()
    // produces) and replaces the current annotation set with it. Ported
    // from v2's processImportedData(), adapted to v3's data model (a real
    // maskCanvas per brush annotation instead of a shared drawCanvas). If
    // the imported mask's pixel dimensions don't match the currently loaded
    // image, it's scaled to fit rather than silently misaligning.
    processImportedAnnotations(data) {
        if (!data || !Array.isArray(data.annotations) || !Array.isArray(data.categories)) {
            this.showToast('Invalid annotations JSON — expected COCO-format "annotations" and "categories".');
            return false;
        }

        const bounds = this.getImageBounds();
        const imgW = Math.round(bounds.rw) || 1;
        const imgH = Math.round(bounds.rh) || 1;
        const allClasses = getAllClasses();

        this.annotations = [];
        this.selectedAnnotationId = null;
        this.multiSelectedIds.clear();
        this.instanceCounters = {};
        // A fresh import is a new document, not an edit to undo back past —
        // reset history rather than letting Ctrl+Z reach into the previous
        // annotation set.
        this.initHistory();

        let importedPolygons = 0, importedMasks = 0;

        data.annotations.forEach(ann => {
            const cat = data.categories.find(c => c.id === ann.category_id);
            if (!cat) return;
            const className = cat.name;
            const classDef = allClasses.find(c => c.name.toLowerCase() === className.toLowerCase());
            const color = classDef ? classDef.color : '#10b981';

            const count = this.instanceCounters[className] || 0;
            this.instanceCounters[className] = count + 1;
            const id = (ann.attributes && ann.attributes.track_uuid)
                || `anno_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

            if (ann.iscrowd === 0 && Array.isArray(ann.segmentation) && ann.segmentation.length > 0) {
                // Normally ann.segmentation is [[x1,y1,x2,y2,...]] — an
                // array holding exactly one ring's flat coordinate array
                // (matching generateCOCOFormat()'s own `segmentation:
                // [flatPoints]`). This is the ONE shape unique to polygon
                // export (brush's segmentation is an OBJECT — {size,
                // counts} — never an array), so it's the one place a
                // storage layer that "helpfully" collapses a single-
                // element array-of-arrays down to just the inner array
                // would silently affect polygon restore and never brush.
                // If that's happened, ann.segmentation[0] is a lone
                // coordinate number rather than the ring — detect that and
                // fall back to treating ann.segmentation itself as the
                // flat ring, instead of silently reconstructing zero
                // points (no error either way — just an empty polygon
                // that then never clears computeFinalAnnotationCanvases()'s
                // "at least 3 points" filter, i.e. it looks like it never
                // persisted at all).
                const flat = Array.isArray(ann.segmentation[0]) ? ann.segmentation[0] : ann.segmentation;
                const points = [];
                for (let i = 0; i < flat.length; i += 2) points.push({ x: flat[i], y: flat[i + 1] });
                // A real ring always has >= 3 points — computeFinalAnnotationCanvases()
                // silently excludes anything under that from rendering (no
                // error), which is indistinguishable from "never persisted"
                // unless something actually says so here.
                if (points.length < 3) {
                    console.warn('Restored polygon annotation has fewer than 3 points after unwrapping segmentation — it will not be visible.', ann);
                }
                this.annotations.push({
                    id, class: className, instanceNumber: count + 1, color, objectColor: this.nextObjectColor(), type: 'polygon',
                    visible: true, locked: false, panopticMode: 'none', overlapMode: 'none', points
                });
                importedPolygons++;
            } else if (ann.segmentation && typeof ann.segmentation.counts === 'string') {
                const [rleHeight, rleWidth] = ann.segmentation.size;
                let maskCanvas = this.decodeCocoRLEToCanvas(ann.segmentation.counts, rleHeight, rleWidth, color);
                if (rleWidth !== imgW || rleHeight !== imgH) {
                    const resized = this.createFullSizeCanvas();
                    resized.getContext('2d').drawImage(maskCanvas, 0, 0, rleWidth, rleHeight, 0, 0, imgW, imgH);
                    maskCanvas = resized;
                }
                this.annotations.push({
                    id, class: className, instanceNumber: count + 1, color, objectColor: this.nextObjectColor(), type: 'brush',
                    visible: true, locked: false, panopticMode: 'none', overlapMode: 'none', maskCanvas, offsetX: 0, offsetY: 0
                });
                importedMasks++;
            }
        });

        this.renderAllAnnotations();
        this.updateClassCounts();
        if (typeof this.updateLabelsPanel === 'function') this.updateLabelsPanel();
        this.showToast(`Imported ${importedPolygons} polygon(s) and ${importedMasks} mask(s).`);
        return true;
    }

    triggerImportAnnotations() {
        const input = document.getElementById('annotationsImportInput');
        if (input) input.click();
    }

    handleImportAnnotationsFile(event) {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                this.processImportedAnnotations(data);
            } catch (err) {
                console.error('Failed to parse annotations JSON:', err);
                this.showToast('Failed to parse JSON file.');
            }
            event.target.value = '';
        };
        reader.readAsText(file);
    }

    // Submit is a one-way, hard-to-undo action (hands the annotations off
    // to the platform / logs them as final) — same "confirm before the
    // irreversible thing" pattern as showDeleteConfirmation(), just with
    // its own modal since this isn't tied to any single annotation.
    openSubmitConfirmation() {
        const modal = document.getElementById('submitConfirmationModal');
        // .flex activates this modal's own baked-in items-start/
        // justify-center/pt-20 centering utilities — see
        // showDeleteConfirmation()'s own comment for why .hidden alone
        // isn't enough (they're no-ops without a flex/grid display).
        if (modal) {
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    }

    hideSubmitConfirmation() {
        const modal = document.getElementById('submitConfirmationModal');
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    }

    confirmSubmitAnnotations() {
        this.hideSubmitConfirmation();
        this.submitAnnotations();
    }

    // Ported from v2's submitAnnotations(): builds the COCO payload and
    // hands it to the platform. v3 doesn't have a <crowd-form> wrapper wired
    // up yet (that's a SageMaker Ground Truth custom-element dependency
    // this template doesn't currently load), so this degrades gracefully to
    // a local success toast + console-logged payload — the same fallback
    // v2 used for local testing — instead of silently doing nothing.
    submitAnnotations() {
        let jsonStr = '';
        try {
            jsonStr = this.formatCOCOJSON(JSON.stringify(this.generateCOCOFormat()));
        } catch (e) {
            console.error('Failed to build COCO output on submit:', e);
            this.showToast('Submit failed — check the console for details.');
            return;
        }

        const outputInput = document.getElementById('annotations-output');
        if (outputInput) outputInput.value = jsonStr;

        const hiddenBtn = document.getElementById('hidden-submit-btn');
        const cf = document.querySelector('crowd-form');
        if (hiddenBtn) {
            hiddenBtn.click();
        } else if (cf && typeof cf.submit === 'function') {
            cf.submit();
        } else {
            console.log('Submitted JSON payload:', jsonStr);
            this.showToast('Submitted (local) — see console for the JSON payload.');
        }
    }
}

class SimpleTimeline {
    constructor(videoCtrl) {
        this.videoCtrl = videoCtrl;
        this.track     = document.getElementById('progressTrack');
        this.fill      = document.getElementById('progressFill');
        this.knob      = document.getElementById('progressKnob');
        this.hoverPill = document.getElementById('hoverPill');
        this.isScrubbing = false;
        this.bindEvents();
    }

    bindEvents() {
        if (!this.track) return;

        const scrub = (e) => {
            const rect = this.track.getBoundingClientRect();
            const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            this.videoCtrl.currentTime = pct * this.videoCtrl.duration;
            this.update();
        };

        this.track.addEventListener('mousedown', (e) => { this.isScrubbing = true; scrub(e); });
        window.addEventListener('mousemove',  (e) => { if (this.isScrubbing) scrub(e); });
        window.addEventListener('mouseup',    ()  => { this.isScrubbing = false; });

        // Hover pill — show timestamp
        this.track.addEventListener('mousemove', (e) => {
            if (!this.hoverPill || this.videoCtrl.duration === 0) return;
            const rect = this.track.getBoundingClientRect();
            const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            const sec  = pct * this.videoCtrl.duration;
            
            let displayVal = '';
            if (window.Workspace) {
                displayVal = window.Workspace.formatTimeDisplay(sec, window.Workspace.timestampFormat);
            } else {
                const mm = String(Math.floor(sec / 60)).padStart(2, '0');
                const ss = String(Math.floor(sec % 60)).padStart(2, '0');
                displayVal = `${mm}:${ss}`;
            }

            this.hoverPill.innerText    = displayVal;
            this.hoverPill.style.left   = `${pct * 100}%`;
            this.hoverPill.classList.remove('hidden');
        });
        this.track.addEventListener('mouseleave', () => {
            this.hoverPill?.classList.add('hidden');
        });
    }

    update() {
        if (!this.track || this.videoCtrl.duration === 0) return;
        const pct = (this.videoCtrl.currentTime / this.videoCtrl.duration) * 100;
        if (this.fill) this.fill.style.width = `${pct}%`;
        if (this.knob) this.knob.style.left  = `${pct}%`;
    }
}

class WorkspaceManager {
    constructor() {
        this.videoCtrl       = null;
        this.transform       = null;
        this.timeline        = null;
        this.ui              = null;
        this.timestampFormat = 'Frames';
    }

    init() {
        const videoEl   = document.getElementById('mainVideo');
        const wrapperEl = document.getElementById('videoTransformWrapper');

        this.videoCtrl = new VideoController(videoEl);
        this.transform = new ViewportTransform(wrapperEl, videoEl);
        this.timeline  = new SimpleTimeline(this.videoCtrl);
        this.ui        = new UIManager(this);
        // Must run BEFORE the very first updateLabelsPanel() call below —
        // that call's own syncHiddenInputSilently() would otherwise
        // overwrite #annotations-output's value (which may already hold
        // this task's previously-saved annotations, written by the
        // platform/Liquid before this script ever ran) with an empty
        // payload before captureRestoreData() ever gets a chance to read
        // it back out. See captureRestoreData()'s own comment for why it
        // only stashes the data rather than fully restoring it right here.
        this.ui.captureRestoreData();
        this.ui.renderClassList();
        // Without this, a fresh page load left #instructionContainer as a
        // genuinely blank div — updateLabelsPanel() (and its "no
        // annotations yet" empty state) was only ever triggered by an
        // action afterward (drawing, deleting, ...), never on init itself.
        this.ui.updateLabelsPanel();
        this.ui.bindToolbarEvents();

        // Set initial speed to 1x
        this.videoCtrl.playbackRate = WORKSPACE_CONFIG.DEFAULT_SPEED;

        this.bindEvents();
        this.bindShortcuts();

        window.app = this.ui;

        videoEl.addEventListener('loadedmetadata', () => this.updateWorkspaceUI());

        // Sizes #videoTransformWrapper to the image's own native pixel
        // dimensions (see ViewportTransform.naturalWidth/naturalHeight +
        // fitToContainer()) instead of 100% of its container, then keeps
        // #imageBoundsBox/#annotationCanvas/the clip rect synced via
        // getImageBounds(). Runs once real dimensions are known; unlike the
        // old per-resize letterbox recompute, naturalWidth/naturalHeight
        // never change afterward, so this never needs to run again once the
        // image has loaded.
        const sizeWrapperToImage = () => {
            const nw = videoEl.naturalWidth;
            const nh = videoEl.naturalHeight;
            if (!nw || !nh) return;
            wrapperEl.style.width = nw + 'px';
            wrapperEl.style.height = nh + 'px';
            this.transform.naturalWidth = nw;
            this.transform.naturalHeight = nh;
            this.transform.fitToContainer();
            this.ui.getImageBounds();
            // Only now, with real dimensions in place, can a restored
            // brush/mask annotation be correctly scaled/placed — see
            // captureRestoreData()/loadExistingAnnotations()'s own comments.
            this.ui.loadExistingAnnotations();
            hideAppLoadingOverlay();
        };
        videoEl.addEventListener('load', sizeWrapperToImage);
        // If the image fails outright, don't leave the loading overlay
        // stuck forever over a page the user can otherwise still use — and
        // still attempt the restore (matching v2's own onerror fallback),
        // since a broken image shouldn't also cost the annotator their
        // previously-saved work.
        videoEl.addEventListener('error', () => {
            this.ui.loadExistingAnnotations();
            hideAppLoadingOverlay();
        });
        if (videoEl.complete && videoEl.naturalWidth) sizeWrapperToImage();

        // Resizing the container no longer touches annotation coordinates
        // at all (they live in the image's fixed native pixel grid) — only
        // the CSS transform's scale needs to react, and only while the user
        // hasn't manually zoomed/panned away from the default fit
        // (isAtDefaultFit), so a deliberate zoom level a user picked isn't
        // silently reset just because the sidebar moved.
        window.addEventListener('resize', () => {
            if (this.transform.isAtDefaultFit) this.transform.fitToContainer();
        });
    }

    bindEvents() {
        const video = this.videoCtrl.video;

        video.addEventListener('timeupdate', () => this.updateWorkspaceUI());
        video.addEventListener('play',       () => this.updatePlayState());
        video.addEventListener('pause',      () => this.updatePlayState());
        
        const brushCursor = document.getElementById('brushCursor');
        if (brushCursor) {
            document.body.appendChild(brushCursor);
            brushCursor.style.position = 'fixed';
            brushCursor.style.zIndex = '99999';
        }

        const container = document.getElementById('videoTransformWrapper');
        if (container) {
            // Used to be a from-scratch object-fit:contain recomputation
            // gating wheel-zoom-anchoring and shift/middle-click panning to
            // "inside the actual picture" (as opposed to the letterboxed
            // margin around it). It read video.videoWidth/videoHeight, which
            // only exist on <video> — `video` here is the <img>, so those
            // are always undefined and this always returned true; it's been
            // an unconditional pass-through already, unrelated to the
            // native-pixel coordinate migration. Left as a named no-op
            // rather than removed outright, so the call sites below don't
            // need touching if a real dead-zone check is ever needed again.
            const isInsideVideo = () => true;

            container.parentElement.addEventListener('wheel', (e) => {
                if (!isInsideVideo(e)) return;
                e.preventDefault();
                this.transform.cancelPendingTransition();
                // Settings drawer > General > "Invert mouse wheel zoom
                // direction" — forward/deltaY<0 zooms in by default;
                // inverted, it zooms out instead (and vice versa).
                let zoomingIn = e.deltaY < 0;
                if (this.ui && this.ui.invertWheelZoom) zoomingIn = !zoomingIn;
                // Percentage of the CURRENT scale, not the fixed
                // this.transform.zoomStep — see WORKSPACE_CONFIG.
                // ZOOM_WHEEL_PERCENT's own comment for why a flat step
                // makes a wheel notch feel like it needs two or three tries
                // to register once you're zoomed in a while.
                const percentStep = this.transform.scale * WORKSPACE_CONFIG.ZOOM_WHEEL_PERCENT;
                const step = zoomingIn ? percentStep : -percentStep;
                this.transform.zoom(step, e.clientX, e.clientY);
            }, { passive: false });

            container.parentElement.addEventListener('mousedown', (e) => {
                if (!isInsideVideo(e)) return;
                if (e.button === 1 || e.shiftKey) {
                    this.transform.startPan(e.clientX, e.clientY);
                    container.parentElement.style.cursor = 'grabbing';
                }
            });
            container.parentElement.addEventListener('mousemove', (e) => this.transform.pan(e.clientX, e.clientY));
            window.addEventListener('mouseup', () => {
                this.transform.endPan();
                if (container.parentElement) container.parentElement.style.cursor = 'default';
            });
        }

        // Close menus on outside click
        window.addEventListener('click', () => { if (this.ui) this.ui.closeAllMenus(); });
    }

    updatePlayState() {
        const icon = document.getElementById('playIconSvg');
        if (!icon) return;
        icon.innerHTML = this.videoCtrl.video.paused
            ? '<polygon points="6 3 20 12 6 21 6 3"></polygon>'
            : '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>';
    }

    formatTimeDisplay(totalSeconds, format) {
        if (format === 'Frames') {
            return Math.round(totalSeconds * WORKSPACE_CONFIG.FPS);
        }
        
        const hrs = Math.floor(totalSeconds / 3600);
        const mins = Math.floor((totalSeconds % 3600) / 60);
        const secs = Math.floor(totalSeconds % 60);
        const frames = Math.round((totalSeconds % 1) * WORKSPACE_CONFIG.FPS);
        
        if (format === 'HH:MM:SS') {
            return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        if (format === 'MM:SS') {
            return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        if (format === 'SS.FF') {
            return `${Math.floor(totalSeconds).toString().padStart(2, '0')}.${frames.toString().padStart(2, '0')}`;
        }
        return Math.round(totalSeconds * WORKSPACE_CONFIG.FPS);
    }

    updateWorkspaceUI() {
        const currentTime = this.videoCtrl.currentTime;
        const duration = this.videoCtrl.duration;

        const cfDisplay = this.formatTimeDisplay(currentTime, this.timestampFormat);
        const tfDisplay = this.formatTimeDisplay(duration, this.timestampFormat);

        const inp = document.getElementById('currentFrameInput');
        if (inp && document.activeElement !== inp) inp.value = cfDisplay;

        const tot = document.getElementById('totalFramesText');
        if (tot) tot.textContent = tfDisplay;

        this.timeline.update();
    }

    stepSpeed(direction) {
        const speeds = WORKSPACE_CONFIG.DEFAULT_SPEEDS;
        const cur = this.videoCtrl.playbackRate;
        let idx = speeds.indexOf(cur);
        if (idx === -1) idx = speeds.findIndex(s => s >= cur);
        if (direction === 'up' && idx < speeds.length - 1) {
            this.videoCtrl.playbackRate = speeds[idx + 1];
            document.getElementById('currentSpeedBtn').innerText = speeds[idx + 1] + 'x';
            if(this.ui) this.ui._updateActiveOption('speed-opt', speeds[idx + 1].toString());
        } else if (direction === 'down' && idx > 0) {
            this.videoCtrl.playbackRate = speeds[idx - 1];
            document.getElementById('currentSpeedBtn').innerText = speeds[idx - 1] + 'x';
            if(this.ui) this.ui._updateActiveOption('speed-opt', speeds[idx - 1].toString());
        }
    }

    bindShortcuts() {
        window.addEventListener('keydown', (e) => {
            const key = e.key.toUpperCase();
            const active = document.activeElement;
            if (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') return;

            // A modal with its OWN number/letter shortcuts (Change class)
            // is currently open — its own listener (bound in
            // openChangeClassMenu()) handles these keys against ITS list,
            // not the background sidebar. Without this guard, e.g. pressing
            // "2" while that modal is open would select class #2 in the
            // SIDEBAR behind it instead of option #2 IN the modal.
            const changeClassModal = document.getElementById('changeClassModal');
            if (changeClassModal && changeClassModal.classList.contains('flex')) return;

            // Global Shift shortcuts — top toolbar (Center Content / zoom)
            // and the Labels panel (hide/unhide all). Checked, and returned
            // on, BEFORE the class-letter-shortcut block below: that block
            // has no shiftKey guard of its own, so e.g. Shift+C would
            // otherwise still fall through and get treated as the same
            // plain-C class-shortcut letter is (H is already excluded there
            // via TOOL_SHORTCUT_LETTERS, but C is not).
            if (e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) {
                if (key === 'C') {
                    e.preventDefault();
                    this.transform.animateOnce(() => this.transform.reset());
                    return;
                }
                if (key === 'ARROWUP') {
                    e.preventDefault();
                    this.transform.animateOnce(() => this.transform.zoom(this.transform.scale * WORKSPACE_CONFIG.ZOOM_WHEEL_PERCENT));
                    return;
                }
                if (key === 'ARROWDOWN') {
                    e.preventDefault();
                    this.transform.animateOnce(() => this.transform.zoom(-this.transform.scale * WORKSPACE_CONFIG.ZOOM_WHEEL_PERCENT));
                    return;
                }
                if (key === 'H') {
                    e.preventDefault();
                    if (this.ui) this.ui.toggleHideAll();
                    return;
                }
            }

            // Class selection via keyboard shortcuts (1-9, 0, A-Z)
            let shortcutIndex = -1;
            if (key.length === 1) {
                if (key >= '1' && key <= '9') {
                    shortcutIndex = parseInt(key);
                } else if (key === '0') {
                    shortcutIndex = 10;
                } else if (key >= 'A' && key <= 'Z' && !TOOL_SHORTCUT_LETTERS.includes(key)) {
                    // D/F/G/H are reserved for tool shortcuts (freehand
                    // toggle, brush, polygon, eraser — see
                    // handleCanvasKeyDown) even though getShortcut() may
                    // still hand one of them out as a class's displayed
                    // badge letter; a class landing on one of these is
                    // simply not reachable by that letter, only by click.
                    shortcutIndex = key.charCodeAt(0) - 65 + 11;
                }
            }
            
            if (shortcutIndex > 0) {
                const allClasses = getAllClasses();
                if (shortcutIndex <= allClasses.length) {
                    const cls = allClasses[shortcutIndex - 1];
                    const targetEl = document.querySelector(`.class-group[data-classname="${cls.name}"]`);
                    if (targetEl) {
                        e.preventDefault();
                        if (window.app && typeof window.app.showToolbar === 'function') {
                            window.app.showToolbar(targetEl, cls.name);
                        }
                        return;
                    }
                }
            }

            if (e.altKey && key === 'T') {
                e.preventDefault();
                const formats = ['Frames', 'HH:MM:SS', 'MM:SS', 'SS.FF'];
                let idx = formats.indexOf(this.timestampFormat);
                idx = (idx + 1) % formats.length;
                this.timestampFormat = formats[idx];
                this.updateWorkspaceUI();
                if (this.ui) this.ui._updateActiveOption('ts-opt', this.timestampFormat);
                return;
            }

            switch (key) {
                case WORKSPACE_CONFIG.KEY_MAP.PLAY_PAUSE: e.preventDefault(); this.videoCtrl.togglePlay(); break;
                case WORKSPACE_CONFIG.KEY_MAP.PREV_FRAME:  e.preventDefault(); this.videoCtrl.stepFrames(-1); break;
                case WORKSPACE_CONFIG.KEY_MAP.NEXT_FRAME:  e.preventDefault(); this.videoCtrl.stepFrames(1);  break;
                case 'ARROWUP':   e.preventDefault(); this.stepSpeed('up');   break;
                case 'ARROWDOWN': e.preventDefault(); this.stepSpeed('down'); break;
            }
        });
    }
}

// Fades out and removes #appLoadingOverlay (see its HTML comment) —
// called once the main image is actually ready (or has failed outright,
// so a broken image doesn't leave the overlay stuck forever). Safe to
// call more than once; the element removes itself the first time.
function hideAppLoadingOverlay() {
    const overlay = document.getElementById('appLoadingOverlay');
    if (!overlay) return;
    overlay.style.opacity = '0';
    setTimeout(() => overlay.remove(), 200);
}

// Global hover tooltips for every `data-tooltip="..."` element in the app
// (toolbar buttons, the Labels panel's overlap-mode icon, etc.) — the CSS
// for this already existed (.custom-tooltip/.tooltip-arrow-*/.theme-white in
// Panoptic-Segmentation.css) but nothing anywhere ever created, positioned,
// or showed the element that CSS was written for, so `data-tooltip` was pure
// inert markup and hovering ANY of these buttons did nothing. One delegated
// listener on `document` (rather than binding each `[data-tooltip]` element
// individually at load time) so this also covers elements created later —
// e.g. the Labels panel's per-row must/cannot-overlap icon, which is
// (re)built from scratch by updateLabelsPanel() every time the panel
// re-renders, well after this runs once at startup.
function initGlobalTooltips() {
    let tooltipEl = null;
    let currentTarget = null;

    const ensureTooltipEl = () => {
        if (!tooltipEl) {
            tooltipEl = document.createElement('div');
            tooltipEl.className = 'custom-tooltip';
            document.body.appendChild(tooltipEl);
        }
        return tooltipEl;
    };

    // Positions the tooltip against `target` and returns which side it
    // actually ended up on ('top' | 'bottom') — not necessarily
    // `requestedPos`. Two things a naive "always honor requestedPos, just
    // clamp into whatever room exists" version got wrong in practice:
    //
    // 1. Near the top of the viewport (e.g. the main toolbar's "Center
    //    Content" icon), honoring `pos="top"` and merely clamping the
    //    result to stay on-screen renders the tooltip ON TOP OF the
    //    toolbar's own icon row instead of above it — there's nowhere
    //    above to clamp INTO. Flipping to the opposite side (which has
    //    room) instead of clamping fixes this.
    // 2. Centering the tooltip body on the target and clamping THAT
    //    horizontally to stay on-screen (e.g. near the sidebar's right
    //    edge) shifts the whole body sideways — the arrow, drawn at a
    //    fixed 50% of the body, then points at a neighboring icon instead
    //    of the one actually hovered (the Labels panel's "Hide all
    //    labels" eye tooltip landing over the lock icon next to it). The
    //    arrow's own position is corrected below to track the target's
    //    real center independently of however far the body got clamped.
    const positionTooltip = (target, requestedPos) => {
        const targetRect = target.getBoundingClientRect();
        const elRect = tooltipEl.getBoundingClientRect();
        const margin = 8;  // min gap kept from the viewport edge
        const gap = 10;     // min gap kept between the target and the tooltip body

        let resolvedPos = requestedPos;
        const fitsAbove = targetRect.top - elRect.height - gap >= margin;
        const fitsBelow = targetRect.bottom + elRect.height + gap <= window.innerHeight - margin;
        if (requestedPos === 'bottom' && !fitsBelow && fitsAbove) resolvedPos = 'top';
        else if (requestedPos !== 'bottom' && !fitsAbove && fitsBelow) resolvedPos = 'bottom';

        const top = resolvedPos === 'bottom'
            ? targetRect.bottom + gap
            : targetRect.top - elRect.height - gap;
        tooltipEl.style.top = `${Math.max(margin, Math.min(top, window.innerHeight - elRect.height - margin))}px`;

        const targetCenterX = targetRect.left + targetRect.width / 2;
        const left = Math.max(margin, Math.min(targetCenterX - elRect.width / 2, window.innerWidth - elRect.width - margin));
        tooltipEl.style.left = `${left}px`;

        const arrowEl = tooltipEl.querySelector('.tooltip-arrow');
        if (arrowEl) {
            arrowEl.classList.remove('tooltip-arrow-top', 'tooltip-arrow-bottom');
            arrowEl.classList.add(resolvedPos === 'bottom' ? 'tooltip-arrow-bottom' : 'tooltip-arrow-top');
            // Arrow's own horizontal offset, in the tooltip's local
            // coordinate space, so its tip lands on `targetCenterX` even
            // though `left` above may have been clamped away from that.
            const arrowLeft = Math.max(10, Math.min(targetCenterX - left - 6, elRect.width - 22));
            arrowEl.style.left = `${arrowLeft}px`;
        }

        return resolvedPos;
    };

    const showTooltip = (target) => {
        const richTitle = target.getAttribute('data-tooltip-title');
        const text = target.getAttribute('data-tooltip');
        // "0"/"" placeholder tooltips (frame-skip rows before a real value is
        // set) and anything explicitly disabled shouldn't show a bubble.
        if ((!text && !richTitle) || target.classList.contains('pointer-events-none')) return;

        const pos = target.getAttribute('data-tooltip-pos') || 'top';
        const isWhite = target.getAttribute('data-tooltip-theme') === 'white';
        const shortcut = target.getAttribute('data-shortcut');

        const el = ensureTooltipEl();
        // Arrow's direction/offset class+style is set by positionTooltip()
        // once the resolved side (which may differ from `pos`) is known —
        // plain, undirected here so there's nothing wrong to briefly show.
        if (richTitle) {
            // Rich variant — bold state title + a constant instructional
            // line + a colored state pill (see the Labels panel's
            // must/cannot-overlap icon, the one place this is used so far)
            // instead of the plain single-line bubble every other
            // data-tooltip element gets.
            const desc = target.getAttribute('data-tooltip-desc') || '';
            const badge = target.getAttribute('data-tooltip-badge');
            const badgeVariant = target.getAttribute('data-tooltip-badge-variant') || 'none';
            el.className = 'custom-tooltip rich' + (isWhite ? ' theme-white' : '');
            el.innerHTML =
                `<div class="tooltip-rich-header">
                    <span class="tooltip-rich-title">${richTitle}</span>
                    ${badge ? `<span class="tooltip-rich-badge badge-${badgeVariant}">${badge}</span>` : ''}
                </div>` +
                (desc ? `<div class="tooltip-rich-desc">${desc}</div>` : '') +
                `<div class="tooltip-arrow"></div>`;
        } else {
            el.className = 'custom-tooltip' + (isWhite ? ' theme-white' : '');
            el.innerHTML = `<span>${text}</span>` +
                (shortcut ? `<span class="tooltip-shortcut">${shortcut}</span>` : '') +
                `<div class="tooltip-arrow"></div>`;
        }

        // Positioned (but not yet .visible, so it's still invisible per the
        // opacity:0 base rule) BEFORE measuring, so getBoundingClientRect()
        // below reflects this tooltip's real, current content/size rather
        // than whatever the previous target's text happened to measure.
        requestAnimationFrame(() => {
            if (currentTarget !== target) return; // pointer already moved on
            positionTooltip(target, pos);
            el.classList.add('visible');
        });
    };

    const hideTooltip = () => {
        if (tooltipEl) tooltipEl.classList.remove('visible');
        currentTarget = null;
    };

    // Matches either the plain `data-tooltip` text OR the rich variant's
    // `data-tooltip-title` (see showTooltip()) — the overlap icon sets only
    // the latter, so a selector limited to `[data-tooltip]` alone silently
    // never matched it and hovering it did nothing.
    const TOOLTIP_SELECTOR = '[data-tooltip], [data-tooltip-title]';

    document.addEventListener('mouseover', (e) => {
        const target = e.target.closest(TOOLTIP_SELECTOR);
        if (!target || target === currentTarget) return;
        currentTarget = target;
        showTooltip(target);
    });

    document.addEventListener('mouseout', (e) => {
        const target = e.target.closest(TOOLTIP_SELECTOR);
        if (!target || target !== currentTarget) return;
        // Moving onto a still-nested child of the same tooltip target
        // (e.g. its own SVG icon) isn't actually leaving it.
        if (e.relatedTarget && target.contains(e.relatedTarget)) return;
        hideTooltip();
    });

    // A stale tooltip left floating over content that just moved/scrolled
    // out from under its target reads as a rendering glitch — drop it
    // immediately rather than waiting for the next mouseover elsewhere.
    document.addEventListener('mousedown', hideTooltip);
    window.addEventListener('scroll', hideTooltip, true);
}

// Everything now lives inside a real <crowd-form> (see
// docs/FMN_TEMPLATE_PERSISTENCE_GUIDE.md Section 3) — pressing Enter in any
// of this template's many text/number/search inputs (size, rotate, search
// boxes, frame filters, ...) would otherwise trigger the browser's own
// implicit form submission, silently ending the task. Blurring the input
// also stops a held-down Enter from repeat-firing this.
//
// Deliberately scoped to only event.target.tagName === 'INPUT' — NOT a
// blanket "any Enter, anywhere" guard. Buttons (the toolbar, the Submit/
// Cancel/Yes buttons in the confirmation modals) rely on the browser's own
// default "Enter activates the focused button" behavior for keyboard
// users; preventDefault()-ing Enter globally regardless of target would
// silently break clicking them via keyboard, which is exactly the kind of
// keyboard-accessibility regression this template is trying to avoid
// elsewhere (see finishActiveDrawing()/#btnFinishAnnotation).
document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && event.target.tagName === 'INPUT') {
        event.preventDefault();
        event.target.blur();
    }
});

// Bootstrap
const initApp = () => {
    if (!window.Workspace) {
        window.Workspace = new WorkspaceManager();
        window.Workspace.init();
    }
    initGlobalTooltips();
};
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

// Belt-and-suspenders alongside syncHiddenInputSilently()'s continuous
// background sync (see updateLabelsPanel()) — regenerates and writes the
// current COCO JSON into #annotations-output right before ANY actual
// submission, whichever UI element triggered it: this template's own
// Submit button (submitAnnotations() already writes it too, but this
// covers it again for free), or — the actual point of this — the
// platform's own native "Save and Exit", which never calls into this
// template's JS at all. Ported from v2's setupCrowdForm(), the
// confirmed-working reference for this exact mechanism on this platform.
function setupCrowdForm() {
    const cf = document.querySelector('crowd-form');
    if (cf) {
        cf.onsubmit = function () {
            if (window.app && typeof window.app.syncHiddenInputSilently === 'function') {
                window.app.syncHiddenInputSilently();
            }
        };
    }
}
if (window.customElements && customElements.whenDefined) {
    customElements.whenDefined('crowd-form').then(setupCrowdForm).catch(setupCrowdForm);
} else {
    document.addEventListener('DOMContentLoaded', setupCrowdForm);
}

// Fallback restore path for the case window.FMN.existingAnnotation wasn't
// populated yet at captureRestoreData()'s first, very early synchronous
// check (WorkspaceManager.init() runs at DOMContentLoaded here, earlier
// than v2's equivalent check, which only happens once its own image has
// loaded — by which point FMN's restore bridge has reliably already run).
// See the FMN_TEMPLATE_PERSISTENCE_GUIDE.md's "Dynamic JS Templates"
// section for why this event exists at all. captureRestoreData()/
// loadExistingAnnotations() are both one-shot (_restoredOnce), so this is
// a no-op if the earlier synchronous check already found and restored
// the data.
window.addEventListener('fmn-annotation-restored', () => {
    if (window.app && typeof window.app.captureRestoreData === 'function') {
        window.app.captureRestoreData();
        window.app.loadExistingAnnotations();
    }
});

// Extra global functions referenced in HTML
//
// navigator.clipboard.writeText() silently rejects (no dialog, no thrown
// error visible to the user) in a lot of contexts this template can end up
// loaded in — file:// (no server, common for local testing), a sandboxed
// iframe without the clipboard-write permission (common for embedded
// labeling-platform templates like this one), or plain HTTP instead of
// HTTPS. The old code awaited nothing and had no .catch(), so a rejected
// promise just vanished — the button looked like it did nothing at all.
// Falls back to the older execCommand('copy') path (which works in more
// of those restricted contexts) and always shows the little "Copied"
// speech-bubble next to the button either way, since silence is what made
// this look broken — auto-hides itself after 1.5s.
window.copyVideoName = function () {
    const text = document.getElementById('videoNameDisplay')?.innerText;
    if (!text) return;

    const notify = (ok) => {
        const tip = document.getElementById('copyNameTooltip');
        const tipText = document.getElementById('copyNameTooltipText');
        const tipIcon = document.getElementById('copyNameTooltipIcon');
        if (!tip || !tipText) return;
        tipText.textContent = ok ? 'Copied' : 'Failed to copy';
        if (tipIcon) tipIcon.style.display = ok ? '' : 'none';
        tip.classList.remove('hidden');
        clearTimeout(window._copyNameTooltipTimer);
        window._copyNameTooltipTimer = setTimeout(() => tip.classList.add('hidden'), 1500);
    };

    const legacyCopy = () => {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
        document.body.removeChild(textarea);
        notify(ok);
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => notify(true)).catch(legacyCopy);
    } else {
        legacyCopy();
    }
};
window.closeAnnotationPanel = function () {
    document.getElementById('annotationOverlay')?.classList.add('hidden');
};
